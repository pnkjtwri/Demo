package com.ge.cashmap.mapper;

public class CashMapRule {
	private String fundsFlowID;
	private String subTransactionName;
	private String transactionName;
	
	/**
	 * @return the fundsFlowID
	 */
	public String getFundsFlowID() {
		return fundsFlowID;
	}
	/**
	 * @param fundsFlowID the fundsFlowID to set
	 */
	public void setFundsFlowID(String fundsFlowID) {
		this.fundsFlowID = fundsFlowID;
	}
	/**
	 * @return the subTransactionName
	 */
	public String getSubTransactionName() {
		return subTransactionName;
	}
	/**
	 * @param subTransactionName the subTransactionName to set
	 */
	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}
	/**
	 * @return the transactionName
	 */
	public String getTransactionName() {
		return transactionName;
	}
	/**
	 * @param transactionName the transactionName to set
	 */
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
}
