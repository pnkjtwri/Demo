package com.ge.cashmap.command;

import java.util.List;

import com.ge.cashmap.mapper.GECashMapRuleBean;

public class CashMapCommand {
	
	List<GECashMapRuleBean> geCashMapRuleBeanLst;
	private String fundsFlowID;
	private int lineNum;
    private double vertexX;
    private double vertexY;
    private String userSSO;
    
	
	/**
	 * @return the fundsFlowID
	 */
	public String getFundsFlowID() {
		return fundsFlowID;
	}
	/**
	 * @param fundsFlowID the fundsFlowID to set
	 */
	public void setFundsFlowID(String fundsFlowID) {
		this.fundsFlowID = fundsFlowID;
	}
	/**
	 * @return the lineNum
	 */
	public int getLineNum() {
		return lineNum;
	}
	/**
	 * @param lineNum the lineNum to set
	 */
	public void setLineNum(int lineNum) {
		this.lineNum = lineNum;
	}
	/**
	 * @return the vertexX
	 */
	public double getVertexX() {
		return vertexX;
	}
	/**
	 * @param vertexX the vertexX to set
	 */
	public void setVertexX(double vertexX) {
		this.vertexX = vertexX;
	}
	/**
	 * @return the vertexY
	 */
	public double getVertexY() {
		return vertexY;
	}
	/**
	 * @param vertexY the vertexY to set
	 */
	public void setVertexY(double vertexY) {
		this.vertexY = vertexY;
	}
	/**
	 * @return the userSSO
	 */
	public String getUserSSO() {
		return userSSO;
	}
	/**
	 * @param userSSO the userSSO to set
	 */
	public void setUserSSO(String userSSO) {
		this.userSSO = userSSO;
	}
	/**
	 * @return the geCashMapRuleBeanLst
	 */
	public List<GECashMapRuleBean> getGeCashMapRuleBeanLst() {
		return geCashMapRuleBeanLst;
	}
	/**
	 * @param geCashMapRuleBeanLst the geCashMapRuleBeanLst to set
	 */
	public void setGeCashMapRuleBeanLst(
			List<GECashMapRuleBean> geCashMapRuleBeanLst) {
		this.geCashMapRuleBeanLst = geCashMapRuleBeanLst;
	}
}
