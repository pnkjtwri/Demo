package com.ge.cashmap.service;

public interface CheckUserService {
	
	public boolean checkUserSSO(String userSSO);
	
	public boolean checkICFGroupUser(String userSSO);

	public boolean checkCashGroupUser(String userSSO);
}
