package com.ge.cashmap.security;

public class CustomAuthenticationEntryPoint {

}
