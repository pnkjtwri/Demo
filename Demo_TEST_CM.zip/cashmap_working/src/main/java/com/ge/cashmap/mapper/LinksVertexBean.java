package com.ge.cashmap.mapper;

public class LinksVertexBean {
	private String fundsFlowID = "";
	private String orientation = "";
	private int lineNum;
    private double vertexX;
    private double vertexY;
    
	/**
	 * @return the fundsFlowID
	 */
	public String getFundsFlowID() {
		return fundsFlowID;
	}
	/**
	 * @param fundsFlowID the fundsFlowID to set
	 */
	public void setFundsFlowID(String fundsFlowID) {
		this.fundsFlowID = fundsFlowID;
	}
	/**
	 * @return the lineNum
	 */
	public int getLineNum() {
		return lineNum;
	}
	/**
	 * @param lineNum the lineNum to set
	 */
	public void setLineNum(int lineNum) {
		this.lineNum = lineNum;
	}
	/**
	 * @return the vertexX
	 */
	public double getVertexX() {
		return vertexX;
	}
	/**
	 * @param vertexX the vertexX to set
	 */
	public void setVertexX(double vertexX) {
		this.vertexX = vertexX;
	}
	/**
	 * @return the vertexY
	 */
	public double getVertexY() {
		return vertexY;
	}
	/**
	 * @param vertexY the vertexY to set
	 */
	public void setVertexY(double vertexY) {
		this.vertexY = vertexY;
	}
	/**
	 * @return the orientation
	 */
	public String getOrientation() {
		return orientation;
	}
	/**
	 * @param orientation the orientation to set
	 */
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
}
