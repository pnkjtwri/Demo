package com.ge.cashmap.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.cashmap.command.CashMapCommand;
import com.ge.cashmap.mapper.CashMapRule;
import com.ge.cashmap.service.CashMapFundFlowServie;
import com.ge.cashmap.service.CheckUserService;
import com.ge.cashmap.service.GraphStructureService;

@Controller
public class CashMapController {
	private static Logger log   = Logger.getLogger(CashMapController.class);
	private String loggedInUser;
	
	@Autowired
	CashMapFundFlowServie cashMapFundFlow;
	
	@Autowired
	GraphStructureService graphStructure;
	
	@Autowired
	CheckUserService checkUser;

	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/", method={RequestMethod.GET})
	public ModelAndView cashMapView(HttpServletRequest request, CashMapCommand cashMapCommand)  {
		log.info("CashMapController - Start Cash Map Page");
		
		loggedInUser = request.getHeader("georaclehrid");
		loggedInUser = "999999001";
		
		Map<Object,Object> model = new HashMap<Object,Object>();
		ModelAndView mvcCash     = null;
		
		if(checkUser.checkUserSSO(loggedInUser)){
			
			//check for USer Group
			log.info("CashMapController - Going to Check logged-in user group");
			String userGroup = checkUserGroup(loggedInUser);

			List<CashMapRule> cashMapRuleList = null;
			if(userGroup == null || userGroup.trim().equals("")){
				cashMapRuleList = new ArrayList<CashMapRule>();
			}else{
				cashMapRuleList = cashMapFundFlow.getCashMapFundsFlow(userGroup);
			}
			
			List<String> cashMapRuleListString = null;
			if(cashMapRuleList != null && cashMapRuleList.size() > 0){
				cashMapRuleListString = new ArrayList<String>();
				
				for(Iterator<CashMapRule> cashMapBean = cashMapRuleList.iterator(); cashMapBean.hasNext(); ) {
					CashMapRule item = cashMapBean.next();
					cashMapRuleListString.add((item.getTransactionName()+"-"+item.getTransactionName()+"-"+item.getFundsFlowID()));
				}
			}
			
			model.put("cashMapRuleList", cashMapRuleList);
			model.put("loggedInUser", loggedInUser);
			if(cashMapRuleListString != null && cashMapRuleListString.size() > 0){
				model.put("cashMapRuleSearchList", cashMapRuleListString);
			}
			mvcCash = new ModelAndView("cashMapView");
		}else{
			mvcCash = new ModelAndView("errorPageView");
		}
		log.info("CashMapController - End of Cash Map View");
		
		mvcCash.addObject("cashMapBean", model);
		return mvcCash;
	}
	
	/**
	 * Method used for checking logged-in user related to which group
	 * @param loggedInUser
	 * @return
	 */
	private String checkUserGroup(String loggedInUser){
		String userGroup= "";
		boolean icfUserGroup = checkUser.checkICFGroupUser(loggedInUser);
		boolean cashUserGroup = checkUser.checkCashGroupUser(loggedInUser); 
		if(icfUserGroup && cashUserGroup){
			log.info("CashMapController - logged-in user is related to both ICF and Cash group");
			return "ALL";	
		}else if(icfUserGroup){
			log.info("CashMapController - logged-in user is related to ICF group");
			return "ICF";
		}else if(cashUserGroup){
			log.info("CashMapController - logged-in user is related to Cash group");
			return "CASH";
		}
		
		return userGroup;
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/logout", method={RequestMethod.GET})
	public void cashMapLogout(HttpServletRequest request, CashMapCommand cashMapCommand, 
			HttpServletResponse response) throws Exception {
		log.info("CashMapController - Start logout");
		log.info("CashMapController - End logout");
		request.getSession().invalidate();
		response.sendRedirect("https://ssologin.stage.corporate.ge.com/logoff/logoff.jsp?");
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/getGraph", method={RequestMethod.POST})
	@ResponseBody
	public String generateGraph(@RequestParam(value = "flowIdName") String flowIdName)  {
		log.info("CashMapController - Start Ajax Call generateGraph");
		JSONObject cashMapJsonData = graphStructure.getGraphStructure(flowIdName, false);
		log.info("CashMapController - End Ajax Call generateGraph");
	    return cashMapJsonData.toString();
	    
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/saveComments", method={RequestMethod.POST})
	@ResponseBody
	public String saveComments(
								@RequestParam(value = "flowIdName") String flowIdName,
								@RequestParam(value = "nodeId") String nodeId,
								@RequestParam(value = "commentData") String commentData,
								@RequestParam(value = "lineNo") String lineNo,
								@RequestParam(value = "commentType") String commentType,
								@RequestParam(value = "loggedInSSO") String loggedInSSO
							  ){
		log.info("CashMapController - Start Ajax Call saveComments");
		JSONObject cashMapJsonData = null;
		boolean isDataSaved        = false;
		
		if(commentType != null && "NODE".equalsIgnoreCase(commentType)){
			isDataSaved = cashMapFundFlow.saveComments(flowIdName, nodeId, commentData, lineNo, commentType, loggedInSSO);
		}
		else if(commentType != null && "LINK".equalsIgnoreCase(commentType)){
			isDataSaved = cashMapFundFlow.saveComments(flowIdName, null, commentData, lineNo, commentType, loggedInSSO);
		}
		
		if(isDataSaved){
			cashMapJsonData = graphStructure.getGraphStructure(flowIdName, false);
		}
		log.info("CashMapController - End Ajax Call saveComments");
	    return cashMapJsonData.toString();
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/getLinkComments", method={RequestMethod.POST})
	@ResponseBody
	public String getLinkComments(
								@RequestParam(value = "flowIdName") String flowIdName,
								@RequestParam(value = "lineNo") String lineNo
							  ){
		log.info("CashMapController - Start Ajax Call getLinkComments");
		String linkCommentData = cashMapFundFlow.getLinkCommentData(flowIdName, lineNo, "LINK");
		log.info("CashMapController - End Ajax Call getLinkComments");
	    return linkCommentData;
	}
	
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/saveSignatures", method={RequestMethod.POST})
	@ResponseBody
	public String saveSignatures( @RequestParam(value = "flowIdName") String flowIdName,
								  @RequestParam(value = "formdata") String formdata){
		log.info("CashMapController - Start Ajax Call saveSignatures");
		String[] str	=	formdata.toString().split("&");
		int savedValue = cashMapFundFlow.saveSignature(flowIdName, str);
		log.info("CashMapController - End Ajax Call saveSignatures");
	    return savedValue+"";
	}
	
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/getSignaturesCount", method={RequestMethod.POST})
	@ResponseBody
	public String signatureCount(@RequestParam(value = "flowIdName") String flowIdName){
		log.info("CashMapController - Start Ajax Call Signature Count");
		int signatureCount = cashMapFundFlow.getSignaturesCount(flowIdName);
		log.info("CashMapController - End Ajax Call Signature Count");
	    return signatureCount+"";
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/getSignatures", method={RequestMethod.POST})
	@ResponseBody
	public String getSignatures( @RequestParam(value = "flowIdName") String flowIdName){
		log.info("CashMapController - Start Ajax Call getSignatures");
		String returnValue = cashMapFundFlow.getSignatures(flowIdName);
		log.info("CashMapController - End Ajax Call getSignatures");
	    return returnValue;
	}
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/deleteSign", method={RequestMethod.POST})
	@ResponseBody
	public String deleteSign( @RequestParam(value = "flowIdName") String flowIdName,
			                  @RequestParam(value = "signPk") String signPk
			                ){
		log.info("CashMapController - Start Ajax Call deleteSign");
		String message = "";
		boolean isDeleted = cashMapFundFlow.deleteSign(signPk);
		
		if(isDeleted){
			message = "Record deleted successfully";
		}else{
			message = "Couldn't delete the record";
		}
		log.info("CashMapController - End Ajax Call deleteSign");
	    return message;
	}
	
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/updateSign", method={RequestMethod.POST})
	@ResponseBody
	public String updateSign( @RequestParam(value = "flowIdName") String flowIdName,
			                  @RequestParam(value = "Name") String Name,
			                  @RequestParam(value = "DepName") String DepName,
			                  @RequestParam(value = "signPk") String signPk
			                ){
		log.info("CashMapController - Start Ajax Call updateSign");
		String message = "";
		boolean isUpdated = cashMapFundFlow.updateSign(Name, DepName, signPk);
		
		if(isUpdated){
			message = "1";
		}else{
			message = "0";
		}
		log.info("CashMapController - End Ajax Call updateSign");
	    return message;
	}
	
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/saveFlowIDComment", method={RequestMethod.POST})
	@ResponseBody
	public String saveFlowIDComment( @RequestParam(value = "flowIdName") String flowIdName,
			                  @RequestParam(value = "commentData") String commentData,
			                  @RequestParam(value = "loggedInSSO") String loggedInSSO
			                ){
		log.info("CashMapController - Start Ajax Call saveFlowIDComment");
		
		int returnValue = cashMapFundFlow.saveFlowIDCommentsInDB(flowIdName, commentData, loggedInSSO);
		
		log.info("CashMapController - End Ajax Call saveFlowIDComment");
	    return (returnValue > 0 ? "1" : "2");
	}
	
	
	/**
	 * 
	 * 
	 **/
	@RequestMapping(value="/saveCoordinates", method={RequestMethod.POST})
	@ResponseBody
	public String saveCoordinates( @RequestParam(value = "saveCoordinatesJson") String saveCoordinatesJson,
			                       @RequestParam(value = "flowIdName") String flowIdName
			                     ){
		log.info("CashMapController - Start Ajax Call saveCoordinates");
		
		boolean returnValue = cashMapFundFlow.saveCoordinates(flowIdName, saveCoordinatesJson);
		
		log.info("CashMapController - End Ajax Call saveCoordinates");
	    return (returnValue == true ? "1" : "2");
	}
	
}
