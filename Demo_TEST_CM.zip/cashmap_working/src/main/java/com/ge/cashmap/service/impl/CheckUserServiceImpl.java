package com.ge.cashmap.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.ge.cashmap.dao.UserDao;
import com.ge.cashmap.service.CheckUserService;

public class CheckUserServiceImpl implements CheckUserService {

	@Autowired
	UserDao userDao;
	
	public boolean checkUserSSO(String userSSO) {
		int returnValue = userDao.validateUserSso(userSSO);
		return (returnValue > 0 ? true : false) ;
	}
	
	public boolean checkICFGroupUser(String userSSO){
		int returnValue = userDao.checkICFGroupUser(userSSO);
		return (returnValue > 0 ? true : false) ;
	}
	
	public boolean checkCashGroupUser(String userSSO){
		int returnValue = userDao.checkCashGroupUser(userSSO);
		return (returnValue > 0 ? true : false) ;
	}

}
