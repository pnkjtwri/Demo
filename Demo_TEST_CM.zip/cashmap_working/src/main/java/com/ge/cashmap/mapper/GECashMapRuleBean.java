package com.ge.cashmap.mapper;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

public class GECashMapRuleBean {
	private Integer rulePk;
	private String valueDay="";
	private String subTransactionName = "";
	private String fundsFlowID = "";
	private String referenceID = "";
	private String stepNum = "";
	private String type= "";
	private String tcode= "";
	private String legalENtityName = "";
	private String legalEntityCDRCode = "";
	private String legalEntityGoldID= "";
	private String me = "";
	private String bankName= "";
	private String branch= "";
	private String swiftCode= "";
	private String accountNum= "";
	private String amount = "" ;
	private String currency = "";
	private String amountInDollar = "";
	private String cashPoolIndicator ="";
	private String liquidityTag="";
	private String bankCountry="";
	private Date lastUpdatedDate;
	private String userSSO = "";
	private String user ="";
	private String comments = "";
	private String auditUserSSO = "";
	private Date auditUserTimestamp;
	
	private String transactionName = "";
	private String payable= "";
	private String receivable= "";
	private String flowLabel="";
	private String stepNoString= "Step Num:";
	private int lineNum;
	private String name;
	private String depName;
	private String geCashMapSignPk;
	private Double interestExpense;
	
	/**
	 * @return the rulePk
	 */
	public Integer getRulePk() {
		return rulePk;
	}
	/**
	 * @param rulePk the rulePk to set
	 */
	public void setRulePk(Integer rulePk) {
		this.rulePk = rulePk;
	}
	/**
	 * @return the valueDay
	 */
	public String getValueDay() {
		if(valueDay != null && !valueDay.equals(""))
			return valueDay.substring(0, 10);
		else
			return valueDay;
	}
	/**
	 * @param valueDay the valueDay to set
	 */
	public void setValueDay(String valueDay) {
		this.valueDay = valueDay;
	}
	/**
	 * @return the subTransactionName
	 */
	public String getSubTransactionName() {
		return subTransactionName;
	}
	/**
	 * @param subTransactionName the subTransactionName to set
	 */
	public void setSubTransactionName(String subTransactionName) {
		this.subTransactionName = subTransactionName;
	}
	/**
	 * @return the fundsFlowID
	 */
	public String getFundsFlowID() {
		return fundsFlowID;
	}
	/**
	 * @param fundsFlowID the fundsFlowID to set
	 */
	public void setFundsFlowID(String fundsFlowID) {
		this.fundsFlowID = fundsFlowID;
	}
	/**
	 * @return the referenceID
	 */
	public String getReferenceID() {
		return referenceID;
	}
	/**
	 * @param referenceID the referenceID to set
	 */
	public void setReferenceID(String referenceID) {
		this.referenceID = referenceID;
	}
	/**
	 * @return the stepNum
	 */
	public String getStepNum() {
		return stepNum;
	}
	/**
	 * @param stepNum the stepNum to set
	 */
	public void setStepNum(String stepNum) {
		this.stepNum = stepNum;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the tcode
	 */
	public String getTcode() {
		return tcode;
	}
	/**
	 * @param tcode the tcode to set
	 */
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	/**
	 * @return the legalENtityName
	 */
	public String getLegalENtityName() {
		return legalENtityName.toUpperCase();
	}
	/**
	 * @param legalENtityName the legalENtityName to set
	 */
	public void setLegalENtityName(String legalENtityName) {
		this.legalENtityName = legalENtityName;
	}
	/**
	 * @return the legalEntityCDRCode
	 */
	public String getLegalEntityCDRCode() {
		if(legalEntityCDRCode != "")
			return "MLE: "+legalEntityCDRCode;
		else
			return this.legalEntityCDRCode;
	}
	/**
	 * @param legalEntityCDRCode the legalEntityCDRCode to set
	 */
	public void setLegalEntityCDRCode(String legalEntityCDRCode) {
		this.legalEntityCDRCode = legalEntityCDRCode;
	}
	/**
	 * @return the legalEntityGoldID
	 */
	public String getLegalEntityGoldID() {
		if(legalEntityGoldID != "")
			return "Gold ID: " + legalEntityGoldID;
		else
			return this.legalEntityGoldID;
	}
	/**
	 * @param legalEntityGoldID the legalEntityGoldID to set
	 */
	public void setLegalEntityGoldID(String legalEntityGoldID) {
		this.legalEntityGoldID = legalEntityGoldID;
	}
	/**
	 * @return the me
	 */
	public String getMe() {
		if(me != "")
			return "ME: "+me;
		else
			return this.me;
	}
	/**
	 * @param me the me to set
	 */
	public void setMe(String me) {
		this.me = me;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		if(bankName != "")
			return "Bank: "+bankName;
		else
			return this.bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		if(branch != "")
			return "Branch: "+branch;
		else
			return this.branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the swiftCode
	 */
	public String getSwiftCode() {
		if(swiftCode != "")
			return "Swift Code: "+swiftCode;
		else
			return this.swiftCode;
	}
	/**
	 * @param swiftCode the swiftCode to set
	 */
	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}
	/**
	 * @return the accountNum
	 */
	public String getAccountNum() {
		if(accountNum != "")
			return "Account #: "+accountNum;
		else
			return this.accountNum;
	}
	/**
	 * @param accountNum the accountNum to set
	 */
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	/**
	 * @return the amount
	 */
	public String getAmount() {
		/*if(amount != null && !amount.equals("")){
			BigDecimal doubleAmt = new BigDecimal(amount);
			Double roundOff = Math.round(doubleAmt.doubleValue() * 100.0) / 100.0;
			return NumberFormat.getNumberInstance(Locale.US).format(Double.parseDouble(roundOff.toString()));
		}*/
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the amountInDollar
	 */
	public String getAmountInDollar() {
		if(amountInDollar != null && !amountInDollar.equals("")){
			Double doubleAmt = Double.parseDouble(amountInDollar);
			Double roundOff = Math.round(doubleAmt * 100.0) / 100.0;
			return NumberFormat.getNumberInstance(Locale.US).format(Double.parseDouble(roundOff.toString()));
		}
		
		return amountInDollar;
	}
	/**
	 * @param amountInDollar the amountInDollar to set
	 */
	public void setAmountInDollar(String amountInDollar) {
		this.amountInDollar = amountInDollar;
	}
	/**
	 * @return the cashPoolIndicator
	 */
	public String getCashPoolIndicator() {
		if(cashPoolIndicator != "")
			return "CashPoolIndicator: "+cashPoolIndicator.toUpperCase();
		else
			return this.cashPoolIndicator.toUpperCase();
	}
	/**
	 * @param cashPoolIndicator the cashPoolIndicator to set
	 */
	public void setCashPoolIndicator(String cashPoolIndicator) {
		this.cashPoolIndicator = cashPoolIndicator;
	}
	/**
	 * @return the liquidityTag
	 */
	public String getLiquidityTag() {
		return liquidityTag;
	}
	/**
	 * @param liquidityTag the liquidityTag to set
	 */
	public void setLiquidityTag(String liquidityTag) {
		this.liquidityTag = liquidityTag;
	}
	/**
	 * @return the bankCountry
	 */
	public String getBankCountry() {
		return bankCountry;
	}
	/**
	 * @param bankCountry the bankCountry to set
	 */
	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}
	/**
	 * @return the lastUpdatedDate
	 */
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	/**
	 * @return the userSSO
	 */
	public String getUserSSO() {
		return userSSO;
	}
	/**
	 * @param userSSO the userSSO to set
	 */
	public void setUserSSO(String userSSO) {
		this.userSSO = userSSO;
	}
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the auditUserSSO
	 */
	public String getAuditUserSSO() {
		return auditUserSSO;
	}
	/**
	 * @param auditUserSSO the auditUserSSO to set
	 */
	public void setAuditUserSSO(String auditUserSSO) {
		this.auditUserSSO = auditUserSSO;
	}
	/**
	 * @return the auditUserTimestamp
	 */
	public Date getAuditUserTimestamp() {
		return auditUserTimestamp;
	}
	/**
	 * @param auditUserTimestamp the auditUserTimestamp to set
	 */
	public void setAuditUserTimestamp(Date auditUserTimestamp) {
		this.auditUserTimestamp = auditUserTimestamp;
	}
	/**
	 * @return the transactionName
	 */
	public String getTransactionName() {
		return transactionName;
	}
	/**
	 * @param transactionName the transactionName to set
	 */
	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}
	/**
	 * @return the payable
	 */
	public String getPayable() {
		return payable;
	}
	/**
	 * @param payable the payable to set
	 */
	public void setPayable(String payable) {
		this.payable = payable;
	}
	/**
	 * @return the receivable
	 */
	public String getReceivable() {
		return receivable;
	}
	/**
	 * @param receivable the receivable to set
	 */
	public void setReceivable(String receivable) {
		this.receivable = receivable;
	}
	/**
	 * @return the flowLabel
	 */
	public String getFlowLabel() {
		return flowLabel;
	}
	/**
	 * @param flowLabel the flowLabel to set
	 */
	public void setFlowLabel(String flowLabel) {
		this.flowLabel = flowLabel;
	}
	/**
	 * @return the stepNoString
	 */
	public String getStepNoString() {
		return stepNoString;
	}
	/**
	 * @param stepNoString the stepNoString to set
	 */
	public void setStepNoString(String stepNoString) {
		this.stepNoString = stepNoString;
	}
	/**
	 * @return the lineNum
	 */
	public int getLineNum() {
		return lineNum;
	}
	/**
	 * @param lineNum the lineNum to set
	 */
	public void setLineNum(int lineNum) {
		this.lineNum = lineNum;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		if(name!=null)
			return name;
		else
			return "";
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the depName
	 */
	public String getDepName() {
		if(depName != null)
			return depName;
		else
			return "";
	}
	/**
	 * @param depName the depName to set
	 */
	public void setDepName(String depName) {
		this.depName = depName;
	}
	/**
	 * @return the geCashMapSignPk
	 */
	public String getGeCashMapSignPk() {
		return geCashMapSignPk;
	}
	/**
	 * @param geCashMapSignPk the geCashMapSignPk to set
	 */
	public void setGeCashMapSignPk(String geCashMapSignPk) {
		this.geCashMapSignPk = geCashMapSignPk;
	}
	
	public Double getInterestExpense() {
		return interestExpense;
	}
	public void setInterestExpense(Double interestExpense) {
		this.interestExpense = interestExpense;
	}
	
	
}
