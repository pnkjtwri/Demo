package com.ge.cashmap.service;

import org.json.JSONObject;

public interface GraphStructureService {
	JSONObject getGraphStructure(String fundFlowId, boolean dataSaved);
	/*JSONObject createNodeCoordinatesJsonObject(List<ElementCoordinatesBean> elementCoordinatesDataList, JSONObject elementCoordinatesJsonData);
	JSONObject createLinkVertexJsonObject(List<LinksVertexBean> linkVerticesDataList,JSONObject linkVertexJsonData);
	JSONObject createjsonNodeObject(List<GECashMapRuleBean> cashMapRuleUnionDataList, JSONObject cashMapRuleJsonData); 
	JSONObject createjsonLinkObject(List<GECashMapRuleBean> cashMapRuleDataList, JSONObject cashMapRuleJsonData) ;
	JSONObject createjsonLastUpdateObject(String lastUpdateDtString,JSONObject cashMapJsonData);
	JSONObject createjsonDataSavedObject(String savedDataString,JSONObject cashMapJsonData);
	JSONObject createjsonFundsFlowLabelObject(String fundFlowLabel, JSONObject cashMapRuleJsonData); 
	JSONObject getCommetsByFlowIDAndJSONData(String flowID, JSONObject cashMapJsonData);*/
}