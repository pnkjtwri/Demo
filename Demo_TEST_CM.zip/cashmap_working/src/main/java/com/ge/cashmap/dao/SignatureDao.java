package com.ge.cashmap.dao;

import java.util.List;

import com.ge.cashmap.mapper.GECashMapRuleBean;

public interface SignatureDao {
	public int saveSignature(GECashMapRuleBean geCashMapRuleParam);
	public List<GECashMapRuleBean> getSignatures(String fundFlowId);
	public int getSignatureCount(String fundFlowId);
	public int deleteSign(String signPk);
	public int updateSign(GECashMapRuleBean geCashMapRuleParam);
}
