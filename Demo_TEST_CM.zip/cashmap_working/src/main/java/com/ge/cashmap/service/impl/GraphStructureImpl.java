package com.ge.cashmap.service.impl;

import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ge.cashmap.dao.CommentsDao;
import com.ge.cashmap.dao.CoordinatesDao;
import com.ge.cashmap.dao.GeCashMapFundsFlowDao;
import com.ge.cashmap.mapper.ElementCoordinatesBean;
import com.ge.cashmap.mapper.GECashMapRuleBean;
import com.ge.cashmap.mapper.LinksVertexBean;
import com.ge.cashmap.service.GraphStructureService;
import com.ge.cashmap.utility.CashMapUtility;

public class GraphStructureImpl implements GraphStructureService {
	
	@Autowired
	GeCashMapFundsFlowDao geCashMapFundsFlow;
	
	@Autowired
	CoordinatesDao coordinatesDao;
	
	@Autowired
	CommentsDao commentsDao;

	@Transactional
	public JSONObject getGraphStructure(String fundFlowId, boolean dataSaved) {
		List<GECashMapRuleBean> cashMapRuleUnionDataList = geCashMapFundsFlow.getGECashMapRuleUnionData(fundFlowId);
		List<GECashMapRuleBean> cashMapRuleDataList      = geCashMapFundsFlow.getGECashMapRuleData(fundFlowId);
		String lastUpdateDtStr                           = geCashMapFundsFlow.getGECashMapLastUpdateData(fundFlowId);
		
		//create json object
		JSONObject cashMapJsonData  =new JSONObject();
		
		createjsonNodeObject(cashMapRuleUnionDataList, cashMapJsonData);
		createjsonLinkObject(cashMapRuleDataList, cashMapJsonData);
		createjsonLastUpdateObject(lastUpdateDtStr, cashMapJsonData);
		getCommetsByFlowIDAndJSONData(fundFlowId, cashMapJsonData);

		//if I am coming in this method after saving the comments; 
		//then will create a json for showing the data saved successfully...
		if(dataSaved){
			createjsonDataSavedObject("1", cashMapJsonData);
		}
		
		/*if(coordinatesDao.getNodeCordinatesByFlowID(fundFlowId) > 0 )*/{   
			List<ElementCoordinatesBean> elementCoordinatesDataList = coordinatesDao.getElementCoordinatesData(fundFlowId);
			List<LinksVertexBean> linkVerticesDataList              = coordinatesDao.getLinkVerticesData(fundFlowId);
			
			createNodeCoordinatesJsonObject(elementCoordinatesDataList, cashMapJsonData);
			createLinkVertexJsonObject(linkVerticesDataList, cashMapJsonData);
		}
		
		String flowLabelValue = cashMapRuleUnionDataList.get(0).getFlowLabel();
		createjsonFundsFlowLabelObject(flowLabelValue, cashMapJsonData);
		
		return cashMapJsonData;
	}

	private JSONObject createNodeCoordinatesJsonObject(List<ElementCoordinatesBean> elementCoordinatesDataList,	JSONObject elementCoordinatesJsonData) {
		Iterator<ElementCoordinatesBean> elementCoordinatesDataListItr =  elementCoordinatesDataList.iterator();
		try {
		JSONArray jsonArray = new JSONArray();
			while (elementCoordinatesDataListItr.hasNext()) {
				ElementCoordinatesBean nodeCoordinateBean = elementCoordinatesDataListItr
						.next();
				JSONObject cashMapRuleJsonObj = new JSONObject();
				cashMapRuleJsonObj.put("elementFlowID", nodeCoordinateBean.getFundsFlowID());
				cashMapRuleJsonObj.put("elementTCode", nodeCoordinateBean.getTcode());
				cashMapRuleJsonObj.put("elementCenterX", nodeCoordinateBean.getCenterX());
				cashMapRuleJsonObj.put("elementCenterY", nodeCoordinateBean.getCenterY());
				cashMapRuleJsonObj.put("orientation", nodeCoordinateBean.getOrientation());
				jsonArray.put(cashMapRuleJsonObj);
			}
			elementCoordinatesJsonData.put("elementCoordinates", jsonArray);
		} catch (JSONException e) {
			throw new RuntimeException();
		}
		return elementCoordinatesJsonData;
		
	
	}

	private JSONObject createLinkVertexJsonObject(List<LinksVertexBean> linkVerticesDataList, JSONObject linkVertexJsonData) {
		Iterator<LinksVertexBean> linkVerticesDataListItr =  linkVerticesDataList.iterator();
		try {
		JSONArray jsonArray = new JSONArray();
			while (linkVerticesDataListItr.hasNext()) {
				LinksVertexBean nodeCoordinateBean = linkVerticesDataListItr.next();
				JSONObject cashMapRuleJsonObj = new JSONObject();
				cashMapRuleJsonObj.put("linkFlowID", nodeCoordinateBean.getFundsFlowID());
				cashMapRuleJsonObj.put("linkLineNo", nodeCoordinateBean.getLineNum());
				cashMapRuleJsonObj.put("linkVertexX", nodeCoordinateBean.getVertexX());
				cashMapRuleJsonObj.put("linkVertexY", nodeCoordinateBean.getVertexY());
				cashMapRuleJsonObj.put("orientation", nodeCoordinateBean.getOrientation());
				jsonArray.put(cashMapRuleJsonObj);
			}
			linkVertexJsonData.put("linkVertex", jsonArray);
		} catch (JSONException e) {
			throw new RuntimeException();
		}
		return linkVertexJsonData;
	}

	private JSONObject createjsonNodeObject(List<GECashMapRuleBean> cashMapRuleUnionDataList, JSONObject cashMapRuleJsonData) {
		Iterator<GECashMapRuleBean> cashMapRuleDataListItr =  cashMapRuleUnionDataList.iterator();
		
		try {
			int width = 0;
			int height= 0;
			
			JSONArray jsonArray = new JSONArray();
			
			while (cashMapRuleDataListItr.hasNext()) {
				GECashMapRuleBean emswiftConfig = cashMapRuleDataListItr.next();
				JSONObject cashMapRuleJsonObj   = new JSONObject();
				//max size of boxes
				int maxSizeallowed = 36;
				//Split LE NAME to fit properly in box
				StringBuffer nameAttrSb = new StringBuffer();
				//create Line1
				if(emswiftConfig.getLegalENtityName() !=""){
						List<String> leNameFormatted = 	CashMapUtility.splitEqually(emswiftConfig.getLegalENtityName(), maxSizeallowed);
						Iterator<String> leNameFormattedIterator = leNameFormatted.iterator();
						while(leNameFormattedIterator.hasNext()){
							nameAttrSb.append(leNameFormattedIterator.next()+"\r\n");
						}	
					}
				//create Line 2
				if(emswiftConfig.getLegalEntityCDRCode()!=null || emswiftConfig.getMe()!=null || emswiftConfig.getLegalEntityGoldID()!=null)
				{
					StringBuffer line2Buffer = new StringBuffer();
					if(emswiftConfig.getLegalEntityCDRCode() != "")
						line2Buffer.append(emswiftConfig.getLegalEntityCDRCode());
					if(emswiftConfig.getMe() != "")
						line2Buffer.append("/"+emswiftConfig.getMe());
					if(emswiftConfig.getLegalEntityGoldID() != "")
						line2Buffer.append("/"+emswiftConfig.getLegalEntityGoldID());
					if(line2Buffer.toString().length() != 0){
						List<String> line2Formatted = 	CashMapUtility.splitEqually(line2Buffer.toString(), maxSizeallowed);
						Iterator<String> leNameFormattedIterator = line2Formatted.iterator();
						while(leNameFormattedIterator.hasNext()){
							nameAttrSb.append(leNameFormattedIterator.next()+"\r\n");
						}
					}
						
				}
				//create Line 3
				if(emswiftConfig.getBankName() != ""){
					List<String> line3Formatted = 	CashMapUtility.splitEqually(emswiftConfig.getBankName(), maxSizeallowed);
					Iterator<String> line3Formattor = line3Formatted.iterator();
					while(line3Formattor.hasNext()){
						nameAttrSb.append(line3Formattor.next()+"\r\n");
					}
				}
				//create Line 4
				if(emswiftConfig.getSwiftCode() != ""){
					List<String> line4Formatted = 	CashMapUtility.splitEqually(emswiftConfig.getSwiftCode(), maxSizeallowed);
					Iterator<String> line4Formattor = line4Formatted.iterator();
					while(line4Formattor.hasNext()){
						nameAttrSb.append(line4Formattor.next()+"\r\n");
					}
				}
				//create Line5
				if(emswiftConfig.getAccountNum() != ""){
					List<String> line5Formatted = 	CashMapUtility.splitEqually(emswiftConfig.getAccountNum(), maxSizeallowed);
					Iterator<String> line5Formattor = line5Formatted.iterator();
					while(line5Formattor.hasNext()){
						nameAttrSb.append(line5Formattor.next()+"\r\n");
					}
				}
				//create Line 6
				if(emswiftConfig.getTcode() != "" || emswiftConfig.getCurrency()!=null){
					StringBuffer line6Sb = new StringBuffer();
					if(emswiftConfig.getTcode() != "")
						line6Sb.append("TC: "+emswiftConfig.getTcode());	
					if(emswiftConfig.getCurrency() != "")
						line6Sb.append("/"+emswiftConfig.getCurrency());	
					List<String> line6Formatted = 	CashMapUtility.splitEqually(line6Sb.toString(), maxSizeallowed);
					Iterator<String> line6Formattor = line6Formatted.iterator();
					while(line6Formattor.hasNext()){
						nameAttrSb.append(line6Formattor.next()+"\r\n");
					}
				}

				//create Line 7
				//create Line5
				if(emswiftConfig.getCashPoolIndicator() != ""){
					List<String> line7Formatted = 	CashMapUtility.splitEqually(emswiftConfig.getCashPoolIndicator(), maxSizeallowed);
					Iterator<String> line7Formattor = line7Formatted.iterator();
					while(line7Formattor.hasNext()){
						nameAttrSb.append(line7Formattor.next()+"\r\n");
					}
				}
				
				//create Line 8
				//create Line6
				if(emswiftConfig.getComments() != ""){
					List<String> line7Formatted = 	CashMapUtility.splitEqually("Comments:"+emswiftConfig.getComments(), maxSizeallowed);
					nameAttrSb.append("\r\n(");
					for (int i = 0; i < line7Formatted.size(); i++) {
						if(i == (line7Formatted.size()-1)){
							nameAttrSb.append(line7Formatted.get(i)+")\r\n");
						}else{
							nameAttrSb.append(line7Formatted.get(i)+"\r\n");
						}
					}
				}
				
				// For EXTL entity set name as EXTERNAL
				if("EXTL".equals(emswiftConfig.getTcode())){
					String setEXTLData = "EXTERNAL";
					if(emswiftConfig.getComments()!=null && !emswiftConfig.getComments().equals("")){
						setEXTLData = setEXTLData + "\r\n";
						List<String> line7Formatted = 	CashMapUtility.splitEqually("Comments:"+emswiftConfig.getComments(), maxSizeallowed);
						setEXTLData = setEXTLData + "\r\n(";
						for (int i = 0; i < line7Formatted.size(); i++) {
							if(i == (line7Formatted.size()-1)){
								setEXTLData = setEXTLData + line7Formatted.get(i)+")";
							}else{
								setEXTLData = setEXTLData + line7Formatted.get(i)+"\r\n";
							}
						}
					}
					
					cashMapRuleJsonObj.put("name",setEXTLData);
				}
				else{
					cashMapRuleJsonObj.put("name",nameAttrSb.toString());
				}
				cashMapRuleJsonObj.put("id", emswiftConfig.getTcode());
				cashMapRuleJsonObj.put("comments", emswiftConfig.getComments());
				cashMapRuleJsonObj.put("lineNo", emswiftConfig.getLineNum());
				//calculate height and width
				String[] nameArr = nameAttrSb.toString().split("\r\n");
				for (int i = 0; i < nameArr.length; i++) {
					width = nameArr[i].length()>width?nameArr[i].length():width;
				}
				height = nameArr.length>height?nameArr.length:height;
				
				jsonArray.put(cashMapRuleJsonObj);
			}
			//put height and width in json object
			cashMapRuleJsonData.put("height", height);
			cashMapRuleJsonData.put("width", width);
			cashMapRuleJsonData.put("nodes", jsonArray);
		} catch (JSONException e) {
			throw new RuntimeException();
		}
		return cashMapRuleJsonData;
	}

	private JSONObject createjsonLinkObject(List<GECashMapRuleBean> cashMapRuleDataList, JSONObject cashMapRuleJsonData) {
		Iterator<GECashMapRuleBean> cashMapRuleDataListItr =  cashMapRuleDataList.iterator();
		try {
		JSONArray jsonArray = new JSONArray();
			while (cashMapRuleDataListItr.hasNext()) {
				GECashMapRuleBean emswiftConfig = cashMapRuleDataListItr
						.next();
				JSONObject cashMapRuleJsonObj = new JSONObject();
				cashMapRuleJsonObj.put("source", emswiftConfig.getPayable());
				cashMapRuleJsonObj.put("target", emswiftConfig.getReceivable());
				cashMapRuleJsonObj.put("cashPoolIndicator", emswiftConfig.getCashPoolIndicator());
				cashMapRuleJsonObj.put("lineNo", emswiftConfig.getLineNum());
				cashMapRuleJsonObj.put("stepNo", emswiftConfig.getStepNoString()+emswiftConfig.getStepNum());
				
				StringBuffer nameAttrSb = new StringBuffer();
				int maxSizeallowed = 20;
				
				nameAttrSb.append(emswiftConfig.getStepNoString()+emswiftConfig.getStepNum());
				nameAttrSb.append("\r\n" + emswiftConfig.getType());
				if(emswiftConfig.getInterestExpense() != null && !emswiftConfig.getInterestExpense().equals("") 
						&& emswiftConfig.getInterestExpense() != 0){
					nameAttrSb.append(" " +	emswiftConfig.getCurrency().toUpperCase());
					nameAttrSb.append(" " + CashMapUtility.foramtAmount(emswiftConfig.getAmount()));
					nameAttrSb.append("\n" + "+ Int " + CashMapUtility.foramtAmount(emswiftConfig.getInterestExpense()+""));
					Double tot = new Double(emswiftConfig.getInterestExpense()) + new Double(emswiftConfig.getAmount()); 
					nameAttrSb.append("\n" + "Total " + CashMapUtility.foramtAmount(tot+""));
					nameAttrSb.append("\r\n("+emswiftConfig.getAmountInDollar()+" USD)");
					
				}else{
					nameAttrSb.append(" " + CashMapUtility.foramtAmount(emswiftConfig.getAmount()));
					nameAttrSb.append(" " +	emswiftConfig.getCurrency().toUpperCase());
					nameAttrSb.append("\r\n("+emswiftConfig.getAmountInDollar()+" USD)");
				}
				
				nameAttrSb.append("\r\non "+emswiftConfig.getValueDay()+"\r\n");
				
				if(emswiftConfig.getComments() != ""){
					List<String> line7Formatted = 	CashMapUtility.splitEqually(emswiftConfig.getComments(), maxSizeallowed);
					nameAttrSb.append("\r\n(");
					for (int i = 0; i < line7Formatted.size(); i++) {
						if(i == (line7Formatted.size()-1)){
							nameAttrSb.append(line7Formatted.get(i)+")\r\n");
						}else{
							nameAttrSb.append(line7Formatted.get(i)+"\r\n");
						}
					}
				}
				
				cashMapRuleJsonObj.put("linkComment", emswiftConfig.getComments());
				cashMapRuleJsonObj.put("label", nameAttrSb);
				jsonArray.put(cashMapRuleJsonObj);
			}
			cashMapRuleJsonData.put("links", jsonArray);
		} catch (JSONException e) {
			throw new RuntimeException();
		}
		return cashMapRuleJsonData;
	}

	private JSONObject createjsonLastUpdateObject(String lastUpdateDtString, JSONObject cashMapJsonData) {
		try {
				JSONArray jsonArray = new JSONArray();
				jsonArray.put("Last Update Date: "+lastUpdateDtString);
				cashMapJsonData.put("lstUpdateDate", jsonArray);
			} catch (JSONException e) {
				throw new RuntimeException();
			}
		return cashMapJsonData;
	}

	private JSONObject createjsonDataSavedObject(String savedDataString, JSONObject cashMapJsonData) {
		try {
				JSONArray jsonArray = new JSONArray();
				jsonArray.put(savedDataString);
				cashMapJsonData.put("dataSaved", jsonArray);
			} catch (JSONException e) {
				throw new RuntimeException();
			}
		return cashMapJsonData;
	}

	private JSONObject createjsonFundsFlowLabelObject(String fundFlowLabel,
			JSONObject cashMapRuleJsonData) {
		try {
				JSONArray jsonArray = new JSONArray();
				jsonArray.put(fundFlowLabel);
				cashMapRuleJsonData.put("flowlabel", jsonArray);
			} catch (JSONException e) {
				throw new RuntimeException();
			}
		return cashMapRuleJsonData;
	}

	private JSONObject getCommetsByFlowIDAndJSONData(String flowID, JSONObject cashMapJsonData) {
		String getComments = "";
		try {
			GECashMapRuleBean param = new GECashMapRuleBean();
			param.setFundsFlowID(flowID);
			param.setComments("FLOW");
			getComments = commentsDao.getFlowCommetsFromDB(param);
			JSONArray jsonArray = new JSONArray();
			jsonArray.put(getComments);
			cashMapJsonData.put("flowIDComment", jsonArray);
		} catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException();
		}
		if(getComments == null){
			getComments = "";
		}
		return cashMapJsonData;
	}
}
