package com.ge.cashmap.utility;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CashMapUtility {
	
	public static final List<String> splitEqually(String text, int size){
		List<String> ret = new ArrayList<String>((text.length() + size - 1) / size);
	    for (int start = 0; start < text.length(); start += size) {
	        ret.add(text.substring(start, Math.min(text.length(), start + size)));
	    }
	    return ret;
	}
	
	public static String removePlusSign(String passString){
		String splitName[] = passString.split("\\+");
		String rtnString = "";
		for (int i = 0; i < splitName.length; i++) {
			if(rtnString.equals("")){
				rtnString =	splitName[i];
			}else{
				rtnString = rtnString+" "+splitName[i];
			}	
		}
		return rtnString;
	}
	
	public static String foramtAmount(String amount){
		if(amount != null && !amount.equals("") && !amount.equals("0")){
			BigDecimal doubleAmt = new BigDecimal(amount);
			Double roundOff = Math.round(doubleAmt.doubleValue() * 100.0) / 100.0;
			return NumberFormat.getNumberInstance(Locale.US).format(Double.parseDouble(roundOff.toString()));
		}
		return amount;
	}
}
