package com.ge.cashmap.dao;

import java.util.List;

import com.ge.cashmap.mapper.GECashMapRuleBean;

public interface GeCashMapFundsFlowDao {
	public List<GECashMapRuleBean> getGECashMapFundsFlowIDData();
	public List<GECashMapRuleBean> getGECashMapRuleUnionData(String fundsFlowId);
	public List<GECashMapRuleBean>  getGECashMapRuleData(String fundsFlowId);
	public String getGECashMapLastUpdateData(String fundsFlowId);
	public List<GECashMapRuleBean> getGECashMapNumericFundsFlowIDData();
	public List<GECashMapRuleBean> getGECashMapFundsFlowIDDataStartsWithF();
}