package com.ge.cashmap.dao;

import java.util.List;
import java.util.Map;

import com.ge.cashmap.mapper.ElementCoordinatesBean;
import com.ge.cashmap.mapper.LinksVertexBean;

public interface CoordinatesDao {
	public int saveNodeCoordinates(ElementCoordinatesBean elementCoordinatesparam);
	public List<ElementCoordinatesBean> getElementCoordinatesData(String fundFlowId);
	public List<LinksVertexBean> getLinkVerticesData(String fundFlowId) ;
	public int getNodeCordinatesByFlowID(String fundFlowId);
	public int saveLinkCoordinates(ElementCoordinatesBean elementCoordinatesparam);
	public int deleteCashMapLink(Map<String, String> param);
}
