package com.ge.cashmap.service;

import java.util.List;

import com.ge.cashmap.mapper.CashMapRule;

public interface CashMapFundFlowServie {
	public List<CashMapRule> getCashMapFundsFlow(String userGroup);
	public boolean saveComments(String flowIdName, String tCode, String comment, String lineNo, String commentType, String userSSo);
	public String getLinkCommentData(String fundFlowId, String lineNo, String commentType);
	public int saveSignature(String fundFlowId, String[] contributers);
	public String getSignatures(String fundFlowId);
	public int getSignaturesCount(String fundFlowId);
	public boolean deleteSign(String signPk);
	public boolean updateSign(String name, String depName, String signPk);
	public int saveFlowIDCommentsInDB(String fundFlowId, String comment, String userSSo);
	public boolean saveCoordinates(String fundFlowId, String saveCoordinatesJson);
}
