package com.ge.cashmap.mapper;

public class ElementCoordinatesBean {
	private String fundsFlowID = "";
	private String tcode= "";
    private double centerX;
    private double centerY;
    private int lineNum;
    private int vertexNo;
    private double vertexX;
    private double vertexY;
    private String orientation;
    
	/**
	 * @return the fundsFlowID
	 */
	public String getFundsFlowID() {
		return fundsFlowID;
	}
	/**
	 * @param fundsFlowID the fundsFlowID to set
	 */
	public void setFundsFlowID(String fundsFlowID) {
		this.fundsFlowID = fundsFlowID;
	}
	/**
	 * @return the tcode
	 */
	public String getTcode() {
		return tcode;
	}
	/**
	 * @param tcode the tcode to set
	 */
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	/**
	 * @return the centerX
	 */
	public double getCenterX() {
		return centerX;
	}
	/**
	 * @param centerX the centerX to set
	 */
	public void setCenterX(double centerX) {
		this.centerX = centerX;
	}
	/**
	 * @return the centerY
	 */
	public double getCenterY() {
		return centerY;
	}
	/**
	 * @param centerY the centerY to set
	 */
	public void setCenterY(double centerY) {
		this.centerY = centerY;
	}
	/**
	 * @return the lineNum
	 */
	public int getLineNum() {
		return lineNum;
	}
	/**
	 * @param lineNum the lineNum to set
	 */
	public void setLineNum(int lineNum) {
		this.lineNum = lineNum;
	}
	/**
	 * @return the vertexNo
	 */
	public int getVertexNo() {
		return vertexNo;
	}
	/**
	 * @param vertexNo the vertexNo to set
	 */
	public void setVertexNo(int vertexNo) {
		this.vertexNo = vertexNo;
	}
	/**
	 * @return the vertexX
	 */
	public double getVertexX() {
		return vertexX;
	}
	/**
	 * @param vertexX the vertexX to set
	 */
	public void setVertexX(double vertexX) {
		this.vertexX = vertexX;
	}
	/**
	 * @return the vertexY
	 */
	public double getVertexY() {
		return vertexY;
	}
	/**
	 * @param vertexY the vertexY to set
	 */
	public void setVertexY(double vertexY) {
		this.vertexY = vertexY;
	}
	/**
	 * @return the orientation
	 */
	public String getOrientation() {
		return orientation;
	}
	/**
	 * @param orientation the orientation to set
	 */
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
}
