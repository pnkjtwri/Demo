package com.ge.cashmap.dao;

import com.ge.cashmap.mapper.GECashMapRuleBean;

public interface CommentsDao {
	public int saveTCodeCommentsInDB(GECashMapRuleBean geCashMapRuleParam);
	public int saveLineNoCommentsInDB(GECashMapRuleBean geCashMapRuleParam);
	public int updateCashMapComments(GECashMapRuleBean geCashMapRuleParam);
	public int saveCashMapComments(GECashMapRuleBean geCashMapRuleParam);
	public String getFlowCommetsFromDB(GECashMapRuleBean geCashMapRuleParam);
	public String getLinkCommets(GECashMapRuleBean geCashMapRuleParam);
}
