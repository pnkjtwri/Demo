package com.ge.cashmap.dao;

public interface UserDao {
	public int validateUserSso(String userSSO);

	public int checkICFGroupUser(String userSSO);
	
	public int checkCashGroupUser(String userSSO);
}
