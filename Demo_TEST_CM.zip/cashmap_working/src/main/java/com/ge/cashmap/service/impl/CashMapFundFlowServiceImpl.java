package com.ge.cashmap.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ge.cashmap.dao.CommentsDao;
import com.ge.cashmap.dao.CoordinatesDao;
import com.ge.cashmap.dao.GeCashMapFundsFlowDao;
import com.ge.cashmap.dao.SignatureDao;
import com.ge.cashmap.mapper.CashMapRule;
import com.ge.cashmap.mapper.ElementCoordinatesBean;
import com.ge.cashmap.mapper.GECashMapRuleBean;
import com.ge.cashmap.service.CashMapFundFlowServie;
import com.ge.cashmap.utility.CashMapUtility;

public class CashMapFundFlowServiceImpl implements CashMapFundFlowServie {

	@Autowired
	GeCashMapFundsFlowDao GeCashMapFundsFlow;
	
	@Autowired
	CommentsDao commentsDao;
	
	@Autowired
	SignatureDao signatureDao;
	
	@Autowired
	CoordinatesDao coordinatesDao;
	
	@Transactional
	public List<CashMapRule> getCashMapFundsFlow(String userGroup) {
		List<GECashMapRuleBean> cashMapFundflowIdList = new ArrayList<GECashMapRuleBean>();
		if(userGroup.equalsIgnoreCase("ICF")){
			cashMapFundflowIdList =  GeCashMapFundsFlow.getGECashMapFundsFlowIDDataStartsWithF();
		}else if(userGroup.equalsIgnoreCase("CASH")){
			cashMapFundflowIdList =  GeCashMapFundsFlow.getGECashMapNumericFundsFlowIDData();
		}else if(userGroup.equalsIgnoreCase("ALL")){
			cashMapFundflowIdList =  GeCashMapFundsFlow.getGECashMapFundsFlowIDData();
		}
		
		List<CashMapRule> cashMapRuleList = new ArrayList<CashMapRule>();
		if(cashMapFundflowIdList != null && cashMapFundflowIdList.size() > 0){
			CashMapRule cashMapRule = null;
			for(int listSize = 0; listSize < cashMapFundflowIdList.size(); listSize++){
				GECashMapRuleBean cashMapRuleBean = cashMapFundflowIdList.get(listSize);
				cashMapRule = new CashMapRule();
				cashMapRule.setFundsFlowID(cashMapRuleBean.getFundsFlowID());
				cashMapRule.setTransactionName(cashMapRuleBean.getTransactionName());
				cashMapRule.setSubTransactionName(cashMapRuleBean.getSubTransactionName());
				
				cashMapRuleList.add(cashMapRule);
			}
		}
		return cashMapRuleList;
	}

	@Transactional
	public boolean saveComments(String flowIdName, String tCode,
			String comment, String lineNo, String commentType, String loggedInSSO) {
		int rowSaved = 0;
		GECashMapRuleBean param = new GECashMapRuleBean();
		param.setFundsFlowID(flowIdName);
		param.setTcode(tCode);
		param.setComments(comment);
		param.setLineNum(Integer.parseInt(lineNo));
		param.setType(commentType);
		param.setUserSSO(loggedInSSO);
		
		if( tCode != null && tCode.length() > 0 ){
			rowSaved = commentsDao.saveTCodeCommentsInDB(param);
		}else{
			rowSaved = commentsDao.saveLineNoCommentsInDB(param);
		}
		
		return (rowSaved > 0 ? true : false);
	}

	@Transactional
	public String getLinkCommentData(String fundFlowId, String lineNo,
			String commentType) {
		GECashMapRuleBean param = new GECashMapRuleBean();
		param.setFundsFlowID(fundFlowId);
		param.setLineNum(Integer.parseInt(lineNo));
		param.setType(commentType);
		
		String returnData = commentsDao.getLinkCommets(param);
		
		return returnData;
	}

	@Transactional
	public int saveSignature(String fundFlowId, String[] contributers) {
		
		int counter = 0 ;
		String name	=	"";
		String depName	=	"";
		
		try{
			while(counter < contributers.length){
				if(counter%2 == 0){
					String getSplitName[]	=	contributers[counter].split("=");
					if(getSplitName.length>1){
						name = getSplitName[1];
					}else{
						name = "";
					}
					name = CashMapUtility.removePlusSign(name);
				}
				else
				{
					String getSplitDepName[] =	contributers[counter].split("=");
					if(getSplitDepName.length > 1){
						depName = getSplitDepName[1];
					}else{
						depName = "";
					}
					depName = CashMapUtility.removePlusSign(depName);
					
					GECashMapRuleBean param =  new GECashMapRuleBean();
					param.setFundsFlowID(fundFlowId);
					param.setName(name);
					param.setDepName(depName);
					
					signatureDao.saveSignature(param);
				}
				counter++;
			}
		}catch(Exception ex){
			return 2;
		}
		
		return 1;
	}

	@Transactional
	public String getSignatures(String fundFlowId) {
		StringBuilder sb                   = null;
		GECashMapRuleBean cashMapRuleBean  = null;
		
		List<GECashMapRuleBean> signatureList = signatureDao.getSignatures(fundFlowId);
		if(signatureList != null && signatureList.size() > 0){
			sb	=	new StringBuilder();
			for(int listCount = 0; listCount < signatureList.size();  listCount++) {
				cashMapRuleBean  = (GECashMapRuleBean)signatureList.get(listCount);
				if(listCount%2 == 0)
					sb.append("<div class=\"left-panel signature\" name=\""+cashMapRuleBean.getName()+"\" depname=\""+cashMapRuleBean.getDepName()
							+"\" signPk=\""+cashMapRuleBean.getGeCashMapSignPk()+"\" ><p>"+cashMapRuleBean.getName()+"<br />"+cashMapRuleBean.getDepName()+"</p>"
							+ "<input type=\"button\" class=\"edit_btn\" onclick=\"updateSign(this)\" />"
							+ "<input type=\"button\" class=\"delete_btn\" onclick=\"deleteSign(this)\" />"
							+ "</div>");
				else
					sb.append("<div class=\"right-panel signature\" name=\""+cashMapRuleBean.getName()+"\" depname=\""+cashMapRuleBean.getDepName()
							+"\" signPk=\""+cashMapRuleBean.getGeCashMapSignPk()+"\"><p>"+cashMapRuleBean.getName()+"<br />"+cashMapRuleBean.getDepName()+"</p>"
							+ "<input type=\"button\" class=\"edit_btn\" onclick=\"updateSign(this)\" />"
							+ "<input type=\"button\" class=\"delete_btn\" onclick=\"deleteSign(this)\" />"
							+ "</div>");
			}
		}
		return (sb != null ? sb.toString() : "");
	}

	@Transactional
	public int getSignaturesCount(String fundFlowId) {
		int returnValue = signatureDao.getSignatureCount(fundFlowId);
		return returnValue;
	}

	@Transactional
	public boolean deleteSign(String signPk) {
		int returnValue = signatureDao.deleteSign(signPk);
		return (returnValue > 0 ? true : false);
	}

	@Transactional
	public boolean updateSign(String name, String depName, String signPk) {
		GECashMapRuleBean param =  new GECashMapRuleBean();
		
		param.setName(name);
		param.setDepName(depName);
		param.setGeCashMapSignPk(signPk);
		
		int returnValue = signatureDao.updateSign(param);
		return (returnValue > 0 ? true : false);
	}

	@Transactional
	public int saveFlowIDCommentsInDB(String fundFlowId, String comment, String userSSo) {
		GECashMapRuleBean param =  new GECashMapRuleBean();
		
		param.setFundsFlowID(fundFlowId);
		param.setComments(comment);
		param.setUserSSO(userSSo);
		
		int returnValue = commentsDao.updateCashMapComments(param);
		if(returnValue < 1){
			returnValue = commentsDao.saveCashMapComments(param);
		}
		
		return returnValue;
	}

	@Transactional
	public boolean saveCoordinates(String fundFlowId, String saveCoordinatesJson) {
		
		JSONObject saveCoordinatesObj = null;
		boolean updateFlag            = false;
		try{
			saveCoordinatesObj = new JSONObject(saveCoordinatesJson);
			JSONArray nodedata = saveCoordinatesObj.getJSONArray("listOfNodes"); 
			JSONArray linkdata = saveCoordinatesObj.getJSONArray("listOfLinks");
			
			int n = nodedata.length();
			int l = linkdata.length();
			String orientation           = "";
			ElementCoordinatesBean param = null;
			int returnValue              = 0;
			for (int i = 0; i < n; i++) {
				JSONObject node = nodedata.getJSONObject(i);
				
				param = new ElementCoordinatesBean();
				param.setFundsFlowID(node.getString("flowIdName"));
				param.setTcode(node.getString("tcode"));
				param.setCenterX(node.getDouble("centerX"));
				param.setCenterY(node.getDouble("centerY"));
				orientation = node.getString("Orientation");
				param.setOrientation(orientation);
				
				returnValue = coordinatesDao.saveNodeCoordinates(param);
				if(returnValue > 0 ){updateFlag = true;}
			}
			
			if(fundFlowId != null){
				Map<String,String> paramDel = new HashMap<String, String>();
				paramDel.put("fundFlowId", fundFlowId);
				paramDel.put("orientation", orientation);
				
				coordinatesDao.deleteCashMapLink(paramDel);
			}
			
			for (int j = 0; j < l; j++) {
				JSONObject link = linkdata.getJSONObject(j);
				
				param = new ElementCoordinatesBean();
				param.setFundsFlowID(link.getString("flowIdName"));
				param.setLineNum(link.getInt("lineNo"));
				param.setVertexX(link.getDouble("vertexX"));
				param.setVertexY(link.getDouble("vertexY"));
				param.setVertexNo(link.getInt("vertexNo"));
				param.setOrientation(link.getString("Orientation"));
				
				returnValue = coordinatesDao.saveLinkCoordinates(param);
				
				if(returnValue > 0 ){updateFlag = true;}
			}
		}catch (JSONException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		return updateFlag;
	}

	@Transactional
	public List<CashMapRule> getCashMapNumericFundsFlow() {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	public List<CashMapRule> getCashMapFundsFlowOnlyStartsWithF() {
		// TODO Auto-generated method stub
		return null;
	}

}