//$(function() {
//	var availableTags = dropDownTextList;
//    $( "#tags" ).autocomplete({
//      source: availableTags
//    });
//  });
  
//$("#tags").blur(function(e){
//	var lastIndex = $("#tags").val().lastIndexOf("-");
//	var selectedFlowId = $("#tags").val().substring(lastIndex+1, $("#tags").val().length);
//	alert(selectedFlowId);
//});

var filterFlow  = [];
function initSearch(availableFlow){
	$("#searchFlowID").keyup(function() {
		//var availableFlow = <%=dropDownTextList%>;//'CashMapTest5-CashMapTest5-10018';
		filterFlow  = [];
		var selectedChar = $("#searchFlowID").val();
		//alert(selectedChar);
		if(selectedChar.trim==''){
			setFilteredFlows(availableFlow);
		}else{
			_.each(availableFlow, function(flowName) {
				//console.log(selectedChar);
				var getFlowNameLower =  flowName.toLowerCase();
				var selectedCharLower = selectedChar.toLowerCase();
				if(getFlowNameLower.indexOf(selectedCharLower) > -1){
					filterFlow.push(flowName);
				}
			});
			setFilteredFlows(filterFlow);
		}
	hideButtons();
	resetForm();
	});
}

function setFilteredFlows(optionList){
	$('#selectedRecordID').empty();
	$('#selectedRecordID').append('<option value="0">Choose A Flow Map</option>');
	//console.log("optionList--->"+optionList);
	_.each(optionList, function(flowName) {
		$('#selectedRecordID').append('<option value="'+getFlowIdFromIndex(flowName)+'">'+flowName+'</option>');
	});
}

function getFlowIdFromIndex(flowName){
	var index = flowName.lastIndexOf("-");
	if(index <= 0){
		return '0';
	}else{
		var rtnData = flowName.substring(index+1,flowName.length);
		if(isNaN(rtnData)){
			index = flowName.substring(0,index).lastIndexOf("-");
			rtnData = flowName.substring(index+1,flowName.length);
		}
		//alert(rtnData);
		return rtnData
	}
	
}


function setPaperDivInSpan(){
	$('#paperSpan').html('<div id="paper"  align="left" text-align:center" onclick="resetOpacity()" style = "margin-top:40px;"></div>');
}

$.prototype.enable = function () {
    $.each(this, function (index, el) {
        $(el).removeAttr('disabled');
    });
}

$.prototype.disable = function () {
    $.each(this, function (index, el) {
        $(el).attr('disabled', 'disabled');
    });
}

var count	=	getSignaturesCount();

function initMehtod(byDefFlowId){
	$(document).ready(function () {
		//alert(byDefFlowId);
		if(byDefFlowId == null || byDefFlowId == 'null'){
			//do nothing
		}else{
			if(!($("#selectedRecordID option[value='"+byDefFlowId+"']").length > 0)){
				$("#commonAlertDialog").dialog("open");
				$('#commonAlertSpan').html('');
				$('#commonAlertSpan').html("Cashmap database does not hold details for funds flow id: "+byDefFlowId);
				$('#selectedRecordID').val('0');
			}else{
				$('#selectedRecordID').val(byDefFlowId);
				$('#selectedRecordID').change();
			}
		}
			
	    'use strict';
	    var maxCount	=	10;
	    $('.repeater').repeater({
	        defaultValues: {        
	        },
	        show: function () {
	        	if(count <= maxCount){
	            	$(this).slideDown();
	            	count++;
	        	}
	        },	
	        hide: function (deleteElement) {
	            if(confirm('Are you sure you want to delete this element?')) {
	                $(this).slideUp(deleteElement);
	            }
	        }
	    });
	});
}

function reloadForm(){
	var i = 0;
	$('[data-repeater-item]').each(function(){
		if(i>0)
		this.remove();
		i++;
});
}

$('#Submit').click(function(e){
	
	var fd = $("#signForm").serialize();
	$('#sigFormLoadingImage').show();
	$('#showSignAlert').hide();
    $.ajax({
        url: "saveSignatures",
        data: { flowIdName: $('#flowID').val(), formdata: fd},
        type : 'POST',
        dataType : 'html',
        success: function (response) {
        	$("#signForm").trigger('reset');
        	$('#sigFormLoadingImage').hide();
        	if(response == '1'){
        		$("#showSignAlert").css('color','green');
        		$('#showSignAlert').html("Saved successfully.");
        	}else{
        		$("#showSignAlert").css('color','red');
        		$('#showSignAlert').html("Could not save.");
        	}
        	$('#showSignAlert').show();
        	
        	getSignatures();
        	reloadForm();
        }
    });
    $('#showSignAlert').delay(5000).fadeOut('slow');
});

function updateSign(element){
	
	$("#oldname").val($(element).closest(".signature").attr("name"));
	$("#olddepname").val($(element).closest(".signature").attr("depname"));
	$("#signPk").val($(element).closest(".signature").attr("signPk"));
	
	$("#name").val($("#oldname").val());
	$("#depname").val($("#olddepname").val());
	$("#dialogSign").dialog("open");
	
}

function updateSignature(){
	var name = $("#name").val();
	var depname = $("#depname").val();
	var signPk = $("#signPk").val();
	$("#dialogSignShowAlert").hide();
	$("#LoadingImage3").show();
	$.ajax({
        url : 'updateSign', 
        data : { flowIdName: $('#selectedRecordID').val(), Name: name,DepName: depname,signPk: signPk}, 
        type : 'POST',
        dataType : 'html',
        success : function(response) {
        	getSignatures();
        	if(response == '1'){
        		$("#dialogSignShowAlert").css('color','green');
        		$('#dialogSignShowAlert').html("Saved successfully.");
        	}else{
        		$("#dialogSignShowAlert").css('color','red');
        		$('#dialogSignShowAlert').html("Could not save.");
        	}
        	$("#dialogSignShowAlert").show();
        	closeDialogSign();
        	$("#LoadingImage3").hide();
        	
        },
        error : function(request, textStatus, errorThrown) {
		$("#LoadingImage").hide();
        alert(errorThrown);
        }
    });
	$('#dialogSignShowAlert').delay(5000).fadeOut('slow');
}

function deleteSign(element){
	
	if(confirm('Are you sure want to delete this signature?'))
	{
		var signPk = 	$(element).closest(".signature").attr("signPk");
		
		$.ajax({
	        url : 'deleteSign', 
	        data : { flowIdName: $('#selectedRecordID').val(), signPk: signPk}, 
	        type : 'POST',
	        dataType : 'html',
	        success : function(response) {
	        	getSignatures();
	        	alert(response);
	        },
	        error : function(request, textStatus, errorThrown) {
			$("#LoadingImage").hide();
	        alert(errorThrown);
	        }
	    });
	}
	
}

	
function getSignaturesCount(){
	var count = 0;
	$.ajax({
        url : 'getSignaturesCount', 
        data : { flowIdName: $('#selectedRecordID').val()}, 
        type : 'POST',
        dataType : 'html',
        success : function(response) {
        	/* if(response >= 10)
        	{
        		$("#signForm").hide();
        	};
*/
			count = response;
        },
        error : function(request, textStatus, errorThrown) {
		$("#LoadingImage").hide();
        alert(errorThrown);
        }
    });
	
	return count;
}

function getSignatures(){
	$("#sigFormLoadingImage").show();
	$("#LoadingImage").show();
	$.ajax({
        url : 'getSignatures', 
        data : { flowIdName: $('#selectedRecordID').val()}, 
        type : 'POST',
        dataType : 'html',
        success : function(response) {
        	$("#sigFormLoadingImage").hide();
        	$("#LoadingImage").hide();
        	$('#sign').html(response);
        	$("#sign").show();
        },
        error : function(request, textStatus, errorThrown) {
		$("#sigFormLoadingImage").hide();
		$("#LoadingImage").hide();
        alert(errorThrown);
        }
    });
}


$("#dialogSign").dialog ({
	autoOpen : false,
	close: function(event, ui){ closeDialogSign(); }
});

$("#commonAlertDialog").dialog ({
	autoOpen : false
});

function closeDialogSign(){
	$("#dialogSign").dialog("close");
	getSignatures();
	$("#showAlert").html('');
	$("#showAlert").hide();
	$("#name").val('');
	$("#oldname").val('');
	$("#depname").val('');
	$("#olddepname").val('');
}

	
	function showLastUpdateDateAndComment(){
		var dataList = eval('dataList = ' + $('#adjacency-list').val());
		$("#showLastUpdateDate").html(dataList.lstUpdateDate);
		$("#flowIdCommentTextArea").val(dataList.flowIDComment);
		$("#flowIdCommentLabel").html('');
		$("#flowIdCommentLabel").html(dataList.flowIDComment);
		$('#flowIdCommentTextArea').keyup();
	}

	$("#dialog").dialog ({
		autoOpen : false,
		close: function(event, ui){ closeDialog(); }
	});

	function resetOpacity(){
		if($("#dialog").dialog( "isOpen" )){
			$("#paper").css({ opacity: 0.7});
		}else{
			$("#paper").css({ opacity: 1});
		}
		
	}

	var saveCmntBtnClicked = '0';
	function closeDialog(){
		$( "#dialog" ).dialog("close");
		$("#paper").css({ opacity: 1});
		if(saveCmntBtnClicked == '1'){
			$('#paperSpan').html('');
			setPaperDivInSpan();
			showSavedCoordinates = 1;
			createGraph(paperOrientation);
			saveCmntBtnClicked = 0;
		}
	}
	
	//Code to handle max character in textarea starts
	$('#commentTextArea').keypress(function (event) {
		var max = 100;
		var len = $(this).val().length;
		if (event.which < 0x20) {
	   		return; // Do nothing
	   	}
		if (len >= max) {
	   		event.preventDefault();
	   	}

	});
	
	$('#commentTextArea').keyup(function (event) {
		var max = 100;
	   	var len = $(this).val().length;
	  	var char = max - len;
	  	$('#charNum').text(char + ' characters left');			
	});
	
	//Code to handle max character in fundflowID textarea starts
	$('#flowIdCommentTextArea').keypress(function (event) {
		var max = 500;
		var len = $(this).val().length;
		if (event.which < 0x20) {
	   		return; // Do nothing
	   	}
		if (len >= max) {
	   		event.preventDefault();
	   	}

	});
	
	$('#flowIdCommentTextArea').keyup(function (event) {
		var max = 500;
	   	var len = $(this).val().length;
	  	var char = max - len;
	  	$('#fivecharNum').html(char + ' characters left');			
	});
	
	
	function increaseGraphFont(){
		showSavedCoordinates = 1;
		globalGraphLetterSize = globalGraphLetterSize+1;
		$('#paperSpan').html('');
		setPaperDivInSpan();
		createGraph(paperOrientation);
	}
	
	function decreaseGraphFont(){
		if(globalGraphLetterSize > 1){
			showSavedCoordinates = 1;
			globalGraphLetterSize = globalGraphLetterSize-1;
			$('#paperSpan').html('');
			setPaperDivInSpan();
			createGraph(paperOrientation);
		}
	}
	
//$('#downloadFile').click(function () {
//    var specialElementHandlers = 
//    function (element,renderer) {
//    return true;
//    }
//    var doc = new jsPDF();
//    doc.fromHTML($('#paper').html(), 15, 15, {
//    'width': 170,
//    'elementHandlers': specialElementHandlers
//    });
//    doc.output('dataurlnewwindow'); 
//});
	

	
	//$('#saveButtonID').onClick(function(e){
	//	html2canvas(document.body, { onrendered: function(canvas) {  document.body.appendChild(canvas);}});
	//});
	
	//function saveAsPDF(){
	//	html2canvas(document.body, { onrendered: function(canvas) {  document.body.appendChild(canvas);}});
	//}
	
	function hideButtons(){
		$("#horizontalOrientation").hide();
		$("#verticalOrientation").hide();
		$("#saveCoordinates").hide();
		$("#plusBtn").hide();
		$("#minusBtn").hide();
	}
	
	function resetForm(){
		$('#signForm').hide();
    	$('#sign').hide();
    	$("#flowIdCommentTextAreaDiv").hide();
    	$("#flowIdCommentTextArea").val('');
    	$("#flowIdCommentLabel").html('');
    	$("#showLastUpdateDate").html('');
    	$("#saveVertecShowAlert").html('');
    	$('#showFlowIdCommentTextAreaAlert').hide();
    	$('#header').text('');
    	setPaperDivInSpan();
	}
	
	var showSavedCoordinates = 0;
	$('#selectedRecordID').change(function(e){
		paperOrientation = "lr";
		resetBtnBackground();
		$('#adjacency-list').val('');
		if($("#paper").length == 0) {
			//console.log("in if...");
		}else{
			//console.log("in else...");
			$("#paper").empty();
		}
		$('#paperSpan').html('');
		setPaperDivInSpan();
		resetForm();
        if($('#selectedRecordID').val()=='0'){
        	//DO NOTHING
			//clearComments();
        	hideButtons();
        	//$('#searchFlowID').val('');
        }else{
			$("#LoadingImage").show();
        	$("#header").show();
			//clearComments();
        	//alert($('#selectedRecordID').val());
        	$.ajax({
                url : 'getGraph', 
                data : { flowIdName: $('#selectedRecordID').val()}, 
                type : 'POST',
                dataType : 'html',
                success : function(response) {
					$("#LoadingImage").hide();
					$("#horizontalOrientation").show();
					$("#verticalOrientation").show();
					//$("#hideBackGroundBtn").show();
					$("#plusBtn").show();
					$("#minusBtn").show();
					$("#saveCoordinates").show();
					$('#adjacency-list').val(response);
					showSavedCoordinates = 1;
               	 	createGraph(paperOrientation);
               	   	$('#flowID').val($('#selectedRecordID').val());
               	 	$("#LoadingImage").show();
               	 	showLastUpdateDateAndComment();
	               	getSignatures();
	               	reloadForm();
	               	$('#signForm').show();
	               	$("#flowIdCommentTextAreaDiv").show();
	               	setHorizontalBtnAsClicked();
                },
                error : function(request, textStatus, errorThrown) {
				$("#LoadingImage").hide();
                alert(errorThrown);
                }
            });
        }
	});

var iAmInLinkOrNode = '';
var globalGraphLetterSize = 11;
var graph = new joint.dia.Graph;
function createGraph(orientation){
	
	//alert($('#adjacency-list').val());
	if($('#adjacency-list').val() != ""){
			joint.layout.DirectedGraph = {
			  layout: function (graph, opt) {
			    opt = opt || {
			    };
			    var dGraph = new dagre.graphlib.Graph();
			/*    var dGraph = new dagre.graphlib.Graph({ multigraph: true })*/
			    var inputGraph = this._prepareData(graph, dGraph);
			    var runner = dGraph.setGraph({});
			    if (opt.debugLevel) {
			      runner.debugLevel(opt.debugLevel);
			    }
			    if (opt.rankDir) {
			      inputGraph.graph().rankdir = opt.rankDir;
			    }
			    if (opt.rankSep) {
			      inputGraph.graph().rankSep = opt.rankSep;
			    }
			    if (opt.edgeSep) {
			      inputGraph.graph().edgeSep = opt.edgeSep;
			    }
			    if (opt.nodeSep) {
			      inputGraph.graph().nodeSep = opt.nodeSep;
			    }
			    if (opt.rankSep) {
			      inputGraph.graph().rankSep = opt.rankSep;
			    }
			    var layoutGraph = dagre.layout(inputGraph);
			    inputGraph.nodes().forEach(function (u) {
			      var value = inputGraph.node(u); 
			      if (!value.dummy) {
				  //alert("x coordinate is::"+(value.x - value.width) /2 );
				   //alert("y coordinate is::"+(value.y - value.height )/ 2 );
			        var cell = graph.getCell(u);
			        opt.setPosition
			        ? opt.setPosition(cell, value) 
			        : graph.get('cells').get(u).set('position', {
			          x: value.x - value.width / 2,
			          y: value.y + value.height/ 2
			        });
			      }
			    });
			    if (opt.setLinkVertices) {
				//alert("In set link vertices");
			      inputGraph.edges().forEach(function (e) {
			        var e_label = inputGraph.edge(e.v, e.w);
			        var link = graph.getCell(e_label);
			        if (link) {
			          opt.setVertices
			          ? opt.setVertices(link, value.points) 
			          : link.set('vertices', value.points);
				   }
			      });
			    }
			    return {
			      width: runner.graph().width,
			      height: runner.graph().height
			    };
			  },
			  _prepareData: function (graph, dagre_graph) {
			    var dagreGraph = dagre_graph;
			    // For each element.
			    _.each(graph.getElements(), function (cell) {
			      if (dagreGraph.hasNode(cell.id)) return;
			      dagreGraph.setNode(cell.id.toString(), {
			        width: cell.get('size').width,
			        height: cell.get('size').height,
			        rank: cell.get('rank')
			      });
			    });
			    // For each link.
			    _.each(graph.getLinks(), function (cell) {
			      if (dagreGraph.hasEdge(cell.id)) return;
			      var sourceId = cell.get('source').id.toString();
			      var targetId = cell.get('target').id.toString();
			      dagreGraph.setEdge(sourceId, targetId, {
			        label: cell.id,
			        minLen: cell.get('minLen') || 1
			      });
			    });
			    return dagreGraph;
			  }
			};
			
			//fix for overlapping links between two elements. 
			function adjustVertices(graph, cell,rankDirData) {
				// If the cell is a view, find its model.
				cell = cell.model || cell;

				if (cell instanceof joint.dia.Element) {

					_.chain(graph.getConnectedLinks(cell)).groupBy(function(link) {
						// the key of the group is the model id of the link's source or target, but not our cell id.
						return _.omit([link.get('source').id, link.get('target').id], cell.id)[0];
					}).each(function(group, key) {
						// If the member of the group has both source and target model adjust vertices.
						if (key !== 'undefined') adjustVertices(graph, _.first(group),rankDirData);
					});

					return;
				}

				// The cell is a link. Let's find its source and target models.
				var srcId = cell.get('source').id || cell.previous('source').id;
				var trgId = cell.get('target').id || cell.previous('target').id;

				// If one of the ends is not a model, the link has no siblings.
				if (!srcId || !trgId) return;

				var siblings = _.filter(graph.getLinks(), function(sibling) {

					var _srcId = sibling.get('source').id;
					var _trgId = sibling.get('target').id;

					return (_srcId === srcId && _trgId === trgId) || (_srcId === trgId && _trgId === srcId);
				});

				switch (siblings.length) {

				case 0:
					// The link was removed and had no siblings.
					break;

				case 1:
					// There is only one link between the source and target. No vertices needed.
					cell.unset('vertices');
					break;

				default:
					// There is more than one siblings. We need to create vertices.

					// First of all we'll find the middle point of the link.
					var srcCenter = graph.getCell(srcId).getBBox().center();
					//alert("after"+srcCenter.y);
					var trgCenter = graph.getCell(trgId).getBBox().center();
					
					var midPoint = g.line(srcCenter, trgCenter).midpoint();


					// Then find the angle it forms.
					var theta = srcCenter.theta(trgCenter);
					
					// This is the maximum distance between links
					var gap = 100;

					_.each(siblings, function(sibling, index) {

						// We want the offset values to be calculated as follows 0, 20, 20, 40, 40, 60, 60 ..
						var offset = gap * Math.ceil(index / 2);

						// Now we need the vertices to be placed at points which are 'offset' pixels distant
						// from the first link and forms a perpendicular angle to it. And as index goes up
						// alternate left and right.
						//
						//  ^  odd indexes 
						//  |
						//  |--  index 0 line (straight line between a source center and a target center.
						//  |
						//  v  even indexes
						var sign =  index % 2 ? 1 : -1;
						//alert("theta is::"+theta);
						var angle = g.toRad(theta*sign + 90);
						// We found the vertex.
						var vertex = g.point.fromPolar(offset, angle, midPoint);
						var vx = 0;
						var vy = 0;
						//if(index != 0){
							if (rankDirData == "lr")
							{
								vx= vertex.x;
								vy= vertex.y+1.2*graph.getCell(srcId).getBBox().height;
							}
							else{
								vx= vertex.x+1.2*graph.getCell(srcId).getBBox().width;
								vy= vertex.y;
							} 
							//alert("vx:"+vx+"   vy::"+vy);
							sibling.set('vertices', [{ x: vx, y: vy }]);
							//}
					});
					
				}
			};

			// Helpers.
			// --------
			
			function buildGraph(data) {
			  var elements = [];
			  var links = [];
			  var height = data.height;
			  var width = data.width;
			  _.each(data.nodes, function(node) {
				elements.push(makeElement(node,height,width));
			  });
			  
			  _.each(data.links, function(edge) {
				links.push(makeLink(edge)); 
			  });
			  
			  return elements.concat(links);
			}
			
			function makeLink(edge) {

				var edgeLabel = edge.label;
				var splitEdge = edgeLabel.split("\r\n");
				var finalEdgelabel = '';

				for(var k = 0; k<splitEdge.length;k++){
					if(finalEdgelabel == ''){
						finalEdgelabel = splitEdge[k];
					}else{
						finalEdgelabel = finalEdgelabel +"\n" + splitEdge[k];
					}
				}
				
				  if (edge.cashPoolIndicator.toString() == "CashPoolIndicator:ZBA" || edge.source.toString() == "U336" || edge.target.toString() == "U336") {
				   var lnk = new joint.dia.Link({
					  id: edge.lineNo.toString(),
					  //router: { name: 'manhattan' },
					  source: { id: edge.source.toString() },
				      target: { id: edge.target.toString() },
					  attrs: {
				        '.marker-target': { d: 'M 10 0 L 0 5 L 10 10 z' },
						'.marker-vertices': {d : '5.414L2,25.667l5.613-1.441c2.339'},
						'.connection': {stroke: '#3498DB', 'stroke-width': 3, 'stroke-dasharray': '5 2' }
				      },
				      labels: [{
				        position: 0.5,
				        attrs: {
				          text: {
				            text: finalEdgelabel,
							'font-size': globalGraphLetterSize,
							'font-family': 'Inspira',
							'font-weight': 'bold'
				          }
				        }
				      }]
				     // ,connector: {stroke: 'blue'}
				  });
				  } else {
				  var lnk = new joint.dia.Link({
					  id: edge.lineNo.toString(),
					  //router: { name: 'manhattan' },
				      source: { id: edge.source.toString() },
				      target: { id: edge.target.toString() },
				      attrs: {
				        '.marker-target': { d: 'M 10 0 L 0 5 L 10 10 z' },
						'.marker-vertices': {d : '5.414L2,25.667l5.613-1.441c2.339'}
				      },
				      labels: [{
				        position: 0.5,
				        attrs: {
				          text: {
				            text: finalEdgelabel,
							'font-size': globalGraphLetterSize,
							'font-family': 'Inspira',
							'font-weight': 'bold'
				          }
				        }
				      }]
				     // ,connector: {name: 'smooth'}
				  });
				    
				  }
				  
				  return lnk;
				}
				
				/* joint.shapes.custom = {};
				// The following custom shape creates a link out of the whole element.
				// joint.shapes.custom.ElementLink = joint.shapes.basic.Rect.extend({
					// // Note the `<a>` SVG element surrounding the rest of the markup.
					// markup: '<a><g class="rotatable"><g class="scalable"><rect/></g><text/></g></a>',
					// defaults: joint.util.deepSupplement({
						// type: 'custom.ElementLink'
					// }, joint.shapes.basic.Rect.prototype.defaults)
				// });
				// The following custom shape creates a link only out of the label inside the element.
				joint.shapes.custom.ElementLabelLink = joint.shapes.basic.Rect.extend({
					// Note the `<a>` SVG element surrounding the rest of the markup.
					markup: '<g class="rotatable"><g class="scalable"><rect/></g><a><text/></a></g>',
					defaults: joint.util.deepSupplement({
						type: 'custom.ElementLabelLink'
					}, joint.shapes.basic.Rect.prototype.defaults)
				}); */
			
			function makeElement(node,height,width) {
			    //var maxLineLength = _.max(node.name.split('\n'), function(l) { return l.length; }).length;

			    var nodeName = node.name;
			    var splitName = nodeName.split("\r\n");
			    var finalNameNode = "";
			    //alert(splitName);
			    for(var z=0; z<splitName.length; z++){	    	
				    if(finalNameNode == ''){
				    	finalNameNode = splitName[z];
					}else{
						finalNameNode = finalNameNode +"\n"+ splitName[z] ;
					}
			    }
			   
				//alert(finalNameNode);
			    // Compute width/height of the rectangle based on the number
			    // of lines in the label and the letter size. 0.6 * letterSize is
			    // an approximation of the monospace font letter width.
			    var letterSize = globalGraphLetterSize;
			    //alert(maxTextLen);
			    var width = 1.06*(letterSize * (0.6 *(width)));
			    var height = 1.3*( (height) * letterSize);
			
				if(node.id == 'EXTL')
				{
					return new joint.shapes.basic.Rect({
						id: node.id.toString(),
						size: { width: width, height: height },
						attrs: {
							text: { 
							  text: finalNameNode, 
							  'font-size': letterSize+3, 
							  'font-family': 'Inspira',
							  'x-alignment': 'middle'},
							rect: {
								width: width, height: height,
								rx: 5, ry: 5,
								stroke: '#555',
								fill: 'lightgreen' 
							}
						}
					});
				}
				else
				{
					return new joint.shapes.basic.Rect({
						id: node.id.toString(),
						size: { width: width, height: height },
						attrs: {
							text: { 
							  text: finalNameNode, 
							  'font-size': letterSize, 
							  'font-family': 'Inspira',
							  'x-alignment': 'middle',
							  fill:'white'},
							rect: {
								width: width, height: height,
								rx: 5, ry: 5,
								stroke: '#555',
								fill: '#026cb6' 
							}
						}
					});
				}
			}
			
			// Main.
			// -----
			
			graph = new joint.dia.Graph;
			var gridSize = 1;
			var width = 3000;
			var height = 3000;
			var paper = new joint.dia.Paper({
			    el: $('#paper'),
			    width: width,
			    height: height,
			    gridSize: gridSize,
			    model: graph,
				perpendicularLinks: true
				// tell the paper to use our LinkView
			   // linkView: PatternLinkView
			
			});
			
			
			//var myAdjustVertices = _.partial(adjustVertices, graph);
			// adjust vertices when a cell is removed or its source/target was changed
			//graph.on('add remove change:source change:target', myAdjustVertices);

			// also when an user stops interacting with an element.
			//paper.on('cell:pointerclick', myAdjustVertices);
			
			//Invoke Comments functionality
		 	paper.on('cell:pointerdblclick',function(cellView, evt, x, y) {
		 		
		 		$("#showAlert").hide();
				$('#commentTextArea').val(''); 
				
				var nodeId = cellView.model.id;
				$('#selectedNodeId').val(nodeId);
				
				var comment="";
				var stepNo="";
				
				$("#paper").css({ opacity: 0.7});
				$("#paper").css({"display": "block"});
				
				var datalist = eval('dataList = ' + $('#adjacency-list').val());
				
		 		//var cell = graph.getCell(nodeId);
		 		if(cellView.model instanceof joint.dia.Link){
		 			iAmInLinkOrNode = "LINK";
		 			_.each(datalist.links, function(link) {
						if(link.lineNo == nodeId){
							stepNo = link.stepNo;
							$('#selectedLineNo').val(link.lineNo);
							comment = link.linkComment;
						}
					});
		 			//nodeId = cell.lineNo;
		 			$("#dialog").dialog ({
						 title: 'Comments for '+stepNo
					});
		 		}else{
		 			
		 			iAmInLinkOrNode = "NODE";
		 			_.each(datalist.nodes, function(node) {
						if(node.id == nodeId){
							comment=node.comments;
							$('#selectedLineNo').val(node.lineNo);
						}
					});
		 			
		 			$("#dialog").dialog ({
						 title: 'Comments for '+nodeId
					});
		 			
		 			$('#dialog').attr('title', 'Comments for '+nodeId);
					
		 		}
				
		 		$('#commentTextArea').val(comment);
		 		$("#dialog").dialog("open");
				$('#commentTextArea').keyup();
			});
			
			
		 	paper.on('cell:pointermove', function (cellView, evt, x, y) {

		 	    var bbox = cellView.getBBox();
		 	    var constrained = false;
		 	    var constrainedX = x;
		 	    //console.log(bbox.x);
		 	    if (bbox.x <= 0) { 
		 	        constrainedX = x + gridSize;
		 	        constrained = true
		 	    }
		 	    
		 	    if (bbox.x + bbox.width >= width) { 
		 	        constrainedX = x - gridSize; 
		 	        constrained = true
		 	    }
		 	                        
		 	    var constrainedY = y;
		 	    
		 	    if (bbox.y <= 0) {
		 	        constrainedY = y + gridSize;
		 	        constrained = true
		 	    }
		 	    
		 	    if (bbox.y + bbox.height >= height) { 
		 	        constrainedY = y - gridSize; 
		 	        constrained = true
		 	    }
		 	    
		 	    //if you fire the event all the time you get a stack overflow
		 	    if (constrained) { 
		 	        cellView.pointermove(evt, constrainedX, constrainedY)
		 	    }
		 	});
			
			// Just give the viewport a little padding.
			//V(paper.viewport).translate(40, 40);
						
			
			function layout() {
				var dataList;
			    try {
			        dataList = eval('dataList = ' + $('#adjacency-list').val());
			   } catch (e) { 
				   //alert(e); 
				  }
				  
			   var rankDirData = "";
			   

				if(typeof orientation != 'undefined'){
					rankDirData=orientation;
				}
				else{
					rankDirData="lr";
				}
			   var nodeSepData=0;
			   var rankSepData=0;
			   var edgeSepData=0;
			   
			    if (rankDirData === "lr") {
					nodeSepData=150;
					rankSepData=200;
					edgeSepData=200;
					//paper.setOrigin(0, 200);
				}
				else{
					nodeSepData=200;
					rankSepData=100;
					edgeSepData=500;
					//paper.setOrigin(0, 100);
				}
				//alert("rankDirData is::"+rankDirData);
			    var cells = buildGraph(dataList);
			    $('#header').text(dataList.flowlabel);
			    graph.resetCells(cells);
				joint.layout.DirectedGraph.layout(graph, {
			      //setLinkVertices: true,
					  rankDir: rankDirData,
				      nodeSep:nodeSepData,
				      rankSep: rankSepData,
					  edgeSep: edgeSepData
			    });
				_.each(cells, function(cell) {	
			    adjustVertices(graph,cell,rankDirData);					  
			  });
			  
			  var bbox = graph.getBBox(graph.getElements());
			  //var paperHeight=bbox.height + 500;
			  //var paperWidth=bbox.width+500;
			  height = bbox.height + 500;
			  width = bbox.width+500;
			  paper.setDimensions(width,height);
			  document.getElementById("paper").style.padding = "0px";
			} 
			layout();
			
            $('#setLinkVerticesBtn').click();
			

		}
	}
	
$('#saveCoordinates').click(function(e){
	var listOfNodesCoordinates = [];
	var listOfLinksCoordinates = [];
	_.each(graph.getElements(), function(cell) {
		var node = {flowIdName:$('#flowID').val(),
					"tcode": cell.id,
					"centerX": graph.getCell(cell.id).getBBox().x,
					"centerY": graph.getCell(cell.id).getBBox().y,
					"Orientation": paperOrientation
				 };
		listOfNodesCoordinates.push(node);
		//alert("listOfNodes:::"+node);
		/*_.each(graph.getConnectedLinks(cell), function(link) {
		var linkId = link.id;
		var vertexNo = 1;
			_.each(link.get('vertices'), function(vertex) {
			var linkVertex= {flowIdName:$('#flowID').val(),
					"lineNo": linkId,
					"vertexX": vertex.x,
					"vertexY": vertex.y,
					"tcode" : cell.id,
					"vertexNo": vertexNo
				 };
			
			listOfLinksCoordinates.push(linkVertex);
			//alert("listOfLinks:::"+linkVertex);
			vertexNo++;
			});
		});*/
		});
	
	_.each(graph.getLinks(), function(link) {
		//alert(link.id);
		var linkId = link.id;
		var vertexNo = 1;
			_.each(link.get('vertices'), function(vertex) {
			var linkVertex= {flowIdName:$('#flowID').val(),
					"lineNo": linkId,
					"vertexX": vertex.x,
					"vertexY": vertex.y,
					"vertexNo": vertexNo,
					"Orientation": paperOrientation
				 };
			
			listOfLinksCoordinates.push(linkVertex);
			//alert("listOfLinks:::"+linkVertex);
			vertexNo++;
			});
		});
	
		var saveCoordinatesJson = {listOfNodes:listOfNodesCoordinates,listOfLinks:listOfLinksCoordinates};
		//console.log("save coordinates json is::"+JSON.stringify(saveCoordinatesJson));
		$("#LoadingImage").show();
		
		$.ajax({
			url : 'saveCoordinates', 
			data : {flowIdName:$('#flowID').val(), saveCoordinatesJson: JSON.stringify(saveCoordinatesJson)}, 
			type : 'POST',
			dataType : 'html',
			success : function(response) {
				$("#LoadingImage").hide();
				$("#saveVertecShowAlert").show();
				if(response == '1'){
					$("#saveVertecShowAlert").css('color','green');
					$('#saveVertecShowAlert').html("Saved successfully.");
				}else{
					$("#saveVertecShowAlert").css('color','red');
	        		$('#saveVertecShowAlert').html("Could not save.");
				}
				
			},
			error : function(request, textStatus, errorThrown) {
				$("#LoadingImage").hide();
				alert(errorThrown);
			}
		});
			
		$('#saveVertecShowAlert').delay(5000).fadeOut('slow');
});

$('#setLinkVerticesBtn').click(function(e){
	//console.log("paperOrientation.."+paperOrientation);
	if(showSavedCoordinates == 1){
		
		 var dataList = eval('dataList = ' + $('#adjacency-list').val());
		 
		  _.each(graph.getElements(), function(cell) {
   		   for(var elementIndex = 0; elementIndex < dataList.elementCoordinates.length; elementIndex ++){
   			//console.log(dataList.elementCoordinates[elementIndex].elementTCode+" from DB");
       			 //console.log(cell.id+" from Graph");
       			 //console.log((dataList.elementCoordinates[elementIndex].elementTCode == cell.id));
       			if(dataList.elementCoordinates[elementIndex].elementTCode == cell.id && 
       					paperOrientation == dataList.elementCoordinates[elementIndex].orientation){
       			//console.log("inside if...");
           			var elementX = dataList.elementCoordinates[elementIndex].elementCenterX;
               		var elementY = dataList.elementCoordinates[elementIndex].elementCenterY;
               		cell.set('position', {x: elementX, y: elementY});
               		//console.log(elementX);
               		//console.log(elementY);
       			}
           		/*  _.each(graph.getConnectedLinks(cell), function(link) {
                  		_.each(dataList.linkVertex, function(linkVertex) {
                  		   
                  	   		if(linkVertex.linkLineNo == link.id){
                  	   			link.set('vertices', [{ x: linkVertex.linkVertexX, y: linkVertex.linkVertexY }]);
     						}
     					}); 
       						
					}); */
       		 
       		 }
       		
       	 });
		  
		    _.each(graph.getLinks(), function(link) {
		   var vertex = [];
		   var vertexLength = 0;
   		   for(var linkIndex = 0; linkIndex < dataList.linkVertex.length; linkIndex ++){
   			   if(dataList.linkVertex[linkIndex].linkLineNo == link.id && 
   					paperOrientation == dataList.linkVertex[linkIndex].orientation){
						//console.log("link...");
      					var elementX = dataList.linkVertex[linkIndex].linkVertexX;
              			var elementY = dataList.linkVertex[linkIndex].linkVertexY;
						vertex[vertexLength] = {x : elementX,y : elementY};
						vertexLength ++;
      				}
          		}
				if(vertex.length >0){
					link.set('vertices', vertex);
				}
			}); 
   	   
   	   showSavedCoordinates = 0;
	}
});
	
	var paperOrientation = "lr";
	 $('#horizontalOrientation').click(function(e){
		paperOrientation = "lr";
		setHorizontalBtnAsClicked();
		$('#paperSpan').html('');
		setPaperDivInSpan();
		showSavedCoordinates = 1;
		getGraphDetailsByHoriOrVertiBtnClick();
	});
				
	 $('#verticalOrientation').click(function(e){
		paperOrientation = "tb";
		setVerticalBtnAsClicked();
		$('#paperSpan').html('');
		setPaperDivInSpan();
		showSavedCoordinates = 1;
		getGraphDetailsByHoriOrVertiBtnClick();
	});
	 
	 function getGraphDetailsByHoriOrVertiBtnClick(){
		$("#LoadingImage").show();
		$.ajax({
            url : 'getGraph', 
            data : { flowIdName: $('#selectedRecordID').val()}, 
            type : 'POST',
            dataType : 'html',
            success : function(response) {
				$("#LoadingImage").hide();
				$('#adjacency-list').val(response);
				createGraph(paperOrientation);
            },
            error : function(request, textStatus, errorThrown) {
			$("#LoadingImage").hide();
            alert(errorThrown);
            }
        });
	 }
	 
	 function setHorizontalBtnAsClicked(){
		$('#verticalOrientation').css('background-color','#54D2F7');
		$('#horizontalOrientation').css('background-color','lightgray');
	 }
	 
	 function setVerticalBtnAsClicked(){
		$('#verticalOrientation').css('background-color','lightgray');
		$('#horizontalOrientation').css('background-color','#54D2F7');
	 }
	 
	 function resetBtnBackground(){
		 $('#horizontalOrientation').css('background-color','#54D2F7');
		 $('#verticalOrientation').css('background-color','#54D2F7');
	 }
	 
/* 	 $('#showBackGroundBtn').click(function(e){
		$('.body').removeClass("hide-bg");
		$("#showBackGroundBtn").hide();
		$("#hideBackGroundBtn").show();
	});
	 
	 $('#hideBackGroundBtn').click(function(e){
		$('.body').addClass("hide-bg");
		$("#hideBackGroundBtn").hide();
		$("#showBackGroundBtn").show();
	});
	 
	  */

	 $('#saveTextArea').click(function(e){
		saveCmntBtnClicked = '0';
		$("#showAlert").hide();
		if($('#commentTextArea').val().length > 100){
			$("#showAlert").show();
			$("#showAlert").css('color','red');
			$("#showAlert").html("Comment can't has more than 100 characters.");	
		}else{
			$("#LoadingImage2").show();
			
			/*var setMethodCallName = 'saveComments';
			if(iAmInLinkOrNode=='NODE'){
				setMethodCallName = 'saveComments';
			}else if(iAmInLinkOrNode=='LINK'){
				setMethodCallName = 'saveLinkComments';
			}*/
			
			$.ajax({
				url : 'saveComments', 
				data : { flowIdName: $('#selectedRecordID').val(), nodeId: $('#selectedNodeId').val(), lineNo: $('#selectedLineNo').val(), 
					commentData: $('#commentTextArea').val(), commentType: iAmInLinkOrNode,loggedInSSO:$('#loggedInSSO').val()}, 
				type : 'POST',
				dataType : 'html',
				success : function(response) {
					$("#LoadingImage2").hide();
					$('#adjacency-list').val('');
					$('#adjacency-list').val(response);
					var dataList = eval('dataList = ' + $('#adjacency-list').val());
					saveCmntBtnClicked = '1';
					if(dataList.dataSaved == '1'){
		        		$("#showAlert").css('color','green');
		        		$('#showAlert').html("Saved successfully.");
		        	}else{
		        		$("#showAlert").css('color','red');
		        		$('#showAlert').html("Could not save.");
		        	}
					$("#showAlert").show();
					$( "#dialog" ).dialog("close");
				},
				error : function(request, textStatus, errorThrown) {
					$("#LoadingImage2").hide();
					alert(errorThrown);
				}
			});
		}
		$('#showAlert').delay(5000).fadeOut('slow');
	});
	 
	 $('#saveFlowIdCommentTextArea').click(function(e){
		 $('#showFlowIdCommentTextAreaAlert').hide();
			if($('#flowIdCommentTextArea').val().length > 500){
				$("#showFlowIdCommentTextAreaAlert").css('color','red');
				$("#showFlowIdCommentTextAreaAlert").show();
				$("#showFlowIdCommentTextAreaAlert").html("Comment can't has more than 500 characters.");	
			}else{
				$("#flowIdCommentLoadingImage").show();
				
				$.ajax({
					url : 'saveFlowIDComment',
					data : { flowIdName: $('#selectedRecordID').val(), commentData: $('#flowIdCommentTextArea').val(), loggedInSSO:$('#loggedInSSO').val()}, 
					type : 'POST',
					dataType : 'html',
					success : function(response) {
						$("#flowIdCommentLoadingImage").hide();
						if(response == '1'){
			        		$("#showFlowIdCommentTextAreaAlert").css('color','green');
			        		$('#showFlowIdCommentTextAreaAlert').html("Saved successfully.");
			        	}else{
			        		$("#showFlowIdCommentTextAreaAlert").css('color','red');
			        		$('#showFlowIdCommentTextAreaAlert').html("Could not save.");
			        	}
						$("#showFlowIdCommentTextAreaAlert").show();
						$("#flowIdCommentLabel").html('');
						$("#flowIdCommentLabel").html($('#flowIdCommentTextArea').val());
					},
					error : function(request, textStatus, errorThrown) {
						$("#flowIdCommentLoadingImage").hide();
						alert(errorThrown);
					}
				});
			}
			$('#showFlowIdCommentTextAreaAlert').delay(5000).fadeOut('slow');
		});
	
	/* $('#sendMailBtn').click(function(e){
		$("#LoadingImage").show();
		$.ajax({
            url : 'SendPDFViaEmail', 
            //data : { flowIdName: $('#selectedRecordID').val()}, 
            type : 'GET',
            dataType : 'html',
            success : function(response) {
				$("#LoadingImage").hide();
				alert(response);
            },
            error : function(request, textStatus, errorThrown) {
			$("#LoadingImage").hide();
            alert(errorThrown);
            }
        });
	}); */