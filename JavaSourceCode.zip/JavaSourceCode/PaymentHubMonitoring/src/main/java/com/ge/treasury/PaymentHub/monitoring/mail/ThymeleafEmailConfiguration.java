/**
 * 
 */
package com.ge.treasury.PaymentHub.monitoring.mail;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

/**
 * @author padmajaarekuti
 *
 */
@Configuration
public class ThymeleafEmailConfiguration {
	
	@Value("${configuration.mailServer.host}")
	private String mailHost;
	
	@Value("${configuration.mailServer.protocol}")
	private String mailProtocol;
	
	@Value("${configuration.mailServer.port}")
	private String mailPort;
	
	@Value("${configuration.mailServer.password}")
	private String mailPwd;
	
	@Value("${configuration.mailSmtp.auth}")
	private String mailAuth;
	
	   @Bean 
	   public JavaMailSender getJavaMailSenderImpl(){
	        JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl(); 
	        javaMailSender.setHost(mailHost);
	        javaMailSender.setPort(Integer.parseInt(mailPort));
	        javaMailSender.setProtocol(mailProtocol); 
	        javaMailSender.setPassword(mailPwd);
	        Properties props = new Properties();
	        props.setProperty("mail.smtp.auth", mailAuth); 
	        javaMailSender.setJavaMailProperties(props);

	        return javaMailSender;
	    }

	    @Bean
	    public ClassLoaderTemplateResolver emailTemplateResolver(){
	        ClassLoaderTemplateResolver emailTemplateResolver = new ClassLoaderTemplateResolver();
	        emailTemplateResolver.setPrefix("/");
	        emailTemplateResolver.setSuffix(".html");
	        emailTemplateResolver.setTemplateMode("HTML5");
	        emailTemplateResolver.setCharacterEncoding("UTF-8");
	        emailTemplateResolver.setOrder(1);

	        return emailTemplateResolver;
	    } 
	  
	}
