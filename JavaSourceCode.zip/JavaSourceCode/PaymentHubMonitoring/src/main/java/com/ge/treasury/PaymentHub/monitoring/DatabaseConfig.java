package com.ge.treasury.PaymentHub.monitoring;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@MapperScan(basePackages="com.ge.treasury.PaymentHub.monitoring")
public class DatabaseConfig {
	
	@Value("${configuration.dataSource.dbDriverClassName}")
	private String dbDriverClassName;
	
	@Value("${configuration.dataSource.dbUrl}")
	private String dbUrl;
	
	@Value("${configuration.dataSource.dbUsername}")
	private String dbUserId;
	
	@Value("${configuration.dataSource.dbPassword}")
	private String dbPassword;
	
	
	@Bean
    public DataSource getDataSource() { 
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(dbDriverClassName);
       
		dataSource.setUrl(dbUrl);
		dataSource.setUsername(dbUserId);
		dataSource.setPassword(dbPassword);
		System.out.println("Datasoure created successfully");
		return dataSource; 
    }
	
	@Bean
	public DataSourceTransactionManager transactionManager() {
		return new DataSourceTransactionManager(getDataSource());
	}
	
    @Bean
    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        return sessionFactory.getObject();
    }
	
	@Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
