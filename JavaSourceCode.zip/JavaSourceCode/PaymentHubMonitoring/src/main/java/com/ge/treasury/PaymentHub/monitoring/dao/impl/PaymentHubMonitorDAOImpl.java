package com.ge.treasury.PaymentHub.monitoring.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ge.treasury.PaymentHub.monitoring.dao.PaymentHubMonitorDAO;
import com.ge.treasury.PaymentHub.monitoring.model.BlankImportStatusDataBean;
import com.ge.treasury.PaymentHub.monitoring.rowmapper.BlankImportStatusDataRowMapper;

@Repository
@SuppressWarnings("unchecked")
public class PaymentHubMonitorDAOImpl implements PaymentHubMonitorDAO {
	
	@Autowired private DataSource dataSource;
	@Autowired private JdbcTemplate jdbc;
	
	/*private final String pfiBusinessQuery = "SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS ";
	
	private final String businessInstanceMappingQuery = "SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFIBUS_TSAINST_MAPPING "
			+ "WHERE PFI_BUSINESS_ID = ? ";
	
	private final String segregatorDetailsQuery = "SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SEGREGATOR_FILE "
			+ "WHERE IMPORT_STATUS_FILE_NAME is null and TSAINSTANCES_ID = ? ";*/
	
	/*private final String srcPaymentFileDetailsQuery = "SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SRC_PAYMENT_FILE "
			+ "WHERE SRC_PAYMENT_FILE_ID = ?";*/
	
	private final String getBlankImportStatusFileDataQuery = "select seg.*, bus.PFI_BUSINESS_NAME, bus.SLA_TIME, src.SRC_PAYMENT_FILE_NAME  from "
			+ "T_webcashTSA_segregator_file seg, T_webcashTSA_src_payment_file src, T_webcashTSA_pfi_business bus, T_WEBCASHTSA_PFIBUS_TSAINST_MAPPING tsamap "
			+ "where src.src_payment_file_id = seg.src_payment_file_id "
			+ "and seg.tsainstances_id = tsamap.tsainstances_id and bus.pfi_business_id = tsamap.pfi_business_id "
			+ "and src.pfi_business_id = bus.pfi_business_id and import_status_file_name is null ";

	/**
	 * Method used for getting all row of T_WEBCASHTSA_PFI_BUSINESS table
	 */
	/*@Override
	public List<PFIBusiness> getPFIBusinessDetails(){
		return jdbc.query(pfiBusinessQuery, new PFIBusinessRowMapper());
	}*/
	
	/**
	 * Method used for getting T_WEBCASHTSA_PFIBUS_TSAINST_MAPPING table recrods on the basis of PFI_BUSINESS_ID column
	 */
	/*@Override
	public List<PFIBusinessTSAInstanceMapping> getPFIBusinessInstanceMappingDetails(long businessID){
		return jdbc.query(businessInstanceMappingQuery, new Object[] { businessID }, new PFIBusinessTSAInstancesRowMapper());
	}*/
	
	/**
	 * Method used for getting T_WEBCASHTSA_SEGREGATOR_FILE table records on the basis of TSAINSTANCES_ID column and IMPORT_STATUS_FILE_NAME is null
	 */
	@Override
	public List<BlankImportStatusDataBean> getBlankImportStatusReportForAllBusiness(){
		
		//return jdbc.query(segregatorDetailsQuery, new Object[] { tsaInstanceID }, new SegregatorFileRowMapper());
		return jdbc.query(getBlankImportStatusFileDataQuery, new BlankImportStatusDataRowMapper());
	}
	
	/**
	 * Method used for getting T_WEBCASHTSA_SRC_PAYMENT_FILE record on the basis of SRC_PAYMENT_FILE_ID column
	 * @param srcPaymentFileID
	 */
	/*@Override
	public SrcPaymentFile getSrcPaymentFileDetails(Long srcPaymentFileID){
		
		return (SrcPaymentFile)jdbc.queryForObject(srcPaymentFileDetailsQuery, new Object[] { srcPaymentFileID }, new SrcPaymentFileRowMapper());
	}*/

}
