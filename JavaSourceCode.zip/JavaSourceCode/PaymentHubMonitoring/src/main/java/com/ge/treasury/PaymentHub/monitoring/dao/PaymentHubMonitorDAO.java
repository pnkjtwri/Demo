package com.ge.treasury.PaymentHub.monitoring.dao;

import java.util.List;

import com.ge.treasury.PaymentHub.monitoring.model.BlankImportStatusDataBean;

public interface PaymentHubMonitorDAO {

	/*List<PFIBusiness> getPFIBusinessDetails();
	
	List<PFIBusinessTSAInstanceMapping> getPFIBusinessInstanceMappingDetails(long businessID);*/
	
	List<BlankImportStatusDataBean> getBlankImportStatusReportForAllBusiness();

	//SrcPaymentFile getSrcPaymentFileDetails(Long srcPaymentFileID);

}
