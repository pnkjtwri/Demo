package com.ge.treasury.PaymentHub.monitoring.model;

import java.sql.Timestamp;

public class BlankImportStatusDataBean {
	
	private Long segregatorFileID;
	private Long srcPaymentFileID;
	private String segregatorFileName;
	private String paymentInstType;
	private Integer tsaInstanceID;
	private Integer fileStatusID;
	private String importStatusFileName;
	private Integer noOfTransaction;
	private String hashString;
	private Integer slaTime;
	private String pfiBusinessName;
	private String srcPaymentFileName;
	private String createdBy;
	private Timestamp createdTimestamp;
	private String lastModifiedBy;
	private Timestamp lastModifiedTimestamp;
	
	
	public Long getSegregatorFileID() {
		return segregatorFileID;
	}
	public void setSegregatorFileID(Long segregatorFileID) {
		this.segregatorFileID = segregatorFileID;
	}
	public Long getSrcPaymentFileID() {
		return srcPaymentFileID;
	}
	public void setSrcPaymentFileID(Long srcPaymentFileID) {
		this.srcPaymentFileID = srcPaymentFileID;
	}
	public String getSegregatorFileName() {
		return segregatorFileName;
	}
	public void setSegregatorFileName(String segregatorFileName) {
		this.segregatorFileName = segregatorFileName;
	}
	public String getPaymentInstType() {
		return paymentInstType;
	}
	public void setPaymentInstType(String paymentInstType) {
		this.paymentInstType = paymentInstType;
	}
	public Integer getTsaInstanceID() {
		return tsaInstanceID;
	}
	public void setTsaInstanceID(Integer tsaInstanceID) {
		this.tsaInstanceID = tsaInstanceID;
	}
	public Integer getFileStatusID() {
		return fileStatusID;
	}
	public void setFileStatusID(Integer fileStatusID) {
		this.fileStatusID = fileStatusID;
	}
	public String getImportStatusFileName() {
		return importStatusFileName;
	}
	public void setImportStatusFileName(String importStatusFileName) {
		this.importStatusFileName = importStatusFileName;
	}
	public Integer getNoOfTransaction() {
		return noOfTransaction;
	}
	public void setNoOfTransaction(Integer noOfTransaction) {
		this.noOfTransaction = noOfTransaction;
	}
	public String getHashString() {
		return hashString;
	}
	public void setHashString(String hashString) {
		this.hashString = hashString;
	}
	public Integer getSlaTime() {
		return slaTime;
	}
	public void setSlaTime(Integer slaTime) {
		this.slaTime = slaTime;
	}
	public String getPfiBusinessName() {
		return pfiBusinessName;
	}
	public void setPfiBusinessName(String pfiBusinessName) {
		this.pfiBusinessName = pfiBusinessName;
	}
	public String getSrcPaymentFileName() {
		return srcPaymentFileName;
	}
	public void setSrcPaymentFileName(String srcPaymentFileName) {
		this.srcPaymentFileName = srcPaymentFileName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}
	public void setLastModifiedTimestamp(Timestamp lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}
	
	
}
