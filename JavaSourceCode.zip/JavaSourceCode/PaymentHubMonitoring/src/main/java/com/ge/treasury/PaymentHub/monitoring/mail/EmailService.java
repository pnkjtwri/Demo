/**
 * 
 */
package com.ge.treasury.PaymentHub.monitoring.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.ge.treasury.PaymentHub.monitoring.util.PaymentHubMonitorUtility;

/**
 * @author pankaj1.tiwari
 *
 */
@Service
public class EmailService {

	final static Logger logger = Logger.getLogger(EmailService.class);
	
    @Autowired private JavaMailSender mailSender;
    
    @Autowired private TemplateEngine templateEngine;
 
    @Value("${recipientDL}")
	private String recipientEmail;
    
    @Value("${fromDL}")
	private String fromDL;
    
    
    public void sendPainMailNotification(String mailSubject, String sourceFileName, String error) throws MessagingException {
		logger.info("[EmailService.class] [inside sendPainMailNotification()]");
		logger.info("[EmailService.class] [inside sendPainMailNotification()] [Going to send E-Mail notification...]");
		Map<String,Object> mailContentMap = new HashMap<String, Object>();
		InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            PaymentHubMonitorUtility.getErrorFormStackTrace(e);
        }
        mailContentMap.put("sourceFileName", sourceFileName);
        mailContentMap.put("hostName", hostAndIP.getHostAddress());
        mailContentMap.put("shortMsg", error );
        mailContentMap.put("longMsg", "NA" );  
		
		sendMail("email-simple2", mailSubject, mailContentMap);
		logger.info("[EmailService.class] [inside sendPainMailNotification()] [E-Mail notification has sent successfully.]");
	}
    
    /* 
     * Send HTML mail (simple) 
     */
    private void sendMail(final String templateNm, String subject, Map<String,Object> bodyContent) 
            throws MessagingException {
    	Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
        // Prepare the evaluation context
        final Context ctx = new Context(bLocale);
        ctx.setVariable("bodyContent", bodyContent);
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);

    }
 

}