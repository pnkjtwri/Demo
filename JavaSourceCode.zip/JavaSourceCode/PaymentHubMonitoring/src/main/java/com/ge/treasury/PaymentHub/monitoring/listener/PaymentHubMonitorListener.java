package com.ge.treasury.PaymentHub.monitoring.listener;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RestController;

import com.ge.treasury.PaymentHub.monitoring.dao.impl.PaymentHubMonitorDAOImpl;
import com.ge.treasury.PaymentHub.monitoring.mail.EmailService;
import com.ge.treasury.PaymentHub.monitoring.model.BlankImportStatusDataBean;
import com.ge.treasury.PaymentHub.monitoring.util.PaymentHubMonitorUtility;

@RestController
public class PaymentHubMonitorListener {
	
	private static final Logger logger = Logger.getLogger(PaymentHubMonitorListener.class);
	
	@Autowired PaymentHubMonitorDAOImpl importReportSLADAO;
	@Autowired private EmailService emailService;
	
	@Scheduled(cron="${monitorPollingTime}")
	private void sendMailNotificationForImportReport() {
		logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()]");
		
		logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Going to get those feedback files data which are not received yet..]");
		List<BlankImportStatusDataBean> segregatorDtlsList = importReportSLADAO.getBlankImportStatusReportForAllBusiness();
			if(segregatorDtlsList != null && segregatorDtlsList.size() > 0){
				logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Got some feedback files records which are not recieved yet from dataabse.] [Going to iterate all of them.]");
				for (Iterator<BlankImportStatusDataBean> itr = segregatorDtlsList.iterator(); itr
						.hasNext();) {
					BlankImportStatusDataBean beanObj = (BlankImportStatusDataBean) itr
							.next();
					
					//current date time
					Date currentTimestamp = new Date();
					logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Current Timestap] : ["+currentTimestamp+"]");
					//segregator file creation date time
					Date createdDate = beanObj.getCreatedTimestamp();
					logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Created Date-Timestap] : ["+createdDate+"]");
					logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Going to parse Created Date-Timestap as per Current Timestamp format]");
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String createdResult = df.format(createdDate);
					try {
						createdDate=df.parse(createdResult);
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Created Date-Timestap after modified as per Current Timestamp] : ["+createdDate+"]");
					} catch (ParseException e) {
				       e.printStackTrace();
					}
					
					long currentTimeLong = currentTimestamp.getTime();
					long createdDateLong = createdDate.getTime();
					
					
					long diffTime = currentTimeLong - createdDateLong;
					
					long diffDays = diffTime / (1000 * 60 * 60 * 24);
					logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Difference of days in Current and Created Timestamp] : ["+diffDays+"]");
					if(diffDays > 0){
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Difference of days in Current and Created Timestamp is more than 0(zero). SO, no need to check for for minutes.] ");
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [So, going to send mail-notification for "+beanObj.getSegregatorFileName()+" file.For which; we didn't recevied feedback file.]");
						sendMailNotificatin(beanObj);
					}else{
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Difference of days in Current and Created Timestamp is 0(zero). SO, Going to get minutes differences...] ");
						long diffTimeInMin = diffTime / (60 * 1000) % 60;
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Difference of minutes in Current and Created Timestamp] : ["+diffTimeInMin+"]");
						logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Timestamp for sending mail notification for "+beanObj.getPfiBusinessName()+" business] : ["+beanObj.getSlaTime()+"] minutes");
						if(diffTimeInMin > beanObj.getSlaTime()){
							logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Business Mail notification timestamp is smaller than Difference of minutes in Current and Created Timestamp...]");
							logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [So, going to send mail-notification for "+beanObj.getSegregatorFileName()+" file.For which; we didn't recevied feedback file.]");
							sendMailNotificatin(beanObj);
						}
						else{
							//skip
							logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Business Mail notification timestamp is greater than Difference of minutes in Current and Created Timestamp...]");
							logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [Will not send mail notification for "+beanObj.getSegregatorFileName()+" file. ]");
						}
					}	
				}//end for loop
			}else{
				logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificationForImportReport()] [All feedback files already received..]");
			}
					
	}
	
	/**
	 * Method used for sending mail notification
	 * @param BlankImportStatusDataBean
	 */
	private void sendMailNotificatin(BlankImportStatusDataBean beanObj){
		logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificatin()]");
		logger.info("[PaymentHubMonitorListener.class] [inside sendMailNotificatin()] [Preparing mail-content....]");
		String bodyContent = "Didn't get feedback file for "+beanObj.getSegregatorFileName();
		try {
			if(emailService == null)emailService = new EmailService();
			emailService.sendPainMailNotification("Didn't get feedback file", beanObj.getSrcPaymentFileName(), bodyContent);
		} catch (MessagingException e1) {
			logger.error(PaymentHubMonitorUtility.getErrorFormStackTrace(e1));
		}
	}

}
