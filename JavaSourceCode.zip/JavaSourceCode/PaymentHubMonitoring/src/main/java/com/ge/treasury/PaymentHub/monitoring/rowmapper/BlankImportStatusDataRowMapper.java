package com.ge.treasury.PaymentHub.monitoring.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.monitoring.model.BlankImportStatusDataBean;

@SuppressWarnings("rawtypes")
public class BlankImportStatusDataRowMapper implements RowMapper {
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		BlankImportStatusDataBean beanObj = new BlankImportStatusDataBean();
		
		beanObj.setSegregatorFileID(rs.getLong("SEGREGATOR_FILE_ID"));
		beanObj.setSrcPaymentFileID(rs.getLong("SRC_PAYMENT_FILE_ID"));
		beanObj.setSegregatorFileName(rs.getString("SEGREGATOR_FILE_NAME"));
		beanObj.setPaymentInstType(rs.getString("PAYMENT_INST_TYPE"));
		beanObj.setTsaInstanceID(rs.getInt("TSAINSTANCES_ID"));
		beanObj.setFileStatusID(rs.getInt("FILESTATUS_ID"));
		beanObj.setImportStatusFileName(rs.getString("IMPORT_STATUS_FILE_NAME"));
		beanObj.setNoOfTransaction(rs.getInt("NO_OF_TRANSACTIONS"));
		beanObj.setHashString(rs.getString("HASH_STRING"));
		beanObj.setCreatedBy(rs.getString("CREATED_BY"));
		beanObj.setCreatedTimestamp(rs.getTimestamp("CREATED_TIMESTAMP"));
		beanObj.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		beanObj.setLastModifiedTimestamp(rs.getTimestamp("LAST_MODIFIED_TIMESTAMP"));
		beanObj.setPfiBusinessName(rs.getString("PFI_BUSINESS_NAME"));
		beanObj.setSlaTime(rs.getInt("SLA_TIME"));
		beanObj.setSrcPaymentFileName(rs.getString("SRC_PAYMENT_FILE_NAME"));
		
		return beanObj;
	}
	
}
