package com.ge.treasury.PaymentHub.monitoring.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class PaymentHubMonitorUtility {
	/*
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
}
