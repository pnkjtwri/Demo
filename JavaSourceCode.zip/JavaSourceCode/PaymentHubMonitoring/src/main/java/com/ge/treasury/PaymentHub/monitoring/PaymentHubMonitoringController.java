package com.ge.treasury.PaymentHub.monitoring;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableAutoConfiguration
@ComponentScan(basePackages = "com.ge.treasury.PaymentHub.monitoring")
public class PaymentHubMonitoringController extends SpringBootServletInitializer {
	
	public static void main(String[] args) throws Exception { 
		
		SpringApplication.run(PaymentHubMonitoringController.class, args);
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
		defaultProperties.put("spring.config.location", "file:/app/tsaweb/properties/paymenthubmonitor/application.yml");
        return application.sources(PaymentHubMonitoringController.class).properties(defaultProperties);
    }
}
