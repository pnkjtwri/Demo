package com.ge.treasury.payment.splitter.mapper;

public class TsaInstanceMapper {
	private String tsaInstanceId;
	private String tsaInstanceIdentifier;
	
	/**
	 * @return the tsaInstanceId
	 */
	public String getTsaInstanceId() {
		return tsaInstanceId;
	}
	/**
	 * @return the tsaInstanceIdentifier
	 */
	public String getTsaInstanceIdentifier() {
		return tsaInstanceIdentifier;
	}
	/**
	 * @param tsaInstanceId the tsaInstanceId to set
	 */
	public void setTsaInstanceId(String tsaInstanceId) {
		this.tsaInstanceId = tsaInstanceId;
	}
	/**
	 * @param tsaInstanceIdentifier the tsaInstanceIdentifier to set
	 */
	public void setTsaInstanceIdentifier(String tsaInstanceIdentifier) {
		this.tsaInstanceIdentifier = tsaInstanceIdentifier;
	}
}
