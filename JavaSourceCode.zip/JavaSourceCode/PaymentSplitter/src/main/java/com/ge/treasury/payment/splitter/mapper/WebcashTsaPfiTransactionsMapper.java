package com.ge.treasury.payment.splitter.mapper;

import java.sql.Timestamp;

/**
 * this class is mapper with the data base table
 * T_WEBCASHTSA_PFI_TRANSACTIONS
 * */
public class WebcashTsaPfiTransactionsMapper {
	private Integer pfiTransactionId;
	private Integer srcPaymentFileId;
	private Integer segregatorFileId;
	private String transactionType;
	private String modelId;
	private String accountId;
	private String debitorAccountId; /**what is difference with account id*/
	private String trustedSource;
	private Timestamp transValueDate;
	private String currency;
	private String transactionAmount;
	private String createdBy;
	private Timestamp createdTimeStamp;
	private String lastModifiedBy;
	private Timestamp lastModifiedTimeStamp;
	private String transHashString;
	private String recordNumber;
	
	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}
	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @return the debitorAccountId
	 */
	public String getDebitorAccountId() {
		return debitorAccountId;
	}
	/**
	 * @return the trustedSource
	 */
	public String getTrustedSource() {
		return trustedSource;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @return the transactionAmount
	 */
	public String getTransactionAmount() {
		return transactionAmount;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	/**
	 * @return the transHashString
	 */
	public String getTransHashString() {
		return transHashString;
	}
	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @param debitorAccountId the debitorAccountId to set
	 */
	public void setDebitorAccountId(String debitorAccountId) {
		this.debitorAccountId = debitorAccountId;
	}
	/**
	 * @param trustedSource the trustedSource to set
	 */
	public void setTrustedSource(String trustedSource) {
		this.trustedSource = trustedSource;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @param transactionAmount the transactionAmount to set
	 */
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @param transHashString the transHashString to set
	 */
	public void setTransHashString(String transHashString) {
		this.transHashString = transHashString;
	}
	/**
	 * @return the pfiTransactionId
	 */
	public Integer getPfiTransactionId() {
		return pfiTransactionId;
	}
	/**
	 * @return the srcPaymentFileId
	 */
	public Integer getSrcPaymentFileId() {
		return srcPaymentFileId;
	}
	/**
	 * @return the segregatorFileId
	 */
	public Integer getSegregatorFileId() {
		return segregatorFileId;
	}
	/**
	 * @return the transValueDate
	 */
	public Timestamp getTransValueDate() {
		return transValueDate;
	}
	/**
	 * @return the createdTimeStamp
	 */
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	/**
	 * @return the lastModifiedTimeStamp
	 */
	public Timestamp getLastModifiedTimeStamp() {
		return lastModifiedTimeStamp;
	}
	/**
	 * @param pfiTransactionId the pfiTransactionId to set
	 */
	public void setPfiTransactionId(Integer pfiTransactionId) {
		this.pfiTransactionId = pfiTransactionId;
	}
	/**
	 * @param srcPaymentFileId the srcPaymentFileId to set
	 */
	public void setSrcPaymentFileId(Integer srcPaymentFileId) {
		this.srcPaymentFileId = srcPaymentFileId;
	}
	/**
	 * @param segregatorFileId the segregatorFileId to set
	 */
	public void setSegregatorFileId(Integer segregatorFileId) {
		this.segregatorFileId = segregatorFileId;
	}
	/**
	 * @param transValueDate the transValueDate to set
	 */
	public void setTransValueDate(Timestamp transValueDate) {
		this.transValueDate = transValueDate;
	}
	/**
	 * @param createdTimeStamp the createdTimeStamp to set
	 */
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	/**
	 * @param lastModifiedTimeStamp the lastModifiedTimeStamp to set
	 */
	public void setLastModifiedTimeStamp(Timestamp lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}
	public String getRecordNumber() {
		return recordNumber;
	}
	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}
}
