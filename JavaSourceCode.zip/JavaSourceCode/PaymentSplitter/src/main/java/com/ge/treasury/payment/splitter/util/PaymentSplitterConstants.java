package com.ge.treasury.payment.splitter.util;

public class PaymentSplitterConstants {

	public class PaymentConstants{
		public static final String TSA_TRANSACTION_INDEX_KEY 		= "TSA_TRANSACTION_IDX_KEY";
		public static final String TSA_TRANSACTION_MAP_KEY 			= "TSA_TRANSACTION_MAP_KEY";
		public static final String NON_TSA_TRANSACTION_INDEX_KEY 	= "NONTSA_TRANSACTION_IDX_KEY";
		
		public static final String TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY 	= "TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY";
		public static final String NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY 	= "NONTSA_TRANSACTION_MAPPER_BEAN_LISTKEY";
		public static final String TSA_INSTANCE_ID_LIST_KEY 				= "TSA_INSTANCE_ID_LIST_KEY";
		
		public static final String ACCOUNT_ID_INPUT_PARAM_KEY	 	= "accountIDList";
		public static final String MODEL_ID_INPUT_PARAM_KEY		 	= "modelIDList";
		public static final String TRANSACTIONS_STRING     		 	= "TRANSACTIONS_STRING_KEY";
	}
	
	public class GenericConstants{
		public static final String IS_TSA_TRANSACTION		 		= "true";
		public static final String NOT_APPLICABLE				 	= "NA";
		public static final String DEFAULT_SSO					 	= "221032396";
		
		public static final String ACCOUNT_INFO_MAP_KEY			 	= "221032396";
		public static final String ACCOUNT_INFO_LIST_MAP_KEY	 	= "221032396";
	}
	
	public class LookUpServiceConstants{
		public static final String ACCOUNT_INFO_MAP_KEY			 	= "accountIinfoMap";
		public static final String ACCOUNT_INFO_LIST_MAP_KEY	 	= "accountInfoListMap";
		public static final String MODEL_INFO_MAP_KEY			 	= "modelIinfoMap";
		public static final String MODEL_INFO_LIST_MAP_KEY	 		= "modelInfoListMap";
	}
	
	public class TransactionElementConstants{
		public static final String TRANSACTION_ELEMENT		 		= "Transaction";
		public static final String TRANSACTION_TYPE_ELEMENT		 	= "Transaction_Type";
		public static final String TEXT_ELEMENT		 				= "#text";
		public static final String MODEL_INFO_ELEMENT		 		= "Model_Info";
		public static final String MODEL_ID_ELEMENT		 			= "Model_ID";
		public static final String BANK_ACCOUNT_ELEMENT		 		= "Bank_Account";
		public static final String BANK_ACCOUNT_TYPE_ELEMENT		= "Bank_Account_Type";
		public static final String ACCOUNT_ID_ELEMENT		 		= "Account_ID";
		public static final String ACCOUNT_NUMBER_ELEMENT		 	= "Account_Number";
		public static final String DEBIT_ELEMENT		 			= "DR";
		public static final String ACCOUNT_ELEMENT		 			= "Account";
		public static final String AMOUNT_ELEMENT		 			= "Amount";
		public static final String CURRENCY_ELEMENT		 			= "Currency";
		public static final String TRUSTED_SOURCE_ELEMENT		 	= "Trusted_Source";
		public static final String VALUE_DATE_ELEMENT		 		= "Value_Date";
		public static final String TOTAL_RECORD_ELEMENT		 		= "Total_Records";
		public static final String RECORD_NUMBER		 			= "Record_Number";
	}
	
	
	public class MailSubjectConstants{
		public static final String SUB_XML_READER_INITLIZE_FAILED		 		= "Initilization of Document Failed";
		public static final String SUB_READING_INPUT_PARAM_FOR_LOOKUP	 		= "Reading of input parameter for Lookup Service Failed";
		public static final String SUB_SP_CALLING_FAILED				 		= "Execution of Stored Procedure is Failed";
		public static final String SUB_TSA_NONTSA_RECORD_DETAIL_FAILED			= "Reading of TSA and NONTSA Record from file Failed";
		public static final String SUB_PAYMENT_SPLITTING_PROCESS_FAILED			= "Payment splitting process Failed";
		public static final String SUB_TRANSACTION_COUNT_MISMATCH_ERROR			= "Source and generated file transaction is not matching";
		public static final String SUB_ENCRYPTION_DECRYPTION_FAILED				= "Encryption/Decryption process Failed";
	}
	
	public class FileConstants{
		public static final String FILE_CREATION_TIME		 			= "creationTime";
		public static final String FILE_LAST_MODIFIED_TIME		 		= "lastModifiedTime";
		public static final String FILE_CHECK_SUM_ALGORITHM		 		= "MD5";
		public static final String ENCRYPTED_FILE_EXTENSION		 		= ".pgp";
		
		public static final String OPTION_ID_FROM_FILENAME		 		= "BusinessName";
		public static final String USER_ID_FROM_FILENAME		 		= "UserId";
		public static final String ORIGINAL_FILE_NAME_FROM_FILENAME		= "OrignalFileName";
		public static final String GWIX_UNIQUE_ID_FROM_FILENAME	 		= "GwixUniqueId";
	}
	
	public class FileStatusConstants{
		public static final String FILE_STATUS_READY_FOR_SPLIT		 							= "PFIReadyForSplit";
		public static final String FILE_STATUS_SPLIT_IN_PROGRESS	 							= "PFISplitInProgress";
		public static final String FILE_STATUS_SPLIT_COMPLETED		 							= "PFISplitCompleted";
		public static final String FILE_STATUS_SPLIT_FAILED 		 							= "PFISplitFailed";
		public static final String FILE_STATUS_PFI_TRANSFER_COMPLETED							= "PFITransferCompleted";
		public static final String FILE_STATUS_PFITransferFailed								= "PFITransferFailed";
		public static final String FILE_STATUS_PFI_IMPORT_STATUS_RECEIVED						= "PFIImportStatusReceived";
		public static final String FILE_STATUS_PFI_IMPORT_STATUS_SENT_TO_BUSINESS_COMPLETE		= "PFIImportStatusSentToBusinessCompleted";
		public static final String FILE_STATUS_PFI_IMPORT_STATUT_SENT_TO_BUSINESS_FAILED		= "PFIImportStatusSentToBusinessFailed";
		public static final String FILE_STATUS_SPLIT_FILE_READY_TO_TRANSFER						= "SplitFileReadyToTransfer";				
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_CMM_COMPLETE				= "SplitFileTransferToCMMCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_CMM_FAILED				= "SplitFileTransferToCMMFailed";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_COMPLETE				= "SplitFileTransferToWCCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_FAILED					= "SplitFileTransferToWCFailed";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_COMPLETE		= "SplitFileTransferToTSAInstanceCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED		= "SplitFileTransferToTSAInstanceFailed";
	}
	
}
