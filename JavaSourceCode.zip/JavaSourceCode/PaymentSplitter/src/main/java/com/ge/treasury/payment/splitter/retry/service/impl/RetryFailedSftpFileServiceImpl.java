package com.ge.treasury.payment.splitter.retry.service.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ge.treasury.payment.splitter.PaymentSplitterFileStatusLoader;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSegregatorFileMapper;
import com.ge.treasury.payment.splitter.retry.service.RertyFailedSftpFileService;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

@Component
public class RetryFailedSftpFileServiceImpl implements RertyFailedSftpFileService{
	final static Logger logger = Logger.getLogger(RetryFailedSftpFileServiceImpl.class);
	
	@Value("${encryptedServiceUrl}")
	private String encryptingService;
	
	@Autowired 
	PaymentSplitterPersistenceService fileDaoService;
	
	@Autowired 
	PaymentSplitterFileStatusLoader fileStatus;

	@Override
	public boolean sftpFailedFile(File sftpFile) {
		logger.info("[RetryFailedSftpFileServiceImpl] - Start retry process");
		Map<String,Object> retryFileDetails = new HashMap<String, Object>();
		
		//tsaOutPutFileName	= detailsFromFileName.get(tmpTSaInstanceId)+"_"+optionId+"_"+gwixUserId+"_"+orignalFileName+"_"+gwixUniqueId+".xml.pgp"; - manual
		//tsaOutPutFileName = detailsFromFileName.get(tmpTSaInstanceId)+"_"+optionId+"_"+orignalFileName+"_"+gwixUniqueId+".xml.pgp";   - client location
		
		String sourceFileName  = sftpFile.getName();
		String[] fileDetails   = sourceFileName.split("_");
		
		String tsaIdentifier = fileDetails[0];
		String optionId      = fileDetails[1];
		
		String key  = "";
		
		try{
			Integer.parseInt(fileDetails[2]);
			key = tsaIdentifier+"_"+optionId+"_"+fileDetails[2];
		}catch(Exception e){
			logger.info("[RetryFailedSftpFileServiceImpl] - not a manual location file");
			key = tsaIdentifier+"_"+optionId;
		}
		
		//TSAID_OPTIONID_USERID as key
		retryFileDetails.put(key, sftpFile.getAbsolutePath());
		boolean fileTransferStatus = transaferFilesToSftpLocation(retryFileDetails,tsaIdentifier, sftpFile.getName());
		
		logger.info("[RetryFailedSftpFileServiceImpl] - Finish retry process");
		return fileTransferStatus;
	}
	
	
	
	@SuppressWarnings("unchecked")
	private boolean transaferFilesToSftpLocation(Map<String,Object> transferFileDetails, String tsaIdentifier, String retryFileName){
		logger.info("[RetryFailedSftpFileServiceImpl] - sftp transfer process start");
		WebcashTsaSegregatorFileMapper fileMapperBean = new WebcashTsaSegregatorFileMapper();
		RestTemplate restTemplate	= new RestTemplate();
		Timestamp defaultTimeStamp 	= new Timestamp(System.currentTimeMillis());
		Integer fileStatusRecived 	= fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED);
		boolean fileSftpSuccess 	= false;
		try{
			
			fileMapperBean.setLastModifiedTimeStamp(defaultTimeStamp);
			fileMapperBean.setSegregatorFileName(retryFileName);
			String tsaInstanceId = fileDaoService.getTsaInstanceId(tsaIdentifier);
			fileMapperBean.setTsaInstanceId(Integer.parseInt(tsaInstanceId));
			
			Map<String, Object> resultMapData = null;
			
			try{
				 resultMapData =  restTemplate.postForObject(encryptingService, transferFileDetails, Map.class);
			}catch(Exception e){
				logger.error("[RetryFailedSftpFileServiceImpl] - sftp retry process failed");
				logger.error(PaymentSplitterUtility.getErrorFormStackTrace(e));
			}
			
			if( resultMapData != null && resultMapData.size() > 0){
				for(String tsaId : resultMapData.keySet()){
					String fileSentStatus 	= (String)resultMapData.get(tsaId);
					if( fileSentStatus != null && fileSentStatus.equalsIgnoreCase("Success")){
						fileStatusRecived = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_COMPLETE);
						fileSftpSuccess = true;
						break;
					}else{
						fileStatusRecived = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED);
					}
				}
			}
			
			fileMapperBean.setFileStatusId(fileStatusRecived);
		
			fileDaoService.updRetryFileDetails(fileMapperBean);
		}catch(Exception e){
			logger.error("[RetryFailedSftpFileServiceImpl] - error while updating segregated file sending status");
			logger.error("[RetryFailedSftpFileServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
		}
		logger.info("[RetryFailedSftpFileServiceImpl] - sftp transfer process ends");
		return fileSftpSuccess;
	}

}
