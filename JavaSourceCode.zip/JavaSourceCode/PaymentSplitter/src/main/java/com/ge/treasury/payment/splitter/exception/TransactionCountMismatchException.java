package com.ge.treasury.payment.splitter.exception;

public class TransactionCountMismatchException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3473867722320481035L;
	private String message;
	private Exception ex;
	
	public TransactionCountMismatchException(String msg){
		super(msg);
		this.message = msg;
	}
	
	public TransactionCountMismatchException(String msg, Exception ex){
		super(msg,ex);
		this.message = msg;
		this.ex      = ex;
		this.ex.initCause(new Throwable(msg));
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	
	/**
	 * @return the ex
	 */
	public Exception getEx() {
		return ex;
	}
	
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @param ex the ex to set
	 */
	public void setEx(Exception ex) {
		this.ex = ex;
	}
}
