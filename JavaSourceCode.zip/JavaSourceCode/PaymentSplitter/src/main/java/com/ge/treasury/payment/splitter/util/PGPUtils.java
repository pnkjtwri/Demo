package com.ge.treasury.payment.splitter.util;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Iterator;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.PublicKeyAlgorithmTags;
import org.bouncycastle.bcpg.sig.KeyFlags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedData;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRing;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPSignature;
import org.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;

public class PGPUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(PGPUtils.class);

    //private static final int   BUFFER_SIZE = 1 << 16; // should always be power of 2
    private static final int   KEY_FLAGS = 27;
    private static final int[] MASTER_KEY_CERTIFICATION_TYPES = new int[]{
    	PGPSignature.POSITIVE_CERTIFICATION,
    	PGPSignature.CASUAL_CERTIFICATION,
    	PGPSignature.NO_CERTIFICATION,
    	PGPSignature.DEFAULT_CERTIFICATION
    };

    @SuppressWarnings("unchecked")
    public static PGPPublicKey readPublicKey(InputStream in) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - readPublicKey: entered");
    	PGPPublicKey publicKey = null;
    	try{
	    	PGPPublicKeyRingCollection keyRingCollection = new PGPPublicKeyRingCollection(PGPUtil.getDecoderStream(in));
	
	        //
	        // we just loop through the collection till we find a key suitable for encryption, in the real
	        // world you would probably want to be a bit smarter about this.
	        // iterate through the key rings.
	        //
	        Iterator<PGPPublicKeyRing> rIt = keyRingCollection.getKeyRings();
	
	        while (publicKey == null && rIt.hasNext()) {
	            PGPPublicKeyRing kRing = rIt.next();
	            Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
	            while (publicKey == null && kIt.hasNext()) {
	                PGPPublicKey key = kIt.next();
	                if (key.isEncryptionKey()) {
	                    publicKey = key;
	                }
	            }
	        }
	
	        if (publicKey == null) {
	        	logger.error("[PGPUtils] - Can't find public key in the key ring. Encryption process is failed due to key file is not found.");
	            throw new IllegalArgumentException("Can't find public key in the key ring. Encryption process is failed due to key file is not found.");
	        }
	        if (!isForEncryption(publicKey)) {
	        	logger.error("[PGPUtils] - KeyID"  + publicKey.getKeyID() +  "not flagged for encryption. Key file is not generated with the valid key algorithm, like RSA,DSA,EC or ECDSA.");
	            throw new IllegalArgumentException("KeyID " + publicKey.getKeyID() + " not flagged for encryption. Key file is not generated with the valid key algorithm, like RSA,DSA,EC or ECDSA.");
	        }
    	}catch(Exception e){
    		logger.error("[PGPUtils] - Encryption process Failed !!");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
            throw new FileEncryptionDecryptionException("Encryption process is failed.",e);
    	}
    	logger.info("[PGPUtils] - readPublicKey: completed !!");
        return publicKey;
    }

    @SuppressWarnings("unchecked")
	public static PGPSecretKey readSecretKey(InputStream in) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - readSecretKey: entered");
    	PGPSecretKey secretKey = null;
    	try{
        PGPSecretKeyRingCollection keyRingCollection = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(in));

        //
        // We just loop through the collection till we find a key suitable for signing.
        // In the real world you would probably want to be a bit smarter about this.
        //
        Iterator<PGPSecretKeyRing> rIt = keyRingCollection.getKeyRings();
        while (secretKey == null && rIt.hasNext()) {
            PGPSecretKeyRing keyRing = rIt.next();
            Iterator<PGPSecretKey> kIt = keyRing.getSecretKeys();
            while (secretKey == null && kIt.hasNext()) {
                PGPSecretKey key = kIt.next();
                if (key.isSigningKey()) {
                    secretKey = key;
                }
            }
        }

        // Validate secret key
        if (secretKey == null) {
        	logger.error("[PGPUtils] - Can't find private key in the key ring.");
            throw new IllegalArgumentException("Can't find private key in the key ring.");
        }
        if (!secretKey.isSigningKey()) {
        	logger.error("[PGPUtils] - Private key does not allow signing.");
            throw new IllegalArgumentException("Private key does not allow signing.");
        }
        if (secretKey.getPublicKey().isRevoked()) {
        	logger.error("[PGPUtils] - Private key has been revoked.");
            throw new IllegalArgumentException("Private key has been revoked.");
        }
        if (!hasKeyFlags(secretKey.getPublicKey(), KeyFlags.SIGN_DATA)) {
        	logger.error("[PGPUtils] - Key cannot be used for signing.");
            throw new IllegalArgumentException("Key cannot be used for signing.");
        }
    	}catch(Exception e){
    		logger.error("[PGPUtils] - Decryption process Failed !!");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
            throw new FileEncryptionDecryptionException("Decryption process is failed.",e);
    	}
        logger.info("[PGPUtils] - readSecretKey: Completed !!");
        return secretKey;
    }

    /**
     * Load a secret key ring collection from keyIn and find the private key corresponding to
     * keyID if it exists.
     *
     * @param keyIn input stream representing a key ring collection.
     * @param keyID keyID we want.
     * @param pass passphrase to decrypt secret key with.
     * @return
     * @throws IOException
     * @throws PGPException
     * @throws NoSuchProviderException
     */
    public  static PGPPrivateKey findPrivateKey(InputStream keyIn, long keyID, char[] pass) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - findPrivateKey started..");
    	PGPPrivateKey pgpPvtKey = null;
    	try{
	        PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn));
	        pgpPvtKey = findPrivateKey(pgpSec.getSecretKey(keyID), pass);
    	}catch(Exception e){
    		logger.error("[PGPUtils] - findPrivateKey method has exception !!");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
            throw new FileEncryptionDecryptionException("Private Key have some issue",e);
    	}
    	logger.info("[PGPUtils] - findPrivateKey Completed !!..");
        return pgpPvtKey;

    }

    /**
     * Load a secret key and find the private key in it
     * @param pgpSecKey The secret key
     * @param pass passphrase to decrypt secret key with
     * @return
     * @throws PGPException
     */
    public static PGPPrivateKey findPrivateKey(PGPSecretKey pgpSecKey, char[] pass) throws FileEncryptionDecryptionException{
    	if (pgpSecKey == null) return null;
    	 PGPPrivateKey pgpPvtKey = null;
    	 try{
	        PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(pass);
	        pgpPvtKey = pgpSecKey.extractPrivateKey(decryptor);
    	 }catch(Exception e){
    		 throw new FileEncryptionDecryptionException("Private Key have some issue",e);
    	 }
        return pgpPvtKey;
    }

    /**
     * decrypt the passed in message stream
     * @param writeToFile 
     * @throws IOException 
     * @throws PGPException 
     */
    @SuppressWarnings("null")
	public static void decryptFile(InputStream in, StringBuffer decryptedData, InputStream keyIn, char[] passwd, String outputFileName) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - Decrypting Process started...");
    	try{
	    	Security.addProvider(new BouncyCastleProvider()); 
	        PGPObjectFactory pgpF = null;   
	        Object o = validPGPAlgorithm(in,pgpF);
	        PGPSecurity psec=new PGPSecurity();
	        // the first object might be a PGP marker packet.
	        if (o instanceof  PGPEncryptedDataList) {
	            psec.setEncryptedData ((PGPEncryptedDataList) o); 
	        } else {
	        	 psec.setEncryptedData ((PGPEncryptedDataList) pgpF.nextObject());
	        } 
	        validatePrivateKey(psec,keyIn,passwd);
	        if(psec.getSecretKey()!=null){
	        	writeFileContent(psec.getPkEncryptedData(),psec.getSecretKey(),decryptedData,outputFileName);
	        }
	        logger.info("[PGPUtils] - Decrypting Process completed !!");
    	}catch(Exception e){
    		logger.info("[PGPUtils] - Error while decrypting file ");
    		throw new FileEncryptionDecryptionException("Not able to Decrypt the file - ",e);
    	}
    }

    /**
     * decrypt the passed in message stream
     * @param writeToFile 
     * @throws IOException 
     * @throws PGPException 
     */
   /* @SuppressWarnings("unchecked")
	public static void decryptFile(InputStream in, OutputStream out, InputStream keyIn, char[] passwd) throws IOException, PGPException
    {
    	Security.addProvider(new BouncyCastleProvider()); 
    	
        PGPObjectFactory pgpF =null;   

        Object o = validPGPAlgorithm(in,pgpF);
        
        PGPSecurity psec=new PGPSecurity();

        // the first object might be a PGP marker packet.
        if (o instanceof  PGPEncryptedDataList) {
            psec.setEncryptedData ((PGPEncryptedDataList) o); 
        } else {
        	 psec.setEncryptedData ((PGPEncryptedDataList) pgpF.nextObject());
        } 
       
        validatePrivateKey(psec,keyIn,passwd);
        
        if(psec.getSecretKey()!=null){
        	writeFileContent(out,psec.getPkEncryptedData(),psec.getSecretKey());
        }
    }*/

    /*private static void writeFileContent(OutputStream out,
			PGPPublicKeyEncryptedData pbe, PGPPrivateKey sKey) throws PGPException, IOException {
    	logger.debug("writeFileContent: entered");
    	
    	System.out.println("Key Alogorithm:"+pbe.getSymmetricAlgorithm(new BcPublicKeyDataDecryptorFactory(sKey)));
		
    	InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));

        PGPObjectFactory plainFact = new PGPObjectFactory(clear);

        Object message = plainFact.nextObject();

        if (message instanceof  PGPCompressedData) {
            PGPCompressedData cData = (PGPCompressedData) message;
            PGPObjectFactory pgpFact = new PGPObjectFactory(cData.getDataStream()); 
            message = pgpFact.nextObject();
        }

        if (message instanceof  PGPLiteralData) { 
	            PGPLiteralData ld = (PGPLiteralData) message;
	
	            InputStream unc = ld.getInputStream();
	            int ch;
	            
		         while ((ch = unc.read()) >= 0) {
		                out.write(ch);
		               
		         }
        } else if (message instanceof  PGPOnePassSignatureList) {
            throw new PGPException("Encrypted message contains a signed message - not literal data.");
        } else {
            throw new PGPException("Message is not a simple encrypted file - type unknown.");
        }

        if (pbe.isIntegrityProtected()) {
            if (!pbe.verify()) {
            	throw new PGPException("Message failed integrity check");
            }
        } 
        logger.debug("writeFileContent: exit");
		
	}*/

	/**
     * 
     * @param psec
     * @param keyIn
     * @param passwd
     * @throws PGPFileDecryptException
     */
    private static void validatePrivateKey( PGPSecurity psec, InputStream keyIn, char[] passwd) throws FileEncryptionDecryptionException {
    	logger.info("[PGPUtils] - validatePrivateKey:entered");
    	// find the secret key
        @SuppressWarnings("unchecked")
		Iterator<PGPPublicKeyEncryptedData> it = psec.getEncryptedData().getEncryptedDataObjects(); 
        
        PGPPrivateKey sKey=null;
        PGPPublicKeyEncryptedData pbe=null;
        while (sKey == null && it.hasNext()) {
            pbe = it.next(); 
            try {
				sKey = findPrivateKey(keyIn, pbe.getKeyID(), passwd); 
			} catch (Exception e) {
				throw new FileEncryptionDecryptionException("Secret key for message not found or invalid secret key.",e);
			}
        }

        if (sKey == null) { 
            throw new FileEncryptionDecryptionException("Secret key for message not found or invalid secret key.");
        } 

        psec.setPkEncryptedData(pbe);
        psec.setSecretKey(sKey); 
        
        logger.info("[PGPUtils] - validatePrivateKey completed !!");
	}

    /**
     * 
     * @param pbe
     * @param sKey
     * @param out
     * @throws PGPException
     * @throws IOException
     */
	private static void writeFileContent(PGPPublicKeyEncryptedData pbe, PGPPrivateKey sKey,StringBuffer decryptedData,String outputFileName) throws FileEncryptionDecryptionException {
		logger.info("[PGPUtils] - writing File Content  started..");
		BufferedWriter bw = null;
		FileWriter fw     = null;
		InputStream unc = null;
		try{
    	InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
        PGPObjectFactory plainFact = new PGPObjectFactory(clear);
        Object message = plainFact.nextObject();

        if (message instanceof  PGPCompressedData) {
            PGPCompressedData cData = (PGPCompressedData) message;
            PGPObjectFactory pgpFact = new PGPObjectFactory(cData.getDataStream()); 
            message = pgpFact.nextObject();
        }
        
        File file = new File(outputFileName);
        fw = new FileWriter(file.getAbsoluteFile());
		bw = new BufferedWriter(fw);
		
        if (message instanceof  PGPLiteralData) { 
            PGPLiteralData ld = (PGPLiteralData) message;

            unc = ld.getInputStream();
            int ch;
            
	         while ((ch = unc.read()) >= 0) {
	        	//out.write(ch);
	            decryptedData.append((char)ch);
	            bw.write((char)ch);
	         }
        } else if (message instanceof  PGPOnePassSignatureList) {
        	unc.close();
        	bw.close();
        	fw.close();
            throw new FileEncryptionDecryptionException("Encrypted message contains a signed message - not literal data.");
        } else {
        	unc.close();
        	bw.close();
        	fw.close();
            throw new FileEncryptionDecryptionException("Message is not a simple encrypted file - type unknown.");
        }

        if (pbe.isIntegrityProtected()) {
            if (!pbe.verify()) {
            	bw.close();
            	fw.close();
            	throw new FileEncryptionDecryptionException("Message failed integrity check");
            }
        } 
        bw.close();
    	fw.close();
		}catch(Exception e){
			logger.error("[PGPUtils] - Writing content into the file has been failed.");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new FileEncryptionDecryptionException("Writing content into the file has been failed",e);
		}
		finally{
			try{
			if(unc != null){
				unc.close();
			}
			if(bw != null){
				bw.close();
			}
			if(fw != null){
				fw.close();
			}
			}catch(Exception e){
				logger.error("[PGPUtils] - Error while closing stream while writing content.");
	    		logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			}
		}
    	logger.info("[PGPUtils] - writing File Content  started..");
	}

	/**
     * 
     * @param in
     * @param pgpF
     * @return
     * @throws PGPFileDecryptException
     */
    private static Object validPGPAlgorithm(InputStream in,PGPObjectFactory pgpF) throws FileEncryptionDecryptionException {  
    	logger.debug("validPGPAlgorithm: entered");
    	 Object obj =null; 
    	 try {
			in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);
			
			pgpF = new PGPObjectFactory(in); 

	        obj = pgpF.nextObject(); 
	        
	        if(obj == null){
	        	throw new FileEncryptionDecryptionException("File is not encrypted or it is empty");
	        } 
	        
		} catch (IOException ie) {
			throw new FileEncryptionDecryptionException(ie.getMessage());
		}
    	 logger.debug("validPGPAlgorithm: exit");
    	 return obj;
	}

    /**
     * Method to identify whether file is encrypted or not.
     * @param in
     * @param keyIn
     * @param pubKeyIn
     * @param passwd
     * @throws IOException
     * @throws PGPException
     */
	 /*public static void verifyFileForEncryption(InputStream in, InputStream keyIn, InputStream pubKeyIn,char[] passwd) throws FileEncryptionDecryptionException{
		 
		logger.debug("verifyFileForEncryption: entered");
		 
		Security.addProvider(new BouncyCastleProvider());

		PGPObjectFactory pgpF = null;

		Object o = validPGPAlgorithm(in, pgpF);

		PGPSecurity psec = new PGPSecurity();

		// the first object might be a PGP marker packet.
		if (o instanceof PGPEncryptedDataList) {
			psec.setEncryptedData((PGPEncryptedDataList) o);
		} else {
			psec.setEncryptedData((PGPEncryptedDataList) pgpF.nextObject());
		}

		validatePrivateKey(psec, keyIn, passwd);
		PGPPublicKey pKey=readPublicKey(pubKeyIn);
		if(pKey!=null && pKey.getAlgorithm() != PublicKeyAlgorithmTags.RSA_ENCRYPT){
			throw new PGPFileDecryptException("Provider is not using valid key algorithm",604);
		}
		
		logger.debug("verifyFileForEncryption: exit");
	  }*/
	 
	public static void encryptFile(OutputStream out, File fileName, PGPPublicKey encKey, boolean armor, boolean withIntegrityCheck) throws FileEncryptionDecryptionException{
		logger.info("[PGPUtils] - Encrypting file process started..");
		OutputStream cOut = null;
		ByteArrayOutputStream bOut = null;
		try{
	    	Security.addProvider(new BouncyCastleProvider());
	
	        if (armor) {
	            out = new ArmoredOutputStream(out);
	        }
	
	        bOut = new ByteArrayOutputStream();
	        PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZIP);
	
	        PGPUtil.writeFileToLiteralData(comData.open(bOut), PGPLiteralData.BINARY, fileName );
	
	        comData.close();
	
	        BcPGPDataEncryptorBuilder dataEncryptor = new BcPGPDataEncryptorBuilder(PGPEncryptedData.AES_128);
	        dataEncryptor.setWithIntegrityPacket(withIntegrityCheck);
	        dataEncryptor.setSecureRandom(new SecureRandom());
	
	        PGPEncryptedDataGenerator encryptedDataGenerator = new PGPEncryptedDataGenerator(dataEncryptor);
	        encryptedDataGenerator.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));
	
	        byte[] bytes = bOut.toByteArray();
	        cOut = encryptedDataGenerator.open(out, bytes.length);
	        cOut.write(bytes);
	        cOut.close();
	        bOut.close();
	        out.close();
		}catch(Exception e){
			logger.error("[PGPUtils] - Error while encrypting the file.");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new FileEncryptionDecryptionException("Error while encrypting the file.",e);
		}finally{
			try{
				if(cOut != null){
					cOut.close();
				}
				if(bOut != null){
					bOut.close();
				}
				if(out != null){
					out.close();
				}
			}catch(Exception e){
				logger.error("[PGPUtils] - Error while closing stream while encrypting.");
	    		logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			}
		}
        logger.info("[PGPUtils] - Encrypting file process completed !!");
    } 
	
    /**
     * From LockBox Lobs PGP Encryption tools.
     * http://www.lockboxlabs.org/content/downloads
     *
     * I didn't think it was worth having to import a 4meg lib for three methods
     * @param key
     * @return
     */
    public static boolean isForEncryption(PGPPublicKey key)
    {
        if (key.getAlgorithm() == PublicKeyAlgorithmTags.RSA_SIGN
            || key.getAlgorithm() == PublicKeyAlgorithmTags.DSA
            || key.getAlgorithm() == PublicKeyAlgorithmTags.EC
            || key.getAlgorithm() == PublicKeyAlgorithmTags.ECDSA)
        {
            return false;
        }

        return hasKeyFlags(key, KeyFlags.ENCRYPT_COMMS | KeyFlags.ENCRYPT_STORAGE);
    }

    /**
     * From LockBox Lobs PGP Encryption tools.
     * http://www.lockboxlabs.org/content/downloads
     *
     * I didn't think it was worth having to import a 4meg lib for three methods
     * @param key
     * @return
     */
    @SuppressWarnings("unchecked")
	private static boolean hasKeyFlags(PGPPublicKey encKey, int keyUsage) {
        if (encKey.isMasterKey()) {
            for (int i = 0; i != PGPUtils.MASTER_KEY_CERTIFICATION_TYPES.length; i++) {
                for (Iterator<PGPSignature> eIt = encKey.getSignaturesOfType(PGPUtils.MASTER_KEY_CERTIFICATION_TYPES[i]); eIt.hasNext();) {
                    PGPSignature sig = eIt.next();
                    if (!isMatchingUsage(sig, keyUsage)) {
                        return false;
                    }
                }
            }
        }
        else {
            for (Iterator<PGPSignature> eIt = encKey.getSignaturesOfType(PGPSignature.SUBKEY_BINDING); eIt.hasNext();) {
                PGPSignature sig = eIt.next();
                if (!isMatchingUsage(sig, keyUsage)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * From LockBox Lobs PGP Encryption tools.
     * http://www.lockboxlabs.org/content/downloads
     *
     * I didn't think it was worth having to import a 4meg lib for three methods
     * @param key
     * @return
     */
    private static boolean isMatchingUsage(PGPSignature sig, int keyUsage) {
        if (sig.hasSubpackets()) {
            PGPSignatureSubpacketVector sv = sig.getHashedSubPackets();
            if (sv.hasSubpacket(PGPUtils.KEY_FLAGS)) {
                // code fix suggested by kzt (see comments)
                if ((sv.getKeyFlags() == 0 && keyUsage == 0)) {
                    return false;
                }
            }
        }
        return true;
    }

}
