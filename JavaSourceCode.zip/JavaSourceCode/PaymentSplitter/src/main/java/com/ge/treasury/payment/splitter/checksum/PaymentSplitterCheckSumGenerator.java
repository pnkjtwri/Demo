package com.ge.treasury.payment.splitter.checksum;

import java.io.File;

import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;

public interface PaymentSplitterCheckSumGenerator {
	public String getCheckSumValueForFile(File fileForCheckSum, String algorithm) throws FileHashingProcessException;
	public String getCheckSumValueForString(String sourceString, String algorithm) throws FileHashingProcessException;
	
	public boolean validateFileForCheckSum(String sourceFileGeneratedHashCode, File generatedFileForHashCheck, String algorithm) throws FileHashingProcessException;
}
