package com.ge.treasury.payment.splitter.exception;

public class XmlReaderServiceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5755188429783216150L;
	private String message;
	private Exception ex;
	
	/**
	 * @return the ex
	 */
	public Exception getEx() {
		return ex;
	}

	public XmlReaderServiceException(String msg){
		this.message = msg;
	}
	
	public XmlReaderServiceException(String msg, Exception ex){
		this.message = msg;
		this.ex      = ex;
	}

	
	/**
	 * @return the message
	 */
	public String getMessage() {
		return (String) (message + (ex.getMessage() != null ? ex.getMessage() : ex.getCause()));
	}
}
