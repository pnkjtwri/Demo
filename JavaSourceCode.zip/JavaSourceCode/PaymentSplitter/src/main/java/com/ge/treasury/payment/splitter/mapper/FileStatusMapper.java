package com.ge.treasury.payment.splitter.mapper;

public class FileStatusMapper {
	private String fileStatusId;
	private String fileStatusShortDesc;
	
	/**
	 * @return the fileStatusId
	 */
	public String getFileStatusId() {
		return fileStatusId;
	}
	/**
	 * @return the fileStatusShortDesc
	 */
	public String getFileStatusShortDesc() {
		return fileStatusShortDesc;
	}
	/**
	 * @param fileStatusId the fileStatusId to set
	 */
	public void setFileStatusId(String fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	/**
	 * @param fileStatusShortDesc the fileStatusShortDesc to set
	 */
	public void setFileStatusShortDesc(String fileStatusShortDesc) {
		this.fileStatusShortDesc = fileStatusShortDesc;
	}
}
