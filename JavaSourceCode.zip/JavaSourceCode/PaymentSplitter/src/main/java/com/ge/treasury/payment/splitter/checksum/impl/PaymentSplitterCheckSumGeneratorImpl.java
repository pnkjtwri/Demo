package com.ge.treasury.payment.splitter.checksum.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.splitter.checksum.PaymentSplitterCheckSumGenerator;
import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

@Component
public class PaymentSplitterCheckSumGeneratorImpl implements PaymentSplitterCheckSumGenerator {
	final static Logger logger = Logger.getLogger(PaymentSplitterCheckSumGeneratorImpl.class);
	@Override
	public String getCheckSumValueForFile(File fileForCheckSum, String algorithm) throws FileHashingProcessException{
		logger.info("[PaymentSplitterCheckSumGeneratorImpl] - Check sum process started for file - "+fileForCheckSum.getName()+" with algorithm - "+algorithm);
		String rtnHashString 		= null;
		FileInputStream inputStream = null;
		 try {
			 inputStream 	= new FileInputStream(fileForCheckSum);
			 MessageDigest digest 			= MessageDigest.getInstance(algorithm);
			 byte[] bytesBuffer 			= new byte[1024];
			 int bytesRead = -1;
			 
			 while ((bytesRead = inputStream.read(bytesBuffer)) != -1) {
				 digest.update(bytesBuffer, 0, bytesRead);
			 }
			 inputStream.close();
			 byte[] hashedBytes = digest.digest();
			 rtnHashString = convertByteArrayToHexString(hashedBytes);
		logger.info("[PaymentSplitterCheckSumGeneratorImpl] - Check sum process completed for file - "+fileForCheckSum.getName()+"!!");
		}catch (NoSuchAlgorithmException e) {
			logError(e);
			throw new FileHashingProcessException("Check Sum procees failed while generating hash for the file.",e);
		}catch (FileNotFoundException e) {
			logError(e);
			throw new FileHashingProcessException("Check Sum procees failed. Provided input file is not found.",e);
		}catch (IOException e) {
			logError(e);
			throw new FileHashingProcessException("Check sum process failed.",e);
		}finally{
			try{
				if(inputStream != null){
					inputStream.close();
				}
			}catch(Exception e){
				logger.error("Not able to close input stream.");
			}
		}
		logger.info(rtnHashString+" - Hash generated for the file - "+fileForCheckSum.getName()); 
		return rtnHashString;
	}

	@Override
	public String getCheckSumValueForString(String sourceString, String algorithm) throws FileHashingProcessException{
		 try {
				MessageDigest digest = MessageDigest.getInstance(algorithm);
				byte[] hashedBytes = digest.digest(sourceString.getBytes("UTF-8"));
				return convertByteArrayToHexString(hashedBytes);
			}catch (NoSuchAlgorithmException e) {
				logError(e);
				throw new FileHashingProcessException("Could not generate hash from String");
			} catch( UnsupportedEncodingException  e){
				logError(e);
				throw new FileHashingProcessException("Unsupported Encoding while generating hash check for string");
			}
	
	}
	
	
	private static String convertByteArrayToHexString(byte[] arrayBytes) {
	   	 logger.info("[PaymentSplitterCheckSumGeneratorImpl] - convert ByteArray to HexString");
	       StringBuffer stringBuffer = new StringBuffer();
	       for (int i = 0; i < arrayBytes.length; i++) {
	           stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
	       }
	       logger.info("[PaymentSplitterCheckSumGeneratorImpl] - ByteArray to HexString completed !!");
	       return stringBuffer.toString();
	}
	
	private void logError(Exception e){
		logger.error("[PaymentSplitterCheckSumGeneratorImpl] - Check sum process Failed !!");
		logger.error("[PaymentSplitterCheckSumGeneratorImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
	}

	@Override
	public boolean validateFileForCheckSum(String sourceFileGeneratedHashCode, File generatedFileForHashCheck, String algorithm) throws FileHashingProcessException {
		logger.info("[PaymentSplitterCheckSumGeneratorImpl] - validating check sum for generated file");
		boolean isCheckSumValueMatched = false;
		String hashCodeValueForGeneratedFile = getCheckSumValueForFile(generatedFileForHashCheck,algorithm);
		
		if(sourceFileGeneratedHashCode.equals(hashCodeValueForGeneratedFile)){
			isCheckSumValueMatched = true;
		}
		logger.info("[PaymentSplitterCheckSumGeneratorImpl] - validating check sum completed with isCheckSumValueMatched - "+isCheckSumValueMatched);
		return isCheckSumValueMatched;
	}

}
