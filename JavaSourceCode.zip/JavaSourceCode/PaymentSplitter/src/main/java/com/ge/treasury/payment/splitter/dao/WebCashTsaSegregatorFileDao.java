package com.ge.treasury.payment.splitter.dao;

import java.util.Map;

import com.ge.treasury.payment.splitter.mapper.WebcashTsaSegregatorFileMapper;


public interface WebCashTsaSegregatorFileDao {
	public Integer insertSegregatedFileDetail(WebcashTsaSegregatorFileMapper fileDetail);
	public Integer upddateSegregatedFileDetail(Map<Object, Object> param);
	public Integer updRetryFileStatus(WebcashTsaSegregatorFileMapper fileDetail);
}
