package com.ge.treasury.payment.splitter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.splitter.dao.PaymentSplitterFileStatusDao;
import com.ge.treasury.payment.splitter.mapper.FileStatusMapper;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;


/**
 * 
 * @author Ashutosh.Mishra
 *	This class will load the file status from the table
 *	T_WEBCASHTSA_FILESTATUS on the start up of the application.
 *
 *  getFileStatus method will return all the file status in a collection
 */
@Component
public class PaymentSplitterFileStatusLoader {
	final static Logger logger = Logger.getLogger(PaymentSplitterFileStatusLoader.class);
	private Map<String,Integer> fileStatus = null;
	@Autowired PaymentSplitterFileStatusDao fileStausDao;
	
	/**
	 * @return the fileStatus
	 */
	public final Integer getFileStatus(String fileStatusKey) {
		return fileStatus.get(fileStatusKey);
	}
	
	public final void initFileStatusLoader(){
		loadFileStatus();
	}
	
	private void loadFileStatus(){
		if(fileStatus == null){
			try{
				logger.info("[PaymentSplitterFileStatusLoader] - Loading file status...");
			
				fileStatus = new HashMap<String, Integer>();
				List<FileStatusMapper> fileStatusList = fileStausDao.getFileStatus();
				if(fileStatusList != null && fileStatusList.size() > 0){
					for(FileStatusMapper item :  fileStatusList) {
						fileStatus.put(item.getFileStatusShortDesc(), Integer.parseInt(item.getFileStatusId()));
					}
				}
				if(fileStatus== null || fileStatus.size() <= 0){
					logger.error("Not able to load file status. File status not found in data base.");
					throw new RuntimeException("Not able to load File status.");
				}
				logger.info("[PaymentSplitterFileStatusLoader] - File status loaded!!");
			}catch(Exception e){
				logger.error("Not able to load file status.");
				logger.error(PaymentSplitterUtility.getErrorFormStackTrace(e));
				throw new RuntimeException("Not able to load File status.");
			}
		}
	}
	
}
