package com.ge.treasury.payment.splitter.process.service;

import java.io.File;
import java.util.List;

import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;
import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;
import com.ge.treasury.payment.splitter.exception.TransactionCountMismatchException;
import com.ge.treasury.payment.splitter.exception.XmlReaderServiceException;

public interface PaymentSplitterService {
	public List<String> startPaymentSplitter(File inputFile) throws PaymentSplittingProcessException,TransactionCountMismatchException,FileEncryptionDecryptionException,XmlReaderServiceException,FileHashingProcessException,Exception;
}
