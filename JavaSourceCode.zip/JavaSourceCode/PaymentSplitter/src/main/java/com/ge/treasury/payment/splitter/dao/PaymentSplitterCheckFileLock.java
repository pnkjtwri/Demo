package com.ge.treasury.payment.splitter.dao;

import java.util.List;
import java.util.Map;

import com.ge.treasury.payment.splitter.mapper.TsaInstanceMapper;

public interface PaymentSplitterCheckFileLock {
	public Integer checkIsFileExists(String fileName);
	public void getFileLock(Map<String,Object> param);
	public void deleteLockedFileDetail(String fileName);
	
	/**TSA identifier mehtod*/
	public List<TsaInstanceMapper> getTsaIdentifier(List<String> tsaInstanceIdLst);
	public String getTsaInstanceId(String tsaIdentifier);
}
