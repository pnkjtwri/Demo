package com.ge.treasury.payment.splitter;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.jmx.config.EnableIntegrationMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;

@SpringBootApplication
@EnableAutoConfiguration
@EnableIntegrationMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
@ImportResource({"classpath:config/integrationContext.xml","classpath:config/datasource.xml"})
public class PaymentSplitterApplication extends SpringBootServletInitializer {
	final static Logger logger = Logger.getLogger(PaymentSplitterApplication.class);
	
	public static void main(String[] args) {
		logger.info("[PaymentSplitterApplication] - Going to load main method of Splitter");
		
		SpringApplication.run(PaymentSplitterApplication.class, args);
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
		defaultProperties.put("spring.config.location", "file:/app/tsaweb/properties/paymentsplitter/application.yml");
		return application.sources(PaymentSplitterApplication.class).properties(defaultProperties);
    }
}
