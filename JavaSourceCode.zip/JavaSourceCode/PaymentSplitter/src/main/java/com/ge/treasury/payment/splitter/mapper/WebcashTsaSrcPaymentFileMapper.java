package com.ge.treasury.payment.splitter.mapper;

import java.sql.Timestamp;

/**
 * this class is mapper with the data base table
 * T_WEBCASHTSA_SRC_PAYMENT_FILE
 * */
public class WebcashTsaSrcPaymentFileMapper {
	private Integer srcPaymentFileId;
	private String srcPaymentFileName;
	private String fileType;
	private String fileCreationModule;
	private String fileFormatVersion;
	private Integer trailerTotalRecords;
	private String trailerFileName;
	private String segregationFlag;
	private int fileStatusId;
	private String segregationStatusMessage;
	private Integer pfiBusinessId;
	private String createdBy;
	private Timestamp createdTimeStamp;
	private Timestamp srcFileCreationTimeStamp;
	private String lastModifiedBy;
	private Timestamp lastModifiedTimeStamp;
	private String xmlEncoding;
	private String hashString;
	
	
	/**
	 * @return the srcPaymentFileName
	 */
	public String getSrcPaymentFileName() {
		return srcPaymentFileName;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @return the fileCreationModule
	 */
	public String getFileCreationModule() {
		return fileCreationModule;
	}
	/**
	 * @return the fileFormatVersion
	 */
	public String getFileFormatVersion() {
		return fileFormatVersion;
	}
	/**
	 * @return the trailerFileName
	 */
	public String getTrailerFileName() {
		return trailerFileName;
	}
	/**
	 * @return the segregationFlag
	 */
	public String getSegregationFlag() {
		return segregationFlag;
	}
	/**
	 * @return the segregationStatusMessage
	 */
	public String getSegregationStatusMessage() {
		return segregationStatusMessage;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	/**
	 * @return the xmlEncoding
	 */
	public String getXmlEncoding() {
		return xmlEncoding;
	}
	/**
	 * @return the hashString
	 */
	public String getHashString() {
		return hashString;
	}
	/**
	 * @param srcPaymentFileName the srcPaymentFileName to set
	 */
	public void setSrcPaymentFileName(String srcPaymentFileName) {
		this.srcPaymentFileName = srcPaymentFileName;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @param fileCreationModule the fileCreationModule to set
	 */
	public void setFileCreationModule(String fileCreationModule) {
		this.fileCreationModule = fileCreationModule;
	}
	/**
	 * @param fileFormatVersion the fileFormatVersion to set
	 */
	public void setFileFormatVersion(String fileFormatVersion) {
		this.fileFormatVersion = fileFormatVersion;
	}
	/**
	 * @param trailerFileName the trailerFileName to set
	 */
	public void setTrailerFileName(String trailerFileName) {
		this.trailerFileName = trailerFileName;
	}
	/**
	 * @param segregationFlag the segregationFlag to set
	 */
	public void setSegregationFlag(String segregationFlag) {
		this.segregationFlag = segregationFlag;
	}
	/**
	 * @param segregationStatusMessage the segregationStatusMessage to set
	 */
	public void setSegregationStatusMessage(String segregationStatusMessage) {
		this.segregationStatusMessage = segregationStatusMessage;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @param xmlEncoding the xmlEncoding to set
	 */
	public void setXmlEncoding(String xmlEncoding) {
		this.xmlEncoding = xmlEncoding;
	}
	/**
	 * @param hashString the hashString to set
	 */
	public void setHashString(String hashString) {
		this.hashString = hashString;
	}
	/**
	 * @return the srcPaymentFileId
	 */
	public Integer getSrcPaymentFileId() {
		return srcPaymentFileId;
	}
	/**
	 * @return the trailerTotalRecords
	 */
	public Integer getTrailerTotalRecords() {
		return trailerTotalRecords;
	}
	/**
	 * @return the fileStatusId
	 */
	public int getFileStatusId() {
		return fileStatusId;
	}
	/**
	 * @return the pfiBusinessId
	 */
	public Integer getPfiBusinessId() {
		return pfiBusinessId;
	}
	/**
	 * @param srcPaymentFileId the srcPaymentFileId to set
	 */
	public void setSrcPaymentFileId(Integer srcPaymentFileId) {
		this.srcPaymentFileId = srcPaymentFileId;
	}
	/**
	 * @param trailerTotalRecords the trailerTotalRecords to set
	 */
	public void setTrailerTotalRecords(Integer trailerTotalRecords) {
		this.trailerTotalRecords = trailerTotalRecords;
	}
	/**
	 * @param fileStatusId the fileStatusId to set
	 */
	public void setFileStatusId(int fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	/**
	 * @param pfiBusinessId the pfiBusinessId to set
	 */
	public void setPfiBusinessId(Integer pfiBusinessId) {
		this.pfiBusinessId = pfiBusinessId;
	}
	/**
	 * @return the createdTimeStamp
	 */
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	/**
	 * @return the srcFileCreationTimeStamp
	 */
	public Timestamp getSrcFileCreationTimeStamp() {
		return srcFileCreationTimeStamp;
	}
	/**
	 * @return the lastModifiedTimeStamp
	 */
	public Timestamp getLastModifiedTimeStamp() {
		return lastModifiedTimeStamp;
	}
	/**
	 * @param createdTimeStamp the createdTimeStamp to set
	 */
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	/**
	 * @param srcFileCreationTimeStamp the srcFileCreationTimeStamp to set
	 */
	public void setSrcFileCreationTimeStamp(Timestamp srcFileCreationTimeStamp) {
		this.srcFileCreationTimeStamp = srcFileCreationTimeStamp;
	}
	/**
	 * @param lastModifiedTimeStamp the lastModifiedTimeStamp to set
	 */
	public void setLastModifiedTimeStamp(Timestamp lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}

}
