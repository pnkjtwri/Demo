package com.ge.treasury.payment.splitter.mapper;

import java.sql.Timestamp;

public class WebcashTsaSegregatorFileMapper {
	private Integer segregatorFileId;
	private Integer srcPaymentFileId;
	private String segregatorFileName;
	private String paymentInstType;
	private Integer noOfTransactions;
	private Integer tsaInstanceId;
	private String importStatusFileName;
	private Integer fileStatusId;
	private String createdBy;
	private Timestamp createdTimeStamp;
	private String lastModifiedBy;
	private Timestamp lastModifiedTimeStamp;
	private String hashString;
	
	/**
	 * @return the segregatorFileName
	 */
	public String getSegregatorFileName() {
		return segregatorFileName;
	}
	/**
	 * @return the paymentInstType
	 */
	public String getPaymentInstType() {
		return paymentInstType;
	}
	/**
	 * @return the importStatusFileName
	 */
	public String getImportStatusFileName() {
		return importStatusFileName;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	/**
	 * @return the hashString
	 */
	public String getHashString() {
		return hashString;
	}
	/**
	 * @param segregatorFileName the segregatorFileName to set
	 */
	public void setSegregatorFileName(String segregatorFileName) {
		this.segregatorFileName = segregatorFileName;
	}
	/**
	 * @param paymentInstType the paymentInstType to set
	 */
	public void setPaymentInstType(String paymentInstType) {
		this.paymentInstType = paymentInstType;
	}
	/**
	 * @param importStatusFileName the importStatusFileName to set
	 */
	public void setImportStatusFileName(String importStatusFileName) {
		this.importStatusFileName = importStatusFileName;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @param hashString the hashString to set
	 */
	public void setHashString(String hashString) {
		this.hashString = hashString;
	}
	/**
	 * @return the segregatorFileId
	 */
	public Integer getSegregatorFileId() {
		return segregatorFileId;
	}
	/**
	 * @return the srcPaymentFileId
	 */
	public Integer getSrcPaymentFileId() {
		return srcPaymentFileId;
	}
	/**
	 * @return the noOfTransactions
	 */
	public Integer getNoOfTransactions() {
		return noOfTransactions;
	}
	/**
	 * @return the tsaInstanceId
	 */
	public Integer getTsaInstanceId() {
		return tsaInstanceId;
	}
	/**
	 * @return the fileStatusId
	 */
	public Integer getFileStatusId() {
		return fileStatusId;
	}
	/**
	 * @return the createdTimeStamp
	 */
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	/**
	 * @return the lastModifiedTimeStamp
	 */
	public Timestamp getLastModifiedTimeStamp() {
		return lastModifiedTimeStamp;
	}
	/**
	 * @param segregatorFileId the segregatorFileId to set
	 */
	public void setSegregatorFileId(Integer segregatorFileId) {
		this.segregatorFileId = segregatorFileId;
	}
	/**
	 * @param srcPaymentFileId the srcPaymentFileId to set
	 */
	public void setSrcPaymentFileId(Integer srcPaymentFileId) {
		this.srcPaymentFileId = srcPaymentFileId;
	}
	/**
	 * @param noOfTransactions the noOfTransactions to set
	 */
	public void setNoOfTransactions(Integer noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}
	/**
	 * @param tsaInstanceId the tsaInstanceId to set
	 */
	public void setTsaInstanceId(Integer tsaInstanceId) {
		this.tsaInstanceId = tsaInstanceId;
	}
	/**
	 * @param fileStatusId the fileStatusId to set
	 */
	public void setFileStatusId(Integer fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	/**
	 * @param createdTimeStamp the createdTimeStamp to set
	 */
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	/**
	 * @param lastModifiedTimeStamp the lastModifiedTimeStamp to set
	 */
	public void setLastModifiedTimeStamp(Timestamp lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}
}
