package com.ge.treasury.payment.splitter.service.persist.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ge.treasury.payment.splitter.dao.PaymentSplitterCheckFileLock;
import com.ge.treasury.payment.splitter.dao.WebCashTsaPfiTransactionsDao;
import com.ge.treasury.payment.splitter.dao.WebCashTsaSegregatorFileDao;
import com.ge.treasury.payment.splitter.dao.WebCashTsaSrcPaymentFileDao;
import com.ge.treasury.payment.splitter.mapper.TsaInstanceMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaPfiTransactionsMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSegregatorFileMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;

@Component
public class PaymentSplitterPersistenceServiceImpl implements PaymentSplitterPersistenceService {
	final static Logger logger = Logger.getLogger(PaymentSplitterPersistenceServiceImpl.class);
	@Autowired WebCashTsaSrcPaymentFileDao srcFileDao;
	@Autowired WebCashTsaSegregatorFileDao fileSegregatorDao;
	@Autowired WebCashTsaPfiTransactionsDao transactionDao;
	@Autowired PaymentSplitterCheckFileLock checkFileLockDao;
	
	@Value("${transactionPersistInChunksOf}")
	private Integer persistInChunksOf;
	
	@Override
	@Transactional(rollbackFor={Exception.class})
	public Integer saveInputFileDetails(WebcashTsaSrcPaymentFileMapper fileDetails, String optionId) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Getting business id for option id - "+optionId);
		if(optionId != null && optionId.length() > 0){
			Integer businessId = srcFileDao.getBusinessId(optionId);
			fileDetails.setPfiBusinessId(businessId);
			logger.info("[PaymentSplitterDaoServiceImpl] - Business id is - "+businessId);
		}
		
		
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting source file details");
		srcFileDao.insertSrcPaymentFileDetail(fileDetails);
		logger.info("[PaymentSplitterDaoServiceImpl] - File Details saved !!");
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to save srcFileDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return fileDetails.getSrcPaymentFileId();
	}

	@Override
	public void updInputFileDetails(Map<String,Object> param) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - updating Src Payment File details");
		srcFileDao.upddateSrcPaymentFileDetail(param);
		logger.info("[PaymentSplitterDaoServiceImpl] - Src Payment File details Updated!!");
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to update srcFileDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
	}

	@Override
	@Transactional(rollbackFor={Exception.class})
	public Integer saveTransactionDetails(List<WebcashTsaPfiTransactionsMapper> transDetailList, String transactionHashCode,Integer srcPaymentFileId) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting source file transaction details");
		Map<Object, Object> param = new HashMap<Object, Object>();
		param.put("srcPaymentFileId", srcPaymentFileId);
		param.put("transactionHashCode", transactionHashCode);
		
		if(transDetailList != null){
			if(transDetailList.size() > persistInChunksOf.intValue()){
				int endIndex   = persistInChunksOf.intValue();
				//save chunk data
				for(int transPersist=0; transPersist < transDetailList.size(); ){
					logger.info("[PaymentSplitterDaoServiceImpl] - transaction chunk no - "+transPersist);
					List<WebcashTsaPfiTransactionsMapper> subTransactionList = null;
					if(endIndex > transDetailList.size()){
						subTransactionList = transDetailList.subList(transPersist, transDetailList.size());
					}else{
						subTransactionList = transDetailList.subList(transPersist, endIndex);
					}
					param.put("transactionsSubLst", subTransactionList);
					transactionDao.insertTransactionDetail(param);
					
					transPersist = endIndex;
					endIndex    += persistInChunksOf.intValue(); 
				}
				logger.info("[PaymentSplitterDaoServiceImpl] - Transaction inserted!!");
			}else{
				param.put("transactionsSubLst", transDetailList);
				transactionDao.insertTransactionDetail(param);
				logger.info("[PaymentSplitterDaoServiceImpl] - Transaction inserted!!");
			}
		}
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting source file transaction details completed !!");
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to saveTransactionDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return 0;
	}

	@Override
	/*@Transactional(rollbackFor={Exception.class})*/
	/*public void updTransactionDetails(List<WebcashTsaPfiTransactionsMapper> transactionDetailList, Integer ihbSegregatorFileId, Integer srcPaymentFileId) {*/
	public void updTransactionDetails(List<WebcashTsaPfiTransactionsMapper> transactionDetailList) {/*
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - updating transaction details");
		Timestamp defaultTime = new Timestamp(System.currentTimeMillis());
		Map<Object, Object> param = new HashMap<Object, Object>();
		param.put("srcPaymentFileId", srcPaymentFileId);
		param.put("ihbSegregatorFileId", ihbSegregatorFileId);
		param.put("modifiedTime", defaultTime);
		
		if(transactionDetailList != null){
			if(transactionDetailList.size() > persistInChunksOf.intValue()){
				int endIndex   = persistInChunksOf.intValue();
				//update chunk data
				for(int transPersist=0; transPersist < transactionDetailList.size(); ){
					logger.info("[PaymentSplitterDaoServiceImpl] - transaction chunk no - "+transPersist);
					List<WebcashTsaPfiTransactionsMapper> subTransactionList = null;
					if(endIndex > transactionDetailList.size()){
						subTransactionList = transactionDetailList.subList(transPersist, transactionDetailList.size());
					}else{
						subTransactionList = transactionDetailList.subList(transPersist, endIndex);
					}
					param.put("transactionsSubLst", subTransactionList);
					transactionDao.upddateTransactionDetail(param);
					
					transPersist = endIndex;
					endIndex    += persistInChunksOf.intValue(); 
				}
				logger.info("[PaymentSplitterDaoServiceImpl] - Transaction updated!!");
			}else{
				param.put("transactionsSubLst", transactionDetailList);
				transactionDao.upddateTransactionDetail(param);
				logger.info("[PaymentSplitterDaoServiceImpl] - Transaction updated!!");
			}
		}
		
		logger.info("[PaymentSplitterDaoServiceImpl] - Updating transaction completed!!");
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to updTransactionDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
	*/}

	@Override
	/*@Transactional(rollbackFor={Exception.class})*/
	public Integer saveFileSegregationDetails(WebcashTsaSegregatorFileMapper fileSegregatorDetails) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting segregated file details");
		fileSegregatorDao.insertSegregatedFileDetail(fileSegregatorDetails);
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting segregated file details completed !!");
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to saveFileSegregationDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return fileSegregatorDetails.getSegregatorFileId();
	}

	@Override
	public void updFileSegregationDetails(List<WebcashTsaSegregatorFileMapper> fileMapperList) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Persisting segregated file details");
		Map<Object, Object> param = new HashMap<Object, Object>();
		
		if(fileMapperList != null){
			if(fileMapperList.size() > persistInChunksOf.intValue()){
				int endIndex   = persistInChunksOf.intValue();
				//update chunk data
				for(int transPersist=0; transPersist < fileMapperList.size(); ){
					logger.info("[PaymentSplitterDaoServiceImpl] - segregated file updated - "+transPersist);
					List<WebcashTsaSegregatorFileMapper> subFileSegregatorList = null;
					if(endIndex > fileMapperList.size()){
						subFileSegregatorList = fileMapperList.subList(transPersist, fileMapperList.size());
					}else{
						subFileSegregatorList = fileMapperList.subList(transPersist, endIndex);
					}
					param.put("fileSegregatorList", subFileSegregatorList);
					fileSegregatorDao.upddateSegregatedFileDetail(param);
					
					transPersist = endIndex;
					endIndex    += persistInChunksOf.intValue(); 
				}
				logger.info("[PaymentSplitterDaoServiceImpl] - segregated file updated!!");
			}else{
				param.put("fileSegregatorList", fileMapperList);
				fileSegregatorDao.upddateSegregatedFileDetail(param);
				logger.info("[PaymentSplitterDaoServiceImpl] - segregated file updated!!");
			}
		}
		
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to updateFileSegregationDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
	}

	/**
	 * @param persistInChunksOf the persistInChunksOf to set
	 */
	public void setPersistInChunksOf(Integer persistInChunksOf) {
		this.persistInChunksOf = persistInChunksOf;
	}

	@Override
	public List<WebcashTsaSrcPaymentFileMapper> getDetailsFromFileHash(String hashCode) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Getting hash code details");
		List<WebcashTsaSrcPaymentFileMapper> hashDetailList = srcFileDao.getDetailsFromFileHash(hashCode);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to get Hash Details - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return hashDetailList;
	}

	@Override
	public void updRetryFileDetails(WebcashTsaSegregatorFileMapper fileMapperBean) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - updRetryFileDetails");
		fileSegregatorDao.updRetryFileStatus(fileMapperBean);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to updRetryFileDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		
	}

	@Override
	@Transactional(rollbackFor={Exception.class})
	public boolean isSourceFileLocked(String sourceFileName) {
		long startTime = new Date().getTime();
		Integer recordFound = 0;
		recordFound = checkFileLockDao.checkIsFileExists(sourceFileName);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to isSourceFileLocked - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return (recordFound > 0 ? true : false);
	}

	@Override
	@Transactional(rollbackFor={Exception.class})
	public void deleteLockedFileDetails(String sourceFileName) {
		logger.info("[PaymentSplitterDaoServiceImpl] - deleteLockedFileDetails");
		long startTime = new Date().getTime();
		checkFileLockDao.deleteLockedFileDetail(sourceFileName);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to deleteLockedFileDetails - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
	}

	@Override
	@Transactional(rollbackFor={Exception.class})
	public void acquireFileLock(File sourceFileName) {
		long startTime = new Date().getTime();
		Timestamp defaultTimeStamp = new Timestamp(System.currentTimeMillis());
		logger.info("[PaymentSplitterDaoServiceImpl] - acquireFileLock");
		Map<String,Object> param = new HashMap<String, Object>();
		param.put("fileName", sourceFileName.getName());
		param.put("lockedFileProcessTime", defaultTimeStamp);
		param.put("fileSize", (sourceFileName.length()/ 1024));
		param.put("createdBy",PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		param.put("createdTimeStamp",defaultTimeStamp);
		param.put("modifiedBy",PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		param.put("modifiedTimeStamp",defaultTimeStamp);
		checkFileLockDao.getFileLock(param);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to acquireFileLock - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
	}

	@Override
	public List<TsaInstanceMapper> getTsaIdentifier(List<String> tsaInstanceIdLst) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - getTsaIdentifier");
		List<TsaInstanceMapper> identifierList = checkFileLockDao.getTsaIdentifier(tsaInstanceIdLst);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to getTsaIdentifier - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return identifierList;
	}

	@Override
	public String getTsaInstanceId(String tsaIdentifier) {
		long startTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - getTsaIdentifier");
		String tsaInstanceId = checkFileLockDao.getTsaInstanceId(tsaIdentifier);
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterDaoServiceImpl] - Time taken to getTsaIdentifier - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime));
		return tsaInstanceId;
	}
	
}
