package com.ge.treasury.payment.splitter.process;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;
import com.ge.treasury.payment.splitter.exception.TransactionCountMismatchException;

public interface PaymentSplitterProcess {
	public List<String> paymentSplitter(File inputFile,Map<String, Object> tsa_NonTsaTxnMap, Integer sourceFileTransactionCount, Integer srcPaymentFileId, Map<String,String> detailsFromFileName) throws PaymentSplittingProcessException,TransactionCountMismatchException,FileEncryptionDecryptionException;
}
