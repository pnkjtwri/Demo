package com.ge.treasury.payment.splitter.xml.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ge.treasury.payment.splitter.exception.XmlReaderServiceException;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaPfiTransactionsMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;
import com.ge.treasury.payment.splitter.xml.service.XmlReaderService;

@Component
public class XmlReaderServiceImpl implements XmlReaderService {
	final static Logger logger = Logger.getLogger(XmlReaderServiceImpl.class);
	
	/*private DocumentBuilderFactory docBulderFactory;
	private DocumentBuilder dBuilder;
	private Document xmlDocumentObject;*/
	private Map<String,String> fileAttributes = null;

	/*
	 * Read the file and prepare account id and model id list.
	 * @return Map<String,List<String>>, with list of Account Id and Model Id
	 * 
	 */
	@Override
	public Map<String,List<String>> readInputForLookUpService(File inputFile) throws XmlReaderServiceException{
		Map<String,List<String>> inputParamMap 	= new HashMap<String, List<String>>();
		List<String> accountIdList 			= new ArrayList<String>();
		List<String> modelIdList 			= new ArrayList<String>();
		
		DocumentBuilderFactory docBulderFactory = null;
		DocumentBuilder dBuilder    			= null;
		Document xmlDocumentObject  			= null;
		FileInputStream xmlFileInputStream 		= null;
		
		logger.info("[XmlReaderServiceImpl] - Preparing Input parameter for Calling service starting ...");
		try{
			
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 		 	= docBulderFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			xmlDocumentObject 	= dBuilder.parse(xmlFileInputStream);
			
			xmlDocumentObject.getDocumentElement().normalize();
			NodeList nList = xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_ELEMENT);
			
			if(nList != null && nList.getLength() > 0){
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					Element eElement = (Element) nNode;
					
					Node modelIdNode = eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.MODEL_ID_ELEMENT).item(0);
					String modelIDValue = null;
					if(modelIdNode != null && modelIdNode.getTextContent().length() > 0){
						modelIDValue = modelIdNode.getTextContent();
					}
					
					Node accountIDNode = null;
					String accountIDValue = null;
					
					NodeList bankAccountNodeList = eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.BANK_ACCOUNT_ELEMENT);
					
					for(int childNode = 0; childNode < bankAccountNodeList.getLength(); childNode++){
						Node childNodeBankAccount = bankAccountNodeList.item(childNode);
						
						Element bankAcElement = (Element) childNodeBankAccount;
						Node bankAcTypeNode = bankAcElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.BANK_ACCOUNT_TYPE_ELEMENT).item(0);
						if(bankAcTypeNode != null && bankAcTypeNode.getTextContent().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.DEBIT_ELEMENT)){
							accountIDNode = bankAcElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_ID_ELEMENT).item(0);
							if(accountIDNode != null && accountIDNode.getTextContent().length() > 0){
								accountIDValue = accountIDNode.getTextContent();
							}
						}
					}
					if(accountIDValue != null){
						accountIdList.add(accountIDValue);
					}
					if(modelIDValue != null){
						modelIdList.add(modelIDValue);
					}
				}
				
				if(accountIdList.size() > 0){
					logger.info("[XmlReaderServiceImpl] - account Id list for Input - "+accountIdList);
					inputParamMap.put(PaymentSplitterConstants.PaymentConstants.ACCOUNT_ID_INPUT_PARAM_KEY, accountIdList);
				}
				
				if(modelIdList.size() > 0){
					logger.info("[XmlReaderServiceImpl] - model Id list for Input - "+modelIdList);
					inputParamMap.put(PaymentSplitterConstants.PaymentConstants.MODEL_ID_INPUT_PARAM_KEY, modelIdList);
				}
			logger.info("[XmlReaderServiceImpl] - Preparing Input parameter for Calling service Completed !!");
			}else{
				logger.info("[XmlReaderServiceImpl] - Transaction Element not found!!");
			}
		}catch(Exception e){
			logger.info("[XmlReaderServiceImpl] - Preparing Input parameter for Calling service Failed");
			logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new XmlReaderServiceException("[XmlReaderServiceImpl] - Preparing Input parameter for Calling service Failed !!", e);
		}finally{
			if(xmlFileInputStream != null){
				try{
					xmlFileInputStream.close();
				}catch(Exception ex){
					logger.error("[XmlReaderServiceImpl] - Error while closing input stream in readInputForLookUpService");
				}
			}
		}
		
		return inputParamMap;
	}
	
	
	/*
	 * prepare list of index positions for Ihb and Non Ihb transactions
	 * @param List<IHBAccount>, list of IHB account and model id
	 * 
	 * @return  Map<String, List<Integer>>, Index positions for IHB transaction and Non IHB transactions 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getPaymentsTSA_NONTSA(Map<Object, Object> tsaNonTsaModelAccountIdMap, File inputFile) throws XmlReaderServiceException{
		Set<Integer> nonTsaTxnIndexList 		= new HashSet<Integer>();
		Map<String, Object> tsaTxnIdxListMap 	= new HashMap<String, Object>();
		Set<String> tsaInstanceIdList 			=  new HashSet<String>();
		List<WebcashTsaPfiTransactionsMapper> nonTsaTransactionMapperBeanList 	= new ArrayList<WebcashTsaPfiTransactionsMapper>();
		
		DocumentBuilderFactory docBulderFactory = null;
		DocumentBuilder dBuilder    			= null;
		Document xmlDocumentObject  			= null;
		FileInputStream xmlFileInputStream 		= null;
		
		logger.info("[XmlReaderServiceImpl] - Identifying TSA and NON TSA Payments Index positions start..");
		Map<String, Object> tsa_NonTsaMap = new HashMap<String, Object>();
		try{
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 		 	= docBulderFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			xmlDocumentObject 	= dBuilder.parse(xmlFileInputStream);
			
			xmlDocumentObject.getDocumentElement().normalize();
			
			NodeList nList = xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_ELEMENT);
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode 			= nList.item(temp);
				Element eElement 	= (Element) nNode;
				
				if(nNode.getNodeName().equals(PaymentSplitterConstants.TransactionElementConstants.TEXT_ELEMENT)){
					 continue;
				 }
				
				NodeList transactionNodeList = nNode.getChildNodes();
				boolean isTSATransaction = false;
				Node modelIDNode      = null;
				Node accountIdNode    = null;
				
				breakFromOuter:
				for(int transCount = 0; transCount < transactionNodeList.getLength(); transCount++){
					Node transNode = transactionNodeList.item(transCount);
					if(transNode.getNodeName().equals(PaymentSplitterConstants.TransactionElementConstants.TEXT_ELEMENT)){
						 continue;
					 }
					
					if(transNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.MODEL_INFO_ELEMENT)){
						NodeList modelNodeList = transNode.getChildNodes();
						for(int nodeCount = 0; nodeCount < modelNodeList.getLength(); nodeCount++){
							Node modelNode = modelNodeList.item(nodeCount);
							if(modelNode.getNodeName().equals(PaymentSplitterConstants.TransactionElementConstants.TEXT_ELEMENT)){
								 continue;
							 }
							
							if(modelNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.MODEL_ID_ELEMENT)){
								modelIDNode = modelNode;
								break;
							}
						}
					}
					
					if(transNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.BANK_ACCOUNT_ELEMENT)){
						boolean isDRAccount = false;
						NodeList bankAccountNodeList = transNode.getChildNodes();
						for(int nodeCount = 0; nodeCount < bankAccountNodeList.getLength(); nodeCount++){
							Node bankNode = bankAccountNodeList.item(nodeCount);
							if(bankNode.getNodeName().equals(PaymentSplitterConstants.TransactionElementConstants.TEXT_ELEMENT)){
								 continue;
							 }
							
							if(bankNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.BANK_ACCOUNT_TYPE_ELEMENT) 
									&& bankNode.getTextContent().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.DEBIT_ELEMENT)){
								isDRAccount = true;
							}
							
							if(bankNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_ELEMENT) && isDRAccount){
								NodeList accountNodeList = bankNode.getChildNodes();
								for(int acCount = 0; acCount < accountNodeList.getLength(); acCount++){
									Node acNode = accountNodeList.item(acCount);
									if(bankNode.getNodeName().equals(PaymentSplitterConstants.TransactionElementConstants.TEXT_ELEMENT)){
										 continue;
									 }
									
									if(acNode.getNodeName().equalsIgnoreCase(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_ID_ELEMENT)){
										accountIdNode = acNode;
										break breakFromOuter;
									}
								}
							}
						}
					}
				}
				
				isTSATransaction = false;
				String tsaInstanceId = "";
				
				// Check if model is a TSA
				if(modelIDNode != null && modelIDNode.getTextContent().length() > 0){
					if(tsaNonTsaModelAccountIdMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.MODEL_INFO_MAP_KEY)){
						Map<String,Object> modelIdinfoMap = ((Map<String, Object>)tsaNonTsaModelAccountIdMap.get(PaymentSplitterConstants.LookUpServiceConstants.MODEL_INFO_MAP_KEY)); 
						if(modelIdinfoMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.MODEL_INFO_LIST_MAP_KEY)){
							Map<String, Object> tsaModelIDMap = (Map<String, Object>)modelIdinfoMap.get(PaymentSplitterConstants.LookUpServiceConstants.MODEL_INFO_LIST_MAP_KEY);
							if(tsaModelIDMap != null && tsaModelIDMap.size() > 0){
							   for (final String key : tsaModelIDMap.keySet()) {
								   tsaInstanceId = key;
							       List<String> tmpList = (List<String>)tsaModelIDMap.get(tsaInstanceId);
							       if(tmpList != null && tmpList.size() > 0){
							    	   if(tmpList.contains(modelIDNode.getTextContent().trim())){
							    		   isTSATransaction = true;
											break;
							    	   }
							       }
							   }
							}
						}
					}
				}
				
				//Check if account is a TSA IF model is NOT
				if(accountIdNode != null && accountIdNode.getTextContent().length() > 0 && !isTSATransaction){
					if(tsaNonTsaModelAccountIdMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.ACCOUNT_INFO_MAP_KEY)){
						Map<String,Object> accountIdinfoMap = ((Map<String, Object>)tsaNonTsaModelAccountIdMap.get(PaymentSplitterConstants.LookUpServiceConstants.ACCOUNT_INFO_MAP_KEY)); 
						if(accountIdinfoMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.ACCOUNT_INFO_LIST_MAP_KEY)){
							Map<String, Object> tsaAccountIDMap = (Map<String, Object>)accountIdinfoMap.get(PaymentSplitterConstants.LookUpServiceConstants.ACCOUNT_INFO_LIST_MAP_KEY);
							if(tsaAccountIDMap != null && tsaAccountIDMap.size() > 0){
							   for (final String key : tsaAccountIDMap.keySet()) {
								   tsaInstanceId = key;
							       List<String> tmpList = (List<String>)tsaAccountIDMap.get(tsaInstanceId);
							       if(tmpList != null && tmpList.size() > 0){
							    	   if(tmpList.contains(accountIdNode.getTextContent().trim())){
							    		   isTSATransaction = true;
											break;
							    	   }
							       }
							   }
							}
						}
					}
				}
				
				//Adding tsaInstance Ids
				if(tsaInstanceId != null && tsaInstanceId.length() > 0){
					tsaInstanceIdList.add(tsaInstanceId);
				}
				
				if(isTSATransaction){
					if(tsaTxnIdxListMap.containsKey(tsaInstanceId)){
						((ArrayList<Integer>)tsaTxnIdxListMap.get(tsaInstanceId)).add(temp);
						getTransactionMapperBean(eElement,((ArrayList<WebcashTsaPfiTransactionsMapper>)tsaTxnIdxListMap.get(tsaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY)));
					}else{
						List<Integer> tsaTxnIdxList = new ArrayList<Integer>();
						tsaTxnIdxList.add(temp);
						tsaTxnIdxListMap.put(tsaInstanceId, tsaTxnIdxList);
						
						List<WebcashTsaPfiTransactionsMapper> tsaTransactionMapperBeanList 		= new ArrayList<WebcashTsaPfiTransactionsMapper>();
						getTransactionMapperBean(eElement,tsaTransactionMapperBeanList);
						tsaTxnIdxListMap.put(tsaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY, tsaTransactionMapperBeanList);
					}
				}else if(accountIdNode != null || modelIDNode != null){
					//adding NON TSA transaction index positions
					nonTsaTxnIndexList.add(temp);
					//adding NON TSA transaction bean in list
					getTransactionMapperBean(eElement,nonTsaTransactionMapperBeanList);
				}
			}
			//Putting TSA Details
			if(tsaTxnIdxListMap != null && tsaTxnIdxListMap.size() > 0){
				tsa_NonTsaMap.put(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY, tsaTxnIdxListMap);
			}
			//Putting NonTSA Details
			if(nonTsaTxnIndexList != null && nonTsaTxnIndexList.size() > 0){
				List<Integer> sortedNonIhbList = new ArrayList<Integer>(nonTsaTxnIndexList);
				Collections.sort(sortedNonIhbList);
				tsa_NonTsaMap.put(PaymentSplitterConstants.PaymentConstants.NON_TSA_TRANSACTION_INDEX_KEY, sortedNonIhbList);
			}
			
			//Putting non tsa transaction bean list
			if(nonTsaTransactionMapperBeanList != null && nonTsaTransactionMapperBeanList.size() > 0){
				tsa_NonTsaMap.put(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY, nonTsaTransactionMapperBeanList);
			}
			//Putting tsa instance id key
			if(tsaInstanceIdList != null && tsaInstanceIdList.size() > 0){
				tsa_NonTsaMap.put(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY, new ArrayList<String>(tsaInstanceIdList));
			}
		logger.info("[XmlReaderServiceImpl] - Identifying TSA and NON TSA Payments Index positions Completed !!");
		}catch(Exception e){
			logger.error("[XmlReaderServiceImpl] - Error while Identifying TSA and NON TSA Payments Index positions");
			logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new XmlReaderServiceException("[XmlReaderServiceImpl] - Error while Identifying TSA and NON TSA Payments Index positions.", e);
		}finally{
			if(xmlFileInputStream != null){
				try{
					xmlFileInputStream.close();
				}catch(Exception ex){
					logger.error("[XmlReaderServiceImpl] - Error while closing input stream in readInputForLookUpService");
				}
			}
		}
		return tsa_NonTsaMap;
	}
	

	/*
	 * Return the count of transaction element in the source file
	 * 
	 * @return, Integer, count of transaction
	 **/
	@Override
	public Integer getSourceFileTransactionCount(File inputFile)throws XmlReaderServiceException {
		logger.info("[XmlReaderServiceImpl] - Source File Transaction count start...");
		Integer sourceFileTransactionCount = 0;
		DocumentBuilderFactory docBulderFactory = null;
		DocumentBuilder dBuilder    			= null;
		Document xmlDocumentObject  			= null;
		FileInputStream xmlFileInputStream 		= null;
		
		try{
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 		 	= docBulderFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			xmlDocumentObject 	= dBuilder.parse(xmlFileInputStream);
			
			xmlDocumentObject.getDocumentElement().normalize();
			
			if(xmlDocumentObject != null){
				sourceFileTransactionCount = xmlDocumentObject.getElementsByTagName("Transaction").getLength();
			}
		}catch(Exception e){
			logger.error("[XmlReaderServiceImpl] - Error while getting total no of transactions");
			logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new XmlReaderServiceException("[XmlReaderServiceImpl] - Error while getting total no of transactions", e);
		}finally{
			if(xmlFileInputStream != null){
				try{
					xmlFileInputStream.close();
				}catch(Exception ex){
					logger.error("[XmlReaderServiceImpl] - Error while closing input stream in getSourceFileTransactionCount");
				}
			}
		}
		logger.info("[XmlReaderServiceImpl] - Source File Transaction count - "+sourceFileTransactionCount);
		logger.info("[XmlReaderServiceImpl] - Source File Transaction count complete !!");
		return sourceFileTransactionCount;
	}
	
	
	/*
	 * Initialize document component with the received input file
	 * and prepare document object.
	 * 
	 * @param inputFile, Input File received
	 */
	/*public void initilizeComponent(File inputFile) throws XmlReaderServiceException{
		logger.info("[XmlReaderServiceImpl] - Initilizing document component..");
		FileInputStream xmlFileInputStream = null;
		try {
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 		 	= docBulderFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			xmlDocumentObject 	= dBuilder.parse(xmlFileInputStream);
			
			xmlDocumentObject.getDocumentElement().normalize();
			logger.info("[XmlReaderServiceImpl] - Component initialized for - "+inputFile.getName());
		}catch(Exception e){
			logger.info("[XmlReaderServiceImpl] - Initilizing document component Failed !!");
			logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new XmlReaderServiceException("[XmlReaderServiceImpl] - Initilizing document component Failed for the file -"+inputFile.getName(), e);
		}
		
		finally{
			if(xmlFileInputStream != null){
				try {
					xmlFileInputStream.close();
				} catch (IOException e) {
					logger.error("[XmlReaderServiceImpl] - xmlFileInputStream File is not able to close");
					logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
				}
			}
		}
		
		logger.info("[XmlReaderServiceImpl] - Document component Initilized !!");
	}*/
	
	
	/**
	 * Get the source file details to persist in db
	 * @param File inputFile, source file
	 */
	@Override
	public WebcashTsaSrcPaymentFileMapper getFileDetailsToPersist(File inputFile, String fileHashCode) throws IOException, XmlReaderServiceException{
		WebcashTsaSrcPaymentFileMapper fileDetails 	= new WebcashTsaSrcPaymentFileMapper();
		Timestamp defaultTime 						= new Timestamp(System.currentTimeMillis());
		fileAttributes			= null;
		fileAttributes 			= PaymentSplitterUtility.getFileAttributes(inputFile);
		DocumentBuilderFactory docBulderFactory = null;
		DocumentBuilder dBuilder    			= null;
		Document xmlDocumentObject  			= null;
		FileInputStream xmlFileInputStream 		= null;
		
		try{
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 		 	= docBulderFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			xmlDocumentObject 	= dBuilder.parse(xmlFileInputStream);
			
			xmlDocumentObject.getDocumentElement().normalize();
			fileDetails.setCreatedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
			fileDetails.setLastModifiedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
			if(xmlDocumentObject.getElementsByTagName("File_Type").item(0) != null){
				fileDetails.setFileType(xmlDocumentObject.getElementsByTagName("File_Type").item(0).getTextContent().trim());
			}
			else{
				fileDetails.setFileType(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
			}
			if(xmlDocumentObject.getElementsByTagName("File_Format_Version").item(0) != null){
				fileDetails.setFileFormatVersion(xmlDocumentObject.getElementsByTagName("File_Format_Version").item(0).getTextContent().trim());
			}else{
				fileDetails.setFileFormatVersion(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
			}
			if(xmlDocumentObject.getElementsByTagName("Creation_Module").item(0) != null){
				fileDetails.setFileCreationModule(xmlDocumentObject.getElementsByTagName("Creation_Module").item(0).getTextContent().trim());
			}else{
				fileDetails.setFileCreationModule(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
			}
			if(xmlDocumentObject.getElementsByTagName("File_Name").item(0) != null){
				fileDetails.setTrailerFileName(xmlDocumentObject.getElementsByTagName("File_Name").item(0).getTextContent().trim());
			}else{
				fileDetails.setTrailerFileName(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
			}
			
			if(xmlDocumentObject.getElementsByTagName("Total_Records").item(0) != null){
				String totRec = xmlDocumentObject.getElementsByTagName("Total_Records").item(0).getTextContent().trim();
				fileDetails.setTrailerTotalRecords(Integer.parseInt(totRec));
			}else{
				fileDetails.setTrailerTotalRecords(0);
			}
			
			fileDetails.setSrcPaymentFileName(inputFile.getName());
			fileDetails.setFileStatusId(1);
			fileDetails.setLastModifiedTimeStamp(defaultTime);
			fileDetails.setSegregationFlag("N");
			fileDetails.setPfiBusinessId(1);
			if(fileAttributes != null){
				fileDetails.setSrcFileCreationTimeStamp(Timestamp.valueOf(fileAttributes.get(PaymentSplitterConstants.FileConstants.FILE_CREATION_TIME)));
			}else{
				fileDetails.setSrcFileCreationTimeStamp(defaultTime);
			}
			fileDetails.setCreatedTimeStamp(defaultTime);
			fileDetails.setSegregationStatusMessage("PAYMENT SPLITTING PROCESS STARTED");
			fileDetails.setHashString(fileHashCode);
		}catch(Exception e){
			logger.error("[XmlReaderServiceImpl] - Error while preparing bean for saving file details");
			logger.error("[XmlReaderServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new XmlReaderServiceException("[XmlReaderServiceImpl] - Error while preparing bean for saving file details", e);
		}finally{
			if(xmlFileInputStream != null){
				try{
					xmlFileInputStream.close();
				}catch(Exception ex){
					logger.error("[XmlReaderServiceImpl] - Error while closing input stream in getFileDetailsToPersist");
				}
			}
		}
		return fileDetails;
		
	}

	/**
	 * get transaction details from source file
	 * 
	 * @param eElement
	 * @param transactionBeanList
	 */
	private void getTransactionMapperBean(Element eElement, List<WebcashTsaPfiTransactionsMapper> transactionBeanList){
		WebcashTsaPfiTransactionsMapper transactionDetails 			 = new WebcashTsaPfiTransactionsMapper();
		Timestamp defaultTime 										 = new Timestamp(System.currentTimeMillis());
		
		//adding <Record_Key> value....
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.RECORD_NUMBER).item(0) != null){
			transactionDetails.setRecordNumber(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.RECORD_NUMBER).item(0).getTextContent().trim());
		}else{
			transactionDetails.setRecordNumber(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.MODEL_ID_ELEMENT).item(0) != null){
			transactionDetails.setModelId(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.MODEL_ID_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setModelId(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_TYPE_ELEMENT).item(0) != null){
			transactionDetails.setTransactionType(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_TYPE_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setTransactionType(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_NUMBER_ELEMENT).item(0) != null){
			transactionDetails.setAccountId(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_NUMBER_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setAccountId(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_ID_ELEMENT).item(0) != null){
			transactionDetails.setDebitorAccountId(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.ACCOUNT_ID_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setDebitorAccountId(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRUSTED_SOURCE_ELEMENT).item(0) != null){
			transactionDetails.setTrustedSource(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRUSTED_SOURCE_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setTrustedSource(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.VALUE_DATE_ELEMENT).item(0) != null){
			String valueDate 		= eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.VALUE_DATE_ELEMENT).item(0).getTextContent().trim();
			SimpleDateFormat sdf 	= new SimpleDateFormat("yyyy-MM-dd");
			Date dateValue 			= null;
			try{
				dateValue		 	= sdf.parse(valueDate);
				transactionDetails.setTransValueDate(new Timestamp(dateValue.getTime()));
			}catch(Exception e){
				transactionDetails.setTransValueDate(defaultTime);
			}
			
		}else{
			transactionDetails.setTransValueDate(defaultTime);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.CURRENCY_ELEMENT).item(0) != null){
			transactionDetails.setCurrency(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.CURRENCY_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setCurrency(PaymentSplitterConstants.GenericConstants.NOT_APPLICABLE);
		}
		if(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.AMOUNT_ELEMENT).item(0) != null){
			transactionDetails.setTransactionAmount(eElement.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.AMOUNT_ELEMENT).item(0).getTextContent().trim());
		}else{
			transactionDetails.setTransactionAmount("0");
		}
		
		transactionDetails.setCreatedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		transactionDetails.setLastModifiedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		
		transactionDetails.setCreatedTimeStamp(defaultTime);
		transactionDetails.setLastModifiedTimeStamp(defaultTime);
		transactionDetails.setSegregatorFileId(0);
		transactionDetails.setSrcPaymentFileId(0);
		
		transactionBeanList.add(transactionDetails);
	}
	
}
