package com.ge.treasury.payment.splitter.mapper;



public class IHBAccount {
	private String accountData;
	private String isIhbBusiness;
	private String modelId;
	public String getAccountData() {
		return accountData;
	}
	public void setAccountData(String accountData) {
		this.accountData = accountData;
	}
	
	public String getIsIhbBusiness() {
		return isIhbBusiness;
	}
	/**
	 * @param isIhbBusiness the isIhbBusiness to set
	 */
	public void setIsIhbBusiness(String isIhbBusiness) {
		this.isIhbBusiness = isIhbBusiness;
	}
	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}
	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	

}
