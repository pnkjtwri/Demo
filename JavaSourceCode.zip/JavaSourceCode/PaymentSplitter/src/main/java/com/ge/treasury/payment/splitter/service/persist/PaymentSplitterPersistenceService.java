package com.ge.treasury.payment.splitter.service.persist;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.ge.treasury.payment.splitter.mapper.TsaInstanceMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaPfiTransactionsMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSegregatorFileMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;

public interface PaymentSplitterPersistenceService {
	/**Parent file details persisting methods**/
	public Integer saveInputFileDetails(WebcashTsaSrcPaymentFileMapper fileDetails, String optionID);
	public void updInputFileDetails(Map<String,Object> param);
	public List<WebcashTsaSrcPaymentFileMapper> getDetailsFromFileHash(String hashCode);
	/**Parent file details persisting methods**/
	
	/**Splitted files transaction details persisting methods**/
	public Integer saveTransactionDetails(List<WebcashTsaPfiTransactionsMapper> transDetailList,String transactionHashCode,Integer srcPaymentFileId);
	public void updTransactionDetails(List<WebcashTsaPfiTransactionsMapper> transactionDetailList);
	/**Splitted files transaction details persisting methods**/
	
	/**Splitted files details persisting methods**/
	public Integer saveFileSegregationDetails(WebcashTsaSegregatorFileMapper fileSegregatorDetails);
	public void updFileSegregationDetails(List<WebcashTsaSegregatorFileMapper> fileMapperList);
	public void updRetryFileDetails(WebcashTsaSegregatorFileMapper fileMapperBean);
	/**Splitted files details persisting methods**/
	
	/**Files Locking details methods**/
	public boolean isSourceFileLocked(String sourceFileName);
	public void acquireFileLock(File sourceFileName);
	public void deleteLockedFileDetails(String sourceFileName);
	/**Files Locking details methods**/
	
	/**TSA Details methods**/
	public List<TsaInstanceMapper> getTsaIdentifier(List<String> tsaInstanceIdLst);
	public String getTsaInstanceId(String tsaIdentifier);	
	/**TSA Details methods**/
}
