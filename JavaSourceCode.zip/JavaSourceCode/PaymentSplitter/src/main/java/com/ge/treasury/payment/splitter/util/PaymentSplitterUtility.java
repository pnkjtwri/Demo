package com.ge.treasury.payment.splitter.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;

public class PaymentSplitterUtility {
	final static Logger logger = Logger.getLogger(PaymentSplitterUtility.class);
	
	/*
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

	/*
	 * Remove white space from generated files
	 * @param fileLocation, generated file location
	 * @param xmlEncoding, source file ecoding pattern
	*/
	public static void removeWhitSpace(File fileLocation, String xmlEncoding) throws IOException {
		logger.info("[PaymentSplitterUtility] - Start removing white space from generated output file");
		StringBuffer modifiedStream = new StringBuffer();
		Writer out  = null;
		BufferedReader reader = null;
		
		try{
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileLocation), xmlEncoding));
			String line = null;
			while((line = reader.readLine()) != null)
			{
				if(line.equalsIgnoreCase(" ")){
					continue;
				}
				modifiedStream.append(line.trim());
			}
			
			out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileLocation), xmlEncoding));
			out.write(modifiedStream.toString());
		}catch(IOException io){
			logger.error("[PaymentSplitterUtility] - Error while removing white spaces from generated xml file.");
			logger.error("[PaymentSplitterUtility] - "+getErrorFormStackTrace(io));
			throw new RuntimeException(io);
		}
		finally{
			if(reader != null){
				reader.close();
			}
			if(out != null){
				out.close();
			}
		}
		logger.info("[PaymentSplitterUtility] - While space removed from generated output file");
	}
	
	public static String getTransactionAsString(File fileLocation) throws IOException {
		logger.info("[PaymentSplitterUtility] - Start getting transactions as string");
		StringBuffer modifiedStream = new StringBuffer();
		BufferedReader reader 		= null;
		try{
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileLocation)));
			String line = null;
			while((line = reader.readLine()) != null){
				if(line.contains(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_ELEMENT)){
					modifiedStream.append(line.trim());
					continue;
				}
				
				if(line.contains("File_Trailer_Record") || line.contains("</File>")){
					break;
				}else if(modifiedStream.toString().length() > 0){
					modifiedStream.append(line.trim());
				}
			}
			reader.close();
			//logger.info("[PaymentSplitterUtility] - transaction as string - "+modifiedStream.toString());
			return modifiedStream.toString();
		}catch(IOException io){
			logger.error("[PaymentSplitterUtility] - Error while getting transactions as string.");
			logger.error("[PaymentSplitterUtility] - "+getErrorFormStackTrace(io));
			throw new RuntimeException(io);
		}
		finally{
			if(reader != null){
				reader.close();
			}
		}
	}
	
	
	/**
	* generate formatted file after removing white space
	* @param inputFile, generated file
	*/
	public static Integer generateFileAfterRemovingWhiteSpace(File inputFile){
		logger.info("[PaymentSplitterUtility] - generateFileAfterRemovingWhiteSpace start");
		DocumentBuilderFactory dbFactory 		= null;
		DocumentBuilder dBuilder 				= null;
		FileInputStream xmlFileInputStream 		= null;
		Integer generatedFileTransactionCount 	= 0;
		
		try{
			dbFactory 			= DocumentBuilderFactory.newInstance();
			dBuilder 			= dbFactory.newDocumentBuilder();
			xmlFileInputStream 	= new FileInputStream(inputFile);
			
			Document doc = dBuilder.parse(xmlFileInputStream);
			doc.normalizeDocument();
			
			generatedFileTransactionCount = doc.getElementsByTagName("Transaction").getLength();
			
			try{
				//setting total no of records in file footer
				doc.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TOTAL_RECORD_ELEMENT).item(0).setTextContent(generatedFileTransactionCount+"");
			}catch(Exception e){
				//Do Nothing, log the event
			}
			
			String xmlEncoding = doc.getXmlEncoding();
			if(xmlEncoding == null)
				xmlEncoding = "UTF-8";
			
			TransformerFactory transformerFactory 	= TransformerFactory.newInstance();
			Transformer transformer 				= transformerFactory.newTransformer();
			
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.ENCODING, xmlEncoding);
			
			DOMSource source 	= new DOMSource(doc);
			StreamResult result = new StreamResult(inputFile);
			
			transformer.transform(source, result);
			logger.info("[PaymentSplitterUtility] - Generated file - "+inputFile.getName()+" have no of transaction - "+generatedFileTransactionCount);
			logger.info("[PaymentSplitterUtility] - generateFileAfterRemovingWhiteSpace completed");
			return generatedFileTransactionCount;
		}catch(ParserConfigurationException e){
			throw new RuntimeException("Exception occured while generating xml file. Not able to parse generated xml file - "+inputFile.getName(),e);
		}catch(TransformerException e){
			throw new RuntimeException("Exception occured while generating xml file. Not able to transform generated xml file - "+inputFile.getName(),e);
		}catch(SAXException e){
			throw new RuntimeException("Exception occured while generating xml file. SAX exception occurred while generating xml file - "+inputFile.getName(),e);
		}catch(IOException e){
			throw new RuntimeException("Exception occured while generating xml file. IO exception occureed while generating xml file - "+inputFile.getName(),e);
		}
		finally{
			if(xmlFileInputStream != null){
				try {
					xmlFileInputStream.close();
				} catch (IOException e) {
					logger.error("[PaymentSplitterUtility] - Error while closing input stream for the file - "+inputFile.getName());
					logger.error("[PaymentSplitterUtility] - "+getErrorFormStackTrace(e));
				}
			}
		}
	}
	
	/**
	* Add process block Node and footer node with no of transaction,
	* if not found in source file, this will not use for web cash, its only require for CMM
	*/
	public static void addNodeProcessBlock(File generatedFileLocation, String optionCode, String gwixUser, String feedBack) throws PaymentSplittingProcessException{
	logger.info("[PaymentSplitterUtility] - Start adding Process Block in the generated file - "+generatedFileLocation.getName());
		try {
			/*logger.info("Going to getFeedBackRequiredFromIHBBusiness() of IHBAccountDao.class for getting IS_FEEDBACK_REQUIRED column value by OPTION_ID..");
			String feedback = accountDao.getFeedBackRequiredFromIHBBusiness(optionCode);*/
			
			DocumentBuilderFactory dbFactory 	= DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder 			= dbFactory.newDocumentBuilder();
			Document generatedFileDoc			= dBuilder.parse(generatedFileLocation);
			generatedFileDoc.getDocumentElement().normalize();
			
			generatedFileDoc = adddHeaderandTrailer(generatedFileDoc, generatedFileDoc.getElementsByTagName("Transaction").getLength());
			
			/*Element rootElement 	= generatedFileDoc.getDocumentElement();
			Element processBlock 	= generatedFileDoc.createElement("ProcessBlock");
			Element businessName 	= generatedFileDoc.createElement("BusinessName");
			Element isRequiredTrue 	= generatedFileDoc.createElement("IsFeedbackRequired");
			
			businessName.appendChild(generatedFileDoc.createTextNode(gwixUser));
			isRequiredTrue.appendChild(generatedFileDoc.createTextNode(feedBack));
			
			processBlock.appendChild(generatedFileDoc.importNode(businessName,true));
			processBlock.appendChild(generatedFileDoc.importNode(isRequiredTrue,true));
			rootElement.appendChild(generatedFileDoc.importNode(processBlock,true));*/
			
			String xmlEncode = generatedFileDoc.getXmlEncoding();
			if(xmlEncode == null)
				xmlEncode = "UTF-8";
			
			generatedFileDoc.normalizeDocument();
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.ENCODING, xmlEncode);
			DOMSource source = new DOMSource(generatedFileDoc);
			StreamResult result = new StreamResult(new File(generatedFileLocation.getPath()));
			transformer.transform(source, result);
			logger.info("[PaymentSplitterUtility] - Process Block added in the generated file - "+generatedFileLocation.getName());
		}catch (Exception e) {
			throw new PaymentSplittingProcessException("Error Adding Node <ProcessBlock> in TSA generated file.",e);
		}
	}
	
	/**
	 * Add header nodes and footer nodes if it not present in the file for CMM only
	 * @param generatedFileDoc, generated file
	 * @parma totalRecords, total no of records in generated file
	*/
	private static Document adddHeaderandTrailer(Document generatedFileDoc, int totalRecords ){
		//create File_type node if it dosen't exists
		if(generatedFileDoc.getElementsByTagName("File_Type").item(0) == null){
			Element fileType = generatedFileDoc.createElement("File_Type");
			fileType.appendChild(generatedFileDoc.createTextNode("N/A"));
			
			if(generatedFileDoc.getElementsByTagName("File_Header_Record").item(0) != null){
				Node refNode = generatedFileDoc.getElementsByTagName("File_Header_Record").item(0);
				refNode.getParentNode().insertBefore(generatedFileDoc.importNode(fileType, true), refNode);
			}else{
				Node refNode = generatedFileDoc.getElementsByTagName("Transaction").item(0);
				refNode.getParentNode().insertBefore(generatedFileDoc.importNode(fileType, true), refNode);
			}
		}
		//create File_Header_Record if it dosen't exists
		if(generatedFileDoc.getElementsByTagName("File_Header_Record").item(0) != null){
			//if File_Format_Version does not exist 
			if(generatedFileDoc.getElementsByTagName("File_Format_Version").item(0) == null){
				Element version = generatedFileDoc.createElement("File_Format_Version");
				
				version.appendChild(generatedFileDoc.createTextNode("N/A"));
				generatedFileDoc.getElementsByTagName("File_Header_Record").item(0).appendChild(generatedFileDoc.importNode(version, true));
			  }
			//if Creation_Module does not exist
			if(generatedFileDoc.getElementsByTagName("Creation_Module").item(0) == null){
				Element creationModule = generatedFileDoc.createElement("Creation_Module");
				
				creationModule.appendChild(generatedFileDoc.createTextNode("N/A"));
				generatedFileDoc.getElementsByTagName("File_Header_Record").item(0).appendChild(generatedFileDoc.importNode(creationModule, true));
			}
		}else{
			Element fileHeader 		= generatedFileDoc.createElement("File_Header_Record");
			Element version 		= generatedFileDoc.createElement("File_Format_Version");
			Element creationModule 	= generatedFileDoc.createElement("Creation_Module");
			
			version.appendChild(generatedFileDoc.createTextNode("N/A"));
			creationModule.appendChild(generatedFileDoc.createTextNode("N/A"));
			fileHeader.appendChild(generatedFileDoc.importNode(version, true));
			fileHeader.appendChild(generatedFileDoc.importNode(creationModule, true));
			
			Node refNode = generatedFileDoc.getElementsByTagName("Transaction").item(0);
			refNode.getParentNode().insertBefore(generatedFileDoc.importNode(fileHeader, true), refNode);
		}
		
		//create File_Trailer_Record if it dosen't exists
		if(generatedFileDoc.getElementsByTagName("File_Trailer_Record").item(0) != null){
			// if File_Name does not exist
			if (generatedFileDoc.getElementsByTagName("File_Name").item(0) == null){
				Element fileName = generatedFileDoc.createElement("File_Name");
				
				fileName.appendChild(generatedFileDoc.createTextNode("N/A"));
				generatedFileDoc.getElementsByTagName("File_Trailer_Record").item(0).appendChild(generatedFileDoc.importNode(fileName, true));
			}
			// if Total_Records does not exist
			if (generatedFileDoc.getElementsByTagName("Total_Records").item(0) == null) {
				Element totalRecordElement = generatedFileDoc.createElement("Total_Records");
				
				totalRecordElement.appendChild(generatedFileDoc.createTextNode(String.valueOf(totalRecords)));
				generatedFileDoc.getElementsByTagName("File_Trailer_Record").item(0).appendChild(generatedFileDoc.importNode(totalRecordElement, true));
			}

		}else{
			Element fileTrailer 	= generatedFileDoc.createElement("File_Trailer_Record");
			Element fileName 		= generatedFileDoc.createElement("File_Name");
			Element totalRecord 	= generatedFileDoc.createElement("Total_Records");
			
			fileName.appendChild(generatedFileDoc.createTextNode("N/A"));
			totalRecord.appendChild(generatedFileDoc.createTextNode(String.valueOf(totalRecords)));
			fileTrailer.appendChild(generatedFileDoc.importNode(fileName, true));
			fileTrailer.appendChild(generatedFileDoc.importNode(totalRecord, true));
			
			Node refNode = generatedFileDoc.getElementsByTagName("File").item(0);
			refNode.appendChild(generatedFileDoc.importNode(fileTrailer, true));
		}
		return generatedFileDoc;
	}
	
	/**
	* Move file from given location
	* @param inputFile, files to be moved
	* @param movedLocation, location where we have to move
	* @param isSftpFailed, only true when sftp transfer failed
	*/
	public static void moveFile(File inputFile, String movedLocation, boolean isSftpFailed){
		logger.info("[PaymentSplitterUtility] - File is moving to location - "+movedLocation+inputFile.getName());
		String todayDate  = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
		String renameFileName = movedLocation+inputFile.getName();
		if(!isSftpFailed){
			renameFileName = renameFileName+"_"+todayDate;
		}
		File movedFileLoc = new File(renameFileName);
		boolean moved     = inputFile.renameTo(movedFileLoc);
		if(moved){
			logger.info("[PaymentSplitterUtility] - File is moved successfully to location - "+movedLocation);
		}else{
			logger.info("[PaymentSplitterUtility] - Error while moving file to location - "+movedLocation);
		}
		
	}
	
	/**
	* delete file from given location
	* @param generatedFile, files to be deleted
	*/
	public static void deleteFile(File generatedFile){
		if(generatedFile.exists()){
			logger.info("[PaymentSplitterUtility] - Removing generated file - "+generatedFile.getName());
			if(generatedFile.delete()){
				logger.info("[PaymentSplitterUtility] - Generated file - "+generatedFile.getName()+" deleted !!");
			}else{
				logger.info("[PaymentSplitterUtility] - Error deleting generated file - "+generatedFile.getName());
			}
		}
		
	}
	
	
	/**
	 * to get source file details 
	 * 
	 * @param sourceFile
	 * @return Map<String,String>
	 * @throws IOException
	 */
	public static Map<String,String> getFileAttributes(File sourceFile) throws IOException{
		Map<String,String> attributes = new HashMap<String, String>();
		
		Path filePath = Paths.get(sourceFile.getPath());
        BasicFileAttributes attr = Files.readAttributes(filePath, BasicFileAttributes.class);
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        
        attributes.put(PaymentSplitterConstants.FileConstants.FILE_LAST_MODIFIED_TIME, sdfDate.format(new Date(attr.lastModifiedTime().toMillis())));
        attributes.put(PaymentSplitterConstants.FileConstants.FILE_CREATION_TIME, sdfDate.format(new Date(attr.creationTime().toMillis())));
 		
		return attributes;
	}
	
	/**
	 * Copy file
	 * 
	 * @param destinationLocation
	 * @param sourceFileStream
	 */
	public static void copySourceFileToDestination(String destinationLocation,FileInputStream sourceFileStream){
		try{
			File destinationFile = new File(destinationLocation);
			Files.copy(sourceFileStream, destinationFile.toPath(),StandardCopyOption.REPLACE_EXISTING);
			sourceFileStream.close();
			logger.error("[PaymentSplitterUtility] - File copied to - "+destinationLocation);
		}catch (IOException e) {
			logger.error("[PaymentSplitterUtility] - Error while Payment splitting process for NON TSA");
			logger.error("[PaymentSplitterUtility] - " + PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new RuntimeException("Not able to copy source file to NON TSA output location",e);
		}finally{
			try{
				if(sourceFileStream != null){
					sourceFileStream.close();
				}
			}catch(Exception e){
				logger.error("[PaymentSplitterUtility] - Error while closing source file stream");
				logger.error("[PaymentSplitterUtility] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			}
		}
	}
	
	/**
	 * Method used for checking String is numeric or not
	 * @param data
	 * @return
	 */
	public static boolean isNumeric(String data){
		logger.error("[PaymentSplitterUtility] [inside isNumeric()]");
		try{
			logger.error("[PaymentSplitterUtility] [inside isNumeric()] [Going to parse string as numeric....]");
			Integer.parseInt( data );
			logger.error("[PaymentSplitterUtility] [inside isNumeric()] [String is numeric....]");
			return true;
	   }catch( Exception ex){
		   logger.error("[PaymentSplitterUtility] [inside isNumeric()] [String is not numeric....]");
		   return false;
	   }
	}
	
}
