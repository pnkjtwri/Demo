package com.ge.treasury.payment.splitter.process.service.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ge.treasury.payment.splitter.PaymentSplitterFileStatusLoader;
import com.ge.treasury.payment.splitter.checksum.PaymentSplitterCheckSumGenerator;
import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;
import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;
import com.ge.treasury.payment.splitter.exception.TransactionCountMismatchException;
import com.ge.treasury.payment.splitter.exception.XmlReaderServiceException;
import com.ge.treasury.payment.splitter.mapper.TsaInstanceMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaPfiTransactionsMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;
import com.ge.treasury.payment.splitter.process.PaymentSplitterProcess;
import com.ge.treasury.payment.splitter.process.service.PaymentSplitterService;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;
import com.ge.treasury.payment.splitter.xml.service.XmlReaderService;

/*
 * PaymentSplitterServiceImpl will perform following activity -
 * 
 * 	1) With received input file, it will prepare list for Account Id & Model Id
 *  2) With this List of Account & model, it will call the service method to get 
 *  	the TSA and NonTSA list
 *  3) With this TSA & NON TSA Account & model, it will find out the TSA and 
 *  	Non TSA Transaction index position from the input file.
 *  4) Persist the File and Transaction level details in DB
 *  5) Call the Payment splitting processor to split the file based on the step 3. 
 */

@Component
public class PaymentSplitterServiceImpl implements PaymentSplitterService {
	final static Logger logger = Logger.getLogger(PaymentSplitterServiceImpl.class);
	
	@Autowired XmlReaderService xmlReader;
	@Autowired PaymentSplitterProcess splitterProcess;
	@Autowired PaymentSplitterPersistenceService fileDaoService;
	@Autowired PaymentSplitterCheckSumGenerator hashingService;
	@Autowired PaymentSplitterFileStatusLoader fileStatus; 
	
	@Value("${isTransactionDetailsPersist}")
	private String isTransactionDetailsPersist;
	@Value("${lookUpServiceUrl}")
	private String lookUpService;
	@Value("${dohashcheck}")
	private String dohashcheck;
	
	/*private String gwixUserId				= "";
	private String optionId 				= "";
	private String gwixUniqueId 			= "";*/
	
	@SuppressWarnings("unchecked")
	@Override
	/**
	 * @param File inputFile, source file
	 * @return List<String>, Sftp failed file list
	 */
	public List<String> startPaymentSplitter(File inputFile) throws PaymentSplittingProcessException,TransactionCountMismatchException,
						FileEncryptionDecryptionException,XmlReaderServiceException,FileHashingProcessException,Exception{
		long startTime = new Date().getTime();
		Map<String,String> detailsFromFileName = getFileDetails(inputFile.getName());
		Integer srcPaymentFileId    	= 0;
		
		List<String> sftpFailedFileList = null;
		
		Map<String, Object> tsa_NonTsaTxnMap 		= null;
		Map<String,List<String>> spInputParamMap    = null;
		RestTemplate restTemplate					= new RestTemplate();
		
		/*xmlReader.initilizeComponent(inputFile);*/
		try{
			spInputParamMap 				= xmlReader.readInputForLookUpService(inputFile);
		}catch(Exception e){
			logger.error("[PaymentSplitterServiceImpl] - Error while preparing input parameter for data lookup");
			throw new PaymentSplittingProcessException(e.getMessage(),e);
		}
		
		/**Calling LookUp service to get the details*/
		Map<Object, Object> tsaNonTsaModelAccountIdMap =  restTemplate.postForObject(lookUpService,spInputParamMap, Map.class);
		
		/*Map<Object, Object> tsaNonTsaModelAccountIdMap = getList();*/
		if(tsaNonTsaModelAccountIdMap != null 
			&& (tsaNonTsaModelAccountIdMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.ACCOUNT_INFO_MAP_KEY)
			|| tsaNonTsaModelAccountIdMap.containsKey(PaymentSplitterConstants.LookUpServiceConstants.MODEL_INFO_MAP_KEY))){
				tsa_NonTsaTxnMap 				= xmlReader.getPaymentsTSA_NONTSA(tsaNonTsaModelAccountIdMap, inputFile);
		}
			
		if( tsa_NonTsaTxnMap == null || tsa_NonTsaTxnMap.size() == 0){
			throw new PaymentSplittingProcessException("No Transaction found in the source file - "+inputFile.getName());
		}
		
		/**Hash generation and persisting file details*/
		String fileHashCode 			= hashingService.getCheckSumValueForFile(inputFile, PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
		
		//Validate input file hash code if exists in table
		List<WebcashTsaSrcPaymentFileMapper> fileDetailsExistList = fileDaoService.getDetailsFromFileHash(fileHashCode);
		
		WebcashTsaSrcPaymentFileMapper fileDetails 	= xmlReader.getFileDetailsToPersist(inputFile,fileHashCode);
		fileDetails.setFileStatusId(fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_READY_FOR_SPLIT));
		if(fileDetailsExistList != null && fileDetailsExistList.size() > 0){
			fileDetails.setSegregationStatusMessage("Duplicate File recieved. Hash String found.");
			fileDetails.setFileStatusId(fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FAILED));
		}
		//persisting file details
		srcPaymentFileId = fileDaoService.saveInputFileDetails(fileDetails,detailsFromFileName.get(PaymentSplitterConstants.FileConstants.OPTION_ID_FROM_FILENAME));
		
		//Validate input file hash code if exists in table
		if(fileDetailsExistList != null && fileDetailsExistList.size() > 0){
			//Adding extra check for CRC override
			String userID = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.USER_ID_FROM_FILENAME);
			logger.info("[Found duplicate hash code in source table, going to check if file is Manual import and value of hashcheck flag");
			if(dohashcheck.equals("Y") && !(userID != null && PaymentSplitterUtility.isNumeric(userID) && userID.length() == 9)){
				throw new PaymentSplittingProcessException("We have recieved the duplicate file. Hash String match found in records with SRC PAYMENT FILE ID - "+fileDetailsExistList.get(0).getSrcPaymentFileId());
			}
			else
			{
				logger.info("[This file is duplicate and as dohashcheck is configured as:" + dohashcheck +" and user Id is:"+userID+ " which means it is a  manual payment, so overriding CRC check.]" );
			}
		}
		
		/**Hash generation and persisting transaction details*/
		/*if(isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y")){
			String transactionHashCode = hashingService.getCheckSumValueForString(PaymentSplitterUtility.getTransactionAsString(inputFile), PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
			List<WebcashTsaPfiTransactionsMapper> srcFileTransactionList 	= new ArrayList<WebcashTsaPfiTransactionsMapper>();
			if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY)){
				Map<String,Object>tsaListCollection = (Map<String, Object>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY);
				List<String> tsaInstanceIdList 		= (List<String>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY);
				for(int tsaCount = 0; tsaCount < tsaInstanceIdList.size(); tsaCount++){
					String tsaId = tsaInstanceIdList.get(tsaCount);
					srcFileTransactionList.addAll(((ArrayList<WebcashTsaPfiTransactionsMapper>)((Object)tsaListCollection.get(tsaId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY))));
				}
			}
			
			if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY)){
				srcFileTransactionList.addAll(((ArrayList<WebcashTsaPfiTransactionsMapper>)((Object)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY))));
			}
			
			if(srcFileTransactionList.size() > 0){
				try{
				fileDaoService.saveTransactionDetails(srcFileTransactionList,transactionHashCode,srcPaymentFileId);
				}catch(Exception e){
					updateError(srcPaymentFileId,e);
					logger.error("[PaymentSplitterServiceImpl] - Error while inserting transaction");
					logger.error("[PaymentSplitterServiceImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
					throw new PaymentSplittingProcessException(e.getMessage(),e);
				}
			}
		}*/
		/**Splitting process */
		if(tsa_NonTsaTxnMap != null && tsa_NonTsaTxnMap.size() > 0){
			try{
				populateTsaIdentifier(detailsFromFileName,tsa_NonTsaTxnMap);
				sftpFailedFileList = splitterProcess.paymentSplitter(inputFile, tsa_NonTsaTxnMap, xmlReader.getSourceFileTransactionCount(inputFile),srcPaymentFileId,detailsFromFileName);
			}catch(PaymentSplittingProcessException pse){
				updateError(srcPaymentFileId,pse);
				throw new PaymentSplittingProcessException(pse.getMessage(),pse);
			}catch(TransactionCountMismatchException tce){
				updateError(srcPaymentFileId,tce);
				throw new TransactionCountMismatchException(tce.getMessage(),tce);
			}catch(FileEncryptionDecryptionException fede){
				updateError(srcPaymentFileId,fede);
				throw new FileEncryptionDecryptionException(fede.getMessage(),fede);
			}
		}
		long endTime = new Date().getTime();
		logger.info("[PaymentSplitterServiceImpl] - Time taken to execute startPaymentSplitter() method - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime)+" sec");
		return sftpFailedFileList;
	}
	
	
	private void updateError(Integer srcPaymentFileId, Exception e){
		String errorMessage = "Error while processing file";
		if(e != null){
			errorMessage = ((e.getMessage().length() <= 250)?e.getMessage():e.getMessage().substring(0, 249));
			if(errorMessage == null){
				errorMessage = ((e.getCause() != null && e.getCause().toString().length() <= 250)?e.getCause().toString():e.getCause().toString().substring(0, 249));
			}
		}
		
		Timestamp defaultTimeStamp = new Timestamp(System.currentTimeMillis());
		Map<String,Object> updSrcFileParam = new HashMap<String, Object>();
		updSrcFileParam.put("srcPaymentFileId", srcPaymentFileId);
		updSrcFileParam.put("splitMessage", errorMessage);
		updSrcFileParam.put("fileStatusId", fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FAILED));
		updSrcFileParam.put("modifiedTime", defaultTimeStamp);
		
		fileDaoService.updInputFileDetails(updSrcFileParam);
	}
	
	/**
	 * get details from file name
	 * @param inputFile
	 * @throws PaymentSplittingProcessException 
	 */
	private Map<String,String> getFileDetails(String sourceFileName) throws PaymentSplittingProcessException{
		Map<String,String> detailsFromFileName = new HashMap<String, String>();
		try{
			String[] fileDetails 	= sourceFileName.split("_");
			
			if(fileDetails != null && fileDetails.length > 0){
				String userId   	= fileDetails[0]; 
				String businessName = fileDetails[1];
				String gwixUniqueId = sourceFileName.substring((sourceFileName.lastIndexOf("{")),(sourceFileName.lastIndexOf("}")+1));
				String fileName     = sourceFileName.substring((sourceFileName.toLowerCase().lastIndexOf("_txt")+5),(sourceFileName.indexOf("{")-1));
				
				detailsFromFileName.put(PaymentSplitterConstants.FileConstants.USER_ID_FROM_FILENAME,userId);
				detailsFromFileName.put(PaymentSplitterConstants.FileConstants.OPTION_ID_FROM_FILENAME,businessName);
				detailsFromFileName.put(PaymentSplitterConstants.FileConstants.ORIGINAL_FILE_NAME_FROM_FILENAME,fileName);
				detailsFromFileName.put(PaymentSplitterConstants.FileConstants.GWIX_UNIQUE_ID_FROM_FILENAME,gwixUniqueId);
				
				logger.info("[PaymentSplitterServiceImpl] - details from file - gwixUserId - "+userId+" optionId - "+businessName+" gwixUniqueId - "+gwixUniqueId+" Original fileName - "+fileName);
			}
		}catch(Exception e){
			logger.error("[PaymentSplitterServiceImpl] -"+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("Source file name format is not correct. Please provide the file with accepted naming convention. As per the below details -"
					+ " USERID_OPTIONID_txt_SOURCEFILENAME_GECC_IFTRNXML_20151220181630768_{752D1E2F-1770-473-B0f4-ASS001}.xml / txt, Delimeter(_) should not be there in file extension.");
		}
		return detailsFromFileName;
	}
	
	/**
	 * get the details of TSA Instance id and put in the map
	 * detailsFromFileName
	 * 
	 * @param detailsFromFileName
	 * @param tsa_NonTsaTxnMap
	 */
	private void populateTsaIdentifier(Map<String,String> detailsFromFileName, Map<String, Object> tsa_NonTsaTxnMap){
		if(tsa_NonTsaTxnMap != null && tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY)){
			List<String> tsaInstanceIdList = (List<String>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY);
			
			if(tsaInstanceIdList != null && tsaInstanceIdList.size() > 0){
				List<TsaInstanceMapper>  tsaIdentifilerList = fileDaoService.getTsaIdentifier(tsaInstanceIdList);
				if(tsaIdentifilerList != null && tsaIdentifilerList.size() > 0){
					for (TsaInstanceMapper tsaBean : tsaIdentifilerList) {
						logger.info("[PaymentSplitterServiceImpl] - "+tsaBean.getTsaInstanceId()+" Identifier - "+tsaBean.getTsaInstanceIdentifier());
						detailsFromFileName.put(tsaBean.getTsaInstanceId(), tsaBean.getTsaInstanceIdentifier());
						for (Map.Entry<String, String> entry : detailsFromFileName.entrySet()) {
							logger.info("detailsFromFileName::"+entry.getKey()+" : "+entry.getValue());
						}
					}
				}
			}
		}
	}

	/**
	 * @param isTransactionDetailsPersist the isTransactionDetailsPersist to set
	 */
	public void setIsTransactionDetailsPersist(String isTransactionDetailsPersist) {
		this.isTransactionDetailsPersist = isTransactionDetailsPersist;
	}
}
