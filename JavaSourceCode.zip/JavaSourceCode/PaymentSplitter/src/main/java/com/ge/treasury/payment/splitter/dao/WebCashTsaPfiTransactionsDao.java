package com.ge.treasury.payment.splitter.dao;

import java.util.Map;

public interface WebCashTsaPfiTransactionsDao {
	public void insertTransactionDetail(Map<Object, Object> param);
	public void upddateTransactionDetail(Map<Object, Object> param);
}
