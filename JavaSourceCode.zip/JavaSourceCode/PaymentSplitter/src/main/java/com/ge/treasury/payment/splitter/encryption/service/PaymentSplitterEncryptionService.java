package com.ge.treasury.payment.splitter.encryption.service;

import java.io.File;

import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;

public interface PaymentSplitterEncryptionService {
	public void encryptFile(File fileToEncrypt) throws FileEncryptionDecryptionException;
	public void decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException;
}
