package com.ge.treasury.payment.splitter.retry.activator;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.payment.splitter.encryption.service.PaymentSplitterEncryptionService;
import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.retry.service.RertyFailedSftpFileService;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

@MessageEndpoint
public class SftpRetryListener {
	final static Logger logger = Logger.getLogger(SftpRetryListener.class);
	

	@Value("${archivedSftpFiles}")
	private String archivedSftpLocation;
	
	@Value("${encryptedFilePath}")
	private String encryptedFilePath;
	
	/*@Value("${erroredSftpFiles}")
	private String erroredSftpLocation;*/
	
	@Value("${deleteGeneratedTsaXml}")
	private String deleteGeneratedTsaXml;
	
	@Autowired RertyFailedSftpFileService retryService;
	@Autowired PaymentSplitterPersistenceService fileLockServiceDao;
	@Autowired PaymentSplitterEncryptionService fileDecryptService;
	
	@ServiceActivator
	public void initilizeSftRetry(File inputFile){
		logger.info("[SftpRetryListener] - Retry listener start");
		boolean isFileLocked = false;
		
		if(inputFile.exists()){
			
			isFileLocked = fileLockServiceDao.isSourceFileLocked(inputFile.getName());
		
			if(!isFileLocked){
				fileLockServiceDao.acquireFileLock(inputFile);
				try{
					boolean sentStatus = retryService.sftpFailedFile(inputFile);
					moveSftpFiles(inputFile, sentStatus);
				}catch(Exception e){
					logger.error("[SftpRetryListener] - Error occurred while sending file to sftp location");
					//as per discussion we are not going move the file after getting Failed
					//moveSftpFiles(inputFile, false); 
				}
			}else{
				logger.info("[SftpRetryListener] - "+inputFile.getName()+" is Already Locked by some other process");
			}
			
			if(!isFileLocked){
				fileLockServiceDao.deleteLockedFileDetails(inputFile.getName());
			}
			
			logger.info("[SftpRetryListener] - Retry listener ends");
		}
	}
	
	
	/**
	 * moving sftp files to their respective locations
	 * @param file
	 * @param fileStaus
	 * @throws FileEncryptionDecryptionException 
	 */
	private void moveSftpFiles(File  fileTomove, boolean fileTransferStaus) throws FileEncryptionDecryptionException{
		logger.info("[SftpRetryListener] - moving file starts");
		String locationToMove 	= null;
		
		if(fileTransferStaus){
			locationToMove = archivedSftpLocation;
			
			fileDecryptService.decryptFile(fileTomove);
			String outPutFileName = fileTomove.getName();
			String outPutFilePath = encryptedFilePath+outPutFileName;
			
			PaymentSplitterUtility.moveFile(fileTomove, locationToMove, false);
			//Webcash TSA Release 2 change: decrypted (xml) file also moved to either archive or error folder based on fileStausRecived
			if(deleteGeneratedTsaXml != null && deleteGeneratedTsaXml.equalsIgnoreCase("N")){
				logger.info("decrypted TSA file - "+(outPutFilePath)+" moved to "+locationToMove);
				PaymentSplitterUtility.moveFile(new File(outPutFilePath), locationToMove, false);
			}
		}/*else{
			locationToMove = erroredSftpLocation;
		}*/
		
		 
		logger.info("[SftpRetryListener] - moving file ends");
	}
}
