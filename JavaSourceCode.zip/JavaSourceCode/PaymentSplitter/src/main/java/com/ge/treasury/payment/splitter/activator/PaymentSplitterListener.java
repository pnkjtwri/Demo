package com.ge.treasury.payment.splitter.activator;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.payment.splitter.PaymentSplitterFileStatusLoader;
import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;
import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;
import com.ge.treasury.payment.splitter.exception.TransactionCountMismatchException;
import com.ge.treasury.payment.splitter.exception.XmlReaderServiceException;
import com.ge.treasury.payment.splitter.mail.service.PaymentSplitterMailService;
import com.ge.treasury.payment.splitter.process.service.PaymentSplitterService;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

/*
 * PaymentSplitterListener class will invoke 
 * the payment splitting process for the input file.
 * 
 * This class will activate after poller receives 
 * any file on the polling location.
 **/
@MessageEndpoint
public class PaymentSplitterListener {
	final static Logger logger = Logger.getLogger(PaymentSplitterListener.class);
	
	@Value("${archiveLocation}")
	private String archiveLocation;
	
	@Value("${erroredOutFileLocation}")
	private String erroredOutFileLocation;
	
	@Autowired PaymentSplitterService splitter;
	@Autowired PaymentSplitterMailService mailer;
	@Autowired PaymentSplitterPersistenceService fileLockServiceDao;
	@Autowired PaymentSplitterFileStatusLoader fileStatusLoader;
	/*
	 * initiates the payment splitting process 
	 * 
	 * @param inputFile, File received for processing
	 * */
	@ServiceActivator
	public void initiateSplitter(File inputFile){
		long startTime = new Date().getTime();
		if(inputFile.exists() && inputFile.isFile()){
			logger.info("Process started.....for file name: "+inputFile.getName());
			logger.info("[WebCashSplitterListener] - Payment Splitting Process initiated..");
				
			try{
				List<String> sftpFailedList = splitter.startPaymentSplitter(inputFile);
				failedFileNotification(sftpFailedList, inputFile.getName());
				PaymentSplitterUtility.moveFile(inputFile, archiveLocation,false);
			}catch (XmlReaderServiceException e) {
				logError(inputFile,e, PaymentSplitterConstants.MailSubjectConstants.SUB_READING_INPUT_PARAM_FOR_LOOKUP,"Error occurred while parsing the xml input file into the document object.");
			}catch(PaymentSplittingProcessException pspe){
				logError(inputFile,pspe, PaymentSplitterConstants.MailSubjectConstants.SUB_PAYMENT_SPLITTING_PROCESS_FAILED,"Error recieved inside the payment splitting process.");
			}catch(TransactionCountMismatchException e){
				logError(inputFile,e, PaymentSplitterConstants.MailSubjectConstants.SUB_TRANSACTION_COUNT_MISMATCH_ERROR,"Source and generated file transaction is not matching.");
			}catch(FileEncryptionDecryptionException e){
				logError(inputFile,e, PaymentSplitterConstants.MailSubjectConstants.SUB_ENCRYPTION_DECRYPTION_FAILED,"Encryption or decryption process failed.");
			}catch(FileHashingProcessException e){
				logError(inputFile,e, "File Hashing Exception","Error occurred while hashing process.");
			}catch(Exception e){
				logger.error("[WebCashSplitterListener] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
				logError(inputFile,e, "Not able to process this file","Error while processing");
			}
				
			logger.info("[WebCashSplitterListener] - Payment Splitting Process completed !!");
			fileLockServiceDao.deleteLockedFileDetails(inputFile.getName());
			logger.info("Process end.....for file name: "+inputFile.getName());
		}
		long endTime = new Date().getTime();
		logger.info("[WebCashSplitterListener] - Payment Splitting Process completed in - "+TimeUnit.MILLISECONDS.toSeconds(endTime-startTime)+" sec.");
	}
	
	@PostConstruct
	public void init(){
		try{
			logger.info("[WebCashSplitterListener] - loading file status..");
			fileStatusLoader.initFileStatusLoader();
			logger.info("[WebCashSplitterListener] - file status loaded..");
		}catch(Exception e){
			logger.error("[WebCashSplitterListener] - Loading of File status failed..");
			logger.error("[WebCashSplitterListener] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new RuntimeException("Initilization process failed. Not able to load file status details...."+e.getMessage());
		}
	}
	
	

	/*
	 * logError has following activity -
	 * 	1) Log error message to logger
	 * 	2) send Error mail
	 * 	3) Move input file to error location
	 * */
	private void logError(File sourceFile,Exception e, String mailSubject, String logMsg){
		logger.error("[WebCashSplitterListener] - "+logMsg);
		//sent mail
		try{
			mailer.sendErrorMail(e,mailSubject,sourceFile.getName(),null);
		}catch(Exception ex){
			logger.error("[WebCashSplitterListener] - Mail sending Failed.");
			logger.error("[WebCashSplitterListener] - "+PaymentSplitterUtility.getErrorFormStackTrace(ex));
			logger.error("[WebCashSplitterListener] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
		}
		//move file to error
		PaymentSplitterUtility.moveFile(sourceFile, erroredOutFileLocation, false);
	}
	
	/**
	 * send mail notification for failed files
	 * @param failedSftpFileList
	 */
	private void failedFileNotification(List<String> failedSftpFileList, String sourceFileName){
		List<String> failedList = new ArrayList<String>();
		if(failedSftpFileList != null && failedSftpFileList.size() > 0){
			int fileCount = 1;
			for(String file : failedSftpFileList){
				String fileName = file.substring((file.lastIndexOf(File.separator)+1),file.length());
				failedList.add(fileCount +" - "+ fileName);
				fileCount++;
			}
			try{
				mailer.sendErrorMail(null,"Sending failed to sftp location for some files",sourceFileName,failedList);
			}catch(Exception ex){
				logger.error("[WebCashSplitterListener] - Mail sending Failed while sending failed sftp file details.");
				logger.error("[WebCashSplitterListener] - "+PaymentSplitterUtility.getErrorFormStackTrace(ex));
			}
		}
	}
	
	/*
	 * @param archiveLocation the archiveLocation to set
	 */
	public void setArchiveLocation(String archiveLocation) {
		this.archiveLocation = archiveLocation;
	}
	
	/**
	 * @param erroredOutFileLocation the erroredOutFileLocation to set
	 */
	public void setErroredOutFileLocation(String erroredOutFileLocation) {
		this.erroredOutFileLocation = erroredOutFileLocation;
	}
	
}
