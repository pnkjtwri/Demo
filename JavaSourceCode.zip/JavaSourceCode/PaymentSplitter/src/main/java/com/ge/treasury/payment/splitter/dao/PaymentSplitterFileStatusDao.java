package com.ge.treasury.payment.splitter.dao;

import java.util.List;

import com.ge.treasury.payment.splitter.mapper.FileStatusMapper;

public interface PaymentSplitterFileStatusDao {
	public List<FileStatusMapper> getFileStatus();
}
