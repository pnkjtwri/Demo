package com.ge.treasury.payment.splitter.mail.service;

import java.util.List;

import javax.mail.MessagingException;

public interface PaymentSplitterMailService {
	public void sendErrorMail(Exception ex,String mailSubject,String sourceFileName, List<String> sendingFailedSftpFiles) throws MessagingException;
}
