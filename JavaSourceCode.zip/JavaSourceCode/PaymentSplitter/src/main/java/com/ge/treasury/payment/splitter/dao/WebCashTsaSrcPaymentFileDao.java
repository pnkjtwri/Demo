package com.ge.treasury.payment.splitter.dao;

import java.util.List;
import java.util.Map;

import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;

public interface WebCashTsaSrcPaymentFileDao {
	public void insertSrcPaymentFileDetail(WebcashTsaSrcPaymentFileMapper srcPaymentFile);
	public void upddateSrcPaymentFileDetail(Map<String,Object> param);
	public List<WebcashTsaSrcPaymentFileMapper> getDetailsFromFileHash(String hashCode);
	public Integer getBusinessId(String optionID);
}
