package com.ge.treasury.payment.splitter.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.bouncycastle.openpgp.PGPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;

@Component
public class PGPFileProcessor {
	private static final Logger logger = LoggerFactory.getLogger(PGPFileProcessor.class);
    private StringBuffer decryptedData=new StringBuffer();
    private boolean asciiArmored = true;
    private boolean integrityCheck = true; 

    public boolean encrypt(File inputFileName, String outputFileName, String publicKeyFileName) throws FileEncryptionDecryptionException { 
    	logger.info("[PGPFileProcessor] - encrypt: entered");  
    	FileOutputStream out = null;
    	FileInputStream keyIn = null;
    	try{
	    	File newFile=new File(publicKeyFileName);
	        keyIn = new FileInputStream(newFile.getAbsolutePath()); 
	        out = new FileOutputStream(outputFileName);
	        PGPUtils.encryptFile(out, inputFileName, PGPUtils.readPublicKey(keyIn), asciiArmored, integrityCheck);
	        out.close();
	        keyIn.close();
    	}catch(Exception e){
    		logger.error("[PGPFileProcessor] - Encryption Failed !!");
    		logger.error("[PGPFileProcessor] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
            throw new FileEncryptionDecryptionException("Encryption process is failed.",e);
    	}finally{
    		try{
    			if(out != null){
    				out.close();
    			}
    			if(keyIn != null){
    				keyIn.close();
    			}
    		}catch(Exception e){
    			logger.error("[PGPFileProcessor] - Error closing Stream");
    		}
    	}
        logger.info("[PGPFileProcessor] - encrypt: exit");
        return true;
    }

    /**
     * 
     * @return
     * @throws IOException 
     * @throws PGPException 
     * @throws Exception
     */
    public boolean decrypt(File inputFileName, String outputFileName, String secretKeyFileName, String passphrase) throws FileEncryptionDecryptionException  {
    	logger.info("[PGPFileProcessor] - decrypt: entered");
    	FileInputStream in = null;
    	FileInputStream keyIn = null;
    	try{
	        in = new FileInputStream(inputFileName);  
	        keyIn = new FileInputStream(secretKeyFileName);
	        PGPUtils.decryptFile(in, decryptedData, keyIn, passphrase.toCharArray(),outputFileName);
	        keyIn.close();
	        in.close();
    	}catch(Exception e){
    		logger.error("[PGPFileProcessor] - Decryption Failed !!");
    		logger.error("[PGPFileProcessor] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
    		logger.error("[PGPFileProcessor] - Going to delete encrypted file - "+inputFileName.getName());
    		try{
    			if(keyIn != null){
    				keyIn.close();
    			}
    			if(in != null){
    				in.close();
    			}
    		}catch(Exception ex){
    			logger.error("[PGPFileProcessor] - Error closing Stream");
    			logger.error("[PGPFileProcessor] - "+PaymentSplitterUtility.getErrorFormStackTrace(ex));
    		}
    		PaymentSplitterUtility.deleteFile(inputFileName);
            throw new FileEncryptionDecryptionException("Decryption process is failed.",e);
    	}
    	finally{
    		try{
    			if(keyIn != null){
    				keyIn.close();
    			}
    			if(in != null){
    				in.close();
    			}
    		}catch(Exception e){
    			logger.error("[PGPFileProcessor] - Error closing Stream");
    		}
    	}
        
        logger.info("[PGPFileProcessor] - decrypt: exit");
        return true;
    } 

    /*public boolean decryptWithOutFile() throws Exception  {
    	logger.debug("decrypt: entered");
        FileInputStream in = new FileInputStream(inputFileName);
        FileOutputStream out = new FileOutputStream(outputFileName);
        File newFile=ResourceUtils.getFile("classpath:"+secretKeyFileName);
        FileInputStream keyIn = new FileInputStream(newFile.getAbsolutePath()); 
        PGPUtils.decryptFile(in, out, keyIn,  passphrase.toCharArray());
        in.close();  
        out.close();
        keyIn.close();
        logger.debug("decrypt: exit");
        return true;
    }*/

	/**
     * 
     * @return
     * @throws Exception
     */
    /*public boolean verifyFile(File inputFileName, String secretKeyFileName, String publicKeyFileName, String passphrase) throws Exception {
    	logger.info("verifyFile: entered");
        FileInputStream in = new FileInputStream(inputFileName);
        FileInputStream keyIn = new FileInputStream(secretKeyFileName);
        FileInputStream pubKeyIn = new FileInputStream(publicKeyFileName);
        PGPUtils.verifyFileForEncryption(in, keyIn, pubKeyIn, passphrase.toCharArray());
        in.close(); 
        keyIn.close();
        logger.debug("verifyFile: exit");
        return true;
    }*/  
    
    /**
	 * @return the decryptedData
	 */
	public StringBuffer getDecryptedData() {
		return decryptedData;
	}

	/**
	 * @param decryptedData the decryptedData to set
	 */
	public void setDecryptedData(StringBuffer decryptedData) {
		this.decryptedData = decryptedData;
	}

}
