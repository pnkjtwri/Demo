package com.ge.treasury.payment.splitter.process.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.ge.treasury.payment.splitter.PaymentSplitterFileStatusLoader;
import com.ge.treasury.payment.splitter.checksum.PaymentSplitterCheckSumGenerator;
import com.ge.treasury.payment.splitter.encryption.service.PaymentSplitterEncryptionService;
import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.exception.FileHashingProcessException;
import com.ge.treasury.payment.splitter.exception.PaymentSplittingProcessException;
import com.ge.treasury.payment.splitter.exception.TransactionCountMismatchException;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaPfiTransactionsMapper;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSegregatorFileMapper;
import com.ge.treasury.payment.splitter.process.PaymentSplitterProcess;
import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

/*
 * PaymentSplitterProcessImpl, has to perform following activity -
 * 	1) Split the payments
 * 	2) encrypt the payments if it belongs to TSA
 *  3) transfer encrypted files
 * 
 * */

@Component
public class PaymentSplitterProcessImpl implements PaymentSplitterProcess {
	final static Logger logger = Logger.getLogger(PaymentSplitterProcessImpl.class);
	
	@Value("${tsaOutputFileLocation}")
	private String tsaOutPutFileLocation;
	@Value("${nonTsaOutputFileLocation}")
	private String nonTsaOutputFileLocation;
	@Value("${encryptedFilePath}")
	private String encryptedFilePath;
	@Value("${isTransactionDetailsPersist}")
	private String isTransactionDetailsPersist;
	
	@Value("${encryptedServiceUrl}")
	private String encryptingService;
	
	@Value("${archivedSftpFiles}")
	private String archivedSftpLocation;
	
	/*@Value("${erroredSftpFiles}")
	private String erroredSftpLocation;*/
	@Value("${retryLocation}")
	private String retryLocationForFailedSftpFiles;
	
	@Value("${webcashTemplateFileLocation}")
	private String templateFileLocation;
	
	@Value("${deleteGeneratedTsaXml}")
	private String deleteGeneratedTsaXml;
	
	@Value("${nonTsaTmpFileLocation}")
	private String nonTsaTmpFileLocation;
	
	/*private DocumentBuilderFactory docBulderFactory;
	private DocumentBuilder dBuilder;
	private Document xmlDocumentObject;*/
	
	private List<Integer> tsaTxnIdxList    = null;
	
	/*File tsaFileLocation 	= null;*/
	/*File nonTsaFileLocation = null;*/
	
	@Autowired PaymentSplitterEncryptionService encDecService;
	@Autowired PaymentSplitterPersistenceService fileDaoService;
	@Autowired PaymentSplitterCheckSumGenerator hashingService;
	@Autowired PaymentSplitterFileStatusLoader fileStatus;
	
	/*
	 * This method will split the Payments into multiple files
	 * and also encrypt/decrypt the file if it belongs to TSA
	 * 
	 * @return List<String>, Failed sftp file details
	 * @param File inputFile, Source file
	 * @param Map<String, Object> tsa_NonTsaTxnMap, List of transactions index positions for TSA/NON-TSA
	 * @param Integer sourceFileTransactionCount, Count of transaction from the source file
	 * @param Integer srcPaymentFileId, unique id from data base 
	 * @param String optionId, id from source file
	 * @param String gwixUserId, user id from file
	 * @param String gwixUniqueId, id from file
	 *  
	 * */
	@Override
	@Transactional(rollbackFor={PaymentSplittingProcessException.class,TransactionCountMismatchException.class,FileEncryptionDecryptionException.class,Exception.class})
	public List<String> paymentSplitter(File inputFile, Map<String, Object> tsa_NonTsaTxnMap, Integer sourceFileTransactionCount, Integer srcPaymentFileId, Map<String,String> detailsFromFileName )throws PaymentSplittingProcessException,TransactionCountMismatchException,FileEncryptionDecryptionException {
		long startTimePaymentSplitter         = new Date().getTime();
		Integer totalTsaPaymentCount  		  = 0;
		FileInputStream sourceFileStream      = null;
		List<Integer> allTsaIndexPositionList = new ArrayList<Integer>();
		Map<String,String> listOfEncryptedTsaFiles    = new HashMap<String, String>();
	 	Map<String,Object> transferFileDetails 	= new HashMap<String, Object>();
	 	List<String> sftpFailedFileList         = null;
	 	for (Map.Entry<String, String> entry : detailsFromFileName.entrySet()) {
			logger.info("detailsFromFileName::"+entry.getKey()+" : "+entry.getValue());
		}
		File nonTsaFileLocation = null;
	 	
		//List<WebcashTsaPfiTransactionsMapper> allTsaMapperBeanList 	= null;
		String todayDate  					  						= new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		
		try{
			//we have tsa list of transactions
			if( tsa_NonTsaTxnMap != null && tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY)){
				totalTsaPaymentCount = tsaSplitProcess(detailsFromFileName,tsa_NonTsaTxnMap, srcPaymentFileId, allTsaIndexPositionList, todayDate, listOfEncryptedTsaFiles, inputFile, sourceFileStream);
				
				//listOfTsaFiles, list of all tsa files to be send
				if(listOfEncryptedTsaFiles != null && listOfEncryptedTsaFiles.size() > 0){
					String optionId = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.OPTION_ID_FROM_FILENAME);
					String userId   = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.USER_ID_FROM_FILENAME);
					Integer operatorId = null;
					try{
						operatorId = Integer.parseInt(userId);
					}catch(Exception e){
						logger.info("[PaymentSplitterProcessImpl] - user id is not valid for manual - "+operatorId);
					}
					
					for(String item:listOfEncryptedTsaFiles.keySet()){
						File fileToSend = new File(listOfEncryptedTsaFiles.get(item));
						//transferFileDetails.put(item+"_"+optionId+"_"+userId, fileToSend);
						String tsaIdentifier = item.split("_")[0];
						if(operatorId != null && String.valueOf(operatorId).length() == 9){
							transferFileDetails.put(tsaIdentifier+"_"+optionId+"_"+userId, fileToSend);
						}else{
							transferFileDetails.put(tsaIdentifier+"_"+optionId, fileToSend);
						}
					}
				}
			}
			
			//we have Non TSA Transaction 
			if( tsa_NonTsaTxnMap != null && tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY)
				&& 	tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.NON_TSA_TRANSACTION_INDEX_KEY)){
				List<File> nonTsaFileLocationList = new ArrayList<File>();
				nonTsaSplitProcess(detailsFromFileName,nonTsaFileLocationList, srcPaymentFileId, allTsaIndexPositionList, inputFile, todayDate, tsa_NonTsaTxnMap, sourceFileStream, totalTsaPaymentCount, sourceFileTransactionCount);
				if(nonTsaFileLocationList.size() > 0){
					nonTsaFileLocation = nonTsaFileLocationList.get(0);
				}
			}else if(nonTsaFileLocation == null  && listOfEncryptedTsaFiles.size() <= 0){
				//Only Webcash transaction we have in the file
				webCashFileOnly(sourceFileTransactionCount,detailsFromFileName, sourceFileStream, inputFile, srcPaymentFileId, tsa_NonTsaTxnMap);
			}else if(nonTsaFileLocation == null  && listOfEncryptedTsaFiles.size() > 0) {
				//we have only Tsa transactions, then we have to copy empty webcash file
				//String orignalFileName = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.ORIGINAL_FILE_NAME_FROM_FILENAME);
				String gwixUniqueId    = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.GWIX_UNIQUE_ID_FROM_FILENAME);
				String nonTsaOutputFileName 	= gwixUniqueId+".xml";
				
				URL resource 		= this.getClass().getClassLoader().getResource(templateFileLocation);
				File file 			= new File(resource.toURI());
				logger.info("[PaymentSplitterProcessImpl] - Template file - "+resource.toURI());
				sourceFileStream 	= new FileInputStream(file);
				
				//sourceFileStream 			= new FileInputStream(templateFileLocation);
				PaymentSplitterUtility.copySourceFileToDestination((nonTsaOutputFileLocation+nonTsaOutputFileName), sourceFileStream);
				sourceFileStream.close();
			}
			
			String messageAfterCompleteion     = "";
			Integer fileStausAfterCompletion   = 0;
			String segregationFlag             = "N";

			if(listOfEncryptedTsaFiles != null && listOfEncryptedTsaFiles.size() > 0){
				logger.info("[PaymentSplitterProcessImpl] - Encrypted files list -"+listOfEncryptedTsaFiles.size());
				logger.info("[PaymentSplitterProcessImpl] - transfer files details -"+transferFileDetails.size());
				//Going to sftp all the files
				sftpFailedFileList = transaferFilesToSftpLocation(transferFileDetails,listOfEncryptedTsaFiles, srcPaymentFileId, nonTsaFileLocation);
				
				if(listOfEncryptedTsaFiles.size() > 1){//only multiple tsainstance ids
					messageAfterCompleteion     = PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED;
					fileStausAfterCompletion    = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED);
					segregationFlag				= "Y";
				}else if(listOfEncryptedTsaFiles.size() > 0 && nonTsaFileLocation != null){//one tsa instance id and webcash transactions
					messageAfterCompleteion     = PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED;
					fileStausAfterCompletion    = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED);
					segregationFlag				= "Y";
				}else{//we have only one tsainstance id
					messageAfterCompleteion     = PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED+", Only one tsa Payments Found";
					fileStausAfterCompletion    = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED);
					segregationFlag				= "N";
				}
			}else if(nonTsaFileLocation == null && (listOfEncryptedTsaFiles != null && listOfEncryptedTsaFiles.size() <= 0)){
				messageAfterCompleteion     = PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED+", Only Non-Tsa Payments Found";
				fileStausAfterCompletion    = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_COMPLETED);
				segregationFlag				= "N";
			}
			
			//Setting file status
			updateFileStatus(messageAfterCompleteion, srcPaymentFileId, fileStausAfterCompletion,segregationFlag);
			long endTimePaymentSplitter         = new Date().getTime();
			logger.info("[PaymentSplitterProcessImpl] - Time taken to execute paymentSplitter() method in - "+TimeUnit.MILLISECONDS.toSeconds(endTimePaymentSplitter-startTimePaymentSplitter)+" sec");
		}catch(FileNotFoundException e){
			logError(nonTsaFileLocation, "Not able to create source file stream while generating xml files.",e,srcPaymentFileId,listOfEncryptedTsaFiles);
			throw new PaymentSplittingProcessException("Not able to create source file, source File not found.",e);
		}catch(PaymentSplittingProcessException e){
			logError(nonTsaFileLocation, "Getting error while splitting payments.",e,srcPaymentFileId,listOfEncryptedTsaFiles);
			throw new PaymentSplittingProcessException(e.getMessage(),e);
		}catch(IOException io){
			logError(nonTsaFileLocation, "IO Exception occurred.",io,srcPaymentFileId,listOfEncryptedTsaFiles);
			throw new PaymentSplittingProcessException(io.getMessage(),io);
		}
		catch (FileEncryptionDecryptionException e) {
			logError(nonTsaFileLocation, "Getting error while encrypting files.",e,srcPaymentFileId,listOfEncryptedTsaFiles);
			throw new FileEncryptionDecryptionException("Encryption/Decryption process failed. Not able to encrypt/decrypt the file.",e);
		}catch(Exception e){
			logError(nonTsaFileLocation, "Getting error while processing files.",e,srcPaymentFileId,listOfEncryptedTsaFiles);
			throw new PaymentSplittingProcessException("Getting error while processing files. Not able to process the file.",e);
		}
		finally{
			if(sourceFileStream != null){
				try {
					sourceFileStream.close();
				} catch (IOException e) {
					logger.error("[PaymentSplitterProcessImpl] - Not able to close stream");
					logger.error("[PaymentSplitterProcessImpl] - " + PaymentSplitterUtility.getErrorFormStackTrace(e));
				}
			}
		}
		
		return sftpFailedFileList;
	}
	
	
	/**
	 * tsaPaymentSplitter, will find the Non tsa 
	 * transactions index positions 
	 * and remove from the file, to prepare only 
	 * tsa list of transactions in the file.
	 *  
	 * @param sourceFileStream
	 * @param transactionToBeremoved
	 * @param tsaOutPutFileName
	 * @return
	 * @throws PaymentSplittingProcessException
	 */
	private Integer tsaPaymentSplitter(List<File> tsaFilePathList, FileInputStream sourceFileStream,List<Integer> transactionToBeremoved, String tsaOutPutFileName) throws PaymentSplittingProcessException{
		logger.info("[PaymentSplitterProcessImpl] - Startng payment splitting process for tsa Payments");
		logger.info("[PaymentSplitterProcessImpl] - tsa output location - "+tsaOutPutFileLocation+tsaOutPutFileName);
		int tsaRecordsForThisFile  = 0;
		File tsaFileLocation = null;
		if(sourceFileStream != null){
			tsaFileLocation = new File(tsaOutPutFileLocation+tsaOutPutFileName);
			PaymentSplitterUtility.copySourceFileToDestination(tsaFileLocation.getAbsolutePath(), sourceFileStream);
		}
		
		if(tsaFileLocation != null){
			tsaFilePathList.add(tsaFileLocation);
		}
		
		/**init document object for output file*/
		Document xmlDocumentObject = initDocument(tsaFileLocation);
		
		try{
			Element rootElement = xmlDocumentObject.getDocumentElement();
			if(transactionToBeremoved != null && transactionToBeremoved.size() > 0){
				for (int delCount = 0; delCount < transactionToBeremoved.size(); delCount++) {
					Integer idxPosition = transactionToBeremoved.get(delCount);
					idxPosition 		= idxPosition - delCount;
					rootElement.removeChild(xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_ELEMENT).item(idxPosition));
				}
			}
			
			if(tsaTxnIdxList != null && tsaTxnIdxList.size() > 0){
				tsaRecordsForThisFile = tsaTxnIdxList.size();
			}

			/*try{
				xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TOTAL_RECORD_ELEMENT).item(0).setTextContent(tsaRecordsForThisFile+"");
			}catch(Exception e){
				// do nothing, log the event
			}*/
			
			String xmlEncoding = xmlDocumentObject.getXmlEncoding();
			if(xmlEncoding == null)
				xmlEncoding = "UTF-8";
			
			xmlDocumentObject.normalizeDocument();
			tsaRecordsForThisFile = transformGeneratedXml(xmlEncoding,tsaFileLocation,xmlDocumentObject);
			
		}catch(Exception e){
			logger.error("[PaymentSplitterProcessImpl] - Error while processing on the tsa Payments splitting process.");
			logger.error("[PaymentSplitterProcessImpl] - " + PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("Error while processing on the tsa Payments splitting process.",e);
		}
		logger.info("[PaymentSplitterProcessImpl] - Payment splitting process for tsa Complete");
		
		return tsaRecordsForThisFile;
	}

	
	/**
	 * nonTsaPaymentSplitter, will find the tsa 
	 * transactions index positions 
	 * and remove from the file, to prepare only 
	 * NON TSA list of transactions in the file.
	 * 
	 * @param sourceFileStream
	 * @param allTsaIndexPositionList
	 * @param transactionCount
	 * @param nonTsaOutputFileName
	 * @return
	 * @throws PaymentSplittingProcessException
	 */
	private Integer nonTsaPaymentSplitter(List<File> nonTsaFileLocationList, FileInputStream sourceFileStream, List<Integer>allTsaIndexPositionList, Integer transactionCount, String nonTsaOutputFileName) throws PaymentSplittingProcessException{
		logger.info("[PaymentSplitterProcessImpl] - Startng payment splitting process for NON TSA Payments");
		logger.info("[PaymentSplitterProcessImpl] - NON TSA output location - "+nonTsaTmpFileLocation+nonTsaOutputFileName);
		
		int totalNonTsaRecords  = 0;
		//File nonTsaFileLocation = null;
		File nonTsaFileTmpLocation = null;
		if(sourceFileStream != null){
			//nonTsaFileLocation = new File(nonTsaOutputFileLocation+nonTsaOutputFileName);
			nonTsaFileTmpLocation = new File(nonTsaTmpFileLocation+nonTsaOutputFileName);
			PaymentSplitterUtility.copySourceFileToDestination(nonTsaFileTmpLocation.getAbsolutePath(), sourceFileStream);
		}
		if(nonTsaFileTmpLocation != null){
			nonTsaFileLocationList.add(nonTsaFileTmpLocation);
		}
		
		/**
		 * init document object for output tsa file
		 * */
		Document xmlDocumentObject = initDocument(nonTsaFileTmpLocation);
		
		try{
			String xmlEncoding = xmlDocumentObject.getXmlEncoding();
			if(xmlEncoding == null)
				xmlEncoding = "UTF-8";
			
			Element rootElement = xmlDocumentObject.getDocumentElement();
			if(allTsaIndexPositionList != null && allTsaIndexPositionList.size() > 0){
				for (int delCount = 0; delCount < allTsaIndexPositionList.size(); delCount++) {
					Integer idxPosition = allTsaIndexPositionList.get(delCount);
					idxPosition 		= idxPosition - delCount;
					rootElement.removeChild(xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TRANSACTION_ELEMENT).item(idxPosition));
				}
			}
			
			/*try{
				xmlDocumentObject.getElementsByTagName(PaymentSplitterConstants.TransactionElementConstants.TOTAL_RECORD_ELEMENT).item(0).setTextContent(transactionCount+"");
			}catch(Exception e){
				//Do Nothing, log the event
			}*/
			xmlDocumentObject.normalizeDocument();
			totalNonTsaRecords = transformGeneratedXml(xmlEncoding,nonTsaFileTmpLocation,xmlDocumentObject);
		}catch(Exception e){
			logger.error("[PaymentSplitterProcessImpl] - Error while processing on the NON TSA Payments splitting process.");
			logger.error("[PaymentSplitterProcessImpl] - " + PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("Error while processing on the NON TSA Payments splitting process.",e);
		}
		logger.info("[PaymentSplitterProcessImpl] - Payment splitting process for NON TSA Complete");
		return totalNonTsaRecords;
	}
	
	/**
	 * Remove the white spaces from generated file
	 * and transform the generated file in formatted way.
	 * 
	 * @param xmlEncoding
	 * @param generatedFileLocation
	 * @return
	 * @throws TransformerException
	 * @throws IOException
	 * @throws PaymentSplittingProcessException
	 */
	private Integer transformGeneratedXml(String xmlEncoding, File generatedFileLocation, Document xmlDocumentObject) throws TransformerException, IOException, PaymentSplittingProcessException{
		Integer totalRecords = 0;
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, xmlEncoding);
		DOMSource source = new DOMSource(xmlDocumentObject);
		StreamResult result = new StreamResult(generatedFileLocation);
		transformer.transform(source, result);
		
		if(tsaTxnIdxList != null){
			/**We are adding Nodes in case of CMM, so need to check if this is also applicable for TSA*/
			PaymentSplitterUtility.addNodeProcessBlock(generatedFileLocation, "optionCode", "gwixUser","N");
		}
		
		PaymentSplitterUtility.removeWhitSpace(generatedFileLocation, xmlEncoding);
		totalRecords = PaymentSplitterUtility.generateFileAfterRemovingWhiteSpace(generatedFileLocation);
		
		return totalRecords;
	}
	
	/*
	 * This method is used to initialized & create the document object
	 * for the TSA/NON-TSA file.
	 * 
	 * @param File gneratedFile, Files generated for TSA/NON-TSA
	 * */
	private Document initDocument(File gneratedFile) throws PaymentSplittingProcessException{
		logger.info("[PaymentSplitterProcessImpl] - Start document initiliazer for - "+gneratedFile.getName());
		FileInputStream inputStream = null;
		DocumentBuilderFactory docBulderFactory	= null;
		DocumentBuilder dBuilder				= null;
		Document xmlDocumentObject				= null;
		
		try {
			inputStream         = new FileInputStream(gneratedFile);
			docBulderFactory 	= DocumentBuilderFactory.newInstance();
			dBuilder 			= docBulderFactory.newDocumentBuilder();
			xmlDocumentObject	= dBuilder.parse(inputStream);
			xmlDocumentObject.getDocumentElement().normalize();
			logger.info("[PaymentSplitterProcessImpl] - Initialized !!");
		}catch (ParserConfigurationException e) {
			logger.error("[PaymentSplitterProcessImpl] - Initialization failed for - "+gneratedFile.getName());
			logger.error("[PaymentSplitterProcessImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("Parser Failed to parse the file.",e);
		}catch (SAXException e) {
			logger.error("[PaymentSplitterProcessImpl] - Initialization failed for - "+gneratedFile.getName());
			logger.error("[PaymentSplitterProcessImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("SAXException found while creating document object.",e);
		} catch (IOException e) {
			logger.error("[PaymentSplitterProcessImpl] - Initialization failed for - "+gneratedFile.getName());
			logger.error("[PaymentSplitterProcessImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new PaymentSplittingProcessException("File not found while parsing.",e);
		}
		finally{
			if(inputStream != null){
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("[PaymentSplitterProcessImpl] - Not able to close input stream for - "+gneratedFile.getName());
					logger.error("[PaymentSplitterProcessImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
				}
			}
		}
		return xmlDocumentObject;
	}
	
	/**
	 * prepare object for WebcashTsaSegregatorFileMapper
	 * @param srcPaymentFileId
	 * @param segregatorFileName
	 * @param paymentInstType
	 * @param tsaInstanceId
	 * @param fileStatusId
	 * @param importStatusFileName
	 * @param noOfPayments
	 * @param hashString
	 * @return
	 */
	private WebcashTsaSegregatorFileMapper getSegregationDetails(Integer srcPaymentFileId,String segregatorFileName, String paymentInstType, Integer tsaInstanceId, Integer fileStatusId,String importStatusFileName,Integer noOfPayments, String hashString){
		WebcashTsaSegregatorFileMapper fileSegregationDetails = new WebcashTsaSegregatorFileMapper();
		Timestamp defaultTimeStamp = new Timestamp(System.currentTimeMillis());
		
		fileSegregationDetails.setSrcPaymentFileId(srcPaymentFileId);
		fileSegregationDetails.setSegregatorFileName(segregatorFileName);
		fileSegregationDetails.setPaymentInstType(paymentInstType);
		fileSegregationDetails.setTsaInstanceId(tsaInstanceId);
		fileSegregationDetails.setFileStatusId(fileStatusId);
		/*fileSegregationDetails.setImportStatusFileName(importStatusFileName);*/
		fileSegregationDetails.setNoOfTransactions(noOfPayments);
		fileSegregationDetails.setCreatedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		fileSegregationDetails.setLastModifiedBy(PaymentSplitterConstants.GenericConstants.DEFAULT_SSO);
		fileSegregationDetails.setCreatedTimeStamp(defaultTimeStamp);
		fileSegregationDetails.setLastModifiedTimeStamp(defaultTimeStamp);
		fileSegregationDetails.setHashString(hashString);
		
		return fileSegregationDetails;
	}
	
	
	/**
	 * log error messages
	 * 
	 * @param msg
	 * @param e
	 * @param srcPaymentFileId
	 * @param listOfTsaFiles
	 */
	private void logError(File nonTsaFileLocation, String msg, Exception e, Integer srcPaymentFileId,Map<String,String> listOfTsaFiles){
		logger.error("[PaymentSplitterProcessImpl] - "+msg);
		
		if(e != null){
			logger.error("[PaymentSplitterProcessImpl] - " + PaymentSplitterUtility.getErrorFormStackTrace(e));
		}
		try{
			if(listOfTsaFiles != null && listOfTsaFiles.size() > 0){
				for(String tsaInsId : listOfTsaFiles.keySet()){
					String deletingFileName = listOfTsaFiles.get(tsaInsId);
					//deleting encrypted file for TSA
					PaymentSplitterUtility.deleteFile(new File(deletingFileName));
					
					//deleting generated tsa xml files
					deletingFileName        = deletingFileName.substring((deletingFileName.lastIndexOf(File.separatorChar)+1),(deletingFileName.lastIndexOf(PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION)));
					PaymentSplitterUtility.deleteFile(new File(tsaOutPutFileLocation+deletingFileName));
				}
			}
			if(nonTsaFileLocation != null){
				PaymentSplitterUtility.deleteFile(nonTsaFileLocation);
			}
		}catch(Exception ex){
			logger.error("[PaymentSplitterProcessImpl] - " + PaymentSplitterUtility.getErrorFormStackTrace(ex));
		}
	}
	
	/**
	 * updating the message in the data base
	 * 
	 * @param message
	 * @param srcPaymentFileId
	 * @param fileStatusId
	 * @param segregationFlag
	 */
	private void updateFileStatus(String message, Integer srcPaymentFileId, Integer fileStatusId, String segregationFlag){
		Timestamp defaultTimeStamp = new Timestamp(System.currentTimeMillis());
		Map<String,Object> updSrcFileParam = new HashMap<String, Object>();
		updSrcFileParam.put("srcPaymentFileId", srcPaymentFileId);
		updSrcFileParam.put("splitMessage", message);
		updSrcFileParam.put("fileStatusId", fileStatusId);
		updSrcFileParam.put("modifiedTime", defaultTimeStamp);
		if(segregationFlag != null){
			updSrcFileParam.put("segregationFlag", segregationFlag);
		}
		fileDaoService.updInputFileDetails(updSrcFileParam);
	}
	
	/**
	 * Update splitted file details with file status 
	 * 
	 * @param srcPaymentFileId
	 * @param tsaInstancesId
	 * @param fileStatusId
	 */
	private void updateSegregatedFileStatus(List<WebcashTsaSegregatorFileMapper> fileMapperList){
		fileDaoService.updFileSegregationDetails(fileMapperList);
	}
	
	/**
	 * method is creating TSA Files if any Tsa instance Id is found
	 * 
	 * @param tsa_NonTsaTxnMap
	 * @param srcPaymentFileId
	 * @param allTsaIndexPositionList
	 * @param todayDate
	 * @param encryptedListOfTsaFiles
	 * @param allTsaMapperBeanList
	 * @param inputFile
	 * @param sourceFileStream
	 * @return
	 * @throws PaymentSplittingProcessException
	 * @throws IOException
	 * @throws FileEncryptionDecryptionException
	 * @throws FileHashingProcessException
	 */
	@SuppressWarnings("unchecked")
	private Integer tsaSplitProcess(Map<String,String> detailsFromFileName, Map<String, Object> tsa_NonTsaTxnMap, Integer srcPaymentFileId,List<Integer> allTsaIndexPositionList, String todayDate,
			Map<String,String> encryptedListOfTsaFiles, File inputFile, FileInputStream sourceFileStream) throws PaymentSplittingProcessException, IOException, FileEncryptionDecryptionException, FileHashingProcessException{
		Integer totalTsaPaymentCount = 0;
		//Setting file status
		updateFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_IN_PROGRESS, srcPaymentFileId, fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_IN_PROGRESS),"Y");
		List<WebcashTsaPfiTransactionsMapper> allTsaMapperBeanList = null;
		//getting all TSA Transaction index positions list from tsa_NonTsaTxnMap
		Map<String,Object> tsaTransactionsCollection = (Map<String, Object>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_INDEX_KEY);
		
		if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY)){
			//tsaInstanceIdList, will have all tsa Instance Id
			List<String> tsaInstanceIdList = (List<String>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.TSA_INSTANCE_ID_LIST_KEY);
			if(tsaInstanceIdList != null && tsaInstanceIdList.size() > 0){
				List<Integer> transactionToBeremoved = null;
				allTsaMapperBeanList 	= new ArrayList<WebcashTsaPfiTransactionsMapper>();
				for(int tsaIdCount = 0; tsaIdCount < tsaInstanceIdList.size(); tsaIdCount++){
					String tmpTSaInstanceId = tsaInstanceIdList.get(tsaIdCount);
					tsaTxnIdxList           = (List<Integer>)tsaTransactionsCollection.get(tmpTSaInstanceId);
					
					//this list will be used for generating non-tsa file
					allTsaIndexPositionList.addAll(tsaTxnIdxList);
					transactionToBeremoved  = new ArrayList<Integer>();
					
					//Adding rest of the tsa transaction idx postion which sholud not be in tmpTSaInstanceId file
					String tmpTsaInsId = ""; //for this tsa instance id we are going to generate the file
					for(int listCount = 0; listCount < tsaInstanceIdList.size(); listCount++){
						tmpTsaInsId = "";
						tmpTsaInsId = tsaInstanceIdList.get(listCount);
						if(!tmpTSaInstanceId.equalsIgnoreCase(tmpTsaInsId)){
							//we are preparing list of transaction to be removed from current tsa file
							transactionToBeremoved.addAll((List<Integer>)tsaTransactionsCollection.get(tmpTsaInsId));
						}
					}
					
					//add non tsa index positions in transactionToBeremoved list
					if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.NON_TSA_TRANSACTION_INDEX_KEY)){
						transactionToBeremoved.addAll((List<Integer>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.NON_TSA_TRANSACTION_INDEX_KEY));
					}
					for (Map.Entry<String, String> entry : detailsFromFileName.entrySet()) {
						logger.info("detailsFromFileName::"+entry.getKey()+" : "+entry.getValue());
					}
					//create file name for tmpTsaInstanceId
					String gwixUserId      = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.USER_ID_FROM_FILENAME);
					String orignalFileName = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.ORIGINAL_FILE_NAME_FROM_FILENAME);
					String gwixUniqueId    = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.GWIX_UNIQUE_ID_FROM_FILENAME);
					String optionId		   = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.OPTION_ID_FROM_FILENAME);
					
					//String tsaOutPutFileName	= gwixUserId+"_"+orignalFileName+"_"+gwixUniqueId+"_"+optionId+"_"+tmpTSaInstanceId+".xml";
					//Change in TSA File Name - be <COMPANYALIAS>_<INSTITUTION>_<FILETYPE>
					String tsaOutPutFileName	= "";
					Integer userId = null;
					
					try{
							userId = Integer.parseInt(gwixUserId);
						}catch(Exception e){
							//NOT a Valid user Id 
						}
					
					if(userId != null && String.valueOf(userId).length() == 9){
						tsaOutPutFileName	= detailsFromFileName.get(tmpTSaInstanceId)+"_"+optionId+"_"+gwixUserId+"_"+orignalFileName+"_"+gwixUniqueId+"_"+todayDate+"_"+ThreadLocalRandom.current().nextInt(30000)+".xml";
					}else{
						tsaOutPutFileName	= detailsFromFileName.get(tmpTSaInstanceId)+"_"+optionId+"_"+orignalFileName+"_"+gwixUniqueId+"_"+todayDate+"_"+ThreadLocalRandom.current().nextInt(30000)+".xml";
					}
					
					if(transactionToBeremoved != null && transactionToBeremoved.size() > 0){
						Collections.sort(transactionToBeremoved);
						sourceFileStream 		= new FileInputStream(inputFile);
						
						List<File> tsaFilePathList = new ArrayList<File>();
						
						//going to split the files
						int tsaPaymentCount 	= tsaPaymentSplitter(tsaFilePathList,sourceFileStream,transactionToBeremoved,tsaOutPutFileName);
						sourceFileStream.close();
						
						File tsaFileLocation = null;
						
						if(tsaFilePathList.size() > 0){
							tsaFileLocation = tsaFilePathList.get(0);
						}
						
						//Encrypting the generated file
						encDecService.encryptFile(tsaFileLocation);
						//encryptedListOfTsaFiles.put(detailsFromFileName.get(tmpTSaInstanceId),encryptedFilePath+tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION);
						
						//getting hash code for generated file
						String tsaFileHashCode = hashingService.getCheckSumValueForFile(tsaFileLocation, PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
						//getting bean details for tsaId
						WebcashTsaSegregatorFileMapper tsaFileSegregatorDetails = getSegregationDetails(srcPaymentFileId,(tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION),"TSA",Integer.parseInt(tmpTSaInstanceId),fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_READY_TO_TRANSFER),tsaFileLocation.getName(),tsaPaymentCount,tsaFileHashCode);
						
						//persisting details in T_WEBCASHTSA_SEGREGATOR_FILE table
						Integer splittedFileId   = fileDaoService.saveFileSegregationDetails(tsaFileSegregatorDetails);
						encryptedListOfTsaFiles.put(detailsFromFileName.get(tmpTSaInstanceId)+"_"+splittedFileId,encryptedFilePath+tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION);
						
						//update transaction table T_WEBCASHTSA_PFI_TRANSACTIONS for fileId
						if(tsaTransactionsCollection.containsKey(tmpTSaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY)){
							List<WebcashTsaPfiTransactionsMapper> tsaTransactionMapperBeanList 		= (ArrayList<WebcashTsaPfiTransactionsMapper>)tsaTransactionsCollection.get(tmpTSaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY);
							for(int beanCount = 0; beanCount < tsaTransactionMapperBeanList.size(); beanCount++){
								tsaTransactionMapperBeanList.get(beanCount).setSegregatorFileId(splittedFileId);
								tsaTransactionMapperBeanList.get(beanCount).setSrcPaymentFileId(srcPaymentFileId);
								allTsaMapperBeanList.add(tsaTransactionMapperBeanList.get(beanCount));
								
							}
						}
						totalTsaPaymentCount += tsaPaymentCount;
					}else if (tsaInstanceIdList.size() == 1 && transactionToBeremoved != null && transactionToBeremoved.size() <= 0){
						///payments belongs to only one tsa instance id and did not have webcash
						//we are not splitting in this case, we have only one tsa instance id.
						//we are not going to insert in file table and also we are not update transaction table for file id
						sourceFileStream 		= new FileInputStream(inputFile);
						File tsaFileLocation    = new File(tsaOutPutFileLocation+tsaOutPutFileName);
						PaymentSplitterUtility.copySourceFileToDestination(tsaFileLocation.getAbsolutePath(), sourceFileStream);
						sourceFileStream.close();
						
						//Encrypting the generated file
						encDecService.encryptFile(tsaFileLocation);
						//encryptedListOfTsaFiles.put(detailsFromFileName.get(tmpTSaInstanceId),encryptedFilePath+tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION);
						totalTsaPaymentCount = tsaTxnIdxList.size();
						
						//getting hash code for generated file
						String tsaFileHashCode = hashingService.getCheckSumValueForFile(tsaFileLocation, PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
						//getting bean details for tsaId
						WebcashTsaSegregatorFileMapper tsaFileSegregatorDetails = getSegregationDetails(srcPaymentFileId,(tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION),"TSA",Integer.parseInt(tmpTSaInstanceId),fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_READY_TO_TRANSFER),tsaFileLocation.getName(),totalTsaPaymentCount,tsaFileHashCode);
						
						//persisting details in T_WEBCASHTSA_SEGREGATOR_FILE table
						Integer splittedFileId   = fileDaoService.saveFileSegregationDetails(tsaFileSegregatorDetails);
						encryptedListOfTsaFiles.put(detailsFromFileName.get(tmpTSaInstanceId)+"_"+splittedFileId,encryptedFilePath+tsaFileLocation.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION);
						
						//update transaction table T_WEBCASHTSA_PFI_TRANSACTIONS for fileId
						if(tsaTransactionsCollection.containsKey(tmpTSaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY)){
							List<WebcashTsaPfiTransactionsMapper> tsaTransactionMapperBeanList 		= (ArrayList<WebcashTsaPfiTransactionsMapper>)tsaTransactionsCollection.get(tmpTSaInstanceId+"_"+PaymentSplitterConstants.PaymentConstants.TSA_TRANSACTION_MAPPER_BEAN_LIST_KEY);
							for(int beanCount = 0; beanCount < tsaTransactionMapperBeanList.size(); beanCount++){
								tsaTransactionMapperBeanList.get(beanCount).setSegregatorFileId(splittedFileId);
								tsaTransactionMapperBeanList.get(beanCount).setSrcPaymentFileId(srcPaymentFileId);
								allTsaMapperBeanList.add(tsaTransactionMapperBeanList.get(beanCount));
								
							}
						}
					}
				}
			}
		}
		/*if(allTsaMapperBeanList.size() > 0 && isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y")){
			//update transaction table T_WEBCASHTSA_PFI_TRANSACTIONS for fileId
			fileDaoService.updTransactionDetails(allTsaMapperBeanList);
	     }*/
	
		if(isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y")){
			String  transactionHashCode = hashingService.getCheckSumValueForString(PaymentSplitterUtility.getTransactionAsString(inputFile), PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
			
			if(allTsaMapperBeanList.size() > 0){
				try{
					fileDaoService.saveTransactionDetails(allTsaMapperBeanList,transactionHashCode,srcPaymentFileId);
				}catch(Exception e){
					throw new PaymentSplittingProcessException("Failed while saving transaction details",e);
				}
			}
		}
		return totalTsaPaymentCount;
	}
	
	
	
	/***
	 * Splitting Non Tsa transaction and create files if found
	 * 
	 * @param srcPaymentFileId
	 * @param allTsaIndexPositionList
	 * @param inputFile
	 * @param todayDate
	 * @param allTsaMapperBeanList
	 * @param tsa_NonTsaTxnMap
	 * @param sourceFileStream
	 * @param totalTsaPaymentCount
	 * @param sourceFileTransactionCount
	 * @throws PaymentSplittingProcessException
	 * @throws IOException
	 * @throws TransactionCountMismatchException
	 * @throws FileHashingProcessException
	 */
	@SuppressWarnings("unchecked")
	private void nonTsaSplitProcess(Map<String,String> detailsFromFileName,List<File> nonTsaFileLocationList, Integer srcPaymentFileId, List<Integer> allTsaIndexPositionList,File inputFile, String todayDate,
			Map<String, Object> tsa_NonTsaTxnMap, FileInputStream sourceFileStream, Integer totalTsaPaymentCount, Integer sourceFileTransactionCount) throws PaymentSplittingProcessException, IOException, TransactionCountMismatchException, FileHashingProcessException{
		Integer nonTsaPaymentCount 	= 0;
		Integer totalPayment 		= 0;
		File nonTsaFileLocation  = null; 
		
		if( allTsaIndexPositionList != null && allTsaIndexPositionList.size() > 0){
			Collections.sort(allTsaIndexPositionList);
			//create file name for tmpTsaInstanceId
			//String orignalFileName = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.ORIGINAL_FILE_NAME_FROM_FILENAME);
			String gwixUniqueId    = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.GWIX_UNIQUE_ID_FROM_FILENAME);
			String nonTsaOutputFileName 	= gwixUniqueId+".xml";
			
			sourceFileStream 				= new FileInputStream(inputFile);
			nonTsaPaymentCount 				= nonTsaPaymentSplitter(nonTsaFileLocationList, sourceFileStream,allTsaIndexPositionList,nonTsaPaymentCount,nonTsaOutputFileName);
			sourceFileStream.close();
			
			
			if(totalTsaPaymentCount != null){
				totalPayment += totalTsaPaymentCount;
			}
			if(nonTsaPaymentCount != null){
				totalPayment += nonTsaPaymentCount;
			}
			
			logger.info("[PaymentSplitterProcessImpl] - No of transaction count in generated file is - "+totalPayment);
			logger.info("[PaymentSplitterProcessImpl] - No of transaction count in source file is - "+sourceFileTransactionCount);
			
			/**if source and generated file transaction is not equals then throwing exception*/
			if(totalPayment.intValue() != sourceFileTransactionCount.intValue()){
				throw new TransactionCountMismatchException("Source file and generated file transaction is not matching. "
						+ "Number of transaction present in source file are not equals to no of transaction present in generated files.");
			}
			File nonTsaTmpFileLocation  = null;
			if(nonTsaFileLocationList.size() > 0){
				nonTsaTmpFileLocation = nonTsaFileLocationList.get(0); 
			}
			
			//getting hash code for generated file
			String nonTsaFileHashCode = hashingService.getCheckSumValueForFile(nonTsaTmpFileLocation, PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
			//getting bean details for tsaId
			WebcashTsaSegregatorFileMapper splittedFileDetails = getSegregationDetails(srcPaymentFileId,nonTsaTmpFileLocation.getName(),"WC",null,fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_COMPLETE),nonTsaTmpFileLocation.getName(),nonTsaPaymentCount,nonTsaFileHashCode);
			//persisting details in T_WEBCASHTSA_SEGREGATOR_FILE table
			Integer splittedFileId   = fileDaoService.saveFileSegregationDetails(splittedFileDetails);
			List<WebcashTsaPfiTransactionsMapper> allMapperBeanList = null;
			//update transaction table T_WEBCASHTSA_PFI_TRANSACTIONS for fileId
			if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY) 
					&& (isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y"))){
				List<WebcashTsaPfiTransactionsMapper> nonTsaTransactionMapperBeanList 		= (ArrayList<WebcashTsaPfiTransactionsMapper>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY);
				allMapperBeanList = new ArrayList<WebcashTsaPfiTransactionsMapper>();
				for(int beanCount = 0; beanCount < nonTsaTransactionMapperBeanList.size(); beanCount++){
					nonTsaTransactionMapperBeanList.get(beanCount).setSegregatorFileId(splittedFileId);
					nonTsaTransactionMapperBeanList.get(beanCount).setSrcPaymentFileId(srcPaymentFileId);
					allMapperBeanList.add(nonTsaTransactionMapperBeanList.get(beanCount));
					
				}
				//fileDaoService.updTransactionDetails(nonTsaTransactionMapperBeanList);
				if(isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y")){
					String transactionHashCode = hashingService.getCheckSumValueForString(PaymentSplitterUtility.getTransactionAsString(inputFile), PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
					if(nonTsaTransactionMapperBeanList.size() > 0){
						try{
							fileDaoService.saveTransactionDetails(nonTsaTransactionMapperBeanList,transactionHashCode,srcPaymentFileId);
						}catch(Exception e){
							throw new PaymentSplittingProcessException("Failed while saving transaction details",e);
						}
					}
				}
			}
			
			//moving file to orginal location
			if(nonTsaTmpFileLocation != null){
				PaymentSplitterUtility.moveFile(nonTsaTmpFileLocation, nonTsaOutputFileLocation, true);
				nonTsaFileLocation = new File(nonTsaOutputFileLocation+nonTsaOutputFileName);
			}
		}
	}
	
	/***
	 * Updating T_WEBCASHTSA_SEGREGATOR_FILE for all sftp transfer status 
	 * 
	 * @param transferFileDetails
	 * @param listOfEncryptedTsaFiles
	 * @param srcPaymentFileId
	 * @param nonTsaFileLocation
	 */
	@SuppressWarnings("unchecked")
	private List<String> transaferFilesToSftpLocation(Map<String,Object> transferFileDetails, Map<String,String> listOfEncryptedTsaFiles,Integer srcPaymentFileId,File nonTsaFileLocation){
		logger.info("[PaymentSplitterProcessImpl] - Going to sftp files for source payment id - "+srcPaymentFileId);
		RestTemplate restTemplate	= new RestTemplate();
		Integer fileStatusRecived	= fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED);
		String tsaIdentifier        = null;
		List<WebcashTsaSegregatorFileMapper> fileMapperList = new ArrayList<WebcashTsaSegregatorFileMapper>();
		List<String> sftpSendingFailedList = new ArrayList<String>();
		Timestamp defaultTimeStamp = new Timestamp(System.currentTimeMillis());
		Map<String, Object> resultMapData = null;
		
		try{
			logger.info("[PaymentSplitterProcessImpl] transfer file paymentSystem - "+transferFileDetails.keySet());
			resultMapData =  restTemplate.postForObject(encryptingService, transferFileDetails, Map.class);
		}catch(Exception sftpException){
			logger.error("[PaymentSplitterProcessImpl] - Error while connecting to sftp service");
			logger.error("[PaymentSplitterProcessImpl] - "+PaymentSplitterUtility.getErrorFormStackTrace(sftpException));
		}
		
		logger.info("[PaymentSplitterProcessImpl] - Service executed for sftp");
		if( resultMapData != null && resultMapData.size() > 0){
			for(String tsaId : resultMapData.keySet()){
				String fileSentStatus 	= (String)resultMapData.get(tsaId);
				tsaIdentifier       	= null;
				//fileStatusRecived		= 21; //transfer failed
				String segFileId= "";
				Set<String> tsaIdentifierList = listOfEncryptedTsaFiles.keySet();
				for(String tsaInden : tsaIdentifierList){
					String tsaIdentifierKey = tsaInden.split("_")[0];
					segFileId     = tsaInden.split("_")[1];
					
					logger.info("[PaymentSplitterProcessImpl] - sftp moving tsaInsId - "+tsaInden);
					logger.info("[PaymentSplitterProcessImpl] - sftp moving tsaIdentifier - "+tsaIdentifierKey);
					logger.info("[PaymentSplitterProcessImpl] - sftp moving segFileId - "+segFileId);
					logger.info("[PaymentSplitterProcessImpl] - size of  listOfEncryptedTsaFiles - "+listOfEncryptedTsaFiles.size());
					logger.info("[PaymentSplitterProcessImpl] - size of  listOfEncryptedTsaFiles value - "+listOfEncryptedTsaFiles.get(tsaInden));
					
					
					if(tsaId.equalsIgnoreCase(String.valueOf(tsaIdentifierKey))){
						tsaIdentifier = tsaIdentifierKey;
						if( fileSentStatus != null && fileSentStatus.equalsIgnoreCase("Success")){
							fileStatusRecived = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_COMPLETE);
							moveSftpFiles(listOfEncryptedTsaFiles.get(tsaInden), "Success",true);
							
						}else{
							fileStatusRecived = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED);
							sftpSendingFailedList.add(listOfEncryptedTsaFiles.get(tsaInden));
							moveSftpFiles(listOfEncryptedTsaFiles.get(tsaInden), "Failed",true);
						}
						break;
					}
				}
				
				//tsaInstanceId will be null in the case of webcash
				fileMapperList.add(getWebcashTsaSegregatorFileBean(segFileId,srcPaymentFileId, fileStatusRecived, tsaIdentifier,nonTsaFileLocation, defaultTimeStamp));
			}
		}else{
			Set<String> tsaIdentifierKeySet = listOfEncryptedTsaFiles.keySet();
			for(String tsaInsId : tsaIdentifierKeySet){
				String tsaIdentifierDb  = tsaInsId.split("_")[0];
				String segFileId        = tsaInsId.split("_")[1];
				
				logger.info("[PaymentSplitterProcessImpl] - sftp moving tsaInsId - "+tsaInsId);
				logger.info("[PaymentSplitterProcessImpl] - sftp moving tsaIdentifier - "+tsaIdentifierDb);
				logger.info("[PaymentSplitterProcessImpl] - sftp moving segFileId - "+segFileId);
				
				fileStatusRecived = fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED);
				sftpSendingFailedList.add(listOfEncryptedTsaFiles.get(tsaInsId));
				moveSftpFiles(listOfEncryptedTsaFiles.get(tsaInsId), "Failed",true);
				
				fileMapperList.add(getWebcashTsaSegregatorFileBean(segFileId, srcPaymentFileId, fileStatusRecived, tsaIdentifierDb, nonTsaFileLocation, defaultTimeStamp));
			}
		}
		//Add condition to avoid senario of only webcash file, we have not to update
		if(fileMapperList.size() > 0){
			//updating FOR TSA T_WEBCASHTSA_SEGREGATOR_FILE
			updateSegregatedFileStatus(fileMapperList);
		}
		return sftpSendingFailedList;
	}
	
	/**
	 * moving sftp files to their respective locations
	 * @param file
	 * @param fileStaus
	 */
	private void moveSftpFiles(String file, String fileStausRecived, boolean isTsaFiles){
		File  fileTomove 		= new File(file);
		String locationToMove 	= null;
		String xmlFileName    	= fileTomove.getName();
		
		if(fileStausRecived.equalsIgnoreCase("Success")){
			locationToMove = archivedSftpLocation;
		}else{
			locationToMove = retryLocationForFailedSftpFiles;
		}
		
		if(xmlFileName.lastIndexOf(PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION) > 0){
			xmlFileName 			= xmlFileName.substring(0,(xmlFileName.lastIndexOf(PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION)));
			PaymentSplitterUtility.moveFile(fileTomove, locationToMove, true); //encrypted file
			if(isTsaFiles && (deleteGeneratedTsaXml != null && deleteGeneratedTsaXml.equalsIgnoreCase("Y"))){
				PaymentSplitterUtility.deleteFile(new File(tsaOutPutFileLocation+xmlFileName));
				logger.info("Deleted TSA file - "+(tsaOutPutFileLocation+xmlFileName));
			}
			//Webcash TSA Release 2 change: decrypted (xml) file also moved to either archive or error folder based on fileStausRecived
			if(fileStausRecived.equalsIgnoreCase("Success") && deleteGeneratedTsaXml != null && deleteGeneratedTsaXml.equalsIgnoreCase("N")){
				PaymentSplitterUtility.moveFile(new File(tsaOutPutFileLocation+xmlFileName),locationToMove,true );
				logger.info("decrypted TSA file - "+(tsaOutPutFileLocation+xmlFileName)+" moved to "+locationToMove);
			}
		}
	}
	
	/**
	 * preparing bean for segregtor file table
	 * 
	 * @param srcPaymentFileId
	 * @param fileStatusRecived
	 * @param tsaIdentifier
	 * @param nonTsaFileLocation
	 * @param defaultTimeStamp
	 * @return
	 */
	private WebcashTsaSegregatorFileMapper getWebcashTsaSegregatorFileBean(String segFileId, Integer srcPaymentFileId, Integer fileStatusRecived, String tsaIdentifier, File nonTsaFileLocation,Timestamp defaultTimeStamp){
		WebcashTsaSegregatorFileMapper fileMapperBean = new WebcashTsaSegregatorFileMapper();
		fileMapperBean.setSrcPaymentFileId(srcPaymentFileId);
		fileMapperBean.setFileStatusId(fileStatusRecived);
		fileMapperBean.setSegregatorFileId(Integer.parseInt(segFileId));
		if(tsaIdentifier != null){
			String tsaInstanceId = fileDaoService.getTsaInstanceId(tsaIdentifier);
			fileMapperBean.setTsaInstanceId(Integer.parseInt(tsaInstanceId));
		}/*else if (nonTsaFileLocation != null && nonTsaFileLocation.length() > 0){
			fileMapperBean.setSegregatorFileName(nonTsaFileLocation.getName());
		}*/
		fileMapperBean.setLastModifiedTimeStamp(defaultTimeStamp);
		
		return fileMapperBean;
	}
	
	
	private void webCashFileOnly(Integer sourceFileTransactionCount, Map<String,String> detailsFromFileName,FileInputStream sourceFileStream,File inputFile, Integer srcPaymentFileId,Map<String,Object> tsa_NonTsaTxnMap) throws PaymentSplittingProcessException,FileHashingProcessException, IOException{
		//String orignalFileName = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.ORIGINAL_FILE_NAME_FROM_FILENAME);
		String gwixUniqueId    = detailsFromFileName.get(PaymentSplitterConstants.FileConstants.GWIX_UNIQUE_ID_FROM_FILENAME);
		String nonTsaOutputFileName 	= gwixUniqueId+".xml";
		
		sourceFileStream 			= new FileInputStream(inputFile);
		PaymentSplitterUtility.copySourceFileToDestination((nonTsaOutputFileLocation+nonTsaOutputFileName), sourceFileStream);
		sourceFileStream.close();
		//transferFileDetails.put("TSA5", nonTsaFileLocation.getAbsoluteFile());
		
		//getting hash code for generated file
		String nonTsaFileHashCode = hashingService.getCheckSumValueForFile(new File(nonTsaOutputFileLocation+nonTsaOutputFileName), PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
		//getting bean details for tsaId
		WebcashTsaSegregatorFileMapper splittedFileDetails = getSegregationDetails(srcPaymentFileId,nonTsaOutputFileName,"WC",null,fileStatus.getFileStatus(PaymentSplitterConstants.FileStatusConstants.FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_COMPLETE),nonTsaOutputFileName,sourceFileTransactionCount,nonTsaFileHashCode);
		//persisting details in T_WEBCASHTSA_SEGREGATOR_FILE table
		Integer splittedFileId   = fileDaoService.saveFileSegregationDetails(splittedFileDetails);
		
		//update transaction table T_WEBCASHTSA_PFI_TRANSACTIONS for fileId
		if(tsa_NonTsaTxnMap.containsKey(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY) 
				&& (isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y"))){
			List<WebcashTsaPfiTransactionsMapper> nonTsaTransactionMapperBeanList 		= (ArrayList<WebcashTsaPfiTransactionsMapper>)tsa_NonTsaTxnMap.get(PaymentSplitterConstants.PaymentConstants.NONTSA_TRANSACTION_MAPPER_BEAN_LIST_KEY);
			//allTsaMapperBeanList = new ArrayList<WebcashTsaPfiTransactionsMapper>();
			for(int beanCount = 0; beanCount < nonTsaTransactionMapperBeanList.size(); beanCount++){
				nonTsaTransactionMapperBeanList.get(beanCount).setSegregatorFileId(splittedFileId);
				nonTsaTransactionMapperBeanList.get(beanCount).setSrcPaymentFileId(srcPaymentFileId);
				//allTsaMapperBeanList.add(nonTsaTransactionMapperBeanList.get(beanCount));
				
			}
			//fileDaoService.updTransactionDetails(nonTsaTransactionMapperBeanList);
			if(isTransactionDetailsPersist != null && isTransactionDetailsPersist.equalsIgnoreCase("Y")){
				String transactionHashCode = hashingService.getCheckSumValueForString(PaymentSplitterUtility.getTransactionAsString(inputFile), PaymentSplitterConstants.FileConstants.FILE_CHECK_SUM_ALGORITHM);
				if(nonTsaTransactionMapperBeanList.size() > 0){
					try{
						fileDaoService.saveTransactionDetails(nonTsaTransactionMapperBeanList,transactionHashCode,srcPaymentFileId);
					}catch(Exception e){
						throw new PaymentSplittingProcessException("Failed while saving the transaction deatils",e);
					}
				}
			}
		}
	}

	/**
	 * @param encryptedFilePath the encryptedFilePath to set
	 */
	public void setEncryptedFilePath(String encryptedFilePath) {
		this.encryptedFilePath = encryptedFilePath;
	}


	/**
	 * @param tsaOutPutFileLocation the tsaOutPutFileLocation to set
	 */
	public void setTsaOutPutFileLocation(String tsaOutPutFileLocation) {
		this.tsaOutPutFileLocation = tsaOutPutFileLocation;
	}


	/**
	 * @param nonTsaOutputFileLocation the nonTsaOutputFileLocation to set
	 */
	public void setNonTsaOutputFileLocation(String nonTsaOutputFileLocation) {
		this.nonTsaOutputFileLocation = nonTsaOutputFileLocation;
	}

}
