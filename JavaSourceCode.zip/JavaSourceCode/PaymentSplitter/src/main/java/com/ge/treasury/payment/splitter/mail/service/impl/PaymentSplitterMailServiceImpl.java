package com.ge.treasury.payment.splitter.mail.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.ge.treasury.payment.splitter.mail.service.PaymentSplitterMailService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

@Component
public class PaymentSplitterMailServiceImpl implements PaymentSplitterMailService {
	final static Logger logger = Logger.getLogger(PaymentSplitterMailServiceImpl.class);
	
	@Value("${fromDL}")
	private String sender;
	@Value("${recipientDL}")
	private String reciver;
	
	@Autowired
	private JavaMailSender mailSender;
	
    @Autowired 
    private TemplateEngine templateEngine;
	    
    /* 
     * Send HTML mail (simple) 
     */
    private void sendMail(final String templateNm, String subject, Map<String,Object> bodyContent) throws MessagingException {
    	Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
        // Prepare the evaluation context
        final Context ctx = new Context(bLocale);
        /*ctx.setVariable("name", "Team");*/
        ctx.setVariable("bodyContent", bodyContent);
        ctx.addContextExecutionInfo(templateNm);
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(sender);
        String[] sendTo = reciver.split(",");
        //message.setTo(reciver);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);

    }
	
	@Override
	public void sendErrorMail(Exception ex, String mailSubject, String sourceFileName, List<String> sendingFailedSftpFiles) throws MessagingException {
		logger.info("[PaymentSplitterMailServiceImpl] - Start sending mail..");
		Map<String,Object> mailContent = mailContent(ex,sourceFileName, sendingFailedSftpFiles);
		sendMail("email-simple2", mailSubject, mailContent);
		logger.info("[PaymentSplitterMailServiceImpl] - Mail sending process complete !!");
	}
	
	private Map<String,Object> mailContent(Exception ex, String sourceFileName, List<String> sendingFailedSftpFiles){
		logger.info("[PaymentSplitterMailServiceImpl] - Preparing Mail content..");
		/*StringBuffer mailContent = new StringBuffer();*/
		Map<String,Object> mailContent = new HashMap<String, Object>();
		
		InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
            logger.info("[PaymentSplitterMailServiceImpl] - current Hostname/IP address : " + hostAndIP);
        } catch (UnknownHostException e) {
        	logger.error(PaymentSplitterUtility.getErrorFormStackTrace(e));
        }
       
        mailContent.put("sourceFileName", sourceFileName);
        mailContent.put("hostName", hostAndIP.getHostAddress());
        if(ex != null){
	        String shortMsg = ((ex.getMessage() != null && ex.getMessage().length() > 218) ? ex.getMessage().substring(0,218):ex.getMessage());
	        mailContent.put("shortMsg", shortMsg );
	        mailContent.put("longMsg", PaymentSplitterUtility.getErrorFormStackTrace(ex));
        }
        
        if(sendingFailedSftpFiles != null && sendingFailedSftpFiles.size() > 0){
    		mailContent.put("shortMsg", "System has failed to send the following no of files to sftp location" );
        }
        if(sendingFailedSftpFiles == null){
        	sendingFailedSftpFiles = new ArrayList<String>();
        }
        mailContent.put("failedFileList", sendingFailedSftpFiles);
        
		logger.info("[PaymentSplitterMailServiceImpl] - Mail content completed !!");
		return mailContent;
	}

	/**
	 * @param sender the sender to set
	 */
	public void setSender(String sender) {
		this.sender = sender;
	}

	/**
	 * @param reciver the reciver to set
	 */
	public void setReciver(String reciver) {
		this.reciver = reciver;
	}

}
