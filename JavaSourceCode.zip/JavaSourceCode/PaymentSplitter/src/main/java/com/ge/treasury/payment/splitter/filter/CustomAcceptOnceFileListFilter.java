package com.ge.treasury.payment.splitter.filter;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.integration.file.filters.FileListFilter;

import com.ge.treasury.payment.splitter.service.persist.PaymentSplitterPersistenceService;
import com.ge.treasury.payment.splitter.util.PaymentSplitterUtility;

public class CustomAcceptOnceFileListFilter<F> implements FileListFilter<F>{
	final static Logger logger = Logger.getLogger(CustomAcceptOnceFileListFilter.class);
	
	private final Integer maxCapacity = 10;
	private Set<F> fileRead = new HashSet<F>();
	private Queue<F> seen   = new LinkedBlockingQueue<F>(maxCapacity);
	private final Object monitor = new Object();
	
	@Autowired PaymentSplitterPersistenceService fileLockServiceDao;
	
	@Override
	public List<F> filterFiles(F[] files) {
		List<F> accepted = new ArrayList<F>();
		synchronized (this.monitor) {
	        if (files != null) {
	        	boolean isFileLocked = false;
	        	File fileRecieved = null;
	            for (F file : files) {
	            	fileRecieved = new File(file.toString());
	            	if(!this.fileRead.contains(file) && fileRecieved.isFile()  && !file.toString().toLowerCase().contains(".writing")
	            			&& fileRecieved.length() > 0){
		            	isFileLocked = false;
		            	try{
		            		fileLockServiceDao.acquireFileLock(fileRecieved);
		            		isFileLocked = true;
		            		logger.info("[CustomAcceptOnceFileListFilter] - File Lock Acquired for - "+fileRecieved.getName());
		            	}catch(DuplicateKeyException ex){
		            		isFileLocked = false;
		            		logger.info("[CustomAcceptOnceFileListFilter] - "+fileRecieved.getName()+" File is already Locked.. ");
		            		logger.info("[CustomAcceptOnceFileListFilter] - "+PaymentSplitterUtility.getErrorFormStackTrace(ex));
		            	}catch(Exception e){
		            		isFileLocked = false;
		            		logger.info("[CustomAcceptOnceFileListFilter] - getting error while going for file lock.");
		            		logger.info("[CustomAcceptOnceFileListFilter] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
		            	}
		            	
		            	if(isFileLocked){
		            		accepted.add(file);
		            		this.remove(file);
		            		this.fileRead.add(file);
		            		logger.info("[CustomAcceptOnceFileListFilter] - File Recived - "+file);
		            		break;
		            	}else{
		            		//in case if file is already processed by other instance
		            		//then second instance will not check for the same file again 
		            		this.fileRead.add(file);
		            	}
	            	}
	            }
	        }
		}
        return accepted;
	}
	
	private void remove(F fileToRemove){
		if(this.seen.size() == (maxCapacity-2)){
			F removed = this.seen.poll();
			logger.info("[CustomAcceptOnceFileListFilter] - File Removed  - "+removed);
			this.fileRead.remove(removed);
		}
		this.seen.offer(fileToRemove);
	}
}