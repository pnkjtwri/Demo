package com.ge.treasury.payment.splitter.xml.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.ge.treasury.payment.splitter.exception.XmlReaderServiceException;
import com.ge.treasury.payment.splitter.mapper.WebcashTsaSrcPaymentFileMapper;


public interface XmlReaderService {
	public Map<String,List<String>> readInputForLookUpService(File inputFile) throws XmlReaderServiceException;
	/*public void initilizeComponent(File inputFile) throws XmlReaderServiceException;*/
	public Map<String, Object> getPaymentsTSA_NONTSA(Map<Object, Object> tsaNonTsaModelAccountIdMap,File inputFile)  throws XmlReaderServiceException;
	public Integer getSourceFileTransactionCount(File inputFile) throws XmlReaderServiceException;
	public WebcashTsaSrcPaymentFileMapper getFileDetailsToPersist(File inputFile, String fileHashCode) throws IOException, XmlReaderServiceException;
	/*public List<WebcashTsaPfiTransactionsMapper> getTransactionDetailsToPersist(Integer srcPaymentFileId, String transactionHashCode);*/
}
