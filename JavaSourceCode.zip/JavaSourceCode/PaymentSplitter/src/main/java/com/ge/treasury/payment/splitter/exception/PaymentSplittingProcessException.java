package com.ge.treasury.payment.splitter.exception;

public class PaymentSplittingProcessException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5779252678722309643L;
	private String message;
	private Exception ex;
	
	public PaymentSplittingProcessException(String msg){
		this.message = msg;
	}
	
	public PaymentSplittingProcessException(String msg, Exception ex){
		super(msg,ex);
		this.message = msg;
		this.ex      = ex;
	}
	
	/**
	 * @return the message
	 */
	public String getMessage() {
		return (String) (message + (ex != null && ex.getMessage() != null ? ex.getMessage() : ""));
	}

	/**
	 * @return the ex
	 */
	public Exception getEx() {
		return ex;
	}
}
