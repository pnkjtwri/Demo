package com.ge.treasury.payment.splitter.encryption.service.impl;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.splitter.encryption.service.PaymentSplitterEncryptionService;
import com.ge.treasury.payment.splitter.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.splitter.util.PGPFileProcessor;
import com.ge.treasury.payment.splitter.util.PaymentSplitterConstants;

@Component
public class PaymentSplitterEncryptionServiceImpl implements
		PaymentSplitterEncryptionService {
	final static Logger logger = Logger.getLogger(PaymentSplitterEncryptionServiceImpl.class);

	@Value("${encryptedFilePath}")
	private String encryptedFilePath;
	@Value("${publicKeyPath}")
	private String publicKeyPath;
	@Value("${privateKeyPath}")
	private String privateKeyPath;
	@Value("${passPhrase}")
	private String passphrase;
	
	@Autowired PGPFileProcessor pgpProcessor;

	@Override
	public void encryptFile(File fileToEncrypt) throws FileEncryptionDecryptionException {
		pgpProcessor.encrypt(fileToEncrypt, (encryptedFilePath+fileToEncrypt.getName()+PaymentSplitterConstants.FileConstants.ENCRYPTED_FILE_EXTENSION), publicKeyPath);
	}

	@Override
	public void decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException {
		String outPutFileName = fileToDecrypt.getName();
		pgpProcessor.decrypt(fileToDecrypt, (encryptedFilePath+outPutFileName), privateKeyPath, passphrase);
	}

	/**
	 * @param publicKeyPath
	 *            the publicKeyPath to set
	 */
	public void setPublicKeyPath(String publicKeyPath) {
		this.publicKeyPath = publicKeyPath;
	}

	/**
	 * @param privateKeyPath
	 *            the privateKeyPath to set
	 */
	public void setPrivateKeyPath(String privateKeyPath) {
		this.privateKeyPath = privateKeyPath;
	}

	/**
	 * @param passphrase
	 *            the passphrase to set
	 */
	public void setPassphrase(String passphrase) {
		this.passphrase = passphrase;
	}

	/**
	 * @param encryptedFilePath
	 *            the encryptedFilePath to set
	 */
	public void setEncryptedFilePath(String encryptedFilePath) {
		this.encryptedFilePath = encryptedFilePath;
	}

	/**
	 * @param pgpProcessor the pgpProcessor to set
	 */
	public void setPgpProcessor(PGPFileProcessor pgpProcessor) {
		this.pgpProcessor = pgpProcessor;
	}

}
