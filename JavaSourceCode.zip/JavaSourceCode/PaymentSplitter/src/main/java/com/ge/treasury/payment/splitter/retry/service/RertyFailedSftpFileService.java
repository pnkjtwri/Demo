package com.ge.treasury.payment.splitter.retry.service;

import java.io.File;

public interface RertyFailedSftpFileService {
	public boolean sftpFailedFile(File sftpFile);
}
