package com.ge.treasury.manual.bai.merge.model;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.manual.bai.merge.util.BaiConstant;

public class BAIFileTrailer {
	//private String recordCode = "99"; 
	private String recordCode = BaiConstant.FILE_TRAILER_TAG;
	private String fileControlTotal; 
	private String numberOfGroups; 
	private String numberOfRecords; 
	private String[] recordArray;
	private CSVRecord record;
	public String getRecordCode() {
		return recordCode;
	}
	public String getFileControlTotal() {
		return fileControlTotal;
	}
	public void setFileControlTotal(String fileControlTotal) {
		this.fileControlTotal = fileControlTotal;
	}
	public String getNumberOfGroups() {
		return numberOfGroups;
	}
	public void setNumberOfGroups(String numberOfGroups) {
		this.numberOfGroups = numberOfGroups;
	}
	public String getNumberOfRecords() {
		return numberOfRecords;
	}
	public void setNumberOfRecords(String numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	
	public String[] getRecordArray() {
		return recordArray;
	}
	public void setRecordArray(String[] recordArray) {
		this.recordArray = recordArray;
	}
	
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setFileControlTotal(record.get(1));
			setNumberOfGroups(record.get(2));
			setNumberOfRecords(record.get(3));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	
	public String populate(String[] recordArray){
		String status = "success";
		try {		
			setRecordArray(recordArray);
			setFileControlTotal(recordArray[1]);
			setNumberOfGroups(recordArray[2]);
			setNumberOfRecords(recordArray[3]);
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	/*public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}*/
	public String toString(){
		String returnString = "";
		int counter = 0;
		for(String text: recordArray){
			if(counter == 0 ){
				returnString += text + ",";
			}
			else if(counter == 1 ){
				returnString += getFileControlTotal() + ","; 
			}else if(counter == 2 ){
				returnString += getNumberOfGroups() + ","; 
			}else if(counter == 3 ){
				returnString += getNumberOfRecords(); 
			}
			counter++;
		}
		return returnString;
	}
}
