package com.ge.treasury.manual.bai.merge.validate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Stack;

import com.ge.treasury.manual.bai.merge.util.BaiConstant;

public class BaiMergeValidateFile {
	
	public static boolean validateFile(File fileToValidate){
		BufferedReader br       =  null;
		boolean isValidBaiFile  = false;
		
		boolean isFileHeaderFound 		= false;
		boolean isFileTrailerFound 		= false;
		boolean isGroupHeaderFound 		= false;
		boolean isAccountHeaderFound 	= false;
		boolean isAccountHeaderExists 	= false;
		boolean isGroupHeaderExists 	= false;
		
		Stack<String> groupFounds 	= new Stack<String>();
		Stack<String> accountFounds = new Stack<String>();
		
		try{
			String line = "";
			br 	= new BufferedReader(new FileReader(fileToValidate));
			
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiConstant.FILE_HEADER_TAG)){
			    	isFileHeaderFound = true;
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_HEADER_TAG)){
			    	isGroupHeaderExists = true;
			    	groupFounds.push(BaiConstant.GROUP_HEADER_TAG);
			    	if(recordArray[2] == null || recordArray[2].length() <= 0){
			    		break;
			    	} 
			        if(recordArray[4] == null || recordArray[4].length() <= 0 ){
			        	break;
			        }
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.ACCOUNT_HEADER_TAG)){
			    	isAccountHeaderExists = true;
			    	accountFounds.push(BaiConstant.ACCOUNT_HEADER_TAG);
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.FILE_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[3])){
			    		break;
			    	}
			    	isFileTrailerFound = true;
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[3])){
			    		break;
			    	}
			    	groupFounds.pop();
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.ACCOUNT_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	accountFounds.pop();
			    	
			    }
			}
			
			System.out.println("Size of account - "+accountFounds.size());
			if(accountFounds.size() == 0 && isAccountHeaderExists){
				isAccountHeaderFound = true;
			}
			System.out.println("Size of groups - "+groupFounds.size());
			if(groupFounds.size() == 0 && isGroupHeaderExists){
				isGroupHeaderFound = true;
			}

			System.out.println("isFileHeaderFound -> "+isFileHeaderFound+
					" isFileTrailerFound -> "+isFileTrailerFound+" isGroupHeaderFound -> "+isGroupHeaderFound+" isAccountHeaderFound -> "+isAccountHeaderFound);
			
			if(isFileHeaderFound && isFileTrailerFound && isGroupHeaderFound && isAccountHeaderFound){
				isValidBaiFile = true;
			}
		}catch(Exception e){
			System.out.println("Error in file validation - "+fileToValidate.getName());
			e.printStackTrace();
			isValidBaiFile = false;
		}finally{
			if(br != null){
				try{
					br.close();
				}catch(Exception e){
					System.out.println("Error in closing reader");	
				}
			}
		}
		return isValidBaiFile;
	}
	
	private static boolean validateValues(String value){
		boolean isValid = false;
		if(value.indexOf("/") > 0){
			value = value.substring(0,value.indexOf("/"));
		}
		
		if(value != null && value.length() > 0){
			try{
				Long.parseLong(value);
				isValid = true;
			}catch(Exception e){
				isValid = false;
			}
		}
		return isValid;
	}
}
