package com.ge.treasury.manual.bai.merge.model;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.manual.bai.merge.util.BaiConstant;

public class BAIContinuation {
	//private String recordCode = "88";
	private String recordCode = BaiConstant.RECORD_CONTINUTAION_IDENTIFIER;
	private String nextField;
	private CSVRecord record;
	
	public String getRecordCode() {
		return recordCode;
	}
	public String getNextField() {
		return nextField;
	}
	public void setNextField(String nextField) {
		this.nextField = nextField;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	
	public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
