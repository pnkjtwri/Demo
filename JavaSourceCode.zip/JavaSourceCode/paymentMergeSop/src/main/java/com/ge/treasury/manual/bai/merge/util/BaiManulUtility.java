package com.ge.treasury.manual.bai.merge.util;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class BaiManulUtility {
	private static Logger logger = Logger.getLogger(BaiManulUtility.class);
	public static boolean moveFile(File inputFile, String movedLocation, boolean isArchiveOrError){
		String todayDate  		= new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
		String renameFileName 	= movedLocation+inputFile.getName();
		boolean isFileMoved = false;
		if(isArchiveOrError){
			renameFileName = renameFileName+"_"+todayDate;
		}
		
		Path movedFileLocation = FileSystems.getDefault().getPath(renameFileName);
		Path fromFileLocation  = FileSystems.getDefault().getPath(inputFile.getAbsolutePath());
		
		try{
			logger.info("File Moving from  - "+inputFile.getAbsolutePath());
	        Files.move(fromFileLocation, movedFileLocation, StandardCopyOption.REPLACE_EXISTING);
	        logger.info("File Moved to  - "+renameFileName);
	        isFileMoved = true;
	    }catch (Exception e) {
	    	logger.info("Error in File Moving at location - "+renameFileName);
	    	logger.info(e.getMessage());
	    	isFileMoved = false;
	    }
		return isFileMoved;
	}
	
	
	public static void removeFile(String location){
		logger.info("Going to remove file - "+location);
		try{
			Path fileToDelete = Paths.get(location);
			boolean isDeleted = Files.deleteIfExists(fileToDelete);
		    logger.info("File deleted status - "+isDeleted);
		}catch(Exception e){
			logger.info("File deletion failed - "+location);
			logger.info(e.getMessage());
		}
	}
	
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
}
