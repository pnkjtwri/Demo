package com.ge.treasury.manual.bai.merge.util;

public class BaiConstant {
	
		public static final String FILE_HEADER_TAG 						= "01";
		public static final String FILE_TRAILER_TAG 					= "99";
		public static final String GROUP_HEADER_TAG 					= "02";
		public static final String GROUP_TRAILER_TAG 					= "98";
		public static final String ACCOUNT_HEADER_TAG 					= "03";
		public static final String ACCOUNT_TRAILER_TAG 					= "49";
		public static final String TRANSACTION_DETAIL_TAG 				= "16";
		public static final String CONTINUATION_TAG 					= "88";
		public static final String ACCOUNT_IDENTIFIER					= "03";
		public static final String ACCOUNT_TRAILER_IDENTIFIER			= "49";
		public static final String RECORD_CONTINUTAION_IDENTIFIER		= "88";
		public static final String BAI_END_LINE_CHAR						= "/";
		public static final String BAI_NEW_LINE_CHAR						= "\n";
		public static final String TMP_FILE_EXTENSION						= "_tmp";
		public static final String FILE_TARGET_DIR      					= "targetDirForManual";
		public static final String FILE_OUTBOUND_CHANNEL					= "outputChannelToSendFileManual";
		public static final String SOURCE_FILE_MANUAL_LOCATION				= "manualrun/";
}
