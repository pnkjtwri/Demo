package com.ge.treasury.manual.bai.merge.model;
import java.util.List;

public class BAIAccount {
	private BAIAccountIdentifier accountIdentifier;
	private List<BAITransactionDetail> transactionDetails;
	private BAIAccountTrailer accountTrailer;
}
