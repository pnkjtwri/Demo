package com.ge.treasury.manual.bai.merge.model;
import java.util.List;

public class BAIFile {
	private BAIFileHeader fileHeader;
	private List<BAIGroup> groups;
	private BAIFileTrailer fileTrailer;
	public BAIFileHeader getFileHeader() {
		return fileHeader;
	}
	public void setFileHeader(BAIFileHeader fileHeader) {
		this.fileHeader = fileHeader;
	}
	public List<BAIGroup> getGroups() {
		return groups;
	}
	public void setGroups(List<BAIGroup> groups) {
		this.groups = groups;
	}
	public BAIFileTrailer getFileTrailer() {
		return fileTrailer;
	}
	public void setFileTrailer(BAIFileTrailer fileTrailer) {
		this.fileTrailer = fileTrailer;
	}
}
