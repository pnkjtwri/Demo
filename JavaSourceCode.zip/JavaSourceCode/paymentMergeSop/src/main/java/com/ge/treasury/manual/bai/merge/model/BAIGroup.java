package com.ge.treasury.manual.bai.merge.model;
import java.util.ArrayList;
import java.util.List;

public class BAIGroup {
	private BAIGroupHeader groupHeader;
	private List<BAIAccount> accounts;
	private BAIGroupTrailer groupTrailer;
	private ArrayList<String> accountDataLines;
	
	public BAIGroupHeader getGroupHeader() {
		return groupHeader;
	}
	public void setGroupHeader(BAIGroupHeader groupHeader) {
		this.groupHeader = groupHeader;
	}
	public List<BAIAccount> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<BAIAccount> accounts) {
		this.accounts = accounts;
	}
	public BAIGroupTrailer getGroupTrailer() {
		return groupTrailer;
	}
	public void setGroupTrailer(BAIGroupTrailer groupTrailer) {
		this.groupTrailer = groupTrailer;
	}
	public ArrayList<String> getAccountDataLines() {
		return accountDataLines;
	}
	public void setAccountDataLines(ArrayList<String> accountDataLines) {
		this.accountDataLines = accountDataLines;
	}
	
}
