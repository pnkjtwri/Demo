package com.ge.treasury.manual.bai.merge;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.ge.treasury.manual.bai.merge.service.BaiMergeFileService;
import com.ge.treasury.manual.bai.merge.util.BaiConstant;

@EnableAutoConfiguration
@ImportResource("classpath:spring/applicationContext.xml")
public class BaiMergeApplication  implements CommandLineRunner {
	private static Logger logger = Logger.getLogger(BaiMergeApplication.class);
	
	@Autowired
	private ApplicationContext context;
	
	public static void main(String[] args) {
		logger.info("Manual process for Bai merge is initiated...");
		SpringApplication.run(BaiMergeApplication.class, args).close();
		logger.info("Manual process for Bai merge Completed !!");
	}

	@Override
	public void run(String... arg0) throws Exception {
		List<File> listofFiletobemeregd = new ArrayList<File>();
		String nasFileNamePattern = null;
		String DEFAULT_FILE_LOCATION = null;
		String fileRootLocationToSend = null;
		
		try {
			
			if(arg0.length > 1 && arg0[0] != null && arg0[0].length() > 0 && arg0[1] != null && arg0[1].length() > 0){
				nasFileNamePattern    = arg0[0];
				DEFAULT_FILE_LOCATION = arg0[1];
			}
			
			if(!(nasFileNamePattern != null && nasFileNamePattern.length() > 0)){
				logger.info("******************************************************************");
				logger.info("Argument missing for File Name Pattern - "+nasFileNamePattern);
				logger.info("******************************************************************");
				return;
			}
			
			if(!(DEFAULT_FILE_LOCATION != null && DEFAULT_FILE_LOCATION.length() > 0)){
				logger.info("******************************************************************");
				logger.info("Argument missing for File Location - "+DEFAULT_FILE_LOCATION);
				logger.info("******************************************************************");
				return;
			}
			DEFAULT_FILE_LOCATION = DEFAULT_FILE_LOCATION + BaiConstant.SOURCE_FILE_MANUAL_LOCATION;
			logger.info("Provided File Name Pattern For merge - "+nasFileNamePattern);
			logger.info("Locations of files to look for merge - "+DEFAULT_FILE_LOCATION);
			
			if(arg0.length > 2 && arg0[2] != null && arg0[2].length() > 0){
				fileRootLocationToSend = arg0[2];
				logger.info("Root Location for sending merged file - "+fileRootLocationToSend);
			}
			
			final String filePattern = nasFileNamePattern;
			File root = new File( DEFAULT_FILE_LOCATION );
	        File[] list = root.listFiles();
	        for(File fileToMerge : list){
	        	if(fileToMerge.isFile()){
	        		logger.info("File found - "+ fileToMerge.getAbsolutePath());
			    	if(fileToMerge.getName().toUpperCase().contains(filePattern.toUpperCase())){
			    		listofFiletobemeregd.add(fileToMerge);
			    	}else{
			    		logger.info("Skipping file - "+fileToMerge.getName()+ ", not belong to provided file name pattern");
			    	}
	        	}
	        }
			
			if(!(listofFiletobemeregd != null && listofFiletobemeregd.size() > 0)){
				logger.info("***************************************");
				logger.info("We did not received any file or we have only 1 file, For merging process we have atleast more then 1 file !!");
				logger.info("***************************************");
				return;
			}
			
			logger.info("Loading required details for merging process..");
			BaiMergeFileService mergerService = context.getBean(BaiMergeFileService.class);
			logger.info("Details loaded for maerging process..");
			
			/*if(listofFiletobemeregd.size() > 1)*/{
				mergerService.mergeFiles(nasFileNamePattern, listofFiletobemeregd, DEFAULT_FILE_LOCATION,fileRootLocationToSend);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
