package com.ge.treasury.manual.bai.merge.service;

import java.io.File;
import java.util.List;

public interface BaiMergeFileService {
	public String mergeFiles(String fileNamePattern, List<File> fileToMergeList, String rootLocation, String fileRootLocationToSend);
}
