package com.ge.treasury.manual.bai.merge.model;

import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.manual.bai.merge.util.BaiConstant;

public class BAIAccountIdentifier {
	//private String recordCode = "03";
	private String recordCode = BaiConstant.ACCOUNT_IDENTIFIER;
	private String customerAccountNumber;
	private String currencyCode;
	private String typeCode;
	private String amount;
	private String itemCount;
	private String fundsType;
	private CSVRecord record;
	
	
	public String getRecordCode() {
		return recordCode;
	}
	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}
	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getItemCount() {
		return itemCount;
	}
	public void setItemCount(String itemCount) {
		this.itemCount = itemCount;
	}
	public String getFundsType() {
		return fundsType;
	}
	public void setFundsType(String fundsType) {
		this.fundsType = fundsType;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setCustomerAccountNumber(record.get(1));
			setCurrencyCode(record.get(2));
			setTypeCode(record.get(3));
			setAmount(record.get(4));
			setItemCount(record.get(5));
			setFundsType(record.get(6));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
