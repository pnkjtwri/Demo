package com.ge.treasury.manual.bai.merge.dao;

public class JobConfigMapper {
	public Integer inboundConfigId;
	public String tsaName;
	public String jobName;
	public String sourceFileLocation;
	public String sourceFileNamePattern;
	public String nasFileNamePattern;
	public String nasFileLocation;
	public String mappingOrder;
	public String erpTargetFileName;
	public String erpTargetFileLocation;
	
	/**
	 * @return the tsaName
	 */
	public String getTsaName() {
		return tsaName;
	}
	/**
	 * @param tsaName the tsaName to set
	 */
	public void setTsaName(String tsaName) {
		this.tsaName = tsaName;
	}
	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}
	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	/**
	 * @return the sourceFileLocation
	 */
	public String getSourceFileLocation() {
		return sourceFileLocation;
	}
	/**
	 * @param sourceFileLocation the sourceFileLocation to set
	 */
	public void setSourceFileLocation(String sourceFileLocation) {
		this.sourceFileLocation = sourceFileLocation;
	}
	/**
	 * @return the sourceFileNamePattern
	 */
	public String getSourceFileNamePattern() {
		return sourceFileNamePattern;
	}
	/**
	 * @param sourceFileNamePattern the sourceFileNamePattern to set
	 */
	public void setSourceFileNamePattern(String sourceFileNamePattern) {
		this.sourceFileNamePattern = sourceFileNamePattern;
	}
	/**
	 * @return the nasFileNamePattern
	 */
	public String getNasFileNamePattern() {
		return nasFileNamePattern;
	}
	/**
	 * @param nasFileNamePattern the nasFileNamePattern to set
	 */
	public void setNasFileNamePattern(String nasFileNamePattern) {
		this.nasFileNamePattern = nasFileNamePattern;
	}
	/**
	 * @return the nasFileLocation
	 */
	public String getNasFileLocation() {
		return nasFileLocation;
	}
	/**
	 * @param nasFileLocation the nasFileLocation to set
	 */
	public void setNasFileLocation(String nasFileLocation) {
		this.nasFileLocation = nasFileLocation;
	}
	/**
	 * @return the mappingOrder
	 */
	public String getMappingOrder() {
		return mappingOrder;
	}
	/**
	 * @param mappingOrder the mappingOrder to set
	 */
	public void setMappingOrder(String mappingOrder) {
		this.mappingOrder = mappingOrder;
	}
	/**
	 * @return the erpTargetFileName
	 */
	public String getErpTargetFileName() {
		return erpTargetFileName;
	}
	/**
	 * @param erpTargetFileName the erpTargetFileName to set
	 */
	public void setErpTargetFileName(String erpTargetFileName) {
		this.erpTargetFileName = erpTargetFileName;
	}
	/**
	 * @return the erpTargetFileLocation
	 */
	public String getErpTargetFileLocation() {
		return erpTargetFileLocation;
	}
	/**
	 * @param erpTargetFileLocation the erpTargetFileLocation to set
	 */
	public void setErpTargetFileLocation(String erpTargetFileLocation) {
		this.erpTargetFileLocation = erpTargetFileLocation;
	}
	/**
	 * @return the inboundConfigId
	 */
	public Integer getInboundConfigId() {
		return inboundConfigId;
	}
	/**
	 * @param inboundConfigId the inboundConfigId to set
	 */
	public void setInboundConfigId(Integer inboundConfigId) {
		this.inboundConfigId = inboundConfigId;
	}
}
