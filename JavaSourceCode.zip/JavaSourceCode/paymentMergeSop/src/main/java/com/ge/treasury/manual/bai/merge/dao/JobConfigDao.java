package com.ge.treasury.manual.bai.merge.dao;

import java.util.List;
import java.util.Map;

public interface JobConfigDao {
	public List<JobConfigMapper> getNoOfFilesToMerge(Map<String,String> param );
	public int getInboundConfigIdForFile(Map<String,String> param);
	public List<JobConfigMapper> getFileDetails(String nasFileNamePattern);
}
