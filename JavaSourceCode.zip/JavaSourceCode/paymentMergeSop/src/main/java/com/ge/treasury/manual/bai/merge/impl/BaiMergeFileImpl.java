package com.ge.treasury.manual.bai.merge.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import com.ge.treasury.manual.bai.merge.dao.JobConfigDao;
import com.ge.treasury.manual.bai.merge.dao.JobConfigMapper;
import com.ge.treasury.manual.bai.merge.model.BAIFile;
import com.ge.treasury.manual.bai.merge.model.BAIFileHeader;
import com.ge.treasury.manual.bai.merge.model.BAIFileTrailer;
import com.ge.treasury.manual.bai.merge.model.BAIGroup;
import com.ge.treasury.manual.bai.merge.model.BAIGroupHeader;
import com.ge.treasury.manual.bai.merge.model.BAIGroupTrailer;
import com.ge.treasury.manual.bai.merge.service.BaiMergeFileService;
import com.ge.treasury.manual.bai.merge.util.BaiConstant;
import com.ge.treasury.manual.bai.merge.util.BaiManulUtility;

public class BaiMergeFileImpl implements BaiMergeFileService {
	private static Logger logger = Logger.getLogger(BaiMergeFileImpl.class);
	@Autowired
	JobConfigDao mergerFileDetailsDao;
	
	@Value("${mergedFileLocation}")
	private String fileLocation;
	
	@Value("${errorFileLocation}")
	private String errorLocation;
	
	@Value("${archiveMergeFileLocation}")
	private String archiveLocationForMergedFile;
	
	@Value("${archiveSourceFileLocation}")
	private String archiveSourceFileLocation;
	
	@Autowired private ApplicationContext appContext;
	
	@Override
	public String mergeFiles(String fileNamePattern, List<File> fileToMergeList, String rootLocation, String fileRootLocationToSend) {
		logger.info("Preparing locations.. ");
		fileLocation					= rootLocation + fileLocation;
		errorLocation 					= rootLocation + errorLocation;
		archiveSourceFileLocation		= rootLocation + archiveSourceFileLocation;
		archiveLocationForMergedFile	= rootLocation + archiveLocationForMergedFile;
		logger.info("*************************************************************************");
		logger.info("Merged File location - "+fileLocation);
		logger.info("Error File location - "+errorLocation);
		logger.info("Source File Archive location - "+archiveSourceFileLocation);
		logger.info("Merged File Archive location - "+archiveLocationForMergedFile);
		logger.info("*************************************************************************");
		
		List<JobConfigMapper> nasFileDetailList = null;
		List<File> listOfMovedFiles  = new ArrayList<File>();
		
		logger.info("Going to move the file under /manualrun/mergedfile");
		for(File fileToMoved : fileToMergeList){
			if(BaiManulUtility.moveFile(fileToMoved, fileLocation, false)){
				listOfMovedFiles.add(new File(fileLocation+fileToMoved.getName()));
			}else{
				logger.info("Error moving file - "+fileToMoved.getName());
			}
		}
		logger.info("File Moving process complete!!");
		logger.info(listOfMovedFiles.size()+ " No Of Files Moved to - "+fileLocation);
		/*if(listOfMovedFiles.size() < 2){
			logger.info("Merging process cannot continue, we moved only "+listOfMovedFiles.size() +" No of File to the location - "+fileLocation);
			moveAllFile(listOfMovedFiles, fileToMergeList);
			return null;
		}*/
		
		try{
			logger.info("Going to get details for file name pattern");
			nasFileDetailList = mergerFileDetailsDao.getFileDetails(fileNamePattern.trim());
			logger.info("Details found for file name pattern - "+fileNamePattern + " no of details found - "+nasFileDetailList.size());
		}catch(Exception e){
			logger.info("*********************************************************");
			logger.info("no details found for this file pattern - "+fileNamePattern);
			logger.info("Merge process can not continue...we did not found details.");
			logger.info(e.getMessage());
			logger.info("*********************************************************");
		}
		
		if(!(nasFileDetailList != null && nasFileDetailList.size() > 0)){
			logger.info("*********************************************************");
			logger.info("no details found for this file pattern - "+fileNamePattern);
			logger.info("Merge process can not continue...we did not found details.");
			logger.info("*********************************************************");
			logger.info("Moving Files to error");
			moveAllFile(listOfMovedFiles, fileToMergeList);
			return null;
		}
		
		File fileSendToBusiness = null;
		String mergedFileLocation = null;
		boolean isMergeProcessSuccessfull = false;
		
		if(listOfMovedFiles.size() > 1){
			logger.info("Merging process start ...");
			logger.info("going to merge File.. ");
			isMergeProcessSuccessfull = mergeListFile(listOfMovedFiles,nasFileDetailList,nasFileDetailList.get(0).getErpTargetFileName());
			logger.info("Merging of File done");
			
			if(isMergeProcessSuccessfull){
				logger.info("going to merge File group.. ");
				mergedFileLocation = mergeGroup(nasFileDetailList.get(0).getErpTargetFileName(),listOfMovedFiles);
				logger.info("Merging of File group done");
			}
			
			if(mergedFileLocation != null && mergedFileLocation.length() > 0){
				fileSendToBusiness = new File(mergedFileLocation);
			}
		}
		
		boolean fileSentStatus = false;
		if(fileSendToBusiness != null && fileSendToBusiness.exists() && fileSendToBusiness.length() > 1 ){
			logger.info("Going to send file to business");
			fileSentStatus = sendFileToBusiness(fileSendToBusiness, nasFileDetailList.get(0).getErpTargetFileLocation(), fileRootLocationToSend);
			logger.info("File sending process complete !!");
		}else if (listOfMovedFiles.size() == 1){
			logger.info("We have only one file, Going to send the file to business");
			File sourceFile     = listOfMovedFiles.get(0);
			mergedFileLocation  = fileLocation+nasFileDetailList.get(0).getErpTargetFileName();
			fileSendToBusiness = new File(mergedFileLocation);
			try{
				logger.info("Creating target file started..");
				Files.copy(sourceFile.toPath(), fileSendToBusiness.toPath());
				logger.info("Target file created - "+mergedFileLocation);
			}catch(Exception e){
				logger.info("Creating target file is failed.");
				logger.info(BaiManulUtility.getErrorFormStackTrace(e));
				fileSendToBusiness = null;
			}
			if(fileSendToBusiness != null){
				fileSentStatus = sendFileToBusiness(fileSendToBusiness, nasFileDetailList.get(0).getErpTargetFileLocation(), fileRootLocationToSend);
			}
		}
		logger.info("File sending process complete for - "+mergedFileLocation+", With Staus - "+fileSentStatus);
		
		if(fileSentStatus){
			logger.info("Going to archive source files");
			for(File fileMoveToArchive : listOfMovedFiles){
				if(fileMoveToArchive.exists()){
					BaiManulUtility.moveFile(fileMoveToArchive, archiveSourceFileLocation, true);
				}else{
					logger.info("File not found for archiving - "+fileMoveToArchive.getAbsolutePath());
				}
			}
			
			logger.info("Going to archive merged file - "+mergedFileLocation);
			if((fileSendToBusiness != null && fileSendToBusiness.exists())){
				BaiManulUtility.moveFile(fileSendToBusiness, archiveLocationForMergedFile, true);
			}
			
			if(fileSendToBusiness != null && new File(fileSendToBusiness.getAbsolutePath()+BaiConstant.TMP_FILE_EXTENSION).exists()){
				BaiManulUtility.removeFile(fileSendToBusiness.getAbsolutePath()+BaiConstant.TMP_FILE_EXTENSION);
			}
		}else{
				if(!isMergeProcessSuccessfull || mergedFileLocation == null || listOfMovedFiles.size() == 1){
					logger.info("Moving received file to error location");
					moveAllFile(listOfMovedFiles, null);
				}
				File fileToDelete = new File(fileLocation+nasFileDetailList.get(0).getErpTargetFileName()+BaiConstant.TMP_FILE_EXTENSION);
				logger.info("Removing Tmp file if found in case of error - "+fileToDelete.getAbsolutePath());
				if(fileToDelete.exists()){
					logger.info("Tmp file if found in case of error");
					BaiManulUtility.removeFile(fileToDelete.getAbsolutePath());
				}
				
				fileToDelete = new File(fileLocation+nasFileDetailList.get(0).getErpTargetFileName());
				logger.info("Removing merged file if found in case of error - "+fileToDelete.getAbsolutePath());
				if(new File(fileLocation+nasFileDetailList.get(0).getErpTargetFileLocation()).exists()){
					logger.info("merged file found in case of error");
					BaiManulUtility.removeFile(fileToDelete.getAbsolutePath());
				}
		}
		
		return "COMPLETE";
	}
	
	private boolean mergeListFile(List<File> listOfRecivedFiles, List<JobConfigMapper>  configBeanList, String erpTargetOutputFileName){
		logger.info("Going to Merge all the received files, no of files received - "+listOfRecivedFiles.size());
		BAIGroupHeader groupHeader;
		BAIGroupTrailer groupTrailer;
		
		BAIFile baiFile 			= null;
		BAIFileHeader fileHeader 	= null;
		BAIFileTrailer fileTrailer 	= null;
		BAIGroup group 				= null;
		
		ArrayList<String> accountDataLines 		= null;
		ArrayList<BAIGroup> groups 				= null;
		ArrayList<BAIFile> baiFiles 			= new ArrayList<BAIFile>();
		
		BufferedReader br     =  null;
		BufferedWriter writer = null;
		long fileControlTotal = 0;
		long numberOfGroups   = 0;
		long numberOfRecords  = 0;
		StringBuffer fileMergeContent = new StringBuffer();
		String tmpFileName = fileLocation+erpTargetOutputFileName+BaiConstant.TMP_FILE_EXTENSION;
		
		boolean isFileMergeSuccess = false;
		
		try{
			logger.info("Initilizing output file Object");
			writer = new BufferedWriter(new FileWriter(tmpFileName));
			
			String headerLineForOutputFile = "";
			String mappingOrderDb = "0";
			String prevMappingOrder = "0";
			
			for(File file: listOfRecivedFiles){
				baiFile = new BAIFile();
				String line = "";
				br = new BufferedReader(new FileReader(file));
				String status = "success";
			
				while ((line = br.readLine()) != null) {
					String[] recordArray = line.split(",");
				    String firstValue = recordArray[0];
				    
				    if(firstValue.equalsIgnoreCase(BaiConstant.FILE_HEADER_TAG)){
				    	logger.info("Header Tag Found for the file - "+file.getName());
				    	fileHeader = new BAIFileHeader();
				    	groups = new ArrayList<BAIGroup>();
				    	
				    	for(JobConfigMapper configBean : configBeanList){
				    		if(trimBAIFileTimeStamp(file.getName()).toUpperCase().contains(configBean.getNasFileNamePattern().toUpperCase())){
				    			mappingOrderDb = configBean.getMappingOrder();
				    			if(Integer.parseInt(prevMappingOrder) == 0){
				    				prevMappingOrder = mappingOrderDb;
				    				headerLineForOutputFile = line;
				    			}
				    		}
				    	}
				    	
				    	if(mappingOrderDb != null && Integer.parseInt(prevMappingOrder) > Integer.parseInt(mappingOrderDb)){
				    		headerLineForOutputFile = line;
				    		prevMappingOrder = mappingOrderDb;
				    	}
				    	
				    	status = fileHeader.populate(recordArray);
				    	baiFile.setFileHeader(fileHeader);
				    	logger.info("Header Tag value - "+fileHeader.toString());
				    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_HEADER_TAG)){
				    	logger.info("Group Header Found for the file - "+file);
				    	group = new BAIGroup();				    	
				    	groupHeader = new BAIGroupHeader();		
				    	accountDataLines = new ArrayList<String>();
				    	status = groupHeader.populate(recordArray);
				    	group.setGroupHeader(groupHeader);
				    	logger.info("Group Header value - "+groupHeader.toString());
				    }else if(  firstValue.equalsIgnoreCase(BaiConstant.ACCOUNT_HEADER_TAG) 
				    		|| firstValue.equalsIgnoreCase(BaiConstant.ACCOUNT_TRAILER_TAG)
				    		|| firstValue.equalsIgnoreCase(BaiConstant.TRANSACTION_DETAIL_TAG) 
				    		|| firstValue.equalsIgnoreCase(BaiConstant.CONTINUATION_TAG)){
				    	accountDataLines.add(line);
				    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG)){
				    	logger.info("Group Trailer Found for the file - "+file);
				    	groupTrailer = new BAIGroupTrailer();
				    	status = groupTrailer.populate(recordArray);
				    	fileControlTotal += new Long(groupTrailer.getGroupControlTotal());
				    	numberOfGroups ++;
				    	group.setGroupTrailer(groupTrailer);
				    	group.setAccountDataLines(accountDataLines);
				    	groups.add(group);
				    	logger.info("Group Trailer value - "+groupTrailer.toString());
				    }else if(firstValue.equalsIgnoreCase(BaiConstant.FILE_TRAILER_TAG)){
				    	logger.info("File Trailer Found for the file - "+file);
				    	fileTrailer = new BAIFileTrailer();
				    	status = fileTrailer.populate(recordArray);
				    	baiFile.setFileTrailer(fileTrailer);
				    	baiFile.setGroups(groups);
				    	baiFiles.add(baiFile);
				    	logger.info("File Trailer value - "+fileTrailer.toString());
				    }
					
					if(    !firstValue.equalsIgnoreCase(BaiConstant.FILE_HEADER_TAG) 
						&& !firstValue.equalsIgnoreCase(BaiConstant.FILE_TRAILER_TAG)){
						fileMergeContent.append(line);
						fileMergeContent.append(BaiConstant.BAI_NEW_LINE_CHAR);
					}
					
					numberOfRecords ++;
				}
				numberOfRecords = numberOfRecords -2;
				br.close();
			}
			numberOfRecords = numberOfRecords + 2;
			
			if(fileTrailer != null){
				logger.info("Writing File Header value ");
				writer.write(headerLineForOutputFile);
				logger.info("File Header writing complete");
				writer.newLine();
				logger.info("Writing File body value ");
				writer.write(fileMergeContent.toString());
				logger.info("File Body writing complete");
				
				logger.info("Setting Final File Trailer value ");
				fileTrailer.setFileControlTotal(String.valueOf(fileControlTotal));
				fileTrailer.setNumberOfRecords(String.valueOf(numberOfRecords));
				fileTrailer.setNumberOfGroups(String.valueOf(numberOfGroups));
				logger.info("Writing File Trailer value ");
				writer.write(fileTrailer.toString()+BaiConstant.BAI_END_LINE_CHAR);
			}
			writer.flush();
			isFileMergeSuccess = true;
		}catch(Exception e){
			logger.info("Getting Issue while merging all the files, moving files to error.");
			logger.info("Error while Merging all file process");
			logger.info(BaiManulUtility.getErrorFormStackTrace(e));
			isFileMergeSuccess = false;
		}finally{
			try{
				if(br != null){
					br.close();
				}
				
				if(writer != null){
					writer.close();
				}
			}catch(Exception e){
				logger.info("Error while closing writer and reader");
			}
		}
		
		return isFileMergeSuccess;
	}
	
	
	private String mergeGroup(String erpTargetFileName,List<File> listOfRecivedFiles){
		BufferedReader br     = null;
		BufferedWriter writer = null;
		int totalNoOfFileRec  = 0 ;
		int noOfGroups        = 0;
		String tmpFileName = fileLocation+erpTargetFileName+BaiConstant.TMP_FILE_EXTENSION;
		String finalFileName = fileLocation+erpTargetFileName;
		try{
			br = new BufferedReader(new FileReader(tmpFileName));
			writer = new BufferedWriter(new FileWriter(finalFileName));
			
			Map<String,Map<String,List<String>>> groupHeaderMap = new HashMap<String,Map<String,List<String>>>();
			
			String fileHeaderLine = "";
			
			String line = "";
			String groupHEaderKey  = "";
			String groupHEaderLine = "";
			
			List<String> groupLines = new ArrayList<String>();
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiConstant.FILE_HEADER_TAG)){
			    	logger.info("File Header Found during group merge ");
			    	fileHeaderLine = line;
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_HEADER_TAG)){
			    	logger.info("Group Header Found during group merge ");
			    	//groupHeader.put(line, value)
			    	if(recordArray[7].indexOf("/") > 0){
			    		recordArray[7] = recordArray[7].substring(0,recordArray[7].indexOf("/"));
			    	}
			    	
			    	//adding grop header in one for comparing with other Group Hearder
			    	//adding Originator Identification, As-of-Date, As-of-Date Modifier
			    	//groupHEaderKey = recordArray[2]+recordArray[4]+recordArray[7];
			    	//adding Originator Identification, As-of-Date
			    	groupHEaderKey = recordArray[2]+recordArray[4];
			    	groupHEaderLine = line;
			    	groupLines = new ArrayList<String>();
			    }else if(firstValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG)){
			    	logger.info("Group Trailer Found during group merge ");
			    	
			    	long groupAmountTotal = 0l;
			    	int totalAccountCount = 0; //assuming that there will be always one "03" tag
			    	String groupLine      = "";
			    	
			    	if(!groupHeaderMap.containsKey(groupHEaderKey)){
			    		groupLines.add(line);
			    		Map<String,List<String>> groupValueMap = new HashMap<String,List<String>>();
			    		groupValueMap.put(groupHEaderLine, groupLines);
			    		groupHeaderMap.put(groupHEaderKey, groupValueMap);
			    		noOfGroups ++;
			    	}else{
			    		List<String> mergedLineList = new ArrayList<String>();
			    		List<String> tmpRecords =  (groupHeaderMap.get(groupHEaderKey)).get(groupHEaderLine);
			    		int noOfAccountsInMap = getAccountCount(groupHeaderMap, groupHEaderKey, groupHEaderLine);
			    		int totalNoOfGroupRec = 0;
			    		int accountLoopCount = 0;
			    		for(String lineTmp : tmpRecords){
			    			String[] recordTmpArray = lineTmp.split(",");
						    String firstTmpValue 	= recordTmpArray[0];
						    
						    if(firstTmpValue.equalsIgnoreCase(BaiConstant.ACCOUNT_TRAILER_TAG)){
						    	groupAmountTotal += Long.parseLong(recordTmpArray[1]);
						    	
						    	if(recordTmpArray[2].indexOf(BaiConstant.BAI_END_LINE_CHAR) > 0){
				    				String tmpAmt  = recordTmpArray[2].substring(0,recordTmpArray[2].indexOf(BaiConstant.BAI_END_LINE_CHAR));
				    				totalNoOfGroupRec += Integer.parseInt(tmpAmt);
				    			}else{
				    				totalNoOfGroupRec += Integer.parseInt(recordTmpArray[2]);
				    			}
						    	mergedLineList.add(lineTmp); //add accountTrailer to the list
						    	
						    	if(noOfAccountsInMap==accountLoopCount)for(String lineToMerge : groupLines){//going to iterate current account data
						    		mergedLineList.add(lineToMerge);
						    		String[] recordToMergeArray = lineToMerge.split(",");
						    		String fisrtToMergeValue    = recordToMergeArray[0];
						    		if(fisrtToMergeValue.equalsIgnoreCase(BaiConstant.ACCOUNT_HEADER_TAG)){
						    			totalAccountCount ++; 
						    		}
						    		if(fisrtToMergeValue.equalsIgnoreCase(BaiConstant.ACCOUNT_TRAILER_TAG)){
						    			groupAmountTotal += Long.parseLong(recordToMergeArray[1]);
						    			if(recordToMergeArray[2].indexOf(BaiConstant.BAI_END_LINE_CHAR) > 0){
						    				String tmpAmt  = recordToMergeArray[2].substring(0,recordToMergeArray[2].indexOf(BaiConstant.BAI_END_LINE_CHAR));
						    				totalNoOfGroupRec += Integer.parseInt(tmpAmt);
						    			}else{
						    				totalNoOfGroupRec += Integer.parseInt(recordToMergeArray[2]);
						    			}
						    		}
						    	}
						    }
						    
						    if(!firstTmpValue.equalsIgnoreCase(BaiConstant.ACCOUNT_TRAILER_TAG) &&
						       !firstTmpValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG)){
						    	mergedLineList.add(lineTmp); //adding other rows
						    	
						    	if(firstTmpValue.equalsIgnoreCase(BaiConstant.ACCOUNT_HEADER_TAG)){
						    		 accountLoopCount ++;
						    	 }
						    	
						    }
						    
						    if(firstTmpValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG)){
						    	totalNoOfGroupRec += 2;
						    	totalAccountCount = totalAccountCount+noOfAccountsInMap;
						    	groupLine += BaiConstant.GROUP_TRAILER_TAG+","+groupAmountTotal+","+totalAccountCount+","+totalNoOfGroupRec+BaiConstant.BAI_END_LINE_CHAR;
						    }
			    		}
			    		mergedLineList.add(groupLine);
			    		groupHeaderMap.get(groupHEaderKey).put(groupHEaderLine, mergedLineList);
			    	}
			    }
			    
			    if(!firstValue.equalsIgnoreCase(BaiConstant.FILE_HEADER_TAG) && 
			       !firstValue.equalsIgnoreCase(BaiConstant.GROUP_HEADER_TAG) &&
			       !firstValue.equalsIgnoreCase(BaiConstant.GROUP_TRAILER_TAG) &&
			       !firstValue.equalsIgnoreCase(BaiConstant.FILE_TRAILER_TAG)){
				       groupLines.add(line);
					}
			    
			    if(firstValue.equalsIgnoreCase(BaiConstant.FILE_TRAILER_TAG) ){
			    	writer.write(fileHeaderLine);
			    	writer.newLine();
			    	totalNoOfFileRec ++;
			    	
			    	for(String headerKey : groupHeaderMap.keySet()){
			    		Map<String,List<String>> groupValueMap = groupHeaderMap.get(headerKey);
			    		for (Map.Entry<String, List<String>> entry : groupValueMap.entrySet()){
				    		writer.write(entry.getKey());
					    	writer.newLine();
					    	totalNoOfFileRec ++;
					    	for(String contentToWrite : entry.getValue()){
					    		writer.write(contentToWrite);
						    	writer.newLine();
						    	totalNoOfFileRec ++;
					    	}
				    	}
			    	}
			    	
			    	
			    	totalNoOfFileRec = totalNoOfFileRec + 1;
			    	
			    	String fileTrailer = BaiConstant.FILE_TRAILER_TAG+","
			    			+recordArray[1]+","+noOfGroups+","+totalNoOfFileRec+BaiConstant.BAI_END_LINE_CHAR;
			    	writer.write(fileTrailer);
			    	writer.flush();
				 }
			}
		}catch(Exception e){
			logger.info("Error while merging group headers for files, moving files to error..");
			logger.info("Error while merging group headers");
			logger.info(BaiManulUtility.getErrorFormStackTrace(e));
			finalFileName = null;
		}finally{
			try{
				if(writer != null){
					writer.close();
				}
				if(br != null){
					br.close();
				}
			}catch(Exception e){
				logger.info("Error while closing writer and reader in group merging");
			}
		}
		
		return finalFileName;
	}
	
	private int getAccountCount(Map<String,Map<String,List<String>>> groupHeaderMap, String groupHEaderKey, 
			String groupHEaderLine){
		int noOfAccounts = 0;
		List<String> tmpRecords =  (groupHeaderMap.get(groupHEaderKey)).get(groupHEaderLine);
		for(String lineTmp : tmpRecords){
			String[] recordTmpArray = lineTmp.split(",");
		    String firstTmpValue 	= recordTmpArray[0];
		    
		    if(firstTmpValue.equalsIgnoreCase(BaiConstant.ACCOUNT_HEADER_TAG)){
	    		 noOfAccounts ++;  
	    	 }
		}
		return noOfAccounts;
	}
	
	private boolean sendFileToBusiness(File inputFile, String sendFileLocation, String fileRootLocationToSend){
		boolean isSent = false;
		logger.info("Going to transfer merge file...."+inputFile.getName());
		logger.info("Going to transfer file...."+inputFile.getName());
		
		sendFileLocation = sendFileLocation.substring((sendFileLocation.indexOf("/MERGEDBAIAutomatedExtract")),sendFileLocation.length());
		
		if(fileRootLocationToSend != null && fileRootLocationToSend.length() > 0){
			sendFileLocation = fileRootLocationToSend + sendFileLocation;
		}
		
		try{
			AtomicReference<String> targetDir = (AtomicReference<String>)appContext.getBean(BaiConstant.FILE_TARGET_DIR, AtomicReference.class);
			logger.info("Merge file sending location - "+sendFileLocation);
			targetDir.set(sendFileLocation);
			
			Message<File> message = MessageBuilder.withPayload(inputFile).build();
			final MessageChannel baiMergeFileOutboundChannel = appContext.getBean (BaiConstant.FILE_OUTBOUND_CHANNEL, MessageChannel.class);
			isSent = baiMergeFileOutboundChannel.send(message,1000);
			if(isSent){logger.info("Merge file Transefered to  - "+sendFileLocation);}
		} catch (Exception e) {
			logger.info("Got Exception inside sendFileToBusiness()");
			logger.info("Transfer of merge file Failed !!");
			isSent = false;
			e.printStackTrace();
		}
		logger.info("inside sendFileToBusiness() sent status - "+isSent);
		return isSent;  
	}
	
	private void moveAllFile(List<File> listOfMovedFiles, List<File> fileToMergeList){
		if(listOfMovedFiles != null && listOfMovedFiles.size() > 0){
			for(File moveToError : listOfMovedFiles){
				if(moveToError.exists()){
					BaiManulUtility.moveFile(moveToError, errorLocation, false);
				}else{
					logger.info("File not found - "+moveToError.getAbsolutePath());
				}
			}
		}
		if(fileToMergeList != null && fileToMergeList.size() > 0 ){
			for(File moveToError : fileToMergeList){
				if(moveToError.exists()){
					BaiManulUtility.moveFile(moveToError, errorLocation, false);
				}else{
					logger.info("File not found - "+moveToError.getAbsolutePath());
				}
			}
		}
	}
	
	private static String trimBAIFileTimeStamp(String filename) {
		int dotIdx = filename.lastIndexOf(".");
		String fileNameWithTimeStamp = filename.substring(0, dotIdx);
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		String fileNameWithoutTimeStamp = fileNameWithTimeStamp.substring(0, underscoreIdx);
		
		return fileNameWithoutTimeStamp+filename.substring(dotIdx, filename.length());
	}
}
