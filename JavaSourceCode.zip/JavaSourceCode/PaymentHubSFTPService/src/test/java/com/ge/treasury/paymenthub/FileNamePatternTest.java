package com.ge.treasury.paymenthub;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ge.treasury.PaymentHub.FileManagementApplication;
import com.ge.treasury.PaymentHub.dao.impl.PaymentHubJDBCTempleteDAOImpl;

/**
 * Check BAI Input file name pattern against filename pattern available in DB .
 * 
 * @author senthilkumar.raman
 *
 */

@ActiveProfiles("DEV")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(FileManagementApplication.class)
public class FileNamePatternTest {
	
	private static Logger logger = Logger.getLogger(FileNamePatternTest.class);
	@Autowired private PaymentHubJDBCTempleteDAOImpl systemDAOImpl;
	@Value("${BAIFileType}")
	private String baiFileType;
	@Value("${BAIFileLocation}")
	private String baiLocation;
	private List<Map<String,Object>> listOfPatterns = null;
	File decryptFilePD = new File("BAI2-ABXCFSNA-PD_20160209121044.txt_ANTARES_pgp-bai-cfs");
	File decryptFileCD = new File("BAI2-ABXCFSNA-CD_20160209121044.txt_ANTARES_pgp-bai-cfs");
	
	@Test
	public void testFileNamePattern() {
		logger.info("testFileNamePattern() Enter");
		ArrayList<File> fileList = new ArrayList<File>();
		fileList.add(decryptFilePD);
		fileList.add(decryptFileCD);
		Iterator<File> itrFileList = fileList.iterator();
		while (itrFileList.hasNext()){
			File decryptFile = itrFileList.next();
			if(decryptFile.getName().toUpperCase().contains(baiFileType.toUpperCase())){
				
				String inputFileName = decryptFile.getName();
				logger.info("BAI inputFileName : "+inputFileName);
				
				String inputFileNameWithoutTS = null;
				Pattern p = Pattern.compile("(_\\d{4}\\d{2}\\d{2}\\d{2}\\d{2}\\d{2})");
				Matcher m = p.matcher(inputFileName);
				if (m.find()) {
					logger.info("Timestamp found : "+m.group(1));
					inputFileNameWithoutTS= inputFileName.replaceFirst(m.group(1), "");
					logger.info("inputFileNameWithoutTS : "+inputFileNameWithoutTS);
				}else{
					logger.info(" File does not contains Timestamp : ["+inputFileName+"]");
					inputFileNameWithoutTS = inputFileName;
				}
				if(listOfPatterns == null){
					listOfPatterns = systemDAOImpl.getNasFileNamePattern();
				}

				logger.info(" No of patterns found in DB : ["+listOfPatterns.size()+"]");
				boolean isPatternMatched = false;
				String pattern = null;
				for (Map<String, Object> map : listOfPatterns) {
					if(isPatternMatched){
						break;
					}
				    for (Map.Entry<String, Object> entry : map.entrySet()) {
				    	logger.debug(entry.getKey() + " - " + entry.getValue());
				    	pattern = (String) entry.getValue();
				    	if(inputFileNameWithoutTS != null & inputFileNameWithoutTS.equalsIgnoreCase(pattern)){
				    		isPatternMatched = true;
				    		break;
				    	}
				    }
				}
				if(isPatternMatched){
					logger.debug("isPatternMatched : "+isPatternMatched);
					//Process BAI input file
					logger.debug("Pattern Matched successfully, BAI input file going to Process...");
				}else{
					logger.debug("isPatternMatched : "+isPatternMatched);
					//Send input file to unknow location.
					logger.debug("Send input file to unknow location");
				}
				
				Assert.assertEquals("File Pattern is correct", "BAI2", baiFileType );
				
			}else{
				logger.debug("Input file name does not contains word : "+baiFileType);
				logger.debug("Send input file to unknow location");
				//Send input file to unknow location.
			}
		}
		
		logger.info("testFileNamePattern() Exit");
	}

}
