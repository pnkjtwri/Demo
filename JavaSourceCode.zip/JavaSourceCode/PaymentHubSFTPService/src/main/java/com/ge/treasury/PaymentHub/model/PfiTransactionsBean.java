package com.ge.treasury.PaymentHub.model;

import java.sql.Timestamp;

/**
 * this class is mapper with the data base table
 * T_WEBCASHTSA_PFI_TRANSACTIONS
 **/
public class PfiTransactionsBean extends CommonBean {
	private Long pfiTransactionId;
	private Long srcPaymentFileId;
	private Long segregatorFileId;
	private String transactionType;
	private String modelId;
	private String accountId;
	private String debitorAccountId;
	private String trustedSource;
	private Timestamp transValueDate;
	private String currency;
	private String transactionAmount;
	private String transHashString;
	private String recordNumber;
	private String extractionStatus;
	private String debitBankRouteCode;
	private String debitAccountNumber;
	private String creditBankRouteCode;
	private String creditAccountNumber;
	private String operatorID;
	private String operatorName;
	
	
	public Long getPfiTransactionId() {
		return pfiTransactionId;
	}
	public void setPfiTransactionId(Long pfiTransactionId) {
		this.pfiTransactionId = pfiTransactionId;
	}
	public Long getSrcPaymentFileId() {
		return srcPaymentFileId;
	}
	public void setSrcPaymentFileId(Long srcPaymentFileId) {
		this.srcPaymentFileId = srcPaymentFileId;
	}
	public Long getSegregatorFileId() {
		return segregatorFileId;
	}
	public void setSegregatorFileId(Long segregatorFileId) {
		this.segregatorFileId = segregatorFileId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getDebitorAccountId() {
		return debitorAccountId;
	}
	public void setDebitorAccountId(String debitorAccountId) {
		this.debitorAccountId = debitorAccountId;
	}
	public String getTrustedSource() {
		return trustedSource;
	}
	public void setTrustedSource(String trustedSource) {
		this.trustedSource = trustedSource;
	}
	public Timestamp getTransValueDate() {
		return transValueDate;
	}
	public void setTransValueDate(Timestamp transValueDate) {
		this.transValueDate = transValueDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransHashString() {
		return transHashString;
	}
	public void setTransHashString(String transHashString) {
		this.transHashString = transHashString;
	}
	public String getRecordNumber() {
		return recordNumber;
	}
	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}
	public String getExtractionStatus() {
		return extractionStatus;
	}
	public void setExtractionStatus(String extractionStatus) {
		this.extractionStatus = extractionStatus;
	}
	public String getDebitBankRouteCode() {
		return debitBankRouteCode;
	}
	public void setDebitBankRouteCode(String debitBankRouteCode) {
		this.debitBankRouteCode = debitBankRouteCode;
	}
	public String getDebitAccountNumber() {
		return debitAccountNumber;
	}
	public void setDebitAccountNumber(String debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}
	public String getCreditBankRouteCode() {
		return creditBankRouteCode;
	}
	public void setCreditBankRouteCode(String creditBankRouteCode) {
		this.creditBankRouteCode = creditBankRouteCode;
	}
	public String getCreditAccountNumber() {
		return creditAccountNumber;
	}
	public void setCreditAccountNumber(String creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}
	public String getOperatorID() {
		return operatorID;
	}
	public void setOperatorID(String operatorID) {
		this.operatorID = operatorID;
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	
}
