package com.ge.treasury.PaymentHub.model;

public class FileStatusBean extends CommonBean{
	
	private Integer fileStatusID;
	private String fileStatusShortDesc;
	private String fileStatusLongDesc;
	private String fileStatusType;
	private String activeIND;
	private String comments;
	
	
	public Integer getFileStatusID() {
		return fileStatusID;
	}
	public void setFileStatusID(Integer fileStatusID) {
		this.fileStatusID = fileStatusID;
	}
	public String getFileStatusShortDesc() {
		return fileStatusShortDesc;
	}
	public void setFileStatusShortDesc(String fileStatusShortDesc) {
		this.fileStatusShortDesc = fileStatusShortDesc;
	}
	public String getFileStatusLongDesc() {
		return fileStatusLongDesc;
	}
	public void setFileStatusLongDesc(String fileStatusLongDesc) {
		this.fileStatusLongDesc = fileStatusLongDesc;
	}
	public String getFileStatusType() {
		return fileStatusType;
	}
	public void setFileStatusType(String fileStatusType) {
		this.fileStatusType = fileStatusType;
	}
	public String getActiveIND() {
		return activeIND;
	}
	public void setActiveIND(String activeIND) {
		this.activeIND = activeIND;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}
