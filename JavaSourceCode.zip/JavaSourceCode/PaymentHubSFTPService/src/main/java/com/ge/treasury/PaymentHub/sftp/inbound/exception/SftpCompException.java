/**
 * 
 */
package com.ge.treasury.PaymentHub.sftp.inbound.exception;

/**
 * /** custom exception for this component
 * 
 * @author pankaj1.tiwari
 *
 */
public class SftpCompException extends Exception {

  public SftpCompException(Exception exception) {
    super(exception);
  }

  public SftpCompException(String message) {
    super(message);
  }

  private static final long serialVersionUID = 1L;

}