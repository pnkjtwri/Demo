package com.ge.treasury.PaymentHub.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.model.FileStatusBean;

@SuppressWarnings("rawtypes")
public class FileStatusRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(FileStatusRowMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		logger.info("[FileStatusRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into FileStatusBean..]");
		FileStatusBean fileStatusBean = new FileStatusBean();
		fileStatusBean.setFileStatusID(rs.getInt("FILESTATUS_ID"));
		fileStatusBean.setFileStatusShortDesc(rs.getString("FILESTATUS_SHORT_DESC"));
		fileStatusBean.setFileStatusLongDesc(rs.getString("FILESTATUS_LONG_DESC"));
		fileStatusBean.setFileStatusType(rs.getString("FILESTATUS_TYPE"));
		fileStatusBean.setActiveIND(rs.getString("ACTIVE_IND"));
		fileStatusBean.setComments(rs.getString("COMMENTS"));
		fileStatusBean.setCreatedBy(rs.getString("CREATED_BY"));
		fileStatusBean.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		fileStatusBean.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		fileStatusBean.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[FileStatusRowMapper.class] [Inside mapRow()] [Going to return FileStatusBean..]");
		return fileStatusBean;
	}

}
