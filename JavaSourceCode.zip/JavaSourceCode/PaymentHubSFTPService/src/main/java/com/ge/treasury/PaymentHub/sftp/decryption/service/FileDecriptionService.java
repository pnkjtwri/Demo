package com.ge.treasury.PaymentHub.sftp.decryption.service;

import java.io.File;

public interface FileDecriptionService {

	void decryptFile(File inputFile);

}
