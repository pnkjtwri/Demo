/**
 * 
 */
package com.ge.treasury.PaymentHub.sftp.mapper;

import org.apache.ibatis.annotations.Insert;

import com.ge.treasury.PaymentHub.model.FileTransferAuditLog;

/**
 * @author padmajaarekuti
 *
 */
public interface FileTransferAuditLogMapper {
	
	@Insert("INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILETRANSFER_AUDITLOG (FILE_NAME,FILE_TYPE,SRC_LOCATION,DEST_LOCATION,STATUS,COMMENTS,CREATED_BY,LAST_MODIFIED_BY) "
			+ "VALUES(#{fileName}, #{fileType},#{srcLocation},#{destLocation},#{status},#{comments},#{createdBy},#{lastModifiedBy})")
	public void insertAuditLog(FileTransferAuditLog auditLog);
	

}
