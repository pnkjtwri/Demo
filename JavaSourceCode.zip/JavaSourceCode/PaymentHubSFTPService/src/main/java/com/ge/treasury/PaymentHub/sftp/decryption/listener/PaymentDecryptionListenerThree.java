package com.ge.treasury.PaymentHub.sftp.decryption.listener;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.PaymentHub.service.FileLockingService;
import com.ge.treasury.PaymentHub.sftp.decryption.service.impl.FileDecriptionServiceImpl;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;
public class PaymentDecryptionListenerThree {
	
	private static Logger logger = Logger.getLogger(PaymentDecryptionListenerThree.class);

	@Autowired FileDecriptionServiceImpl fileDecriptionService;
	@Autowired FileLockingService fileLockingService;

	@ServiceActivator
	public void decryptSourceFile(File inputFile){
		logger.info("[PaymentDecryptionListenerThree.class] [inside decryptSourceFile()]");
		logger.info("[PaymentDecryptionListenerThree.class] [inside decryptSourceFile()] [Decryption Service invoked for file named : "+inputFile+"]");
		try {
			if(inputFile.exists() && inputFile.length() > 0){
				logger.info("[PaymentDecryptionListenerThree.class] [inside decryptSourceFile()] [Going to check file is locked or not....]");
				logger.info("[PaymentDecryptionListenerThree.class] [inside decryptSourceFile()] [Going to process file....]");
				fileDecriptionService.decryptFile(inputFile);
				logger.info("[PaymentDecryptionListenerThree.class] [inside decryptSourceFile()] [Process has done....]");
				fileLockingService.deleteLockedFileDetail(inputFile);
			}
		} catch (Exception e) {
			logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
		}
	}
}
