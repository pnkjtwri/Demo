package com.ge.treasury.PaymentHub.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;

import aj.org.objectweb.asm.Type;

import com.ge.treasury.PaymentHub.dao.PaymentHubJDBCTempleteDAO;
import com.ge.treasury.PaymentHub.model.FileStatusBean;
import com.ge.treasury.PaymentHub.model.FileTransferAuditLog;
import com.ge.treasury.PaymentHub.model.LockedFileBean;
import com.ge.treasury.PaymentHub.model.PFIBusiness;
import com.ge.treasury.PaymentHub.model.PFIBusinessTSAInstanceMapping;
import com.ge.treasury.PaymentHub.model.PfiTransactionsBean;
import com.ge.treasury.PaymentHub.model.SegregatorFileBean;
import com.ge.treasury.PaymentHub.model.TSAInstance;
import com.ge.treasury.PaymentHub.rowmapper.FileStatusRowMapper;
import com.ge.treasury.PaymentHub.rowmapper.PFIBusinessRowMapper;
import com.ge.treasury.PaymentHub.rowmapper.PFIBusinessTSAInstancesRowMapper;
import com.ge.treasury.PaymentHub.rowmapper.SegregatorFileRowMapper;
import com.ge.treasury.PaymentHub.rowmapper.TSAInstanceRowMapper;

@Repository
@SuppressWarnings({"unchecked"})
public class PaymentHubJDBCTempleteDAOImpl implements PaymentHubJDBCTempleteDAO {

	@Autowired private DataSource dataSource;
	@Autowired private JdbcTemplate jdbc;
	
	private static final String insertAuditLogQuery =
            "INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILETRANSFER_AUDITLOG (FILE_NAME,FILE_TYPE,SRC_LOCATION,DEST_LOCATION,"
            + "STATUS,COMMENTS,CREATED_BY,LAST_MODIFIED_BY) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static final String updateImportStatusFileNameInSegregatorQuery = "UPDATE Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SEGREGATOR_FILE "
			+ "SET IMPORT_STATUS_FILE_NAME = ?, FILESTATUS_ID = ?, LAST_MODIFIED_TIMESTAMP = ? WHERE segregator_file_id = ?";
	
	private static final String insertLockTableQuery = 
			"INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES (LOCKED_FILE_NAME, LOCKED_FILE_PROCESSED_TIME, "
			+ "LOCKED_FILE_SIZE, CREATED_BY, CREATED_TIMESTAMP,LAST_MODIFIED_BY, LAST_MODIFIED_TIMESTAMP) "
			+"VALUES (?, ?, ?, ?, ?, ?, ?) ";
	
	private static final String updatePFITxnDetailsQuery = "UPDATE Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_TRANSACTIONS "
			+ "SET Extraction_status = ?, Debit_Bank_Route_Code = ?, Debit_Account_Number = ?, Credit_Bank_Route_Code = ?, "
			+ "Credit_Account_Number = ?, Operator_ID = ?, Operator_Name = ?, LAST_MODIFIED_BY = ? "
			+ "WHERE SEGREGATOR_FILE_ID = ? AND RECORD_NUMBER = ?";
	
	private static final String getNASFileNamePatternQuery = "select distinct NAS_FILENAME_PATTERN, EXTRACT_TYPE from Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_JOB_CONFIG "
			+ "where TSA_NAME in ( select TSAINSTANCE_IDENTIFIER from Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES where DELETE_FLAG = 'N' )";
	
	/**
	 * Method used for getting all T_WEBCASHTSA_TSAINSTANCES records 
	 */
	@Override
	public List<TSAInstance> getTSAInstanceDetails() {
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES ", 
				new TSAInstanceRowMapper());
	}
	
	/**
	 * Method used for saving downloaded remote files into T_WEBCASHTSA_FILETRANSFER_AUDITLOG table
	 */
	@Override
	public int saveAuditLogDetails(FileTransferAuditLog auditLog){
		Object[] params = new Object[] {
				auditLog.getFileName(), auditLog.getFileType(), auditLog.getSrcLocation(), auditLog.getDestLocation(), 
				auditLog.getStatus(), auditLog.getComments(), auditLog.getCreatedBy(), auditLog.getLastModifiedBy() };
		
		int[] types = new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR
        };
		
		return jdbc.update(insertAuditLogQuery, params, types);
	}
	
	/**
	 * Method used for fetching Business and TSAInsatces mapping records by TSA ID
	 * @param tsaInstancesID
	 */
	@Override
	public List<PFIBusinessTSAInstanceMapping> getBusinessTsaInstanceMappingDetails(long tsaID){
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFIBUS_TSAINST_MAPPING WHERE TSAINSTANCES_ID = "+tsaID+"", 
				new PFIBusinessTSAInstancesRowMapper());
	}

	/**
	 * Method used for fetching T_WEBCASHTSA_PFI_BUSINESS records by Business ID
	 * @param pfiBusinessID
	 */
	@Override
	public List<PFIBusiness> getPFIBusinessDetailsByBusinessID(long businessID){
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS WHERE PFI_BUSINESS_ID = "+businessID+" ", 
				new PFIBusinessRowMapper());
	}
	
	@Override
	public List<PFIBusiness> getPFIBusinessDetailsByBusinessName(
			String businessName) {
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS WHERE upper(PFI_BUSINESS_NAME) = '"+businessName+"' ", 
				new PFIBusinessRowMapper());
	}
	
	/**
	 * Method used for fetching records from T_WEBCASHTSA_SEGREGATOR_FILE on the basis of input file
	 */
	@Override
	public List<SegregatorFileBean> getSegregatorFileDetails(String srcFile){
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SEGREGATOR_FILE WHERE upper(segregator_file_name) = '"+srcFile+"' ", 
				new SegregatorFileRowMapper()); 
	}
	
	/**
	 * Method used for updating import file name into T_WEBCASHTSA_SEGREGATOR_FILE table
	 */
	@Override
	public boolean updateImportStatusFileNameInSegregator(String importFilename, Long segregatorID, Integer fileStatusID){
		
		Timestamp lastModifedTimestamp = new Timestamp(new java.util.Date().getTime());
		
		Object[] params = { importFilename, fileStatusID, lastModifedTimestamp, segregatorID};
		int[] types = {Types.VARCHAR, Type.INT, Types.TIMESTAMP, Types.BIGINT};

		int rows = jdbc.update(updateImportStatusFileNameInSegregatorQuery, params, types);
		if(rows > 0){
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public List<TSAInstance> getTSAInstanceDetailsByIdentifier(
			String tsaIdentifier) {
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES WHERE upper(TSAINSTANCE_IDENTIFIER) = '"+tsaIdentifier+"' ", 
				new TSAInstanceRowMapper()); 
	}
	
	@Override
	public void deleteLockedFileDetail(String fileName){
		jdbc.execute("DELETE FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES WHERE upper(LOCKED_FILE_NAME) = '" + fileName +"'" );
	}
	
	@Override
	public boolean checkLockTable(String inputFileName){
		String sqlCheckLockTable = "SELECT LOCKED_FILE_NAME FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES "
				+ "WHERE upper(LOCKED_FILE_NAME) = '"+inputFileName+"'";
		
		Boolean isLocked = jdbc.execute(sqlCheckLockTable, new PreparedStatementCallback<Boolean>(){
			public Boolean doInPreparedStatement(PreparedStatement ps)  
		            throws SQLException, DataAccessException {
				boolean result = false;
		        ResultSet rs = ps.executeQuery();
		        while(rs.next()) {
		        	 rs.getString("LOCKED_FILE_NAME");
		        	 result = true;
		        	 break;
		        }
		        rs.close();
		        
		        return result;  
		              
		    }  
		});  
		
		return isLocked;
	}
	
	@Override
	public int insertInputFileInfoForLock(LockedFileBean lockedFiles){
		
		Object[] lockTableParams = new Object[] {
				lockedFiles.getLockedFileName(), lockedFiles.getLockedFileProcessedTime(), 
				lockedFiles.getLockedFileSize(),  lockedFiles.getCreatedBy(), lockedFiles.getCreatedTimeStamp(), lockedFiles.getLastModifiedBy(), lockedFiles.getLastModifedTimestamp() };
		
		int[] paraTypes = new int[] {
                Types.VARCHAR, Types.TIMESTAMP,
                Types.DOUBLE, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP
        };
		
		return jdbc.update(insertLockTableQuery, lockTableParams, paraTypes);
		
	}

	@Override
	public List<FileStatusBean> getFileStatusDetailsByDescryption(
			String importstatusfileid) {
		return jdbc.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILESTATUS WHERE upper(FILESTATUS_SHORT_DESC) = '"+importstatusfileid+"' ", 
				new FileStatusRowMapper()); 
	}
	
	@Override
	public void batchUpdatePFITxnDetails(List<PfiTransactionsBean> txnDtlsList){
		
		List<Object[]> batchList = new ArrayList<Object[]>();
        for(PfiTransactionsBean txnBean:txnDtlsList){
        	Timestamp lastModifedTimestamp = new Timestamp(new java.util.Date().getTime());
    	    Object[] tmp = { txnBean.getExtractionStatus(), txnBean.getDebitBankRouteCode(), txnBean.getDebitAccountNumber(), 
    				txnBean.getCreditBankRouteCode(), txnBean.getCreditAccountNumber(), txnBean.getOperatorID(), 
    				txnBean.getOperatorName(), lastModifedTimestamp, txnBean.getSegregatorFileId(), txnBean.getRecordNumber() };
            batchList.add(tmp);
        }

		jdbc.batchUpdate(updatePFITxnDetailsQuery, batchList);
	}

	@Override
	public List<Map<String,Object>> getNasFileNamePattern() {
		return jdbc.queryForList(getNASFileNamePatternQuery.toString());
	}
}
