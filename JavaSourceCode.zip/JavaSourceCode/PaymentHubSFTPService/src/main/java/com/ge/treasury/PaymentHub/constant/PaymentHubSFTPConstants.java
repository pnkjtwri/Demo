package com.ge.treasury.PaymentHub.constant;


public class PaymentHubSFTPConstants {
	public static enum ERROR_TYPE{
		CANNOT_GET_CONNECTION,
		BAD_SQL_ERROR,
		GENRIC_ERROR,
		SEND_CMM_LOCATION_ERROR
	}
	
	
	public class MailContent{
		
		public static final String SUBJECT_GENERIC			  = "Generic error occoured";
		
		public static final String MAIL_HEADER_CONTENT = "Team,\n\n";
		public static final String MAIL_FOOTER_CONTENT_1 = "*Note - This is an auto generated mail.Please do not reply on this mail.\n\n";
		public static final String MAIL_FOOTER_CONTENT_2 = "Regards,\n";
		public static final String MAIL_FOOTER_CONTENT_3 = "WebcashTSA Support Team";
		
		public static final String CANNOT_GET_CONNECTION_MSG 					= "Not able to get database connection : ";
	}
	
	public class Constants{
		public static final String EXTRACT_TYPE = "EXTRACT_TYPE";
	}
	
	
}
