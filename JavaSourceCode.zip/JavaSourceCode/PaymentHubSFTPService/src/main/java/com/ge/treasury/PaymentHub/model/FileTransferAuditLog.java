/**
 * 
 */
package com.ge.treasury.PaymentHub.model;

/**
 * @author padmajaarekuti
 *
 */
public class FileTransferAuditLog extends CommonBean {
	
	private String fileName;
	private String fileType;
	private String srcLocation;
	private String destLocation;
	private String status;
	private String comments;
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the srcLocation
	 */
	public String getSrcLocation() {
		return srcLocation;
	}
	/**
	 * @param srcLocation the srcLocation to set
	 */
	public void setSrcLocation(String srcLocation) {
		this.srcLocation = srcLocation;
	}
	/**
	 * @return the destLocation
	 */
	public String getDestLocation() {
		return destLocation;
	}
	/**
	 * @param destLocation the destLocation to set
	 */
	public void setDestLocation(String destLocation) {
		this.destLocation = destLocation;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
