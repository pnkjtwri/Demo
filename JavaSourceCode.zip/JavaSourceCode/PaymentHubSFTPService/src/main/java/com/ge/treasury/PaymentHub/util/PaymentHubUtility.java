package com.ge.treasury.PaymentHub.util;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.ge.treasury.PaymentHub.model.PfiTransactionsBean;
import com.ge.treasury.PaymentHub.model.SegregatorFileBean;

public class PaymentHubUtility {
	
	/*
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
	public static final String importStatusfileDesc = "SplitFileTSAImportStatusReceived";
	public static final String pfiManulBusiness = "FFIXML";
	
	
	/**
	 * Method used for 
	 * @param srcFile
	 * @return
	 */
	public static boolean pickBaiFileWithNewTimestamp(File srcFile, String OlderTimestampBAIFileLocation) {
		boolean rtnFlg = true;
		File directory = new File(srcFile.getParent());
		for (final File pickedFiles :  directory.listFiles()) {
	        if (pickedFiles.isDirectory()) {
	            //do nothing
	        } else {
	        	if(srcFile.getName().equalsIgnoreCase(pickedFiles.getName())){
	        		//same file
	        	}else{
	        		String srcTimestamp = getTimeStampFromBAIFile(srcFile.getName());
		        	String srcFileNameWithoutTimestamp = getBAIFileNameWithoutTimestamp(srcFile.getName());
		            if(pickedFiles.getName().toUpperCase().startsWith(srcFileNameWithoutTimestamp.toUpperCase())){
		            	String pickedBaiFileTimestamp = getTimeStampFromBAIFile(pickedFiles.getName());
		            	
		            	long srcTimestampLong = Long.parseLong(srcTimestamp);
		            	long pickedBaiFileTimestampLong = Long.parseLong(pickedBaiFileTimestamp);
		            	
		            	if(srcTimestampLong-pickedBaiFileTimestampLong > 0){
		            		//source file is with Current Time-stamp
		            		//moving picked file
		            		File OldTimeStampFileLocation = new File(OlderTimestampBAIFileLocation+pickedFiles.getName());
		            		pickedFiles.renameTo(OldTimeStampFileLocation);
		            		rtnFlg = true;
		            	}else{
		            		//source file is not with Current Time-stamp
		            		//moving current file
		            		File OldTimeStampFileLocation = new File(OlderTimestampBAIFileLocation+srcFile.getName());
		            		srcFile.renameTo(OldTimeStampFileLocation);
		            		rtnFlg = false;
		            		break;
		            	}
		            }
	        	}
	        }
	    }
		return rtnFlg;		
	}
	

	private static String getBAIFileNameWithoutTimestamp(String decryptFile) {
		String fileNameWithoutPgp = decryptFile.substring(0, decryptFile.lastIndexOf("."));
		String fileNameWithTimeStamp = decryptFile.substring(0, fileNameWithoutPgp.lastIndexOf("."));
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		return fileNameWithTimeStamp.substring(0, underscoreIdx);
	}
	
	private static String getTimeStampFromBAIFile(String decryptFile) {
		String fileNameWithoutPgp = decryptFile.substring(0, decryptFile.lastIndexOf("."));
		String fileNameWithTimeStamp = decryptFile.substring(0, fileNameWithoutPgp.lastIndexOf("."));
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		return fileNameWithTimeStamp.substring(underscoreIdx+1, fileNameWithTimeStamp.length());
		
	}
	
	/**
	 * Method used for getting Business Name from source file
	 * @param srcFileName
	 * @return
	 */
	public static String getBusinessNamefromSourceFile(String srcFileName){
		int dotIdx = srcFileName.lastIndexOf(".");
		String fileExtn = srcFileName.substring(dotIdx, srcFileName.length());
		int underscoreIdx = fileExtn.lastIndexOf("_");
		
		return fileExtn.substring(underscoreIdx+1, fileExtn.length());
	}
	
	
	/**
	 * Method used for getting BAI file name without timestamp.
	 * @param decryptFile
	 * @return
	 */
	public static String trimBAIFileTimeStamp(String decryptFile) {
		int dotIdx = decryptFile.lastIndexOf(".");
		String fileNameWithTimeStamp = decryptFile.substring(0, dotIdx);
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		String fileNameWithoutTimeStamp = fileNameWithTimeStamp.substring(0, underscoreIdx);
		
		return fileNameWithoutTimeStamp+decryptFile.substring(dotIdx, decryptFile.length());
	}
	
	/**
	 * Method used for setting the default value as null into Transaction bean
	 * @param PfiTransactionsBean
	 * @return
	 */
	public static PfiTransactionsBean setDefaultTxnDetails(PfiTransactionsBean txnBean, SegregatorFileBean segregatorBean, 
			String operatorID, String operatorName){
		txnBean.setSrcPaymentFileId(segregatorBean.getSrcPaymentFileID());
		txnBean.setSegregatorFileId(segregatorBean.getSegregatorFileID());
		txnBean.setDebitBankRouteCode(null);
		txnBean.setDebitAccountNumber(null);
		txnBean.setCreditBankRouteCode(null);
		txnBean.setCreditAccountNumber(null);
		txnBean.setOperatorID(operatorID);
		txnBean.setOperatorName(operatorName);
		txnBean.setExtractionStatus("Success");
		return txnBean;
	}
}
