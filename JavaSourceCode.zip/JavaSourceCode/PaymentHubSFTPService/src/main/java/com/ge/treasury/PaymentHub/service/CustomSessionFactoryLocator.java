/**
 * 
 */
package com.ge.treasury.PaymentHub.service;

import java.util.Map;

import org.springframework.integration.file.remote.session.DefaultSessionFactoryLocator;
import org.springframework.integration.file.remote.session.SessionFactory;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

/**
 * @author padmajaarekuti
 *
 */
public class CustomSessionFactoryLocator extends DefaultSessionFactoryLocator<DefaultSftpSessionFactory> {

	public CustomSessionFactoryLocator(Map<Object, SessionFactory<DefaultSftpSessionFactory>> factories) {
		super(factories);
		// TODO Auto-generated constructor stub
	}

	 

	/*public CustomSessionFactoryLocator(Map<Object, SessionFactory<String>> factories) {
		super(factories);
		// TODO Auto-generated constructor stub
	}*/

}
