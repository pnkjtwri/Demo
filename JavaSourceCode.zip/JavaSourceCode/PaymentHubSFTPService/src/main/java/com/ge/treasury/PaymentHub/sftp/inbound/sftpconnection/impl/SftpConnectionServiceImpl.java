package com.ge.treasury.PaymentHub.sftp.inbound.sftpconnection.impl;

import org.apache.log4j.Logger;

import com.ge.treasury.PaymentHub.sftp.inbound.exception.SftpCompException;
import com.ge.treasury.PaymentHub.sftp.inbound.sftpconnection.SftpConnectionService;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SftpConnectionServiceImpl implements SftpConnectionService<Session> {

	private static final Logger logger = Logger
			.getLogger(SftpConnectionServiceImpl.class);

	private String sftpSourceHost;
	private String sftpSourceUserName;
	private int sftpPort;
	private String sftpSourcePassword;
	private String sftpKeyFilepath;
	private Session session = null;
	
	public SftpConnectionServiceImpl(String sftpSourceHost,
			String sftpSourceUserName, int sftpPort, String sftpSourcePassword, String sftpKeyFilepath) {
		super();
		this.sftpSourceHost = sftpSourceHost;
		this.sftpSourceUserName = sftpSourceUserName;
		this.sftpPort = sftpPort;
		this.sftpSourcePassword = sftpSourcePassword;
		this.sftpKeyFilepath = sftpKeyFilepath;
	}

	@Override
	public boolean connect() throws SftpCompException {
		JSch jsch = new JSch();
		try {
			jsch.addIdentity(sftpKeyFilepath);
		} catch (JSchException e) {
			//logger.info("failed in adding key identity "+e.getLocalizedMessage());
			logger.info("ffailed in adding key identity "+PaymentHubUtility.getErrorFormStackTrace(e));
			PaymentHubUtility.getErrorFormStackTrace(e);
		}
		boolean sessionCreated = false;
		try {
			session = jsch.getSession(sftpSourceUserName, sftpSourceHost, sftpPort);
			session.setConfig("StrictHostKeyChecking", "no");
			//session.setPassword(sftpSourcePassword);
			session.setConfig("PreferredAuthentications",
					"publickey,keyboard-interactive,password");
			session.connect();
			sessionCreated = true;
			logger.info("successfully connected to host " + sftpSourceHost);
		} catch (JSchException e) {
			sessionCreated = false;
			logger.info("failed in creating sftp session...."+PaymentHubUtility.getErrorFormStackTrace(e));
			//logger.info("failed in creating sftp session..."+e.getLocalizedMessage());
			//throw new SftpCompException(e);
		}
		return sessionCreated;
	}

	@Override
	public Session getClient() {
		return session;
	}

	@Override
	public void disconnect() throws SftpCompException {
		session.disconnect();
		logger.info("disconnected host " + sftpSourceHost + " !!");
	}
}
