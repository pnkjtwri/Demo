package com.ge.treasury.PaymentHub.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.model.SegregatorFileBean;

@SuppressWarnings("rawtypes")
public class SegregatorFileRowMapper implements RowMapper {

private Logger logger = Logger.getLogger(SegregatorFileRowMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		logger.info("[SegregatorFileRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into SegregatorFileBean..]");
		SegregatorFileBean segregatorFile = new SegregatorFileBean();
		segregatorFile.setSegregatorFileID(rs.getLong("SEGREGATOR_FILE_ID"));
		segregatorFile.setSrcPaymentFileID(rs.getLong("SRC_PAYMENT_FILE_ID"));
		segregatorFile.setSegregatorFileName(rs.getString("SEGREGATOR_FILE_NAME"));
		segregatorFile.setPaymentInstType(rs.getString("PAYMENT_INST_TYPE"));
		segregatorFile.setTsaInstanceID(rs.getInt("TSAINSTANCES_ID"));
		segregatorFile.setFileStatusID(rs.getInt("FILESTATUS_ID"));
		segregatorFile.setImportStatusFileName(rs.getString("IMPORT_STATUS_FILE_NAME"));
		segregatorFile.setNoOfTransaction(rs.getInt("NO_OF_TRANSACTIONS"));
		segregatorFile.setHashString(rs.getString("HASH_STRING"));
		segregatorFile.setCreatedBy(rs.getString("CREATED_BY"));
		segregatorFile.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		segregatorFile.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		segregatorFile.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[SegregatorFileRowMapper.class] [Inside mapRow()] [Going to return SegregatorFileBean..]");
		return segregatorFile;
	}
	
}
