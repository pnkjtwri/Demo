package com.ge.treasury.PaymentHub.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.model.SrcPaymentFile;

@SuppressWarnings("rawtypes")
public class SrcPaymentFileRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(SrcPaymentFileRowMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		logger.info("[SrcPaymentFileRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into SrcPaymentFileBean..]");
		SrcPaymentFile paymentFile = new SrcPaymentFile();
		paymentFile.setSrcPaymentFileId(rs.getLong("SRC_PAYMENT_FILE_ID"));
		paymentFile.setSrcPaymentFileName(rs.getString("SRC_PAYMENT_FILE_NAME"));
		paymentFile.setFileType(rs.getString("FILE_TYPE"));
		paymentFile.setFileCreationModule(rs.getString("FILE_CREATION_MODULE"));
		paymentFile.setFileFormatVersion(rs.getString("FILE_FORMAT_VERSION"));
		paymentFile.setTrailerTotalRecords(rs.getInt("TRAILER_TOTAL_RECORDS"));
		paymentFile.setTrailerFileName(rs.getString("TRAILER_FILE_NAME"));
		paymentFile.setSegregationFlag(rs.getString("SEGREGATION_FLAG"));
		paymentFile.setFileStatusId(rs.getInt("FILESTATUS_ID"));
		paymentFile.setSegregationStatusMessage(rs.getString("SEGREGATION_STATUS_MSG"));
		paymentFile.setPfiBusinessId(rs.getInt("PFI_BUSINESS_ID"));
		paymentFile.setSrcFileCreationTimeStamp(rs.getDate("SRC_FILE_CREATION_TIMESTAMP"));
		paymentFile.setCreatedBy(rs.getString("CREATED_BY"));
		paymentFile.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		paymentFile.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		paymentFile.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[SrcPaymentFileRowMapper.class] [Inside mapRow()] [Going to return SrcPaymentFileBean..]");
		return paymentFile;
	}

}
