package com.ge.treasury.PaymentHub.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.model.PFIBusinessTSAInstanceMapping;

@SuppressWarnings("rawtypes")
public class PFIBusinessTSAInstancesRowMapper implements RowMapper {

private Logger logger = Logger.getLogger(PFIBusinessTSAInstancesRowMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		logger.info("[PFIBusinessTSAInstancesRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into PFIBusinessTSAInstanceMapping..]");
		PFIBusinessTSAInstanceMapping businessTSAInstanceMapper = new PFIBusinessTSAInstanceMapping();
		businessTSAInstanceMapper.setPfiBusTSAInstMappingID(rs.getLong("PFIBUS_TSAINST_MAPPING_ID"));
		businessTSAInstanceMapper.setPfiBusinessID(rs.getLong("PFI_BUSINESS_ID"));
		businessTSAInstanceMapper.setTsaInstancesID(rs.getLong("TSAINSTANCES_ID"));
		businessTSAInstanceMapper.setDeleteFlag(rs.getString("DELETE_FLAG"));
		businessTSAInstanceMapper.setPgpOptionID(rs.getString("PGP_OPTION_ID"));
		businessTSAInstanceMapper.setCreatedBy(rs.getString("CREATED_BY"));
		businessTSAInstanceMapper.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		businessTSAInstanceMapper.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		businessTSAInstanceMapper.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[PFIBusinessTSAInstancesRowMapper.class] [Inside mapRow()] [Going to return PFIBusinessTSAInstanceMapping..]");
		return businessTSAInstanceMapper;
	}
	
}
