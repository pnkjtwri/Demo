/*
 * Copyright 2002-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ge.treasury.PaymentHub.sftp;

import java.io.File;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;

/**
 * @author Gary Russell
 * @author Amol Nayak
 *
 */
public class SftpOutboundChannelAdapterSample {

/*
	 public static void main(String args[]){
		 try {
			 System.out.println("Started runDemo");
			 runDemo();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	public static void runDemo() throws Exception{
		DynamicFtpChannelResolver dynamicFtpChannelResolver = new DynamicFtpChannelResolver();
		MessageChannel channel1 = dynamicFtpChannelResolver.resolve("customer1");
		
		ConfigurableApplicationContext ctx =
			new ClassPathXmlApplicationContext("spring/integration/DynamicFtpOutboundChannelAdapterSample-context.xml");
		MessageChannel channel = ctx.getBean("toDynRouter", MessageChannel.class);
		File file = new File("/home/ebtpsSODDev_app/TestSftp.txt");
		Message<File> message = MessageBuilder.withPayload(file)
				.setHeader("paymentSystem", "customer1")
						.build();
		try {
			channel.send(message);
		}
		catch (MessagingException e) {
			System.out.println(e);
			 
		}
		System.out.println("Complete SFTP for customer 1");
		 
		// send to a different customer; again, check the log to see a new ac is built
		 file = new File("/home/ebtpsSODDev_app/TestSftp2.txt");
				message = MessageBuilder.withPayload(file)
						.setHeader("customer", "customer2").build();
				try {
					channel.send(message);
				}
				catch (MessagingException e) {
					System.out.println(e);
				}
				
				System.out.println("Complete SFTP for customer 2");
		ctx.close();
	}*/
}
