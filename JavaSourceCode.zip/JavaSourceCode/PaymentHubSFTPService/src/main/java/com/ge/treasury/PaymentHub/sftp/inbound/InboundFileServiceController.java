package com.ge.treasury.PaymentHub.sftp.inbound;

/**
 * @author pankaj1.tiwari
 *
 */

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.treasury.PaymentHub.dao.impl.PaymentHubJDBCTempleteDAOImpl;
import com.ge.treasury.PaymentHub.model.PFIBusiness;
import com.ge.treasury.PaymentHub.model.PFIBusinessTSAInstanceMapping;
import com.ge.treasury.PaymentHub.model.TSAInstance;
import com.ge.treasury.PaymentHub.service.FileLockingService;
import com.ge.treasury.PaymentHub.sftp.inbound.filesystemservice.FileSystemService;
import com.ge.treasury.PaymentHub.sftp.inbound.filesystemservice.impl.FileSystemServiceImpl;
import com.ge.treasury.PaymentHub.sftp.inbound.sftpconnection.impl.SftpConnectionServiceImpl;
import com.ge.treasury.PaymentHub.sftp.mapper.FileTransferAuditLogMapper;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;

@RestController
public class InboundFileServiceController {

  private static final Logger logger = Logger.getLogger(InboundFileServiceController.class);
  
  @Value("${sftpPort}")
  private String sftpPort;
  @Value("${encryptedFilePath}")
  private String encryptedFilePath;
  @Value("${manualLocation}")
  private String manualFilePath;
  @Value("${manualFileType}")
  private String manualFileType;
  @Value("${accountModelFeedPath}")
  private String accountModelFeedPath;
  @Value("${accountFeedFileType}")
  private String accountFeedFileType;
  @Value("${modelFeedFileType}")
  private String modelFeedFileType;
  
  @Autowired PaymentHubJDBCTempleteDAOImpl paymentHubDAO;
  @Autowired private FileTransferAuditLogMapper logMapper;
  @Autowired FileLockingService fileLockingService;
  
  @Scheduled(cron="${sftpPollingTime}")
  public void startInboundSFTPChannel(){
	  logger.info("Cron job started for SFTP Inbound services....");
      downloadSftpFilesController();
  }
  
  @RequestMapping(value = "/downloadSftpFiles", method=RequestMethod.POST)
  public ResponseEntity<String> downloadSftpFilesController(){
		logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()]");
		
		try{
			
			//Get values from database...
			List<TSAInstance> tsaInstanceBeanList = paymentHubDAO.getTSAInstanceDetails();
			for (TSAInstance tsaInstanceBean : tsaInstanceBeanList) {
				
			
				logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Going to get Business and TSAInstances mapping details...]");
				List<PFIBusinessTSAInstanceMapping> businessTSAInstacesMappingList = paymentHubDAO.getBusinessTsaInstanceMappingDetails
						(tsaInstanceBean.getTsaInstanceId());
				if(businessTSAInstacesMappingList != null && businessTSAInstacesMappingList.size() > 0){
					logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Got the Business and TSAInstances mapping details...]");
					for (Iterator<PFIBusinessTSAInstanceMapping> iterator = businessTSAInstacesMappingList
							.iterator(); iterator.hasNext();) {
						PFIBusinessTSAInstanceMapping pfiBusinessTSAInstanceMapping = (PFIBusinessTSAInstanceMapping) iterator
								.next();
						logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Going to get Business details...]");
						List<PFIBusiness> pfiBusinessList = paymentHubDAO.getPFIBusinessDetailsByBusinessID(pfiBusinessTSAInstanceMapping.getPfiBusinessID());
						if(pfiBusinessList != null && pfiBusinessList.size() > 0){
							logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Got the Business details...]");
							PFIBusiness pfiBusiness = pfiBusinessList.get(0);
							
							logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Going to create session for ] ["+tsaInstanceBean.getHostName()+"] [host]");
							int sftpPortInt = Integer.parseInt(sftpPort);
							
							logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [SFTP connection details... ] ");
							logger.info("Host: ["+tsaInstanceBean.getHostName()+"] == User: ["+tsaInstanceBean.getUserId()+"] == Port: ["+sftpPortInt+"] == KeyPath: ["+tsaInstanceBean.getPfiRespFilePrivateKeyPath()+"] ");
							
							SftpConnectionServiceImpl sftpConnectionService = new SftpConnectionServiceImpl(tsaInstanceBean.getHostName(), tsaInstanceBean.getUserId(), 
					    			sftpPortInt, "NA",tsaInstanceBean.getPfiRespFilePrivateKeyPath());
					    	//connect with session...
					    	boolean istrue = sftpConnectionService.connect();
					    	if(istrue){
					    		FileSystemService fileService = new FileSystemServiceImpl(sftpConnectionService, null, 
					    			 encryptedFilePath, manualFilePath, manualFileType, 
					    			 accountModelFeedPath, accountFeedFileType, modelFeedFileType);
					    		
						    	//going to read & download files from SFTP location
					    		fileService.downloadRemoteFile(pfiBusiness.getPfiRespInputLocation(), 
					    				tsaInstanceBean.getTsaInstanceIdentifier(), logMapper, paymentHubDAO, fileLockingService);
								//disconnect with session
								sftpConnectionService.disconnect();
					    	}else{
					    		logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [can't create SFTP session for ] ["+tsaInstanceBean.getHostName()+"] [host]");
					    	}
						}else{
							logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Didn't get PFI Business details for "+pfiBusinessTSAInstanceMapping.getPfiBusinessID()+" business ID.]");
						}
					}
				}else{
					logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Didn't get Business and TSA Instaces Mapping details for "+tsaInstanceBean.getTsaInstanceId()+" tsa instances ID.]");
				}
			}
			logger.info("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Exist from downloadSftpFilesController()]");
			return new ResponseEntity<String>(HttpStatus.OK);
		}catch(Exception ex){
			logger.error("[InboundFileServiceController.class] [Inside downloadSftpFilesController()] [Got Generic Exception.....]");
			//logger.error(ex.toString());
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			return new ResponseEntity<String>(HttpStatus.EXPECTATION_FAILED);
		}
	}


}
