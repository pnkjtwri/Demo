package com.ge.treasury.PaymentHub.sftp.decryption.exception;

public class FileEncryptionDecryptionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7490491357496851181L;
	
	private String message;
	private Exception ex;
	
	public FileEncryptionDecryptionException(String msg){
		super(msg);
		this.message = msg;
	}
	
	public FileEncryptionDecryptionException(String msg, Exception ex){
		super(msg,ex);
		if(this.message == null && this.ex == null){
			this.message = msg;
			this.ex      = ex;
			if(this.ex.getCause() != null){
				
			}else{
				this.ex.initCause(new Throwable(msg));
			}
		}
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	
	/**
	 * @return the ex
	 */
	public Exception getEx() {
		return ex;
	}
	
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @param ex the ex to set
	 */
	public void setEx(Exception ex) {
		this.ex = ex;
	}

}
