package com.ge.treasury.PaymentHub.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.PaymentHub.model.PFIBusiness;

@SuppressWarnings("rawtypes")
public class PFIBusinessRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(PFIBusinessRowMapper.class);
	
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		logger.info("[PFIBusinessRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into PFIBusinessBean..]");
		PFIBusiness pfiBusiness = new PFIBusiness();
		pfiBusiness.setPfiBusinessID(rs.getLong("PFI_BUSINESS_ID"));
		pfiBusiness.setPfiBusinessName(rs.getString("PFI_BUSINESS_NAME"));
		pfiBusiness.setMergeImportStatusFlg(rs.getString("MERGE_IMPORT_STATUS_FLAG"));
		pfiBusiness.setSplitReqFlg(rs.getString("SPLIT_REQ_FLAG"));
		pfiBusiness.setPfiLocation(rs.getString("PFI_LOCATION"));
		pfiBusiness.setPfiRespFilesLocation(rs.getString("PFI_RESP_FILES_LOCATION"));
		pfiBusiness.setPgpOptionID(rs.getString("PGP_OPTION_ID"));
		pfiBusiness.setPgpOperatorID(rs.getString("PGP_OPERATOR_ID"));
		pfiBusiness.setDeleteFlag(rs.getString("DELETE_FLAG"));
		pfiBusiness.setCreatedBy(rs.getString("CREATED_BY"));
		pfiBusiness.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		pfiBusiness.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		pfiBusiness.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		pfiBusiness.setPfiRespInputLocation(rs.getString("PFI_RESP_INPUT_LOCATION"));
		pfiBusiness.setPfiManualLocation(rs.getString("PFI_MANUAL_LOCATION"));
		logger.info("[PFIBusinessRowMapper.class] [Inside mapRow()] [Going to return PFIBusiness..]");
		return pfiBusiness;
	}

}
