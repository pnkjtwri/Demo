package com.ge.treasury.PaymentHub.sftp.inbound.filesystemservice.impl;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ge.treasury.PaymentHub.dao.PaymentHubJDBCTempleteDAO;
import com.ge.treasury.PaymentHub.model.FileTransferAuditLog;
import com.ge.treasury.PaymentHub.service.FileLockingService;
import com.ge.treasury.PaymentHub.sftp.inbound.exception.SftpCompException;
import com.ge.treasury.PaymentHub.sftp.inbound.filesystemservice.FileSystemService;
import com.ge.treasury.PaymentHub.sftp.inbound.sftpconnection.SftpConnectionService;
import com.ge.treasury.PaymentHub.sftp.mapper.FileTransferAuditLogMapper;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class FileSystemServiceImpl implements FileSystemService {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6100892902139169366L;
	private static final Logger logger = Logger.getLogger(FileSystemServiceImpl.class);
	
	private String businessHome;// = "pgp-gewc-sssinit";
	private SftpConnectionService<Session> sftpTransferServiceImplTarget;
	private SftpConnectionService<Session> sftpTransferServiceImplSource;
	private String encryptedFilePath;
	private String manualFilePath;
	private String manualFileType;
	private String accountModelFeedPath;
	private String accountFeedFileType;
	private String modelFeedFileType;

	public FileSystemServiceImpl(
			SftpConnectionService<Session> sftpTransferServiceImplSource,
			SftpConnectionService<Session> sftpTransferServiceImplTarget,
			String encryptedFilePath, String manualFilePath, String manualFileType, 
			String accountModelFeedPath, String accountFeedFileType, String modelFeedFileType) {
		this.sftpTransferServiceImplSource = sftpTransferServiceImplSource;
		this.sftpTransferServiceImplTarget = sftpTransferServiceImplTarget;
		this.encryptedFilePath = encryptedFilePath;
		this.manualFilePath = manualFilePath;
		this.manualFileType = manualFileType;
		this.accountModelFeedPath = accountModelFeedPath;
		this.accountFeedFileType = accountFeedFileType;
		this.modelFeedFileType = modelFeedFileType;
	}

	/**
	 * Method used for coping data into a File
	 */
	@Override
	public void copyFile(InputStream inputStream, String targetPath)
			throws SftpCompException {
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		try {
			channel = sftpTransferServiceImplTarget.getClient().openChannel(
					"sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			// sftpChannel.cd("targetFileHome");
			// createFolderIfNotExist(targetPath, sftpChannel);
			sftpChannel.put(inputStream, targetPath, ChannelSftp.OVERWRITE);
			logger.debug("file copied  :" + targetPath);
		} catch (Exception exception) {
			throw new SftpCompException(exception);
		} finally {
			cleanup(channel, sftpChannel);
		}
	}

	/**
	 * Method used for closing the open channel
	 * @param channel
	 * @param sftpChannel
	 */
	private void cleanup(Channel channel, ChannelSftp sftpChannel) {
		channel.disconnect();
		sftpChannel.exit();
	}

	/**
	 * Method used for deleting the remote files
	 */
	@Override
	public void deleteFile(String path) throws SftpCompException {
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		try {
			channel = sftpTransferServiceImplSource.getClient().openChannel(
					"sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.rm(path);
		} catch (Exception exception) {
			throw new SftpCompException(exception);
		} finally {
			cleanup(channel, sftpChannel);
		}
		logger.debug("file deleted :" + path);
	}

	/**
	 * Method used for copying the file from remote location to local directory
	 */
	@Override
	public void readFile(String filePath, String fileDestination)
			throws SftpCompException {
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		try {
			channel = sftpTransferServiceImplSource.getClient().openChannel(
					"sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.get(filePath, fileDestination);
		} catch (Exception exception) {
			throw new SftpCompException(exception);
		} finally {
			cleanup(channel, sftpChannel);
		}
		logger.debug("file downloaded :" + filePath);
	}
	
	/**
	 * Method used for getting files list from remote location
	 * @return List<String>
	 */
	@SuppressWarnings("unchecked")
	@Override
	  public List<String> getFileList(String remotePath) throws SftpCompException {
	    List<String> list = new ArrayList<String>();
	    Channel channel = null;
	    ChannelSftp sftpChannel = null;
	    try {
	      channel = sftpTransferServiceImplSource.getClient().openChannel("sftp");
	      channel.connect();
	      sftpChannel = (ChannelSftp) channel;
	      sftpChannel.cd(remotePath);
	      Vector<LsEntry> entries = sftpChannel.ls(remotePath);
	      for (LsEntry entry : entries) {
	    	  if(entry.getAttrs().isDir()){
	    		  if(!entry.getFilename().startsWith("."))
	    			  list = readDirectory(entry.getFilename(), remotePath, list);
	    	  }else{
	    		  list.add(remotePath+entry.getFilename().trim()); 
	    	  }
	      }
	    } catch (Exception exception) {
	      throw new SftpCompException(exception);
	    } finally {
	      cleanup(channel, sftpChannel);
	    }
	    return list;
	  }
	
	/**
	 * Method used for reading and downloading remote files by SFTP connection
	 * @param remotePath (where, we have to look for files)
	 * @param fileDestination (where, we have to download files)
	 * @param tsaInstanceID
	 * @param logMapper
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void downloadRemoteFile(String remotePath, String tsaIdentifier, 
			FileTransferAuditLogMapper logMapper, PaymentHubJDBCTempleteDAO dao, FileLockingService fileLockingService)  throws SftpCompException{
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		FileTransferAuditLog auditLog=null;
		String remoteFile = null;
		String destinationPath = null;
		String finalnasname = "";
		try{
			channel = sftpTransferServiceImplSource.getClient().openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			logger.info("Going to get file from remote path - "+remotePath);
			sftpChannel.cd(remotePath);
			logger.info("Directory chnaged..");
			Vector<LsEntry> entries = sftpChannel.ls(remotePath);
			for (LsEntry entry : entries) {
		 		if(entry.getAttrs().isDir()){
		 			/*if(!entry.getFilename().startsWith(".")){
		 				logger.info("Inside if... going to re-iterate ownself");
		 				logger.info("Found Directory... Going to connect with this directory named :"+remotePath+entry.getFilename().trim());
		 				downloadRemoteFile(remotePath+entry.getFilename(), tsaIdentifier, logMapper);
    		  		}*/
		 		//}else if(!entry.getFilename().startsWith(".") && entry.getFilename() != null && entry.getFilename().length() > 0 && 0 == dao.checkIsFileExists(entry.getFilename()))  {
		 		}else if(!entry.getFilename().startsWith(".") && entry.getFilename() != null && entry.getFilename().length() > 0 )  {
		 			logger.info("Inside else-if... going to download file named :"+entry.getFilename());
		 			remoteFile = entry.getFilename().trim();
		 			if(remoteFile.length() > 0){
		 				logger.info("Making remote file path as File object...for file locking....");
			 			File f = new File(remoteFile);
			 			logger.info("Going to check file lock....");
			 			String lockedfilename = f.getName().toUpperCase()+"_SFTP";
			 			double size = (double)f.length();
			 			//going to get lock on file....
			 			logger.info("Going to get lock into file...");
			 			if(fileLockingService.doFileLockChecksftp(lockedfilename,size)){
			 			
			 				//checking for Account/Model Feed files...
				 			logger.info("Going to check file type.....");
				 			String fileNamewithInstanceIdentifier = null;
				 			if(remoteFile.toUpperCase().contains(accountFeedFileType.toUpperCase()) || 
				 					remoteFile.toUpperCase().contains(modelFeedFileType.toUpperCase())){
				 				logger.info("Got Account/Model Feed files....");
				 				destinationPath = accountModelFeedPath;
				 				
				 				fileNamewithInstanceIdentifier = remoteFile;
				 				
				 				logger.info("Going to check Account/Model Feed file has TSA identifier or not....");
				 				if(!remoteFile.toUpperCase().startsWith(tsaIdentifier.toUpperCase())){
				 					logger.info("Account/Model Feed file does not npt have TSA identifier....");
				 					logger.info("Going to add TSA identifier into Account/Model Feed file....");
				 					fileNamewithInstanceIdentifier = tsaIdentifier+"_"+remoteFile;
				 					logger.info("TSA identifier added into Account/Model Feed file....");
				 				}
				 				
				 			}else{
				 				//Going for other files type except Account/Model Feed files...
				 				logger.info("Got Other file type except Account/Model Feed filesss....");
				 				
					 			if(remoteFile.toUpperCase().startsWith(manualFileType.toUpperCase())){
					 				//destinationPath = manualFilePath;
					 				destinationPath = encryptedFilePath;
					 				fileNamewithInstanceIdentifier = remoteFile;
					 			}else{
					 				destinationPath = encryptedFilePath;
					 				
					 				String[] splitFileName = remoteFile.split("__", 2);
						 			logger.info("Split File name by __ is : "+splitFileName);
						 			if (splitFileName.length == 2){
						 				businessHome = splitFileName[0].toLowerCase();
						 				logger.info("Business Name into Remote Path is :"+String.valueOf(businessHome));
						 			}
						 			fileNamewithInstanceIdentifier = addTSAInstaceAndBusinessNameIntoRemoteFile((splitFileName.length == 2 ? splitFileName[1] : remoteFile), tsaIdentifier, businessHome);
					 			}
				 			}
				 			
				 			logger.info("Going to prepare destination path with file name....");
				 			String prepareDestination = destinationPath;
				 			prepareDestination = prepareDestination+fileNamewithInstanceIdentifier;
				 			
				 			//adding pgp extension...
				 			if(!remoteFile.contains(".pgp"))prepareDestination = prepareDestination+".pgp";
				 			
				 			//adding .writing extension...
				 			prepareDestination = prepareDestination+".writing";
				 			
				 			logger.info("Destination path value for downloadRemoteFile is::"+prepareDestination);
				 			logger.info("Remote path value for downloadRemoteFile is::"+remotePath+entry.getFilename().trim());
				 			//going to download file
				 			sftpChannel.get(remotePath+entry.getFilename().trim(), prepareDestination);
	                        
				 			//going to rename file by removing .writing			 		
				 			finalnasname = (remoteFile.contains(".pgp"))?fileNamewithInstanceIdentifier:fileNamewithInstanceIdentifier+".pgp";
				 			Path source = Paths.get(prepareDestination);
				 			Files.move(source, source.resolveSibling(finalnasname));
				 			
				 			logger.info("encrypted file renamed by removing .writing from path  "+prepareDestination+"  to new name::"+finalnasname);
				 			auditLog=populateSplitTransferAuditLog(remotePath, destinationPath, remoteFile, "S");
				 			logMapper.insertAuditLog(auditLog);
				 			//going to delete file after downloading
				 			logger.info("Going to delete remote file...");
				 			deleteFile(remotePath+remoteFile);
				 			logger.info("remote file deleted...");
				 			
				 			//going to release lock from file...
				 			logger.info("Going to delete SFTP locked file...");
				 			dao.deleteLockedFileDetail(lockedfilename);
				 			logger.info("SFTP locked file deleted...");
				 			
			 			}
		 			}
		 		}
		 	}
		 }catch (Exception e) {
			 logger.error("Error while downloading - "+PaymentHubUtility.getErrorFormStackTrace(e));
			 auditLog=populateSplitTransferAuditLog(remotePath, destinationPath, remoteFile, "F");
			 if(e.getMessage() != null && e.getMessage().length() > 240){
				 auditLog.setComments(e.getMessage().substring(0, 240));
			 }else{
				 auditLog.setComments(e.getMessage().substring(0, e.getMessage().length()));
			 }try{
				 logMapper.insertAuditLog(auditLog);
			 }catch(Exception ex){
				 logger.error("Error recieved while inserting in audit log in case of error");
				 logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			 }
		      throw new SftpCompException(e);
		    } finally {
		      cleanup(channel, sftpChannel);
		    }
	}
	
	/**
	 * Method used for recursive call to getFileList() method for get files
	 * @param dir, remotePath, list
	 * @return
	 * @throws SftpCompException
	 */
	private List<String> readDirectory(String dir, String remotePath, List<String> list) throws SftpCompException{
		remotePath = remotePath+ "/" +dir;
		list.addAll(getFileList(remotePath));
		return list;
	}
	
	/**
	 * Method used for adding TSSA instance identifier into file
	 * @param remoteFile, tsaInstance
	 * @return fileNamewithInstanceIdentifier
	 */
	private String addTSAInstaceAndBusinessNameIntoRemoteFile(String remoteFile, String tsaIdentifier, String businessName){
		if(remoteFile.contains(".pgp")){
			int dotIndex = remoteFile.lastIndexOf(".");
			String fileNameWithoutExtn = remoteFile.substring(0, dotIndex);
			String pgpFileExtn = remoteFile.substring(dotIndex, remoteFile.length());
			return fileNameWithoutExtn+"_"+tsaIdentifier+"_"+businessName+pgpFileExtn;
		}else{
			return remoteFile+"_"+tsaIdentifier+"_"+businessName;
		}
	}

	/**
	 * Method used for checking that any file exist at remote side or not
	 * @return boolean
	 */
	@Override
	public boolean isFileExist(String filePath) throws SftpCompException {
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		try {
			channel = sftpTransferServiceImplSource.getClient().openChannel(
					"sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.lstat(filePath);
			return true;
		} catch (SftpException exception) {

		} catch (JSchException exception) {
			throw new SftpCompException(exception);
		} finally {
			cleanup(channel, sftpChannel);
		}
		return false;
	}

	/**
	 * Method used for creating file at remote location
	 */
	@Override
	public void createFile(String filePath) throws SftpCompException {
		Channel channel = null;
		ChannelSftp sftpChannel = null;
		try {
			channel = sftpTransferServiceImplTarget.getClient().openChannel(
					"sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			OutputStream outputStream = sftpChannel.put(filePath,
					ChannelSftp.OVERWRITE);
			outputStream.close();
		} catch (Exception exception) {
			throw new SftpCompException(exception);
		} finally {
			cleanup(channel, sftpChannel);
		}
		logger.debug("file created :" + filePath);
	}
	
	
	private FileTransferAuditLog populateSplitTransferAuditLog(String remoteLocation, String detinationLocation,
			String remotefile, String transferStatus) {
		FileTransferAuditLog auditLog=new FileTransferAuditLog();
		auditLog.setFileName(remotefile);
		auditLog.setFileType("PAYMENT_FILE");
		auditLog.setSrcLocation(remoteLocation);
		auditLog.setDestLocation(detinationLocation);
		auditLog.setStatus(transferStatus);
		auditLog.setCreatedBy("999999999");
		auditLog.setLastModifiedBy("999999999");
		auditLog.setComments("File Downloaded Successfully");
		return auditLog;
	}

	/*public static class MyProgressMonitor implements SftpProgressMonitor {
		ProgressMonitor monitor;
		long count = 0;
		long max = 0;

		@Override
		public void init(int op, String src, String dest, long max) {
			this.max = max;
			monitor = new ProgressMonitor(null,
					((op == SftpProgressMonitor.PUT) ? "put" : "get") + ": "
							+ src, "", 0, (int) max);
			count = 0;
			percent = -1;
			monitor.setProgress((int) this.count);
			monitor.setMillisToDecideToPopup(1000);
		}

		private long percent = -1;

		@Override
		public boolean count(long count) {
			this.count += count;

			if (percent >= this.count * 100 / max) {
				return true;
			}
			percent = this.count * 100 / max;

			monitor.setNote("Completed " + this.count + "(" + percent
					+ "%) out of " + max + ".");
			monitor.setProgress((int) this.count);

			return !(monitor.isCanceled());
		}

		@Override
		public void end() {
			monitor.close();
		}
	}*/

}
