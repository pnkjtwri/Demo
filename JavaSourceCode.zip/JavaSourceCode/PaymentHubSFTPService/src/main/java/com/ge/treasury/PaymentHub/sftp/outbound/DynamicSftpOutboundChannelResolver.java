/*
 * Copyright 2002-2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ge.treasury.PaymentHub.sftp.outbound;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.ge.treasury.PaymentHub.model.TSAInstance;
import com.ge.treasury.PaymentHub.service.EnvironmentLookupService;

/**
 * Demonstrates how a dynamic Spring Integration flow snippet can be used
 * to send files to dynamic destinations.
 *
 * @author 
 *
 */  
@Component
public class DynamicSftpOutboundChannelResolver {
	private static final Logger logger = Logger.getLogger(DynamicSftpOutboundChannelResolver.class);
	@Autowired
	private Environment propEnv;
	 
	private static EnvironmentLookupService envService;
	
	public static void  setEnvService(EnvironmentLookupService service){
		envService=service;
	}

	//In production environment this value will be significantly higher
	//This is just to demonstrate the concept of limiting the max number of
	//Dynamically created application contexts we'll hold in memory when we execute
	//the code from a junit
	public static final int MAX_CACHE_SIZE = 2;

	private  final LinkedHashMap<String, MessageChannel> channels =
				new LinkedHashMap<String, MessageChannel>() {
					
					private static final long serialVersionUID = 1L;

					@Override
					protected boolean removeEldestEntry(
							Entry<String, MessageChannel> eldest) {
						//This returning true means the least recently used
						//channel and its application context will be closed and removed
						boolean remove = size() > MAX_CACHE_SIZE;
						if(remove) {
							MessageChannel channel = eldest.getValue();
							ConfigurableApplicationContext ctx = contexts.get(channel);
							if(ctx != null) { //shouldn't be null ideally
								ctx.close();
								contexts.remove(channel);
							}
						}
						return remove;
					}
					
				};

	private final Map<MessageChannel, ConfigurableApplicationContext> contexts =
				new HashMap<MessageChannel, ConfigurableApplicationContext>();
	
 	/**
	 * Resolve a customer to a channel, where each customer gets a private
	 * application context and the channel is the inbound channel to that
	 * application context.
	 *
	 * @param customer
	 * @return a channel
	 */
	public MessageChannel resolve(String paymentSystem) {
		MessageChannel channel = this.channels.get(paymentSystem);
		if (channel == null) {
			channel = createNewPaymentChannel(paymentSystem);
		}
		return channel;
	}

	private synchronized MessageChannel createNewPaymentChannel(String paymentSystem) {
		logger.info("createNewPaymentChannel: Entry in createNewPaymentChannel of DynamicSftpOutboundChannelResolver");
		MessageChannel channel = this.channels.get(paymentSystem);
		logger.debug("Payment system in createNewPaymentChannel is::"+paymentSystem);
		logger.debug("channel createted"+(channel == null ? "false" : "true"));
		if (channel == null) {
			ConfigurableApplicationContext ctx = new ClassPathXmlApplicationContext(
					new String[] { "/spring/integration/dynamic-sftp-outbound-adapter-context.xml" },
					false);
			 
			this.setEnvironmentForPaymentSystem(ctx, paymentSystem);
			ctx.refresh();
			channel = ctx.getBean("outboundPaymentChannel", MessageChannel.class);
			this.channels.put(paymentSystem, channel);
			//Will works as the same reference is presented always
			this.contexts.put(channel, ctx);
		}
		logger.info("createNewPaymentChannel: Exit");
		return channel;
	}

	/**
	 * Use Spring 3.1. environment support to set properties for the
	 * customer-specific application context.
	 *
	 * @param ctx
	 * @param customer
	 */
	private void setEnvironmentForPaymentSystem(ConfigurableApplicationContext ctx,
			String paymentSystem) {
		StandardEnvironment env = new StandardEnvironment();
		//System.out.println("Customer host:"+propEnv.getProperty("customer1.host"));
		//EnvironmentLookupService envService=(EnvironmentLookupService) SpringUtils.ctx.getBean("envLookupService");
		
		logger.info("Payment System recieved - "+paymentSystem);
		String tsaInstanceID = "";
		String optionId      = "";
		String sftpPort		 = "";
		Integer operatorId   = null;
		
		if(paymentSystem.contains("_")){
			String[] sftpDetails = paymentSystem.split("_");
			logger.info("sftpdetails length - "+sftpDetails.length);
			if(sftpDetails.length > 0){
				tsaInstanceID = sftpDetails[0];
				optionId      = sftpDetails[1];
				if(sftpDetails.length > 0){
					tsaInstanceID = sftpDetails[0];
					optionId      = sftpDetails[1];
					if(sftpDetails.length>3)
					{
						try{
							String userId  = (sftpDetails[2]);
							operatorId     = Integer.parseInt(userId);
						}catch(Exception e){
							logger.info("User id not found.Error is::"+e.getLocalizedMessage());
						}
						sftpPort = sftpDetails[3];
					}
					else
					{
						sftpPort = sftpDetails[2];
					}
				logger.info("operatorId - "+operatorId);
				logger.info("TSA Id - "+tsaInstanceID);
				logger.info("Option Id - "+optionId);
				logger.info("sftpPort - "+sftpPort);
				}
			}
		}
		
		TSAInstance tsaProps=envService.retriveConfigValue(tsaInstanceID+optionId);
		
		Properties props = new Properties();
		
		if(tsaProps != null){
			// populate properties for payment system
			logger.info("Properties details are.....");
			logger.info("Host: ["+tsaProps.getHostName()+"] ++ sftpuser: ["+tsaProps.getUserId()+"] ++ port: ["+sftpPort+"]");
			props.setProperty("host", tsaProps.getHostName());
			props.setProperty("sftpuser", tsaProps.getUserId());
			//props.setProperty("port", "22");
			props.setProperty("port", sftpPort);
	 		//props.setProperty("password", tsaProps.getPassword());
			props.setProperty("keyFilePath", tsaProps.getPfiRespFilePrivateKeyPath());
			if(operatorId != null && String.valueOf(operatorId).length() == 9){
				logger.info("Transfer to location manual - "+tsaProps.getManualLocation()+" For - "+paymentSystem);
				props.setProperty("remote.directory", tsaProps.getManualLocation());
			}else{
				logger.info("Transfer to location - "+tsaProps.getPfiLocation()+" For - "+paymentSystem);
				props.setProperty("remote.directory", tsaProps.getPfiLocation());
			}
		}else{
			// populate properties for payment system NOT FOUND
			props.setProperty("host", "NA");
			props.setProperty("sftpuser", "NA");
			//props.setProperty("port", "22");
			props.setProperty("port", sftpPort);
			props.setProperty("keyFilePath", "NA");
			props.setProperty("remote.directory", "NA");
		}
		
		
		PropertiesPropertySource pps = new PropertiesPropertySource("props", props);
		env.getPropertySources().addLast(pps);
		logger.debug("before setting sftp session in context in setEnvironmentForPaymentSystem");
		logger.debug("host is::"+env.getProperty("host"));
		logger.debug("user id is::"+env.getProperty("sftpuser"));
		logger.info("key File Path - "+env.getProperty("keyFilePath"));
		ctx.setEnvironment(env);
		logger.debug("after setting sftp session in context in setEnvironmentForPaymentSystem");
	}
}
