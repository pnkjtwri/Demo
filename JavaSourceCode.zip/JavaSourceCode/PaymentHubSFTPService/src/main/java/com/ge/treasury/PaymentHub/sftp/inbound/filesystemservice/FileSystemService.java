package com.ge.treasury.PaymentHub.sftp.inbound.filesystemservice;

import java.io.InputStream;
import java.io.Serializable;
import java.util.List;

import com.ge.treasury.PaymentHub.dao.PaymentHubJDBCTempleteDAO;
import com.ge.treasury.PaymentHub.service.FileLockingService;
import com.ge.treasury.PaymentHub.sftp.inbound.exception.SftpCompException;
import com.ge.treasury.PaymentHub.sftp.mapper.FileTransferAuditLogMapper;

/**
 * /** the perpose of this service is to provide basic file functions like copy,delete and read
 * 
 * @author pankaj1.tiwari
 *
 */
public interface FileSystemService extends Serializable {

  /**
   * copy file from source location to target
   * 
   * @param inputStream
   *          - file as stream
   * @param targetPath
   *          - target path
   * @throws SftpCompException
   */
  void copyFile(InputStream inputStream, String targetPath) throws SftpCompException;

  /**
   * delete file from a specific location
   * 
   * @param path
   *          - file location
   * @throws SftpCompException
   */
  void deleteFile(String path) throws SftpCompException;

  /**
   * /**will read file from target location and return it as stream
   * 
   * @param filePath
   *          -file path with name
   * @param fileDestination
   *          - file destination
   * @throws SftpCompException
   */
  void readFile(String filePath, String fileDestination) throws SftpCompException;

  /**
   * /** check if filepath exist
   * 
   * @param filePath
   *          - filepath of remote machine
   * @return - true if exist else false
   * @throws SftpCompException
   * 
   */
  boolean isFileExist(String filePath) throws SftpCompException;

  /**
   * /** create file in the path specified
   * 
   * @param filePath
   *          - file path to be created
   * @throws SftpCompException
   */
  void createFile(String filePath) throws SftpCompException;

  /**
   * Get all file list of remote location
   * @param remotePath
   * @return
   * @throws SftpCompException
   */
  List<String> getFileList(String remotePath) throws SftpCompException;

  void downloadRemoteFile(String remotePath, String tsaIdentifier, FileTransferAuditLogMapper logMapper,
		PaymentHubJDBCTempleteDAO dao, FileLockingService fileLockingService) throws SftpCompException;

}

