package com.ge.treasury.PaymentHub.dao;

import java.util.List;
import java.util.Map;

import com.ge.treasury.PaymentHub.model.FileStatusBean;
import com.ge.treasury.PaymentHub.model.FileTransferAuditLog;
import com.ge.treasury.PaymentHub.model.LockedFileBean;
import com.ge.treasury.PaymentHub.model.PFIBusiness;
import com.ge.treasury.PaymentHub.model.PFIBusinessTSAInstanceMapping;
import com.ge.treasury.PaymentHub.model.PfiTransactionsBean;
import com.ge.treasury.PaymentHub.model.SegregatorFileBean;
import com.ge.treasury.PaymentHub.model.TSAInstance;

public interface PaymentHubJDBCTempleteDAO {
	
	public List<TSAInstance> getTSAInstanceDetails();

	int saveAuditLogDetails(FileTransferAuditLog auditLog);

	List<SegregatorFileBean> getSegregatorFileDetails(String srcFile);

	boolean updateImportStatusFileNameInSegregator(String importFilename,
			Long segregatorID, Integer fileStatusID);

	List<PFIBusinessTSAInstanceMapping> getBusinessTsaInstanceMappingDetails(
			long tsaID);

	List<PFIBusiness> getPFIBusinessDetailsByBusinessID(long businessID);
	
	List<PFIBusiness> getPFIBusinessDetailsByBusinessName(String businessName);
	
	List<TSAInstance> getTSAInstanceDetailsByIdentifier(String tsaIdentifier);
	
	public void deleteLockedFileDetail(String fileName);

	int insertInputFileInfoForLock(LockedFileBean lockedFiles);

	boolean checkLockTable(String inputFileName);

	List<FileStatusBean> getFileStatusDetailsByDescryption(
			String importstatusfileid);

	void batchUpdatePFITxnDetails(List<PfiTransactionsBean> txnDtlsList);
	
	List<Map<String,Object>> getNasFileNamePattern ();
}
