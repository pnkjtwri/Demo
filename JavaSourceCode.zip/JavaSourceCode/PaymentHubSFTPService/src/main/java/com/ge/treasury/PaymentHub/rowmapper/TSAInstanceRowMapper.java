package com.ge.treasury.PaymentHub.rowmapper;

/**
 * Class designed for mapping the resultset data into Object(AccountInfoBean)
 * @author Pankaj1.Tiwari
 */

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ge.treasury.PaymentHub.model.TSAInstance;

@SuppressWarnings("rawtypes")
@Component
public class TSAInstanceRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(TSAInstanceRowMapper.class);
	
	/**
	 * Method used for mapping the resultset data into AccountInfoBean object
	 */
	@Override
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		logger.info("[TSAInstanceRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into TSAInstanceBean..]");
		TSAInstance tsaInstanceBean = new TSAInstance();
		tsaInstanceBean.setTsaInstanceId(rs.getInt("TSAINSTACES_ID"));
		tsaInstanceBean.setTsaInstanceIdentifier(rs.getString("TSAINSTANCE_IDENTIFIER"));
		tsaInstanceBean.setHostName(rs.getString("HOST_NAME"));
		tsaInstanceBean.setUserId(rs.getString("USER_ID"));
		tsaInstanceBean.setPfiPublicKeyPath(rs.getString("PFI_PUBLIC_KEY_PATH"));
		tsaInstanceBean.setPfiRespFilePrivateKeyPath(rs.getString("PFI_RESP_FILE_PRIVATE_KEY_PATH"));
		tsaInstanceBean.setDeleteFlag(rs.getString("DELETE_FLAG"));
		tsaInstanceBean.setCreatedBy(rs.getString("CREATED_BY"));
		tsaInstanceBean.setCreatedTimestamp(rs.getDate("CREATED_TIMESTAMP"));
		tsaInstanceBean.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		tsaInstanceBean.setLastModifiedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[TSAInstanceRowMapper.class] [Inside mapRow()] [Going to return TSAInstanceBean..]");
		return tsaInstanceBean;
	}
}
