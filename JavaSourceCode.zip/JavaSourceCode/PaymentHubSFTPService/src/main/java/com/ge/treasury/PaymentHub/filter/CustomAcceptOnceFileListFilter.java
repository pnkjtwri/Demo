package com.ge.treasury.PaymentHub.filter;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.file.filters.FileListFilter;

import com.ge.treasury.PaymentHub.service.FileLockingService;

public class CustomAcceptOnceFileListFilter<F> implements FileListFilter<F>{
	final static Logger logger = Logger.getLogger(CustomAcceptOnceFileListFilter.class);
	
	private final Integer maxCapacity = 10;
	private Set<F> fileRead = new HashSet<F>();
	private Queue<F> seen   = new LinkedBlockingQueue<F>(maxCapacity);
	private final Object monitor = new Object();
	
	@Autowired FileLockingService fileLockingService;
	
	@Override
	public List<F> filterFiles(F[] files) {
		List<F> accepted = new ArrayList<F>();
		synchronized (this.monitor) {
	        if (files != null) {
	        	File fileRecieved    = null;
	        	boolean isFileLocked = false;
	        	
	            for (F file : files) {
	            	fileRecieved = new File(file.toString());
	            	if(!this.fileRead.contains(file) && fileRecieved.isFile()  && !file.toString().toLowerCase().contains(".writing") 
	            			&& file.toString().toLowerCase().contains(".pgp") && fileRecieved.length() > 0){
	            		
	            		isFileLocked = fileLockingService.doFileLockCheck(fileRecieved);
	            		
		            	if(isFileLocked){
		            		accepted.add(file);
		            		this.remove(file);
		            		this.fileRead.add(file);
		            		logger.info("[CustomAcceptOnceFileListFilter] - File Recived - "+file);
		            		break;
		            	}else{
		            		//in case if file is already processed by other instance
		            		//we are not going to check for the same file
		            		this.fileRead.add(file);
		            	}
	            	}
	            }
	        }
		}
        return accepted;
	}
	
	private void remove(F fileToRemove){
		if(this.seen.size() == (maxCapacity-2)){
			F removed = this.seen.poll();
			logger.info("[CustomAcceptOnceFileListFilter] - File Removed  - "+removed);
			this.fileRead.remove(removed);
		}
		this.seen.offer(fileToRemove);
	}
}