package com.ge.treasury.PaymentHub.sftp.decryption.decryptService.impl;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.treasury.PaymentHub.sftp.decryption.decryptService.PaymentMergerDecryptionService;
import com.ge.treasury.PaymentHub.sftp.decryption.exception.FileEncryptionDecryptionException;
import com.ge.treasury.PaymentHub.sftp.decryption.util.PGPFileProcessor;

@Service
public class PaymentMergerDecryptionServiceImpl implements
		PaymentMergerDecryptionService {
	final static Logger logger = Logger.getLogger(PaymentMergerDecryptionServiceImpl.class);

	@Value("${encryptedFilePath}")
	private String encryptedFilePath;
	@Value("${privateKeyPath}")
	private String privateKeyPath;
	@Value("${passphrase}")
	private String passphrase;
	
	@Autowired PGPFileProcessor pgpProcessor;

	@Override
	public String decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException {
		String outPutFileName = fileToDecrypt.getName();
		outPutFileName = outPutFileName.replace(".pgp", "");
		boolean rtnFlag = pgpProcessor.decrypt(fileToDecrypt, (encryptedFilePath+outPutFileName), privateKeyPath, passphrase);
		if(rtnFlag){
			return encryptedFilePath+outPutFileName;
		}else{
			throw null;
		}
	}

	/**
	 * @param privateKeyPath
	 *            the privateKeyPath to set
	 */
	public void setPrivateKeyPath(String privateKeyPath) {
		this.privateKeyPath = privateKeyPath;
	}

	/**
	 * @param passphrase
	 *            the passphrase to set
	 */
	public void setPassphrase(String passphrase) {
		this.passphrase = passphrase;
	}

	/**
	 * @param encryptedFilePath
	 *            the encryptedFilePath to set
	 */
	public void setEncryptedFilePath(String encryptedFilePath) {
		this.encryptedFilePath = encryptedFilePath;
	}

	/**
	 * @param pgpProcessor the pgpProcessor to set
	 */
	public void setPgpProcessor(PGPFileProcessor pgpProcessor) {
		this.pgpProcessor = pgpProcessor;
	}

}
