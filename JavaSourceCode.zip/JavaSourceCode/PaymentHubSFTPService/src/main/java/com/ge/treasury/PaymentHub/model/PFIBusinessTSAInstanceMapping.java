package com.ge.treasury.PaymentHub.model;

public class PFIBusinessTSAInstanceMapping extends CommonBean {
	
	private long pfiBusTSAInstMappingID;
	private long pfiBusinessID;
	private long tsaInstancesID;
	private String deleteFlag;
	private String pgpOptionID;
	
	public long getPfiBusTSAInstMappingID() {
		return pfiBusTSAInstMappingID;
	}
	public void setPfiBusTSAInstMappingID(long pfiBusTSAInstMappingID) {
		this.pfiBusTSAInstMappingID = pfiBusTSAInstMappingID;
	}
	public long getPfiBusinessID() {
		return pfiBusinessID;
	}
	public void setPfiBusinessID(long pfiBusinessID) {
		this.pfiBusinessID = pfiBusinessID;
	}
	public long getTsaInstancesID() {
		return tsaInstancesID;
	}
	public void setTsaInstancesID(long tsaInstancesID) {
		this.tsaInstancesID = tsaInstancesID;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getPgpOptionID() {
		return pgpOptionID;
	}
	public void setPgpOptionID(String pgpOptionID) {
		this.pgpOptionID = pgpOptionID;
	}

}
