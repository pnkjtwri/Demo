package com.ge.treasury.PaymentHub.model;

import java.util.Date;

/**
 * this class is mapper with the data base table
 * T_WEBCASHTSA_SRC_PAYMENT_FILE
 * */
public class SrcPaymentFile extends CommonBean{
	private long srcPaymentFileId;
	private String srcPaymentFileName;
	private String fileType;
	private String fileCreationModule;
	private String fileFormatVersion;
	private Integer trailerTotalRecords;
	private String trailerFileName;
	private String segregationFlag;
	private int fileStatusId;
	private String segregationStatusMessage;
	private Integer pfiBusinessId;
	private Date srcFileCreationTimeStamp;
	
	
	public long getSrcPaymentFileId() {
		return srcPaymentFileId;
	}
	public void setSrcPaymentFileId(long srcPaymentFileId) {
		this.srcPaymentFileId = srcPaymentFileId;
	}
	public String getSrcPaymentFileName() {
		return srcPaymentFileName;
	}
	public void setSrcPaymentFileName(String srcPaymentFileName) {
		this.srcPaymentFileName = srcPaymentFileName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileCreationModule() {
		return fileCreationModule;
	}
	public void setFileCreationModule(String fileCreationModule) {
		this.fileCreationModule = fileCreationModule;
	}
	public String getFileFormatVersion() {
		return fileFormatVersion;
	}
	public void setFileFormatVersion(String fileFormatVersion) {
		this.fileFormatVersion = fileFormatVersion;
	}
	public Integer getTrailerTotalRecords() {
		return trailerTotalRecords;
	}
	public void setTrailerTotalRecords(Integer trailerTotalRecords) {
		this.trailerTotalRecords = trailerTotalRecords;
	}
	public String getTrailerFileName() {
		return trailerFileName;
	}
	public void setTrailerFileName(String trailerFileName) {
		this.trailerFileName = trailerFileName;
	}
	public String getSegregationFlag() {
		return segregationFlag;
	}
	public void setSegregationFlag(String segregationFlag) {
		this.segregationFlag = segregationFlag;
	}
	public int getFileStatusId() {
		return fileStatusId;
	}
	public void setFileStatusId(int fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	public String getSegregationStatusMessage() {
		return segregationStatusMessage;
	}
	public void setSegregationStatusMessage(String segregationStatusMessage) {
		this.segregationStatusMessage = segregationStatusMessage;
	}
	public Integer getPfiBusinessId() {
		return pfiBusinessId;
	}
	public void setPfiBusinessId(Integer pfiBusinessId) {
		this.pfiBusinessId = pfiBusinessId;
	}
	public Date getSrcFileCreationTimeStamp() {
		return srcFileCreationTimeStamp;
	}
	public void setSrcFileCreationTimeStamp(Date srcFileCreationTimeStamp) {
		this.srcFileCreationTimeStamp = srcFileCreationTimeStamp;
	}
}
