package com.ge.treasury.PaymentHub.service;

/**
 * @author Pankaj1.Tiwari
 */

import java.io.File;
import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import com.ge.treasury.PaymentHub.dao.impl.PaymentHubJDBCTempleteDAOImpl;
import com.ge.treasury.PaymentHub.model.LockedFileBean;
import com.ge.treasury.PaymentHub.sftp.decryption.util.PaymentDecryptionUtility;

@Service
public class FileLockingService {
	
	private static Logger logger = Logger.getLogger(FileLockingService.class);
	
	@Value("${userid.created.by}")
	private String createdBy;
	@Value("${userid.last.modified.by}")
	private String lastModifiedBy;
	
	@Autowired PaymentHubJDBCTempleteDAOImpl daoImpl;
	
	/**
	 * 
	 * @param inputFileName
	 * @return
	 */
	public boolean doFileLockCheck(File inputFileName){
		logger.info("[FileLockingService.class] [inside doFileLockCheck()]");
		logger.info("[FileLockingService.class] [inputFile"+inputFileName.getAbsolutePath()+"]");
		try{
			if(daoImpl.checkLockTable(inputFileName.getName().toUpperCase())){
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is already processed.]");
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Going to skip this input file.]");
				return false;
			}else{
				//do have a lock on input file
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is not processed yet.]");
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Going to have lock on this file.]");
				int rows = daoImpl.insertInputFileInfoForLock(prepareFileLockBean(inputFileName));
				if(rows>0){
					logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Got the lock on input file successfully]");
					return true;
				}
				else{
					logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Didn't get lock on input file]");
					return false;
				}
			}
		}catch(DuplicateKeyException ex){
			logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is already locked...]");
			logger.info("[FileLockingService] - "+PaymentDecryptionUtility.getErrorFormStackTrace(ex));
			return false;
		}catch(Exception ex){
			logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Getting some error while going for lock]");
			logger.info("[FileLockingService] - "+PaymentDecryptionUtility.getErrorFormStackTrace(ex));
			return false;
		}
		
	}
	
	/**
	 * 
	 * @param inputFileName
	 * @return
	 */
	private LockedFileBean prepareFileLockBean(File inputFileName){
		logger.info("[FileLockingService.class] [inside prepareFileLockBean()]");
		LockedFileBean lock = new LockedFileBean();
		lock.setLockedFileName(inputFileName.getName());
		lock.setLockedFileProcessedTime(new Timestamp(new java.util.Date().getTime()));
		lock.setLockedFileSize((double)inputFileName.length());
		lock.setCreatedBy(createdBy);
		lock.setLastModifiedBy(lastModifiedBy);
		logger.info("[FileLockingService.class] [inside prepareFileLockBean()] [returning FileLock object]");
		return lock;
	}

	public void deleteLockedFileDetail(File inputFile) {
		logger.info("[FileLockingService.class] [inside deleteLockedFileDetail()]");
		logger.info("[FileLockingService.class] [inside deleteLockedFileDetail()] [Going to delete locked file..]");
		daoImpl.deleteLockedFileDetail(inputFile.getName().toUpperCase());
		logger.info("[FileLockingService.class] [inside deleteLockedFileDetail()] [Locked file deleted successfully!!]");
	}
	
	/**
	 * 
	 * @param inputFileName
	 * @param inputFile size
	 * @return
	 */
	public boolean doFileLockChecksftp(String inputFileName, double size){
		logger.info("[FileLockingService.class] [inside doFileLockCheck()]");
		logger.info("[FileLockingService.class] [inputFile"+inputFileName+"]");
		try{
			if(daoImpl.checkLockTable(inputFileName)){
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is already processed.]");
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Going to skip this input file.]");
				return false;
			}else{
				//do have a lock on input file
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is not processed yet.]");
				logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Going to have lock on this file.]");
				int rows = daoImpl.insertInputFileInfoForLock(prepareFileLockBeansftp(inputFileName,size));
				if(rows>0){
					logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Got the lock on input file successfully]");
					return true;
				}
				else{
					logger.info("[FileLockingService.class] [inside doFileLockCheck()] [Didn't get lock on input file]");
					return false;
				}
			}
		}catch(Exception ex){
			logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is already locked...]");
			return false;
		}
		
	}
	
	/**
	 * 
	 * @param inputFileName
	 * @param inputFile size
	 * @return
	 */
	private LockedFileBean prepareFileLockBeansftp(String inputFileName, double size){
		logger.info("[FileLockingService.class] [inside prepareFileLockBeansftp()]");
		LockedFileBean lock = new LockedFileBean();
		lock.setLockedFileName(inputFileName);
		lock.setLockedFileProcessedTime(new Timestamp(new java.util.Date().getTime()));
		lock.setLockedFileSize(size);
		lock.setCreatedBy(createdBy);
		lock.setLastModifiedBy(lastModifiedBy);
		logger.info("[FileLockingService.class] [inside prepareFileLockBeansftp()] [returning FileLock object]");
		return lock;
	}

}
