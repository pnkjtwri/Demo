/**
 * 
 */
package com.ge.treasury.PaymentHub.sftp.inbound.sftpconnection;

import com.ge.treasury.PaymentHub.sftp.inbound.exception.SftpCompException;

/**
 * will provide functions to connect to remote machine
 * 
 * @author Pankaj1.Tiwari
 *
 * @param <S>
 *          - client type ex- Session(SFTP)
 */
public interface SftpConnectionService<S> {
  /**
   * connect to remote machine
 * @return 
   * 
   * @throws SftpCompException
   */
  boolean connect() throws SftpCompException;

  /**
   * return remote server client
   * 
   * @return S - remote machine client
   */
  S getClient();

  /**
   * disconnect to the remote machine
   * 
   * @throws SftpCompException
   */
  void disconnect() throws SftpCompException;
}