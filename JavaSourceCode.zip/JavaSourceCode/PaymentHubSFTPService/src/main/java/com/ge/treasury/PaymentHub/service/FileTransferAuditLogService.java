/**
 * 
 */
package com.ge.treasury.PaymentHub.service;

/**
 * @author padmajaarekuti
 *
 */
public class FileTransferAuditLogService {

}
