package com.ge.treasury.PaymentHub.sftp.decryption.util;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;

public class PaymentDecryptionUtility {
	final static Logger logger = Logger.getLogger(PaymentDecryptionUtility.class);
	
	/**
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
	/**
	* delete file from given location
	* @param generatedFile, files to be deleted
	*/
	public static void deleteFile(File generatedFile){
		if(generatedFile.exists()){
			logger.info("[PaymentDecryptionUtility] - Removing generated file - "+generatedFile.getName());
			if(generatedFile.delete()){
				logger.info("[PaymentDecryptionUtility] - Generated file - "+generatedFile.getName()+" deleted !!");
			}else{
				logger.info("[PaymentDecryptionUtility] - Error deleting generated file - "+generatedFile.getName());
			}
		}
		
	}
	
}
