package com.ge.treasury.PaymentHub.sftp.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import com.ge.treasury.PaymentHub.model.TSAInstance;


@Component
public interface TSAInstancesMapper {
	/*@Select("SELECT TSAINSTANCE_IDENTIFIER, HOST_NAME, USER_ID, PASSWORD, PFI_LOCATION, PFI_RESP_FILE_PRIVATE_KEY_PATH FROM "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES  WHERE DELETE_FLAG='N'")
	@Results({
        @Result(property = "tsaInstanceIdentifier", column = "TSAINSTANCE_IDENTIFIER"),
        @Result(property = "hostName", column = "HOST_NAME"),
        @Result(property = "userId", column = "USER_ID"),
        //@Result(property = "password", column = "PASSWORD"),
        @Result(property = "pfiLocation", column = "PFI_LOCATION"),
        @Result(property = "pfiRespFilePrivateKeyPath", column = "PFI_RESP_FILE_PRIVATE_KEY_PATH")
      })
	public List<TSAInstance> findAll();*/
	
	
	
	@Select(" SELECT TSAINST.TSAINSTACES_ID, TSAINST.HOST_NAME, TSAINST.TSAINSTANCE_IDENTIFIER,TSAINST.USER_ID, "
			+ "TSAINST.PFI_RESP_FILE_PRIVATE_KEY_PATH,TSAINST.DELETE_FLAG, PFIBUS.PFI_LOCATION,PFIBUS.PFI_BUSINESS_ID,"
			+ "PFIBUS.PFI_BUSINESS_NAME, PFIBUS.PFI_BUSINESS_NAME,PFIBUS.PFI_MANUAL_LOCATION, PFIBUS.PGP_OPTION_ID, "
			+ "PFIBUS.DELETE_FLAG FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS PFIBUS "
			+ "JOIN Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFIBUS_TSAINST_MAPPING TSAMAP "
			+ "ON  PFIBUS.PFI_BUSINESS_ID = TSAMAP.PFI_BUSINESS_ID "
			+ "JOIN Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES TSAINST "
			+ "ON TSAMAP.TSAINSTANCES_ID = TSAINST.TSAINSTACES_ID "
			+ "WHERE PFIBUS.DELETE_FLAG = 'N' AND TSAINST.DELETE_FLAG = 'N'")
	@Results({
		@Result(property = "tsaInstanceId", column = "TSAINSTACES_ID"),
        @Result(property = "tsaInstanceIdentifier", column = "TSAINSTANCE_IDENTIFIER"),
        @Result(property = "hostName", column = "HOST_NAME"),
        @Result(property = "userId", column = "USER_ID"),
        @Result(property = "pfiLocation", column = "PFI_LOCATION"),
        @Result(property = "manualLocation", column = "PFI_MANUAL_LOCATION"),
        @Result(property = "pgpOptionId", column = "PGP_OPTION_ID"),
        @Result(property = "pfiRespFilePrivateKeyPath", column = "PFI_RESP_FILE_PRIVATE_KEY_PATH")
        
      })
	public List<TSAInstance> findAll(); 
    
}
