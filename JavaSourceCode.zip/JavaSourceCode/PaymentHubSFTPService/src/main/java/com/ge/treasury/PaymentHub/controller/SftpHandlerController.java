package com.ge.treasury.PaymentHub.controller;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.treasury.PaymentHub.model.FileTransferAuditLog;
import com.ge.treasury.PaymentHub.model.TSAInstance;
import com.ge.treasury.PaymentHub.service.EnvironmentLookupService;
import com.ge.treasury.PaymentHub.sftp.mapper.FileTransferAuditLogMapper;
import com.ge.treasury.PaymentHub.sftp.outbound.DynamicSftpOutboundChannelResolver;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;

@RestController
public class SftpHandlerController {
	private static final Logger logger = Logger.getLogger(SftpHandlerController.class);
	@Autowired private EnvironmentLookupService envService;
	@Autowired private FileTransferAuditLogMapper logMapper;
	/*@Autowired private PaymentHubJDBCTempleteDAO paymentHubJDBCTempleteDAO;*/
	
	
	private ConfigurableApplicationContext ctx;
	
	@Value("${retryLimit}")
	private int retryLimit;
	@Value("${sftpPort}")
	private String sftpPort;
	
	@RequestMapping(value = "/transferFile", method=RequestMethod.POST)
	public Map<String, Object> transferFile(@RequestBody Map<String, Object> sftpFile){
		logger.info("Start process for transfering files..");
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		try{
			int retryAttempt 	= 1;
			
			if(ctx == null){
				ctx = new ClassPathXmlApplicationContext("spring/integration/DynamicSftpOutboundChannelAdapterSample-context.xml");
			}
			MessageChannel channel = ctx.getBean("toDynRouter", MessageChannel.class);
			
			//11_OPTIONID_userID
			
			if(sftpFile != null && sftpFile.size() > 0){
				for(String tsaInstaceId : sftpFile.keySet()){
					logger.info("Transfering files for - "+tsaInstaceId);
					File fileToTransfer = new File((String)sftpFile.get(tsaInstaceId));
					retryAttempt 	= 1;
					//adding sftp port into tsaInstaceId variable...
					tsaInstaceId = tsaInstaceId+"_"+sftpPort;
					Message<File> message = MessageBuilder.withPayload(fileToTransfer).setHeader("paymentSystem", tsaInstaceId).build();
					FileTransferAuditLog auditLog=null;
					boolean fileSent = false;
					for(int retryCount = 0; retryCount < retryLimit; retryCount++){
						try{
							logger.info("File to transfer - "+fileToTransfer.getName());
							fileSent = channel.send(message);
							logger.info("File Sent Status - "+fileSent);
							if(fileSent){
								auditLog=populateSplitTransferAuditLog(fileToTransfer.getPath(),tsaInstaceId,fileToTransfer.getName(),"S");
								logMapper.insertAuditLog(auditLog);
								break;
							}
						}catch(Exception e){
							logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
							logger.error("File sent error, retry Attempt - "+retryAttempt);
							if(!fileSent && (retryAttempt == retryLimit)){
								logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
								auditLog=populateSplitTransferAuditLog(fileToTransfer.getPath(),tsaInstaceId,fileToTransfer.getName(),"F");
								if(e.getMessage() != null && e.getMessage().length() > 239){
									auditLog.setComments(e.getMessage().substring(0, 240));
								}else if(e.getMessage() != null && e.getMessage().length() > 0){
									auditLog.setComments(e.getMessage().substring(0, e.getMessage().length()));
								}
								logMapper.insertAuditLog(auditLog);
							}else if(!fileSent){
								retryAttempt++;
							}
						}
						
					}
					
					String key = tsaInstaceId.split("_")[0];
					logger.info("Key for response - "+key);
					if(fileSent){
						response.put(key,"Success");
						logger.info(fileToTransfer.getName() +" Transferred Successfully !!");
					}else{
						response.put(key,"Failed");
						logger.info(fileToTransfer.getName() +" Transfer Failed !!");
					}
				}
				//ctx.close();
			}
		}catch(Exception ex){
			logger.error("Error while sftping files - "+PaymentHubUtility.getErrorFormStackTrace(ex));
		}
		return response;
	}
	
	private FileTransferAuditLog populateSplitTransferAuditLog(String srcLocation, String paymentSystem, String fileName,String transferStatus) {
		FileTransferAuditLog auditLog=new FileTransferAuditLog();
		auditLog.setFileName(fileName);
		auditLog.setFileType("PAYMENT_FILE");
		auditLog.setSrcLocation(srcLocation);
		//TSAInstance tsaInstance=envService.retriveConfigValue(paymentSystem);
		String tsaInstanceID = "";
		String optionId      = "";
		Integer operatorId   = null;
		
		if(paymentSystem.contains("_")){
			String[] sftpDetails = paymentSystem.split("_");
			logger.info("sftpdetails length - "+sftpDetails.length);
			if(sftpDetails.length > 0){
				tsaInstanceID = sftpDetails[0];
				optionId      = sftpDetails[1];
				try{
					String userId  = (sftpDetails[2]);
					operatorId     = Integer.parseInt(userId);
				}catch(Exception e){
					logger.info("User id not found");
				}
			}
			logger.info("TSA Id - "+tsaInstanceID);
			logger.info("Option Id - "+optionId);
			logger.info("User id - "+operatorId);
		}
		
		TSAInstance tsaInstance=envService.retriveConfigValue(tsaInstanceID+optionId);
		
		if(tsaInstance!=null){
			if(operatorId != null && String.valueOf(operatorId).length() == 9){
			  logger.info("Setting transfer location for manual - "+tsaInstance.getManualLocation());
			  auditLog.setDestLocation(tsaInstance.getManualLocation());
			}else{
				logger.info("Setting transfer location - "+tsaInstance.getPfiLocation());
				auditLog.setDestLocation(tsaInstance.getPfiLocation());
			}
		}else{
			auditLog.setDestLocation("Information not available"); 
		}
		auditLog.setStatus(transferStatus);
		auditLog.setCreatedBy("999999999");
		auditLog.setLastModifiedBy("999999999");
		if(transferStatus != null && transferStatus.equalsIgnoreCase("S")){
			auditLog.setComments("File Transfered Successfully");
		}else{
			auditLog.setComments("File Transfered Failed");
		}
		return auditLog;
	}
	
	@PostConstruct
	public void init(){
		try {   
			logger.info("File Management application has started");
			envService.refreshCache();
			DynamicSftpOutboundChannelResolver.setEnvService(envService);
			logger.info("File Management initilize..");
		} catch (Exception e) {
			logger.error("File Management application initilization failed..");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
			throw new RuntimeException("Aplication initilization failed...");
		}
	}
	

}
