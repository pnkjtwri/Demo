package com.ge.treasury.PaymentHub.sftp.decryption.service.impl;

/**
 * @author pankaj1.tiwari
 * Class designed on Service layer for decrypting and post-processing the source file 
 */

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ge.treasury.PaymentHub.constant.PaymentHubSFTPConstants;
import com.ge.treasury.PaymentHub.dao.impl.PaymentHubJDBCTempleteDAOImpl;
import com.ge.treasury.PaymentHub.mail.EmailService;
import com.ge.treasury.PaymentHub.model.FileStatusBean;
import com.ge.treasury.PaymentHub.model.PFIBusiness;
import com.ge.treasury.PaymentHub.model.PfiTransactionsBean;
import com.ge.treasury.PaymentHub.model.SegregatorFileBean;
import com.ge.treasury.PaymentHub.sftp.decryption.decryptService.impl.PaymentMergerDecryptionServiceImpl;
import com.ge.treasury.PaymentHub.sftp.decryption.exception.FileEncryptionDecryptionException;
import com.ge.treasury.PaymentHub.sftp.decryption.service.FileDecriptionService;
import com.ge.treasury.PaymentHub.util.PaymentHubUtility;

@Service
public class FileDecriptionServiceImpl implements FileDecriptionService {
	
	private static Logger logger = Logger.getLogger(FileDecriptionServiceImpl.class);
	
	@Autowired private PaymentMergerDecryptionServiceImpl paymentMergerDecryptionServiceImpl;
	@Autowired private PaymentHubJDBCTempleteDAOImpl systemDAOImpl;
	@Autowired private ApplicationContext appContext;
	@Autowired private EmailService emailService;
	
	@Value("${importStatusFileType}")
	private String importStatusFileType;
	@Value("${controlStampFileType}")
	private String controlStampFileType;
	@Value("${errorLocation}")
	private String errorLocation;
	@Value("${archiveLocation}")
	private String archiveLocation;
	@Value("${unknownLocation}")
	private String unknownLocation;
	@Value("${manualLocation}")
	private String manualLocation;
	@Value("${manualFileType}")
	private String manualFileType;
	@Value("${keepPlainFile}")
	private String keepPlainFile;
	@Value("${isTransactionDetailsPersist}")
	private String isTransactionDetailsPersist;
	@Value("${BAIFileLocation}")
	private String baiLocation;
	private List<Map<String,Object>> listOfDBPatterns =null;
	boolean isBAIFlag = false;
	@Value("${CRFileLocation}")
	private String crLocation;
	private String fileType = "";

	/**
	 * Method is used for decrypting and post-processing the source file
	 */
	@Override
	public void decryptFile(File inputFile) {
		logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()]");
		File decryptFile = null;
		boolean doneFlg = false;
		fileType = "";
		logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Going to check soruce file is BAI or not??]");
		isBAIFlag = ValidateFileNamePattern(inputFile.getName());
		logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [is source file BAI/CR file : "+isBAIFlag+"]");
		
		if(!inputFile.getName().startsWith(importStatusFileType) && !inputFile.getName().startsWith(controlStampFileType) 
				&& !inputFile.getName().toUpperCase().startsWith(manualFileType.toUpperCase()) && (!isBAIFlag)){
			
			//didn't get Control Stamp or Plugin Details file
			logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Didn't get Cotntrol Stamp/Plugin Details/Manual/BAI/CR file. File name : "+inputFile.getName()+"]");
			String bodyContent = "Source file doesn't belong to Import Status/Control Stmap/BAI/CR file.";
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendPainMailNotification("Unknown file received", inputFile.getName(), bodyContent);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [So, going to redirect this source file into Unkown location.]");
			sendFilestoUnknownLocation(inputFile);
			
		}else{
			//Got Correct file name format....
			logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Got Cotntrol Stamp or Plugin Details or Manual file. File name : "+inputFile.getName()+"]");
			logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [So, Going to process this source file...]");
			try{
				logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Going to decrypt input file]");
				String decryptFileName = paymentMergerDecryptionServiceImpl.decryptFile(inputFile);
				if(decryptFileName != null){
					logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file decrypted successfully.]");
					//Going to check 
					decryptFile = new File(decryptFileName);
					logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Going to check input file type...]");
					if(decryptFile.getName().toUpperCase().startsWith(controlStampFileType.toUpperCase())){
						logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file is control stamp file. So, no need of file validation.]");
						doneFlg = processControlStampFile(decryptFile, inputFile);
					}
					else if(decryptFile.getName().toUpperCase().startsWith(manualFileType.toUpperCase())){
						logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file is Manual file. Going to validate input file.]");
						if(decryptFile.exists()){
							doneFlg = processManualFile(decryptFile, inputFile);
						}else{
							//decrypted file is not generated
							logger.info("Decryption process has done. But, Decrypted file has not generated."); 
							String bodyContent = "Decryption process has done. But, Decrypted file has not generated. ";
							try {
								if(emailService == null)emailService = new EmailService();
								emailService.sendPainMailNotification("Decrypted File generation error", inputFile.getName(), bodyContent);
							} catch (MessagingException e1) {
								logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
							}
							logger.error("Got Exception...Going to move file into error location.....");
							sendFilestoErrorLocation(inputFile, false);
							if(keepPlainFile.equals("Y") && decryptFile!= null && decryptFile.exists())
								sendFilestoErrorLocation(decryptFile, true);
						}
					}
					else if(decryptFile.getName().toUpperCase().startsWith(importStatusFileType.toUpperCase())){
						logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file is import status file. Going to validate input file.]");
						if(decryptFile.exists()){
							doneFlg = processImportStatusFile(decryptFile, inputFile);
							
						}else{
							//decrypted file is not generated
							logger.info("Decryption process has done. But, Decrypted file has not generated."); 
							String bodyContent = "Decryption process has done. But, Decrypted file has not generated. ";
							try {
								if(emailService == null)emailService = new EmailService();
								emailService.sendPainMailNotification("Decrypted File generation error", inputFile.getName(), bodyContent);
							} catch (MessagingException e1) {
								logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
							}
							logger.error("Got Exception...Going to move file into error location.....");
							sendFilestoErrorLocation(inputFile, false);
							if(keepPlainFile.equals("Y") && decryptFile!= null && decryptFile.exists())
								sendFilestoErrorLocation(decryptFile, true);
						}
					}
					//else if(decryptFile.getName().toUpperCase().contains(baiFileType.toUpperCase())){
					else if(isBAIFlag){
						if(fileType != null && !fileType.equals("") && fileType.equalsIgnoreCase("CR")){
							logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file is CR file. Going to process input file.]");
							if(decryptFile.exists()){
								logger.info("CR inputFileName : "+decryptFile.getName());
								//Process BAI input file
								doneFlg = processCrestalReportFile(decryptFile, inputFile);
								//doneFlg will be false...Because no need to archive at feedback location
							}else{
								//decrypted file is not generated
								logger.info("Decryption process has done. But, Decrypted file has not generated."); 
								String bodyContent = "Decryption process has done. But, Decrypted file has not generated. ";
								try {
									if(emailService == null)emailService = new EmailService();
									emailService.sendPainMailNotification("Decrypted File generation error", inputFile.getName(), bodyContent);
								} catch (MessagingException e1) {
									logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
								}
								logger.error("Got Exception...Going to move file into error location.....");
								sendFilestoErrorLocation(inputFile, false);
								if(keepPlainFile.equals("Y") && decryptFile!= null && decryptFile.exists())
									sendFilestoErrorLocation(decryptFile, true);
							}
						}else{
							logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Input file is BAI file. Going to process input file.]");
							if(decryptFile.exists()){
								logger.info("BAI inputFileName : "+decryptFile.getName());
								//Process BAI input file
								doneFlg = processBAIFile(decryptFile, inputFile);
								//doneFlg will be false...Because no need to archive at feedback location
							}else{
								//decrypted file is not generated
								logger.info("Decryption process has done. But, Decrypted file has not generated."); 
								String bodyContent = "Decryption process has done. But, Decrypted file has not generated. ";
								try {
									if(emailService == null)emailService = new EmailService();
									emailService.sendPainMailNotification("Decrypted File generation error", inputFile.getName(), bodyContent);
								} catch (MessagingException e1) {
									logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
								}
								logger.error("Got Exception...Going to move file into error location.....");
								sendFilestoErrorLocation(inputFile, false);
								if(keepPlainFile.equals("Y") && decryptFile!= null && decryptFile.exists())
									sendFilestoErrorLocation(decryptFile, true);
							}
						}
					}
					
					if(doneFlg){
						//process has done...
						//sending pgp file to Archive location...
						sendFilestoArchiveLocation(inputFile, false);
						//sending decrypted file to Archive location...
						if(keepPlainFile.equals("Y") && decryptFile!= null && decryptFile.exists())
							sendFilestoArchiveLocation(decryptFile, true);
					}
				}
			}catch(FileEncryptionDecryptionException ex){
				logger.info("[FileDecriptionServiceImpl.class] [inside decryptFile()] [Got FileEncryptionDecryptionException Exception.]");
				logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
				try {
					if(emailService == null)emailService = new EmailService();
					emailService.sendMailNotificationWithException(ex, "Input File Decryption Error", inputFile.getName());
				} catch (MessagingException e1) {
					logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
				}
				logger.error("Got Exception...Going to move file into error location.....");
				sendFilestoErrorLocation(inputFile, false);
			}
		}
		
		//after all processing...
		//going to delete files in any case (success/failure)
		deleteSrouceFile(inputFile, decryptFile);
	}
	
	private boolean ValidateFileNamePattern(String inputFileName) {
		String inputFileNameWithoutTS = null;
		inputFileNameWithoutTS = trimBAIFileTimeStamp(inputFileName);
	    
		if(listOfDBPatterns == null){
			listOfDBPatterns = systemDAOImpl.getNasFileNamePattern();
		}
		
		logger.info("No of patterns found in DB : ["+listOfDBPatterns.size()+"]");
		boolean isPatternMatched = false;
		String pattern = null;
		for (Map<String, Object> map : listOfDBPatterns) {
			if(isPatternMatched){
				break;
			}
		    for (Map.Entry<String, Object> entry : map.entrySet()) {
		    	logger.debug(entry.getKey() + " - " + entry.getValue());
		    	
		    	pattern = (String) entry.getValue();
		    	if(inputFileNameWithoutTS != null & inputFileNameWithoutTS.equalsIgnoreCase(pattern)){
		    		isPatternMatched = true;
		    		//break;
		    	}
		    	if(entry.getKey().equalsIgnoreCase(PaymentHubSFTPConstants.Constants.EXTRACT_TYPE) && isPatternMatched){
		    		fileType = pattern;
		    		break;
		    	}
		    }
		}
		logger.debug("isPatternMatched : "+isPatternMatched);
		return isPatternMatched;
		
	}

	/**
	 * Method used for processing Control Stamp file
	 * @param decryptedFile
	 */
	private boolean processControlStampFile(File decryptedFile, File srcFileName){
		logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()]");
		boolean rtnFlag = false;
		logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [Going to get Business Name from input file..]");
		String businessName = getBusinessNamefromSourceFile(decryptedFile.getName());
		logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [Got the Business Name from input file. Business Name is : "+businessName+"]");
		logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()]");
		if(businessName != null && !businessName.trim().equals("")){
			logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [Going to get Business NAS location by Business Name : "+businessName+"]");
			List<PFIBusiness> pfiBusinessList = systemDAOImpl.getPFIBusinessDetailsByBusinessName(businessName.trim().toUpperCase());
			if(pfiBusinessList != null && pfiBusinessList.size() > 0){
				PFIBusiness pfiBusiness = pfiBusinessList.get(0);
				String actualSrcFile = getActualSourceFileName(decryptedFile.getName());
				if(actualSrcFile != null && !actualSrcFile.isEmpty()){
					logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [Going to send file to NAS location..]");
					rtnFlag = sendFilestoNASLocation(decryptedFile, pfiBusiness.getPfiRespFilesLocation(), actualSrcFile, srcFileName.getName());
					if(!rtnFlag){
						sendFilestoErrorLocation(srcFileName, false);
						if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
							sendFilestoErrorLocation(decryptedFile, true);
					}
				}else{
					rtnFlag = false;
					logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Not able to get Actual file name from source file : "+srcFileName.getName()+"]");
					//send email....for no actual file name found...
					String bodyContent = "Didn't get Actual file name from source file name. File naming convention is not proper. It should be "
							+ "like this....'fileNameWithDateTime.xml_tsaIdentifier_businessName.pgp'";
					try {
						if(emailService == null)emailService = new EmailService();
						emailService.sendPainMailNotification("File naming convention error", srcFileName.getName(), bodyContent);
					} catch (MessagingException e1) {
						logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
					}
					logger.error("So, Going to move file into error location.....");
					sendFilestoErrorLocation(srcFileName, false);
					if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
						sendFilestoErrorLocation(decryptedFile, true);
				}
					
			}else{
				rtnFlag = false;
				//send email....for no business folder found...
				String bodyContent = "Didn't get Business details for Control stamp file.";
				try {
					if(emailService == null)emailService = new EmailService();
					emailService.sendPainMailNotification("Data Error", srcFileName.getName(), bodyContent);
				} catch (MessagingException e1) {
					logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
					rtnFlag = false;
				}
				logger.error("Got Exception...Going to move file into error location.....");
				sendFilestoErrorLocation(srcFileName, false);
				if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
					sendFilestoErrorLocation(decryptedFile, true);
			}
		}
		return rtnFlag;
	}
	
	/**
	 * Method used for processing the Import Status file
	 * @param decryptedFile
	 */
	private boolean processImportStatusFile(File decryptedFile, File srcFile){
		boolean rtnFalg = false;
		try{
			String fileNameTagVal = readCMMImportXmlFile(decryptedFile, srcFile.getName());
			if(fileNameTagVal != null && !fileNameTagVal.trim().equals("")){
				logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Going to get SEGREGATOR File details by fileName tag]");
				List<SegregatorFileBean> segregatorFileList =systemDAOImpl.getSegregatorFileDetails(fileNameTagVal.trim().toUpperCase()); 
				if(segregatorFileList != null && segregatorFileList.size() > 0){
					
					SegregatorFileBean segregatorFileBean = segregatorFileList.get(0);
					
					//get the actual file name
					String actualSrcFile = getActualSourceFileName(decryptedFile.getName());
					
					if(actualSrcFile != null && !actualSrcFile.isEmpty()){
						//going to get business name
						String businessName = getBusinessNamefromSourceFile(decryptedFile.getName());
						if(businessName != null && !businessName.trim().equals("")){
							List<PFIBusiness> pfiBusinessList = systemDAOImpl.getPFIBusinessDetailsByBusinessName(businessName.trim().toUpperCase());
							if(pfiBusinessList != null && pfiBusinessList.size() > 0){
								PFIBusiness pfiBusiness = pfiBusinessList.get(0);
								//going to get filestatusID...
								List<FileStatusBean> fileStatusList =  systemDAOImpl.getFileStatusDetailsByDescryption(PaymentHubUtility.importStatusfileDesc.toUpperCase());
								if(fileStatusList != null && fileStatusList.size() > 0){
									FileStatusBean fileStatusBean = fileStatusList.get(0);
									
									if(isTransactionDetailsPersist.equals("Y")){
										//going to get transaction details from source file....
										List<PfiTransactionsBean> txnDtlsList = getTransactionLevelDetailsFromXmlFile(decryptedFile, srcFile.getName(), segregatorFileBean);
										if(txnDtlsList != null && txnDtlsList.size() > 0){
											systemDAOImpl.batchUpdatePFITxnDetails(txnDtlsList);
										}
									}
									//going to update import status file name into db
									updateImportStatusFileNameInSegregator(actualSrcFile,segregatorFileBean.getSegregatorFileID(), 
											srcFile.getName(), fileStatusBean.getFileStatusID());
									rtnFalg = sendFilestoNASLocation(decryptedFile, pfiBusiness.getPfiRespFilesLocation(), actualSrcFile, srcFile.getName());
									if(!rtnFalg){
										sendFilestoErrorLocation(srcFile, false);
										if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
											sendFilestoErrorLocation(decryptedFile, true);
									}
								}else{
									rtnFalg = false;
									//send email....for no file status found...
									logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Didn't get File Status ID for Import status file : "+srcFile.getName()+"]");
									String bodyContent = "Didn't get File Status ID for Import status file.";
									try {
										if(emailService == null)emailService = new EmailService();
										emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
									} catch (MessagingException e1) {
										logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
									}
									logger.error("So, Going to move file into error location.....");
									sendFilestoErrorLocation(srcFile, false);
									if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
										sendFilestoErrorLocation(decryptedFile, true);
								}
							}else{
								rtnFalg = false;
								//send email....for no business destination folder found...
								logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Didn't get Business details for Import status file : "+srcFile.getName()+"]");
								String bodyContent = "Didn't get Business details for Import status file.";
								try {
									if(emailService == null)emailService = new EmailService();
									emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
								} catch (MessagingException e1) {
									logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
								}
								logger.error("So, Going to move file into error location.....");
								sendFilestoErrorLocation(srcFile, false);
								if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
									sendFilestoErrorLocation(decryptedFile, true);
							}
						}else{
							rtnFalg = false;
							logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Didn't get Business Name from Import status file name : "+srcFile.getName()+"]");
							//didn't get businessName at into file
							String bodyContent = "Didn't get Business Name from Import status file name.";
							try {
								if(emailService == null)emailService = new EmailService();
								emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
							} catch (MessagingException e1) {
								logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
							}
							logger.error("So, Going to move file into error location.....");
							sendFilestoErrorLocation(srcFile, false);
							if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
								sendFilestoErrorLocation(decryptedFile, true);
						}
					}else{
						rtnFalg = false;
						logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Not able to get Actual file name from source file : "+srcFile.getName()+"]");
						//didn't get actual file name from source file
						String bodyContent = "Didn't get Actual file name from source file name. File naming convention is not proper. It should be "
								+ "like this....'fileNameWithDateTime.xml_tsaIdentifier_businessName.pgp'";
						try {
							if(emailService == null)emailService = new EmailService();
							emailService.sendPainMailNotification("File naming convention error", srcFile.getName(), bodyContent);
						} catch (MessagingException e1) {
							logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
						}
						logger.error("So, Going to move file into error location.....");
						sendFilestoErrorLocation(srcFile, false);
						if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
							sendFilestoErrorLocation(decryptedFile, true);
					}
				}else{
					rtnFalg = false;
					//send email...src file not found at database
					logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Didn't get source file details for Import status file : "+srcFile.getName()+"]");
					String bodyContent = "Didn't get source file details for Import status file.";
					try {
						if(emailService == null)emailService = new EmailService();
						emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
					} catch (MessagingException e1) {
						logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
					}
					logger.error("So, Going to move file into error location.....");
					sendFilestoErrorLocation(srcFile, false);
					if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
						sendFilestoErrorLocation(decryptedFile, true);
				}
			}else{
				rtnFalg = false;
				//send email...fileName tag not found
				logger.info("[FileDecriptionServiceImpl.class] [inside processImportStatusFile()] [Filename tag is blank/null in source file : "+srcFile.getName()+"]");
				String bodyContent = "Filename tag is blank/null in source file.";
				try {
					if(emailService == null)emailService = new EmailService();
					emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
				} catch (MessagingException e1) {
					logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
				}
				logger.error("So, Going to move file into error location.....");
				sendFilestoErrorLocation(srcFile, false);
				if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
					sendFilestoErrorLocation(decryptedFile, true);
			}
		}catch(Exception ex){
			rtnFalg = false;
			logger.error("Got Exception...Going to move file into error location.....");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			sendFilestoErrorLocation(srcFile, false);
			if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
				sendFilestoErrorLocation(decryptedFile, true);
		}
		return rtnFalg;
	}
	
	/**
	 * Method used for process the Manual file type
	 * @param decryptedFile
	 * @param srcFile
	 * @return
	 */
	private boolean processManualFile(File decryptedFile, File srcFile) {
		logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()]");
		boolean rtnFalg = false;
		
		try{
			String fileNameTagVal = readCMMImportXmlFile(decryptedFile, srcFile.getName());
			if(fileNameTagVal != null && !fileNameTagVal.trim().equals("")){
				logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()] [Going to get Segregator File details by fileName tag]");
				List<SegregatorFileBean> segregatorFileList =systemDAOImpl.getSegregatorFileDetails(fileNameTagVal.trim().toUpperCase());
				if(segregatorFileList != null && segregatorFileList.size() > 0){
					SegregatorFileBean segregatorFileBean = segregatorFileList.get(0);
					//going to get business details...
					List<PFIBusiness> pfiBusinessList = systemDAOImpl.getPFIBusinessDetailsByBusinessName(PaymentHubUtility.pfiManulBusiness.toUpperCase());
					if(pfiBusinessList != null && pfiBusinessList.size() > 0){
						PFIBusiness pfiBusiness = pfiBusinessList.get(0);
						//going to get filestatusID...
						List<FileStatusBean> fileStatusList =  systemDAOImpl.getFileStatusDetailsByDescryption(PaymentHubUtility.importStatusfileDesc.toUpperCase());
						if(fileStatusList != null && fileStatusList.size() > 0){
							FileStatusBean fileStatusBean = fileStatusList.get(0);
							
							if(isTransactionDetailsPersist.equals("Y")){
								//going to get transaction details from source file....
								List<PfiTransactionsBean> txnDtlsList = getTransactionLevelDetailsFromXmlFile(decryptedFile, srcFile.getName(), segregatorFileBean);
								if(txnDtlsList != null && txnDtlsList.size() > 0){
									systemDAOImpl.batchUpdatePFITxnDetails(txnDtlsList);
								}
							}
							
							updateImportStatusFileNameInSegregator(srcFile.getName(),segregatorFileBean.getSegregatorFileID(), 
									srcFile.getName(), fileStatusBean.getFileStatusID());
							rtnFalg = sendFilestoNASLocation(decryptedFile, pfiBusiness.getPfiRespFilesLocation(), srcFile.getName(), srcFile.getName());
							if(!rtnFalg){
								sendFilestoErrorLocation(srcFile, false);
								if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
									sendFilestoErrorLocation(decryptedFile, true);
							}
						}else{
							rtnFalg = false;
							//send email....for no file status found...
							logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()] [Didn't get File Status ID for Manual file : "+srcFile.getName()+"]");
							String bodyContent = "Didn't get File Status ID for Manual file.";
							try {
								if(emailService == null)emailService = new EmailService();
								emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
							} catch (MessagingException e1) {
								logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
							}
							logger.error("So, Going to move file into error location.....");
							sendFilestoErrorLocation(srcFile, false);
							if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
								sendFilestoErrorLocation(decryptedFile, true);
						}
					}else{
						rtnFalg = false;
						//send email....for no business destination folder found...
						logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()] [Didn't get Business details for Manual file : "+srcFile.getName()+"]");
						String bodyContent = "Didn't get Business details for Manual file.";
						try {
							if(emailService == null)emailService = new EmailService();
							emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
						} catch (MessagingException e1) {
							logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
						}
						logger.error("So, Going to move file into error location.....");
						sendFilestoErrorLocation(srcFile, false);
						if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
							sendFilestoErrorLocation(decryptedFile, true);
					}
				}else{
					rtnFalg = false;
					//send email...src file not found at database
					logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()] [Didn't get source file details for Manual file : "+srcFile.getName()+"]");
					String bodyContent = "Didn't get source file details for Manual file.";
					try {
						if(emailService == null)emailService = new EmailService();
						emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
					} catch (MessagingException e1) {
						logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
					}
					logger.error("Going to move file into error location.....");
					sendFilestoErrorLocation(srcFile, false);
					if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
						sendFilestoErrorLocation(decryptedFile, true);
				}
			}else{
				rtnFalg = false;
				//send email...fileName tag not found
				logger.info("[FileDecriptionServiceImpl.class] [inside processManualFile()] [Filename tag is blank/null in source file : "+srcFile.getName()+"]");
				String bodyContent = "Filename tag is blank/null in source file.";
				try {
					if(emailService == null)emailService = new EmailService();
					emailService.sendPainMailNotification("Data Error", srcFile.getName(), bodyContent);
				} catch (MessagingException e1) {
					logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
				}
				logger.error("So, Going to move file into error location.....");
				sendFilestoErrorLocation(srcFile, false);
				if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
					sendFilestoErrorLocation(decryptedFile, true);
			}	
		}catch(Exception ex){
			rtnFalg = false;
			logger.error("Got Exception inside processManualFile()...Going to move file into error location.....");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			sendFilestoErrorLocation(srcFile, false);
			if(keepPlainFile.equals("Y") && decryptedFile!= null && decryptedFile.exists())
				sendFilestoErrorLocation(decryptedFile, true);
		}
		return rtnFalg;
	}
	
	/**
	 * Method used for process BAI file
	 * @param decryptFile, srcFile
	 * @return
	 */
	private boolean processBAIFile(File decryptFile, File srcFile) {
		logger.info("[FileDecriptionServiceImpl.class] [inside processBAIFile()]");
		logger.info("[FileDecriptionServiceImpl.class] [inside processBAIFile()] [BAI file is already decrypted. Need to re-direct only.]");
		
		String baiDecryptedFileName = decryptFile.getName();
		File baiDecryptedFileLocation = new File(baiLocation+baiDecryptedFileName);
		File baiEncryptedFileLocation = new File(baiLocation+srcFile.getName());
		logger.info("[FileDecriptionServiceImpl.class] [inside processBAIFile()] [Going to send BAI file..]");
		try {
			logger.info("[FileDecriptionServiceImpl.class] [Inside processBAIFile()] [Going to send Encrypted & Decrypted file into BAI location]");
			Files.copy (decryptFile.toPath(), baiDecryptedFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			Files.copy (srcFile.toPath(), baiEncryptedFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [Inside processBAIFile()] [Encrypted & Decrypted file sent to BAI location successfully.]");
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [Inside processBAIFile()] [Got IOException in copying file to BAI location]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to BAI NAS location", srcFile.getName());
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
		} 
		
		return false;
	}
	
	/**
	 * Method used for process Crestal Report file
	 * @param decryptFile, srcFile
	 * @return
	 */
	private boolean processCrestalReportFile(File decryptFile, File srcFile) {
		logger.info("[FileDecriptionServiceImpl.class] [inside processCrestalReportFile()]");
		logger.info("[FileDecriptionServiceImpl.class] [inside processCrestalReportFile()] [CR file is already decrypted. Need to re-direct only.]");
		
		String crDecryptedFileName = decryptFile.getName();
		File crDecryptedFileLocation = new File(crLocation+crDecryptedFileName);
		File crEncryptedFileLocation = new File(crLocation+srcFile.getName());
		logger.info("[FileDecriptionServiceImpl.class] [inside processCrestalReportFile()] [Going to copy CR file..]");
		try {
			logger.info("[FileDecriptionServiceImpl.class] [Inside processCrestalReportFile()] [Going to send Encrypted & Decrypted file into CR location]");
			Files.copy (decryptFile.toPath(), crDecryptedFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			Files.copy (srcFile.toPath(), crEncryptedFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [Inside processCrestalReportFile()] [Encrypted & Decrypted file copied at CR location successfully.]");
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [Inside processCrestalReportFile()] [Got IOException in copying file to CR location]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to CR NAS location", srcFile.getName());
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
		} 
		
		return false;
	}
	
	/**
	 * 
	 * @param actualSrcFile, segregatorFileId, sourceFile
	 */
	private void updateImportStatusFileNameInSegregator(String actualSrcFile,
			long segregatorFileId, String srcFileName, Integer fileStatusID) {
		logger.error("Inside updateImportStatusFileNameInSegregator()...");
		try{
			logger.error("Going to update import status file name & File Status ID into database...");
			systemDAOImpl.updateImportStatusFileNameInSegregator(actualSrcFile, segregatorFileId, fileStatusID);
			logger.error("Import status file name & File Status ID updated into database successfully.");
		}catch(Exception ex){
			logger.error("Got Exception inside updateImportStatusFileNameInSegregator()...");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));	
			
			String bodyContent = "Got SQL Error in Updating import file name. ";
			bodyContent += ex.toString();
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendPainMailNotification("SQL Error", srcFileName, bodyContent);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Method used for reading <Filename> tag from source file
	 * @param decryptedFile, srcFileName
	 * @return
	 */
	private String readCMMImportXmlFile(File decryptedFile, String srcFileName){
		logger.info("Inside readXmlFile() of FileDecriptionServiceImpl class...");
		String rtnFileName = "";
		try {
			logger.info("Going to create DocumentBuilderFactory instance...");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			logger.info("Going to create DocumentBuilder object...");
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			logger.info("Going to read xml by DocumentBuilder object...");
			Document doc = dBuilder.parse(decryptedFile);
			doc.getDocumentElement().normalize();
			
			logger.info("Going to get Element object of xml file...");
			Element eElement = doc.getDocumentElement();
			
			logger.info("Going to get Filename tag value from xml file...");
			rtnFileName = eElement.getElementsByTagName("Filename").item(0).getTextContent();
			int lastIndex = rtnFileName.lastIndexOf("\\");
			if(lastIndex < 0){
				lastIndex = rtnFileName.lastIndexOf("/");
			}
			rtnFileName = rtnFileName.substring(lastIndex+1, rtnFileName.length() );	
			logger.info("Got the fileName from xml file..."+rtnFileName);
		
		} catch (ParserConfigurationException | SAXException | IOException e) {
			logger.error("Got ParserConfigurationException | SAXException | IOException inside readXmlFile()...");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
			
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(e, "Input File Parser Error", srcFileName);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			throw new RuntimeException(e);
		} catch (Exception ex){
			logger.error("Got Exception inside readXmlFile()...");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));	
			
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Generic ERROR", srcFileName);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			throw new RuntimeException(ex);
		}
		
		return rtnFileName;
	}
	
	/**
	 * Method used for extracting the transaction details from source file
	 * @param decryptedFile, srcFileName, segregatorBean
	 * @return
	 */
	private List<PfiTransactionsBean> getTransactionLevelDetailsFromXmlFile(File decryptedFile, String srcFileName, SegregatorFileBean segregatorBean){
		logger.info("Inside getTransactionLevelDetailsFromXmlFile() of FileDecriptionServiceImpl class...");
		List<PfiTransactionsBean> rtnTxnDetailsList = new ArrayList<PfiTransactionsBean>();
		try {
			logger.info("Going to create DocumentBuilderFactory instance...");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			logger.info("Going to create DocumentBuilder object...");
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			logger.info("Going to read xml by DocumentBuilder object...");
			Document doc = dBuilder.parse(decryptedFile);
			doc.getDocumentElement().normalize();
			
			logger.info("Going to get Element object of xml file...");
			Element eElement = doc.getDocumentElement();
			
			logger.info("Going to read some tag from source file...");
			String operatorID = null;
			String operatorName = null;
			if(eElement.getElementsByTagName("Operator_ID").item(0) != null){
				operatorID = (eElement.getElementsByTagName("Operator_ID").item(0).getTextContent().trim());
				if(operatorID.trim().isEmpty())operatorID=null;
			}
			if(eElement.getElementsByTagName("Operator_Name").item(0) != null){
				operatorName = (eElement.getElementsByTagName("Operator_Name").item(0).getTextContent().trim());
				if(operatorName.trim().isEmpty())operatorName=null;
			}
			
			logger.info("Going to Prepare list for saving transaction detila...");
			NodeList txnNodeList = doc.getElementsByTagName("Transaction");
			for (int i = 0; i < txnNodeList.getLength(); i++) {
				Node txnNode = txnNodeList.item(i);
				Element txnElement = (Element) txnNode;
				PfiTransactionsBean txnBean = new PfiTransactionsBean();
				txnBean = setDefaultTxnDetails(txnBean, segregatorBean, operatorID, operatorName);
				if(txnElement.getElementsByTagName("Source_Line").item(0) != null && 
						txnElement.getElementsByTagName("Source_Line").item(0).getTextContent().trim().length() > 0){
					txnBean.setRecordNumber(txnElement.getElementsByTagName("Source_Line").item(0).getTextContent().trim());
				}
				if(txnElement.getElementsByTagName("Debit_Bank_Route_Code").item(0) != null && 
						txnElement.getElementsByTagName("Debit_Bank_Route_Code").item(0).getTextContent().trim().length() > 0){
					txnBean.setDebitBankRouteCode(txnElement.getElementsByTagName("Debit_Bank_Route_Code").item(0).getTextContent().trim());
				}
				if(txnElement.getElementsByTagName("Debit_Account_Number").item(0) != null && 
						txnElement.getElementsByTagName("Debit_Account_Number").item(0).getTextContent().trim().length() > 0){
					txnBean.setDebitAccountNumber(txnElement.getElementsByTagName("Debit_Account_Number").item(0).getTextContent().trim());
				}
				if(txnElement.getElementsByTagName("Credit_Bank_Route_Code").item(0) != null && 
						txnElement.getElementsByTagName("Credit_Bank_Route_Code").item(0).getTextContent().trim().length() > 0){
					txnBean.setCreditBankRouteCode(txnElement.getElementsByTagName("Credit_Bank_Route_Code").item(0).getTextContent().trim());
				}
				if(txnElement.getElementsByTagName("Credit_Account_Number").item(0) != null && 
						txnElement.getElementsByTagName("Credit_Account_Number").item(0).getTextContent().trim().length() > 0){
					txnBean.setCreditAccountNumber(txnElement.getElementsByTagName("Credit_Account_Number").item(0).getTextContent().trim());
				}
				if(txnElement.getElementsByTagName("Error_Message").item(0) != null && 
						txnElement.getElementsByTagName("Error_Message").item(0).getTextContent().trim().length() > 0){
					String errorMsg = txnElement.getElementsByTagName("Error_Message").item(0).getTextContent().trim();
					if(errorMsg.length() > 500)
						errorMsg = errorMsg.substring(0, 500);
					else
						errorMsg = errorMsg.substring(0, errorMsg.length());
					txnBean.setExtractionStatus(errorMsg);
				}
				rtnTxnDetailsList.add(txnBean);
			}
			logger.info("transaction detila prepared...");
		
		} catch (ParserConfigurationException | SAXException | IOException e) {
			logger.error("Got ParserConfigurationException | SAXException | IOException inside getTransactionLevelDetailsFromXmlFile()...");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(e));
			
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(e, "Input File Parser Error", srcFileName);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			throw new RuntimeException(e);
		} catch (Exception ex){
			logger.error("Got Exception inside getTransactionLevelDetailsFromXmlFile()...");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));	
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Generic ERROR", srcFileName);
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			throw new RuntimeException(ex);
		}
		
		return rtnTxnDetailsList;
	}
	
	/**
	 * Method used for setting the default value as null into Transaction bean
	 * @param PfiTransactionsBean
	 * @return
	 */
	private PfiTransactionsBean setDefaultTxnDetails(PfiTransactionsBean txnBean, SegregatorFileBean segregatorBean, 
			String operatorID, String operatorName){
		txnBean.setSrcPaymentFileId(segregatorBean.getSrcPaymentFileID());
		txnBean.setSegregatorFileId(segregatorBean.getSegregatorFileID());
		txnBean.setDebitBankRouteCode(null);
		txnBean.setDebitAccountNumber(null);
		txnBean.setCreditBankRouteCode(null);
		txnBean.setCreditAccountNumber(null);
		txnBean.setOperatorID(operatorID);
		txnBean.setOperatorName(operatorName);
		txnBean.setExtractionStatus("Success");
		return txnBean;
	}
	
	/**
	 * Method used for sending source file to NAS location
	 * @param inputFile, nasLocation, actualSrcFileName
	 */
	private boolean sendFilestoNASLocation(File decryptedFile, String nasLocation, String actualSrcFileName, String srcFileName){
		logger.info("[FileDecriptionServiceImpl.class] [Inside sftpFilestoNASLocation()]");
		boolean rtnFalg = false;
		File nasFileLocation = new File(nasLocation+actualSrcFileName);
		try {
			Files.copy (decryptedFile.toPath(), nasFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [File copied at NAS locaiton.]");
			rtnFalg = true;
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [inside processControlStampFile()] [Got IOException in copying file to final NAS location.]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to final NAS location", srcFileName);
				rtnFalg = false;
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
				rtnFalg = false;
			}
		} 
		return rtnFalg;
	}
	
	/**
	 * Method used for sending source file to Error location
	 * @param inputFile
	 * @return
	 */
	private boolean sendFilestoErrorLocation(File inputFile, boolean isPlainFile){
		logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoErrorLocation()]");
		String errorFileName = inputFile.getName();
		//getting actual file name...
		if(isPlainFile)
			errorFileName = getActualSourceFileName(inputFile.getName());
		if(errorFileName==null || errorFileName.isEmpty())errorFileName = inputFile.getName();
		File errorFileLocation = new File(errorLocation+errorFileName);
		try {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoErrorLocation()] [Going to send file into Error location]");
			Files.copy (inputFile.toPath(), errorFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoErrorLocation()] [File sent to Error location successfully.]");
			return true;
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoErrorLocation()] [Got IOException in copying file to Error location]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to Error NAS location", inputFile.getName());
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			return false;
		} 
	}
	
	/**
	 * Method used for sending source file to Unknown location
	 * @param inputFile
	 * @return
	 */
	private boolean sendFilestoUnknownLocation(File inputFile){
		logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoUnknownLocation()]");
		File unknownFileLocation = new File(unknownLocation+inputFile.getName());
		try {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoUnknownLocation()] [Going to send file into Unknown location]");
			Files.copy (inputFile.toPath(), unknownFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoUnknownLocation()] [File sent to Unknown location successfully.]");
			return true;
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoUnknownLocation()] [Got IOException in copying file to Unknown location]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to Unknown NAS location", inputFile.getName());
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			return false;
		} 
	}
	
	
	
	/**
	 * Method used for sending source file to Archive location
	 * @param inputFile
	 * @return
	 */
	private boolean sendFilestoArchiveLocation(File inputFile, boolean isPlainFile){
		logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoArchiveLocation()]");
		String archiveFileName = inputFile.getName();
		//getting actual file name for Plain/Decrypted file...
		if(isPlainFile && !inputFile.getName().toUpperCase().startsWith(manualFileType.toUpperCase()))
			archiveFileName = getActualSourceFileName(inputFile.getName());
		if(archiveFileName==null || archiveFileName.isEmpty())archiveFileName = inputFile.getName();
		File archiveFileLocation = new File(archiveLocation+archiveFileName);
		try {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoArchiveLocation()] [Going to send file into Archive location...]");
			Files.copy (inputFile.toPath(), archiveFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoArchiveLocation()] [File sent to Archive location successfully.]");
			return true;
		} catch (IOException ex) {
			logger.info("[FileDecriptionServiceImpl.class] [Inside sendFilestoArchiveLocation()] [Got IOException in copying file to Archive location]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendMailNotificationWithException(ex, "Sending fail to Archive NAS location", inputFile.getName());
			} catch (MessagingException e1) {
				logger.error(PaymentHubUtility.getErrorFormStackTrace(e1));
			}
			return false;
		} 
	}
	
	
	private void deleteSrouceFile(File srcFile, File decryptedFile){
		logger.info("[FileDecriptionServiceImpl.class] [Inside deleteSrouceFile()]");
		logger.info("[FileDecriptionServiceImpl.class] [Inside deleteSrouceFile()] [Going to delete source file...]");
		if(srcFile.exists())
			srcFile.delete();
		if(decryptedFile!= null && decryptedFile.exists())
			decryptedFile.delete();
		logger.info("[FileDecriptionServiceImpl.class] [Inside deleteSrouceFile()] [Source file deleted successfully.]");
	}
	
	/**
	 * Method used for getting Actual File Name from source file
	 * @param srcFileName
	 * @return
	 */
	private String getActualSourceFileName(String srcFileName){
		logger.info("[FileDecriptionServiceImpl.class] [Inside getActualSourceFileName()]");
		try{
			logger.info("[FileDecriptionServiceImpl.class] [Inside getActualSourceFileName()] [Going to get actual file name without business name...]");
			int dotIdx = srcFileName.lastIndexOf(".");
			String fileName = srcFileName.substring(0, dotIdx);
			String fileExtn = srcFileName.substring(dotIdx, srcFileName.length());
			int underscoreIdx = fileExtn.indexOf("_");
			fileExtn = fileExtn.substring(0,underscoreIdx);
			logger.info("[FileDecriptionServiceImpl.class] [Inside getActualSourceFileName()] [Got the actual file name...File name is] : ["+fileName+fileExtn+"] ");
			return fileName+fileExtn;
		}catch(Exception ex){
			logger.info("[FileDecriptionServiceImpl.class] [Inside getActualSourceFileName()] [Got Exception in getting Actual file name...]");
			logger.error(PaymentHubUtility.getErrorFormStackTrace(ex));
			return null;
		}
	}
	
	/**
	 * Method used for getting Business Name from source file
	 * @param srcFileName
	 * @return
	 */
	private String getBusinessNamefromSourceFile(String srcFileName){
		int dotIdx = srcFileName.lastIndexOf(".");
		String fileExtn = srcFileName.substring(dotIdx, srcFileName.length());
		int underscoreIdx = fileExtn.lastIndexOf("_");
		
		return fileExtn.substring(underscoreIdx+1, fileExtn.length());
	}
	
	private String trimBAIFileTimeStamp(String decryptFile) {
		String fileNameWithoutPgp = decryptFile.substring(0, decryptFile.lastIndexOf("."));
		String fileNameWithTimeStamp = decryptFile.substring(0, fileNameWithoutPgp.lastIndexOf("."));
		String fileExtentionWithoutPgp = decryptFile.substring(fileNameWithoutPgp.lastIndexOf("."), fileNameWithoutPgp.length());
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		return fileNameWithTimeStamp.substring(0, underscoreIdx)+fileExtentionWithoutPgp;
	}

}
