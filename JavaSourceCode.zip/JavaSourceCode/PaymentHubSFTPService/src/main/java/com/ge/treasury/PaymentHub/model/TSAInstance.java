package com.ge.treasury.PaymentHub.model;

public class TSAInstance extends CommonBean {

	private String tsaInstanceIdentifier;
	private String pfiLocation;
	private String pfiRespFilesLocation;
	private String pfiPublicKeyPath;
	private String pfiRespFilePrivateKeyPath;
	private String deleteFlag;
	private String hostName;
	private String userId;
	private String manualLocation;
	private String pgpOptionId;
	private Integer tsaInstanceId;
	//private String password;

	/**
	 * @return the tsaInstanceIdentifier
	 */
	public String getTsaInstanceIdentifier() {
		return tsaInstanceIdentifier;
	}
	/**
	 * @param tsaInstanceIdentifier the tsaInstanceIdentifier to set
	 */
	public void setTsaInstanceIdentifier(String tsaInstanceIdentifier) {
		this.tsaInstanceIdentifier = tsaInstanceIdentifier;
	}
	/**
	 * @return the pfiLocation
	 */
	public String getPfiLocation() {
		return pfiLocation;
	}
	/**
	 * @param pfiLocation the pfiLocation to set
	 */
	public void setPfiLocation(String pfiLocation) {
		this.pfiLocation = pfiLocation;
	}
	/**
	 * @return the pfiRespFilesLocation
	 */
	public String getPfiRespFilesLocation() {
		return pfiRespFilesLocation;
	}
	/**
	 * @param pfiRespFilesLocation the pfiRespFilesLocation to set
	 */
	public void setPfiRespFilesLocation(String pfiRespFilesLocation) {
		this.pfiRespFilesLocation = pfiRespFilesLocation;
	}
	/**
	 * @return the pfiPublicKeyPath
	 */
	public String getPfiPublicKeyPath() {
		return pfiPublicKeyPath;
	}
	/**
	 * @param pfiPublicKeyPath the pfiPublicKeyPath to set
	 */
	public void setPfiPublicKeyPath(String pfiPublicKeyPath) {
		this.pfiPublicKeyPath = pfiPublicKeyPath;
	}
	/**
	 * @return the pfiRespFilePrivateKeyPath
	 */
	public String getPfiRespFilePrivateKeyPath() {
		return pfiRespFilePrivateKeyPath;
	}
	/**
	 * @param pfiRespFilePrivateKeyPath the pfiRespFilePrivateKeyPath to set
	 */
	public void setPfiRespFilePrivateKeyPath(String pfiRespFilePrivateKeyPath) {
		this.pfiRespFilePrivateKeyPath = pfiRespFilePrivateKeyPath;
	}
	/**
	 * @return the deleteFlag
	 */
	public String getDeleteFlag() {
		return deleteFlag;
	}
	/**
	 * @param deleteFlag the deleteFlag to set
	 */
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}
	/**
	 * @param hostName the hostName to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the password
	 */
	/*public String getPassword() {
		return password;
	}*/
	/**
	 * @param password the password to set
	 */
	/*public void setPassword(String password) {
		this.password = password;
	}*/
	/**
	 * @return the manualLocation
	 */
	public String getManualLocation() {
		return manualLocation;
	}
	/**
	 * @param manualLocation the manualLocation to set
	 */
	public void setManualLocation(String manualLocation) {
		this.manualLocation = manualLocation;
	}
	/**
	 * @return the pgpOptionId
	 */
	public String getPgpOptionId() {
		return pgpOptionId;
	}
	/**
	 * @param pgpOptionId the pgpOptionId to set
	 */
	public void setPgpOptionId(String pgpOptionId) {
		this.pgpOptionId = pgpOptionId;
	}
	/**
	 * @return the tsaInstanceId
	 */
	public Integer getTsaInstanceId() {
		return tsaInstanceId;
	}
	/**
	 * @param tsaInstanceId the tsaInstanceId to set
	 */
	public void setTsaInstanceId(Integer tsaInstanceId) {
		this.tsaInstanceId = tsaInstanceId;
	}
	
}
