package com.ge.treasury.PaymentHub.sftp.decryption.decryptService;

import java.io.File;

import com.ge.treasury.PaymentHub.sftp.decryption.exception.FileEncryptionDecryptionException;

public interface PaymentMergerDecryptionService {
	
	public String decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException;
	
}
