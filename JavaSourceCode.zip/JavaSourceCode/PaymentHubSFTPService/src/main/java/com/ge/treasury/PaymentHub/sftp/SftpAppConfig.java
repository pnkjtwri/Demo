/**
 * 
 */
package com.ge.treasury.PaymentHub.sftp;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

import com.ge.treasury.PaymentHub.model.TSAInstance;

/**
 * @author padmajaarekuti
 *
 */
@Configuration
public class SftpAppConfig { 
	
	/*@Bean(name="lookupService")
	public EnvironmentLookupService lookupService() {
	    System.out.println("lookupService bean");
	    return new  EnvironmentLookupService();
	}*/
	
	/*@Bean
    public DefaultSftpSessionFactory sftpSessionFactory(TSAInstance instance) {
        DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(
                true);
        factory.setHost(instance.getHostName());
        factory.setPort(22);
        factory.setUser(instance.getUserId());
        factory.setPassword("Cap$itaAl1515@e");   
        Properties sessionConfig= new Properties();
        sessionConfig.put("PreferredAuthentications", "password");
        sessionConfig.put("StrictHostKeyChecking", "no");
		factory.setSessionConfig(sessionConfig);
        return factory;
    }*/
}
