/**
 * 
 */
package com.ge.treasury.PaymentHub.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.ge.treasury.PaymentHub.util.PaymentHubUtility;

/**
 * @author padmajaarekuti
 *
 */
@Service
public class EmailService {

	final static Logger logger = Logger.getLogger(EmailService.class);
	
    @Autowired 
    private JavaMailSender mailSender;
    
    @Autowired 
    private TemplateEngine templateEngine;
 
    @Value("${recipientDL}")
	private String recipientEmail;
    
    @Value("${fromDL}")
	private String fromDL;
    
    
    public void sendMailNotificationWithException(Exception ex, String mailSubject, String sourceFileName) throws MessagingException {
    	logger.info("[EmailService.class] [inside sendMailNotificationWithException()]");
		logger.info("[EmailService.class] [inside sendMailNotificationWithException()] [Going to send E-Mail notification with Stack-Trace...]");
		Map<String,Object> mailContent = mailContent(ex,sourceFileName);
		sendMail("email-simple2", mailSubject, mailContent);
		logger.info("[EmailService.class] [inside sendMailNotificationWithException()] [E-Mail notification has sent with Stack-Trace successfully.]");
	}
    
    public void sendPainMailNotification(String mailSubject, String sourceFileName, String error) throws MessagingException {
		logger.info("[EmailService.class] [inside sendPainMailNotification()]");
		logger.info("[EmailService.class] [inside sendPainMailNotification()] [Going to send E-Mail notification...]");
		Map<String,Object> mailContentMap = new HashMap<String, Object>();
		InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            PaymentHubUtility.getErrorFormStackTrace(e);
        }
        mailContentMap.put("sourceFileName", sourceFileName);
        mailContentMap.put("hostName", hostAndIP.getHostAddress());
        mailContentMap.put("shortMsg", error );
        mailContentMap.put("longMsg", "NA" );  
		
		sendMail("email-simple2", mailSubject, mailContentMap);
		logger.info("[EmailService.class] [inside sendPainMailNotification()] [E-Mail notification has sent successfully.]");
	}
    
    /**
     * Preparing mail body content
     * @param ex, sourceFileName
     * @return
     */
    private Map<String,Object> mailContent(Exception ex, String sourceFileName){
		Map<String,Object> mailContentMap = new HashMap<String, Object>();
		
		InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
        	PaymentHubUtility.getErrorFormStackTrace(e);
        }
        mailContentMap.put("sourceFileName", sourceFileName);
        mailContentMap.put("hostName", hostAndIP.getHostAddress());
        if(ex != null){
	        String shortMsg = ((ex.getMessage() != null && ex.getMessage().length() > 218) ? ex.getMessage().substring(0,218):ex.getMessage());
	        mailContentMap.put("shortMsg", shortMsg );
	        mailContentMap.put("longMsg", PaymentHubUtility.getErrorFormStackTrace(ex));
        }else{
        	
        }
        
		return mailContentMap;
	}
    
    /* 
     * Send HTML mail (simple) 
     */
    private void sendMail(final String templateNm, String subject, Map<String,Object> bodyContent) 
            throws MessagingException {
    	Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
        // Prepare the evaluation context
        final Context ctx = new Context(bLocale);
        //ctx.setVariable("name", recipientName);
        ctx.setVariable("bodyContent", bodyContent);
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);

    }
 
    
    /* 
     * Send HTML mail with attachment. 
     */
    public void sendMailWithAttachment(
            final String recipientName, final String recipientEmail, final String attachmentFileName, 
            final byte[] attachmentBytes, final String attachmentContentType, final Locale locale) 
            throws MessagingException {
        
        // Prepare the evaluation context
        final Context ctx = new Context(locale);
        ctx.setVariable("name", recipientName);
        ctx.setVariable("subscriptionDate", new Date());
        ctx.setVariable("hobbies", Arrays.asList("Cinema", "Sports", "Music"));
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = 
                new MimeMessageHelper(mimeMessage, true /* multipart */, "UTF-8");
        message.setSubject("Example HTML email with attachment");
        message.setFrom("thymeleaf@example.com");
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process("email-withattachment.html", ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Add the attachment
        final InputStreamSource attachmentSource = new ByteArrayResource(attachmentBytes);
        message.addAttachment(
                attachmentFileName, attachmentSource, attachmentContentType);
        
        // Send mail
        this.mailSender.send(mimeMessage);
        
    }
 

}