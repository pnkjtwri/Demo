package com.ge.treasury.PaymentHub.sftp.decryption.util;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.util.Iterator;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.BOMInputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.treasury.PaymentHub.sftp.decryption.exception.FileEncryptionDecryptionException;

public class PGPUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(PGPUtils.class);

    /**
     * Load a secret key and find the private key in it
     * @param pgpSecKey The secret key
     * @param pass passphrase to decrypt secret key with
     * @return
     * @throws PGPException
     */
    public static PGPPrivateKey findPrivateKey(PGPSecretKey pgpSecKey, char[] pass) throws FileEncryptionDecryptionException{
    	if (pgpSecKey == null) return null;
    	 PGPPrivateKey pgpPvtKey = null;
    	 try{
	        PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(pass);
	        pgpPvtKey = pgpSecKey.extractPrivateKey(decryptor);
    	 }catch(Exception e){
    		 throw new FileEncryptionDecryptionException("Private Key have some issue",e);
    	 }
        return pgpPvtKey;
    }
	
	/**
     * Load a secret key ring collection from keyIn and find the private key corresponding to
     * keyID if it exists.
     *
     * @param keyIn input stream representing a key ring collection.
     * @param keyID keyID we want.
     * @param pass passphrase to decrypt secret key with.
     * @return
     * @throws IOException
     * @throws PGPException
     * @throws NoSuchProviderException
     */
    public  static PGPPrivateKey findPrivateKey(InputStream keyIn, long keyID, char[] pass) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - findPrivateKey started..");
    	PGPPrivateKey pgpPvtKey = null;
    	try{
	        PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn));
	        pgpPvtKey = findPrivateKey(pgpSec.getSecretKey(keyID), pass);
    	}catch(Exception e){
    		logger.error("[PGPUtils] - findPrivateKey method has exception !!");
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
            throw new FileEncryptionDecryptionException("Private Key have some issue",e);
    	}
    	logger.info("[PGPUtils] - findPrivateKey Completed !!..");
        return pgpPvtKey;

    }

    /**
     * decrypt the passed in message stream
     * @param writeToFile 
     * @throws IOException 
     * @throws PGPException 
     */
    @SuppressWarnings("null")
	public static void decryptFile(InputStream in, StringBuffer decryptedData, InputStream keyIn, char[] passwd, String outputFileName) throws FileEncryptionDecryptionException{
    	logger.info("[PGPUtils] - Decrypting Process started...");
    	 PGPSecurity psec=new PGPSecurity();
    	 int retrycount = 0;
    	 int maxretry = 4;
    	try{
	    	//Security.addProvider(new BouncyCastleProvider()); 
    		 Provider provider = Security.getProvider("BC");
    		 if (provider==null){
    			logger.info("Provider is not added. Going to add BouncyCastleProvider to Java security");
                provider = new BouncyCastleProvider();
    	        Security.addProvider(provider);
    	    }
	        PGPObjectFactory pgpF = null;   
	        Object o = validPGPAlgorithm(in,pgpF);
	        // the first object might be a PGP marker packet.
	        if (o instanceof  PGPEncryptedDataList) {
	            psec.setEncryptedData ((PGPEncryptedDataList) o); 
	        } else {
	        	 psec.setEncryptedData ((PGPEncryptedDataList) pgpF.nextObject());
	        } 
	        validatePrivateKey(psec,keyIn,passwd);
	        if(psec.getSecretKey()!=null){
	        	writeFileContent(psec.getPkEncryptedData(),psec.getSecretKey(),decryptedData,outputFileName);
	        }
	        logger.info("[PGPUtils] - Decrypting Process completed !!");
    	}catch(Exception e){
    		if(e instanceof FileEncryptionDecryptionException && retrycount<maxretry)
    		{
    			logger.info("[PGPUtils] - Error while writing content of file. Reason is: "+e.getMessage());
    			try{
    				logger.info("[PGPUtils] - calling method writeFileContent again ");
    				writeFileContent(psec.getPkEncryptedData(),psec.getSecretKey(),decryptedData,outputFileName);
    			}
    			catch(Exception e1){
    	    		logger.info("[PGPUtils] - Error while decrypting file ");
    	    		throw new FileEncryptionDecryptionException("Not able to Decrypt the file - ",e1);
    	    		}

    		}
    		else{
    		logger.info("[PGPUtils] - Error while decrypting file ");
    		throw new FileEncryptionDecryptionException("Not able to Decrypt the file - ",e);
    		}
    	}
    }

	/**
     * 
     * @param psec
     * @param keyIn
     * @param passwd
     * @throws PGPFileDecryptException
     */
    private static void validatePrivateKey( PGPSecurity psec, InputStream keyIn, char[] passwd) throws FileEncryptionDecryptionException {
    	logger.info("[PGPUtils] - validatePrivateKey:entered");
    	// find the secret key
        @SuppressWarnings("unchecked")
		Iterator<PGPPublicKeyEncryptedData> it = psec.getEncryptedData().getEncryptedDataObjects(); 
        
        PGPPrivateKey sKey=null;
        PGPPublicKeyEncryptedData pbe=null;
        while (sKey == null && it.hasNext()) {
            pbe = it.next(); 
            try {
				sKey = findPrivateKey(keyIn, pbe.getKeyID(), passwd); 
			} catch (Exception e) {
				throw new FileEncryptionDecryptionException("Secret key for message not found or invalid secret key.",e);
			}
        }

        if (sKey == null) { 
            throw new FileEncryptionDecryptionException("Secret key for message not found or invalid secret key.");
        } 

        psec.setPkEncryptedData(pbe);
        psec.setSecretKey(sKey); 
        
        logger.info("[PGPUtils] - validatePrivateKey completed !!");
	}

    /**
     * 
     * @param pbe
     * @param sKey
     * @param out
     * @throws PGPException
     * @throws IOException
     */
	private static void writeFileContent(PGPPublicKeyEncryptedData pbe, PGPPrivateKey sKey,StringBuffer decryptedData,String outputFileName) throws FileEncryptionDecryptionException {
		logger.info("[PGPUtils] - writing File Content  started..");
		BufferedWriter bufferWriter = null;
		FileWriter fileWriter     = null;
		InputStream inputStream = null;
		BOMInputStream bomStream = null;
		
		InputStream bomInStream = null;
        InputStream dataStream  = null;
        ByteArrayOutputStream baos = null;
		
		try{
    	InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
        PGPObjectFactory plainFact = new PGPObjectFactory(clear);
        Object message = plainFact.nextObject();

        if (message instanceof  PGPCompressedData) {
            PGPCompressedData cData = (PGPCompressedData) message;
            PGPObjectFactory pgpFact = new PGPObjectFactory(cData.getDataStream()); 
            message = pgpFact.nextObject();
        }
        
        File file = new File(outputFileName);
        fileWriter = new FileWriter(file.getAbsoluteFile());
		bufferWriter = new BufferedWriter(fileWriter);
		
        if (message instanceof  PGPLiteralData) { 
            PGPLiteralData ld = (PGPLiteralData) message;

            inputStream = ld.getInputStream();
            
            /**Copy the source stream in to baos*/
            baos = new ByteArrayOutputStream();
            IOUtils.copy(inputStream, baos);
            byte[] bytes = baos.toByteArray();
            
            bomInStream = new ByteArrayInputStream(bytes);
            dataStream  = new ByteArrayInputStream(bytes);
            
            bomStream = new BOMInputStream(bomInStream);
            int ch;
            
            if(bomStream.hasBOM()){
		         while ((ch = bomStream.read()) >= 0) {
		        	//out.write(ch);
		            decryptedData.append((char)ch);
		            bufferWriter.write((char)ch);
		         }
           }else{
           	while ((ch = dataStream.read()) >= 0) {
		        	//out.write(ch);
		            decryptedData.append((char)ch);
		            bufferWriter.write((char)ch);
		         }
           }
        } else if (message instanceof  PGPOnePassSignatureList) {
        	if(inputStream!=null)inputStream.close();
        	if(bomStream != null)bomStream.close();
        	bufferWriter.close();
        	fileWriter.close();
            throw new FileEncryptionDecryptionException("Encrypted message contains a signed message - not literal data.");
        } else {
        	if(inputStream!=null)inputStream.close();
        	if(bomStream != null)bomStream.close();
        	bufferWriter.close();
        	fileWriter.close();
            throw new FileEncryptionDecryptionException("Message is not a simple encrypted file - type unknown.");
        }

        if (pbe.isIntegrityProtected()) {
            if (!pbe.verify()) {
            	bufferWriter.close();
            	fileWriter.close();
            	throw new FileEncryptionDecryptionException("Message failed integrity check");
            }
        } 
        bomStream.close();
        bufferWriter.close();
    	fileWriter.close();
		}catch(Exception e){
			logger.error("[PGPUtils] - Writing content into the file has been failed.Error is:"+ e.getLocalizedMessage());
    		//logger.error("[PGPUtils] - "+PaymentSplitterUtility.getErrorFormStackTrace(e));
			throw new FileEncryptionDecryptionException("Writing content into the file has been failed",e);
		}
		finally{
			try{
			if(inputStream != null){
				inputStream.close();
			}
			if(bufferWriter != null){
				bufferWriter.close();
			}
			if(fileWriter != null){
				fileWriter.close();
			}
			if(bomStream != null){
				bomStream.close();
			}
			if(bomInStream != null){
				bomInStream.close();
			}
			if(dataStream != null){
				dataStream.close();
			}
			if(baos != null){
				baos.close();
			}
			}catch(Exception e){
				logger.error("[PGPUtils] - Error while closing stream while writing content.");
	    		logger.error("[PGPUtils] - "+PaymentDecryptionUtility.getErrorFormStackTrace(e));
			}
		}
    	logger.info("[PGPUtils] - writing File Content  started..");
	}

	/**
     * 
     * @param in
     * @param pgpF
     * @return
     * @throws PGPFileDecryptException
     */
    private static Object validPGPAlgorithm(InputStream in,PGPObjectFactory pgpF) throws FileEncryptionDecryptionException {  
    	logger.debug("validPGPAlgorithm: entered");
    	 Object obj =null; 
    	 try {
			in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);
			
			pgpF = new PGPObjectFactory(in); 

	        obj = pgpF.nextObject(); 
	        
	        if(obj == null){
	        	throw new FileEncryptionDecryptionException("File is not encrypted or it is empty");
	        } 
	        
		} catch (IOException ie) {
			throw new FileEncryptionDecryptionException(ie.getMessage());
		}
    	 logger.debug("validPGPAlgorithm: exit");
    	 return obj;
	}

}
