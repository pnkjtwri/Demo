package com.ge.treasury.PaymentHub.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.ge.treasury.PaymentHub.model.TSAInstance;
import com.ge.treasury.PaymentHub.sftp.mapper.TSAInstancesMapper;

@Service("envLookupService")
public class EnvironmentLookupService {

    private static final Logger logger = Logger.getLogger(EnvironmentLookupService.class);

    @Autowired
    @Qualifier("transactionManager")
    private PlatformTransactionManager txManager;

    @Autowired
    private TSAInstancesMapper tsaInstMapper;

    private final Map<String, TSAInstance> tsaConfig = new HashMap<String, TSAInstance>();
   
    /**
     * Loads all lookups used for File Management Interface from database
     */
   // @PostConstruct
    public void loadLookupData() {
       // logger.info("loading lookup cache");
        new TransactionTemplate(txManager).execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                loadLookups();
            }
        });
        // initialize();
    }

    /**
     * Refreshes the lookup caches
     */
    /*@Scheduled(cron = "${core.lookups.cache.refresh.cron}")*/
    public void refreshCache() {
        loadLookupData();
    }

    /**
     * Loads all lookups from database
     */
    protected void loadLookups() {
        final List<TSAInstance> list = tsaInstMapper.findAll();
        
        //System.out.println("List Size:"+list.size());
        logger.info("List Size:"+list.size());
        for (final TSAInstance property : list) {
        	if(property!=null){
        		//System.out.println("loadLookups"+ property.getTsaInstanceIdentifier());
        		logger.info("loadLookups - "+ property.getTsaInstanceIdentifier());
        		String key = String.valueOf(property.getTsaInstanceIdentifier())+ String.valueOf(property.getPgpOptionId());
        		//tsaConfig.put(String.valueOf(property.getTsaInstanceIdentifier()), property);
        		tsaConfig.put(key, property);
        	}
        }

    }

    /**
     * Will return configuration value for the key provided
     *
     * @param key
     * @return String
     */
    public TSAInstance retriveConfigValue(String key) {
        return tsaConfig.get(key);
    }

}
