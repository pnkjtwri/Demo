package com.ge.treasury.PaymentHub.model;


public class PFIBusiness extends CommonBean {
	
	private long pfiBusinessID;
	private String pfiBusinessName;
	private String mergeImportStatusFlg;
	private String splitReqFlg;
	private String pfiLocation;
	private String pfiRespFilesLocation;
	private String pgpOptionID;
	private String pgpOperatorID;
	private String deleteFlag;
	private String pfiRespInputLocation;
	private String pfiManualLocation;
	
	public long getPfiBusinessID() {
		return pfiBusinessID;
	}
	public void setPfiBusinessID(long pfiBusinessID) {
		this.pfiBusinessID = pfiBusinessID;
	}
	public String getPfiBusinessName() {
		return pfiBusinessName;
	}
	public void setPfiBusinessName(String pfiBusinessName) {
		this.pfiBusinessName = pfiBusinessName;
	}
	public String getMergeImportStatusFlg() {
		return mergeImportStatusFlg;
	}
	public void setMergeImportStatusFlg(String mergeImportStatusFlg) {
		this.mergeImportStatusFlg = mergeImportStatusFlg;
	}
	public String getSplitReqFlg() {
		return splitReqFlg;
	}
	public void setSplitReqFlg(String splitReqFlg) {
		this.splitReqFlg = splitReqFlg;
	}
	public String getPfiLocation() {
		return pfiLocation;
	}
	public void setPfiLocation(String pfiLocation) {
		this.pfiLocation = pfiLocation;
	}
	public String getPfiRespFilesLocation() {
		return pfiRespFilesLocation;
	}
	public void setPfiRespFilesLocation(String pfiRespFilesLocation) {
		this.pfiRespFilesLocation = pfiRespFilesLocation;
	}
	public String getPgpOptionID() {
		return pgpOptionID;
	}
	public void setPgpOptionID(String pgpOptionID) {
		this.pgpOptionID = pgpOptionID;
	}
	public String getPgpOperatorID() {
		return pgpOperatorID;
	}
	public void setPgpOperatorID(String pgpOperatorID) {
		this.pgpOperatorID = pgpOperatorID;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getPfiRespInputLocation() {
		return pfiRespInputLocation;
	}
	public void setPfiRespInputLocation(String pfiRespInputLocation) {
		this.pfiRespInputLocation = pfiRespInputLocation;
	}
	public String getPfiManualLocation() {
		return pfiManualLocation;
	}
	public void setPfiManualLocation(String pfiManualLocation) {
		this.pfiManualLocation = pfiManualLocation;
	}
	
}
