package com.ge.treasury.payment.lookupservices;

/**
 * <p>Class designed for Lookup Service Controller</p>
 * <p>Class will used for getting the AccontInfo and ModelInfo Data</p>
 * @author Pankaj1.Tiwari
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.treasury.payment.lookupservices.mail.EmailService;
import com.ge.treasury.payment.lookupservices.service.LookupDataService;

@RestController
public class LookupDataServiceController {
	private static Logger logger = Logger.getLogger(LookupDataServiceController.class);
	
	 @Autowired 
	 private EmailService emailService;
	
	 private Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
	 
	@Autowired ApplicationContext appContext;
	public void setAppContext(ApplicationContext appContext) {
		this.appContext = appContext;
	}

	/*@RequestMapping(value = "getAccountModeldataTest", method=RequestMethod.GET)
	public void testCall(){
		List<String> accountIDList1 = new ArrayList<String>(){{
			add("AT31"); add("AB01"); add("JB18"); add("3037"); 
		}};
		
		List<String> modelIDList1 = new ArrayList<String>(){{
			add("3034"); add("3035"); add("3036");
		}};
		
		Map<String, List<String>> inputParameter = new HashMap<String, List<String>>();
		inputParameter.put("accountIDList", accountIDList1);
		inputParameter.put("modelIDList", modelIDList1);
		
		callAccountAndModelLookupService(inputParameter);
	}*/
	
	/**
	 * Method used for getting AccountInfo and ModelInfo data into Map
	 * @author Pankaj1.Tiwari
	 * @param accountIDList
	 * @param modelIDList
	 * @return HashMap<Object, Object>
	 */
	@RequestMapping(value = "getAccountModeldata", method=RequestMethod.POST)
	public Map<Object, Object> callAccountAndModelLookupService(@RequestBody Map<String, List<String>> inputParameter){
		logger.debug("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()]");
		
		List<String> accountIDList =  inputParameter.get("accountIDList");
		if(accountIDList == null)accountIDList= new ArrayList<String>();
		List<String> modelIDList =  inputParameter.get("modelIDList");
		if(modelIDList == null)modelIDList = new ArrayList<String>();
		
		Map<Object, Object> rtnFinalMap = new HashMap<Object, Object>();
		try{
			logger.debug("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [loading spring-lookup-context.xml file.....]");
			if(appContext == null)
				appContext = new ClassPathXmlApplicationContext("springConfig/spring-lookup-context.xml");
			 LookupDataService serviceContext = appContext.getBean(LookupDataService.class);
			 rtnFinalMap.put("accountIinfoMap", serviceContext.accountLookupMethod(accountIDList));
			 rtnFinalMap.put("modelIinfoMap", serviceContext.modelLookupMethod(modelIDList));
			
		}catch(CannotGetJdbcConnectionException ex){
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Got CannotGetJdbcConnectionException Exception]");
			String bodyContent = "Not able to get database connection. Please check database credentials : ";
			bodyContent += ex.getMessage();
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("email-simple2", bLocale, "SQL Lookup ERROR", bodyContent);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			//sendMail.sendNotificationMail("SQL Lookup ERROR", msg, LookupConstants.ERROR_TYPE.CANNOT_GET_CONNECTION);
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Email-notification has sent successfully.....]");
		}catch(BadSqlGrammarException ex){
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Got BadSqlGrammarException Exception]");
			String bodyContent = "Query syntax is not correct. Please check : ";
			bodyContent += ex.getMessage();
			if(emailService == null)emailService = new EmailService();
			try {
				emailService.sendSimpleMail("email-simple2", bLocale, "SQL Lookup ERROR", bodyContent);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			//sendMail.sendNotificationMail("SQL Lookup ERROR", msg, LookupConstants.ERROR_TYPE.BAD_SQL_ERROR);
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Email-notification has sent successfully.....]");
		}catch(Exception ex){
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Got Generic Exception.....]");
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Going to send email-notification.....]");
			String bodyContent = "Generic exception : ";
			bodyContent += ex.getMessage();
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("email-simple2", bLocale, "Generic Lookup ERROR", bodyContent);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			//sendMail.sendNotificationMail("Generic Lookup ERROR", msg, LookupConstants.ERROR_TYPE.GENRIC_ERROR);
			logger.error("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Email-notification has sent successfully.....]");
		}
		
		logger.debug("[LookupDataServiceController.class] [Inside callAccountAndModelLookupService()] [Going out of Lookup Service and returning Map data]");
		return rtnFinalMap;
	}
	
}
