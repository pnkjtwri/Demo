package com.ge.treasury.payment.lookupservices.rowmapper;

/**
 * Class designed for mapping the resultset data into Object(ModelInfoBean)
 * @author Pankaj1.Tiwari
 */

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.lookupservices.model.ModelInfoBean;

@SuppressWarnings("rawtypes")
@Component
public class ModelInfoRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(ModelInfoRowMapper.class);
	
	@Value("${modelInfo.Columns}")
	private String modelColumns;
	
	/**
	 * Method used for mapping the resultset data into ModelInfoBean object
	 */
	@Override
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		logger.info("[ModelInfoRowMapper.class] [Inside mapRow()] [Going to return AccountInfoBean..]");
		String modelColumnss[]= modelColumns.split("#");
		ModelInfoBean modelInfoBean = new ModelInfoBean();
		modelInfoBean.setModelInfoID(rs.getLong(modelColumnss[0]));
		modelInfoBean.settInstancesID(rs.getLong(modelColumnss[1]));
		modelInfoBean.setModelID(rs.getString(modelColumnss[2]));
		//modelInfoBean.setStatus(rs.getString(modelColumnss[3]));
		modelInfoBean.setActiveIND(rs.getString(modelColumnss[4]));
		modelInfoBean.setDeleteFlag(rs.getString(modelColumnss[5]));
		modelInfoBean.setCreateBy(rs.getString(modelColumnss[6]));
		modelInfoBean.setCreationDate(rs.getDate(modelColumnss[7]));
		modelInfoBean.setLastModifiedBy(rs.getString(modelColumnss[8]));
		modelInfoBean.setLastModificationDate(rs.getDate(modelColumnss[9]));
		logger.info("[ModelInfoRowMapper.class] [Inside mapRow()] [Going to return ModelInfoBean..]");
		return modelInfoBean;
	}

	public String getModelColumns() {
		return modelColumns;
	}

	public void setModelColumns(String modelColumns) {
		this.modelColumns = modelColumns;
	}

}