package com.ge.treasury.payment.lookupservices.dao.impl;

/**
 * Class designed for implementing the Lookup Repository method for AccontInfo and ModelInfo data 
 * @author Pankaj1.Tiwari
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.ge.treasury.payment.lookupservices.dao.LookupDataRepository;
import com.ge.treasury.payment.lookupservices.model.AccountInfoBean;
import com.ge.treasury.payment.lookupservices.model.ModelInfoBean;
import com.ge.treasury.payment.lookupservices.rowmapper.AccountInfoRowMapper;
import com.ge.treasury.payment.lookupservices.rowmapper.ModelInfoRowMapper;

@SuppressWarnings({"unchecked"})
@Service
public class LookupDataRepositoryImpl implements LookupDataRepository {
	private Logger logger = Logger.getLogger(LookupDataRepositoryImpl.class);

	public LookupDataRepositoryImpl() {
		super();
	}

	@Autowired AccountInfoRowMapper accountMapper;
	@Autowired ModelInfoRowMapper modelMapper;
	
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private JdbcTemplate jdbc;
	
	/*public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbc = new JdbcTemplate(dataSource);
   }*/
	
	/**
	 * <p>Method used for lookup into table named T_WEBCASHTSA_ACCOUNT_INFO</p> 
	 * @param accountIDList
	 * @return List<AccountInfoBean>
	 */
	@Override
	public List<AccountInfoBean> accountInfoLookup(List<String> accountIDList) {
		logger.info("[LookupDataRepositoryImpl.class] [Inside accountInfoLookup()] [Going to lookup into Account Info table.]");
		if(accountIDList != null && accountIDList.size() > 0){
			StringBuffer parameterData = prepareListIntoString(accountIDList);
			return jdbc.query("SELECT * "
					+ "FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO "
					+ "WHERE ACTIVE_IND = 'Y' AND DELETE_FLAG = 'N' "
					//+ "WHERE ACTIVE_IND = 'N' AND DELETE_FLAG = 'Y' "
					+ "AND ACCOUNT_ID in ("+parameterData+") ", 
					accountMapper);
		}else{
			return new ArrayList<AccountInfoBean>();
		}
	}
	
	/**
	 * <p>Method used for lookup into table named T_WEBCASHTSA_MODEL_INFO</p>
	 * @param make
	 * @return List<ModelInfoBean>
	 */
	@Override
	public List<ModelInfoBean> modelInfoLookup(List<String> modelIDList) {
		logger.info("[LookupDataRepositoryImpl.class] [Inside modelInfoLookup()] [Going to lookup into Model Info table.]");
		
		if(modelIDList != null && modelIDList.size() > 0){
			StringBuffer parameterData = prepareListIntoString(modelIDList);
			return jdbc.query("SELECT * "
					+ "FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO "
					+ "WHERE ACTIVE_IND = 'Y' AND DELETE_FLAG = 'N' "
					+ "AND MODEL_ID in ("+parameterData+") ", 
					modelMapper);
		}else{
			return new ArrayList<ModelInfoBean>();
		}
	}
	
	/**
	 * Method used for preparing input parameter for db query
	 * @param listData
	 * @return StringBuffer
	 */
	private StringBuffer prepareListIntoString(List<String> listData){
		logger.info("[LookupDataRepositoryImpl.class] [Inside prepareListIntoString()] [Initializing JdbcTemplate ObjectGoing to preapre String data from input List.]");
		StringBuffer rtnData = null ;
		
		for (Iterator<String> iterator = listData.iterator(); iterator.hasNext();) {
			String strData = (String) iterator.next();
			
			if(rtnData == null || rtnData.equals("")){
				rtnData = new StringBuffer();
				rtnData.append("'"+strData+"'");
			}else
				rtnData.append(","+"'"+strData+"'");
		}
		
		logger.info("[LookupDataRepositoryImpl.class] [Inside prepareListIntoString()] [String data prepared from Input List.]");
		logger.info("[LookupDataRepositoryImpl.class] [Inside prepareListIntoString()] [String data :]"+rtnData);
		return rtnData;
	}
	
}
