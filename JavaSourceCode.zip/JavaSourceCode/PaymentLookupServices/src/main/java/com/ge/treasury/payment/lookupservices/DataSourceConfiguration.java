package com.ge.treasury.payment.lookupservices;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
/**
 * @author padmajaarekuti
 *
 */
@Configuration 
public class DataSourceConfiguration {
	
	@Value("${spring-config.dataSource.dbDriverClassName}")
	private String dbDriverClassName;
	@Value("${spring-config.dataSource.dbUrl}")
	private String dbUrl;
	@Value("${spring-config.dataSource.dbUsername}")
	private String dbUsername;
	@Value("${spring-config.dataSource.dbPassword}")
	private String dbPassword;
	
	private static final Logger logger = LoggerFactory.getLogger(DataSourceConfiguration.class);
	
	@Bean
	public DataSource getDataSource() {
		logger.debug("getDataSource() called");
    	DriverManagerDataSource dataSource = new DriverManagerDataSource();
	    dataSource.setDriverClassName(dbDriverClassName);
	    dataSource.setUrl(dbUrl);
	    dataSource.setUsername(dbUsername);
	    dataSource.setPassword(dbPassword);
	    return dataSource;
	}
	
	@Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
    
}
