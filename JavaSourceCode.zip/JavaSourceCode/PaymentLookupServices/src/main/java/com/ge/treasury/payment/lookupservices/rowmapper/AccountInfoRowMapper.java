package com.ge.treasury.payment.lookupservices.rowmapper;

/**
 * Class designed for mapping the resultset data into Object(AccountInfoBean)
 * @author Pankaj1.Tiwari
 */

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.lookupservices.model.AccountInfoBean;

@SuppressWarnings("rawtypes")
@Component
public class AccountInfoRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(AccountInfoRowMapper.class);
	
	@Value("${acountInfo.Columns}")
	private String accountColumns;
	
	/**
	 * Method used for mapping the resultset data into AccountInfoBean object
	 */
	@Override
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		logger.info("[AccountInfoRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into AccountInfo Bean..]");
		String[] accountColumnss = accountColumns.split("#");
		AccountInfoBean accountInfoBean = new AccountInfoBean();
		accountInfoBean.setAccountInfoID(rs.getLong(accountColumnss[0]));
		accountInfoBean.settInstancesID(rs.getLong(accountColumnss[1]));
		accountInfoBean.setAccountID(rs.getString(accountColumnss[2]));
		accountInfoBean.setAccountNumber(rs.getString(accountColumnss[3]));
		accountInfoBean.setAccountFormat(rs.getString(accountColumnss[4]));
		/*accountInfoBean.setAccountOpenDate(rs.getDate(accountColumnss[5]));
		accountInfoBean.setAccountCloseDate(rs.getDate(accountColumnss[6]));*/
		accountInfoBean.setBankID(rs.getString(accountColumnss[7]));
		accountInfoBean.setBankName(rs.getString(accountColumnss[8]));
		accountInfoBean.setCountry(rs.getString(accountColumnss[9]));
		accountInfoBean.setActiveIND(rs.getString(accountColumnss[10]));
		accountInfoBean.setDeleteFlag(rs.getString(accountColumnss[11]));
		accountInfoBean.setCreateBy(rs.getString(accountColumnss[12]));
		accountInfoBean.setCreationDate(rs.getDate(accountColumnss[13]));
		accountInfoBean.setLastModifiedBy(rs.getString(accountColumnss[14]));
		accountInfoBean.setLastModificationDate(rs.getDate(accountColumnss[15]));
		logger.info("[AccountInfoRowMapper.class] [Inside mapRow()] [Going to return AccountInfoBean..]");
		return accountInfoBean;
	}

	public String getAccountColumns() {
		return accountColumns;
	}

	public void setAccountColumns(String accountColumns) {
		this.accountColumns = accountColumns;
	}
}
