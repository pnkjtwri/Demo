/**
 * 
 */
package com.ge.treasury.payment.lookupservices.mail;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Locale;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

/**
 * @author padmajaarekuti
 *
 */
@Service
public class EmailService {

    @Autowired 
    private JavaMailSender mailSender;
    
    @Autowired 
    private TemplateEngine templateEngine;
 
    @Value("${recipientDL}")
	private String recipientEmail;
    
    @Value("${fromDL}")
	private String fromDL;
    
    /* 
     * Send HTML mail (simple) 
     */
    public void sendSimpleMail(
            final String templateNm,final Locale locale, String subject, String bodyContent) 
            throws MessagingException {
        
    	InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
        	e.printStackTrace();
        }
        
        // Prepare the evaluation context
        final Context ctx = new Context(locale);
        ctx.setVariable("bodyContent", bodyContent);
        ctx.setVariable("hostName", hostAndIP.getHostAddress());
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);

    }
 

}