package com.ge.treasury.payment.lookupservices.service;

import java.util.List;
import java.util.Map;

public interface LookupDataService {
	
	public Map<String, Object> accountLookupMethod(List<String> accountIDList);
	
	public Map<String, Object> modelLookupMethod(List<String> modelIDList);

}
