package com.ge.treasury.payment.lookupservices.dao;

import java.util.List;

import com.ge.treasury.payment.lookupservices.model.AccountInfoBean;
import com.ge.treasury.payment.lookupservices.model.ModelInfoBean;

public interface LookupDataRepository {
	
	public List<AccountInfoBean> accountInfoLookup(List<String> accountIDList);
	
	public List<ModelInfoBean> modelInfoLookup(List<String> modelIDList);

}
