package com.ge.treasury.payment.lookupservices.model;

import java.util.Date;

public class AccountInfoBean {
	
	private Long accountInfoID;
	private Long tInstancesID;
	private String accountID;
	private String accountNumber;
	private String accountFormat;
	private Date accountOpenDate;
	private Date accountCloseDate;
	private String bankID;
	private String bankName;
	private String country;
	private String activeIND;
	private String deleteFlag;
	private String createBy;
	private Date creationDate;
	private String lastModifiedBy;
	private Date lastModificationDate;
	
	
	public Long getAccountInfoID() {
		return accountInfoID;
	}
	public void setAccountInfoID(Long accountInfoID) {
		this.accountInfoID = accountInfoID;
	}
	public Long gettInstancesID() {
		return tInstancesID;
	}
	public void settInstancesID(Long tInstancesID) {
		this.tInstancesID = tInstancesID;
	}
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountFormat() {
		return accountFormat;
	}
	public void setAccountFormat(String accountFormat) {
		this.accountFormat = accountFormat;
	}
	public Date getAccountOpenDate() {
		return accountOpenDate;
	}
	public void setAccountOpenDate(Date accountOpenDate) {
		this.accountOpenDate = accountOpenDate;
	}
	public String getBankID() {
		return bankID;
	}
	public void setBankID(String bankID) {
		this.bankID = bankID;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getActiveIND() {
		return activeIND;
	}
	public void setActiveIND(String activeIND) {
		this.activeIND = activeIND;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModificationDate() {
		return lastModificationDate;
	}
	public void setLastModificationDate(Date lastModificationDate) {
		this.lastModificationDate = lastModificationDate;
	}
	public Date getAccountCloseDate() {
		return accountCloseDate;
	}
	public void setAccountCloseDate(Date accountCloseDate) {
		this.accountCloseDate = accountCloseDate;
	}

}
