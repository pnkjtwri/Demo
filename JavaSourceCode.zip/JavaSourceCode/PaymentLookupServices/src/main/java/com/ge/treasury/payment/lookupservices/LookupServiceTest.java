package com.ge.treasury.payment.lookupservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.client.RestTemplate;


public class LookupServiceTest {
	/*
	@SuppressWarnings({ "unchecked", "serial" })
	public static void main(String arr[]){
		
		System.out.println("We r here....");
		final String lookupUrl = "http://localhost:8055/getAccountModeldata";
		
		List<String> accountIDList = new ArrayList<String>(){{
			add("AT31"); add("AB01"); add("JB18"); add("3037"); 
		}};
		
		List<String> modelIDList = new ArrayList<String>(){{
			add("3034"); add("3035"); add("3036");
		}};
		
	 	Map<String, List<String>> params = new HashMap<String, List<String>>();
	 	params.put("accountIDList", accountIDList);
	 	params.put("modelIDList", modelIDList);
	 	
	 	RestTemplate restTemplate = new RestTemplate();
	 	Map<Object, Object> resultMapData =  restTemplate.postForObject(lookupUrl, params, Map.class);
	 	
	 	System.out.println(resultMapData);
	 	
	 	//getting Account_Info & Model_Info Map Data...
	 	if(resultMapData != null && resultMapData.size() > 0){
	 		Map<String, Object> accountInfoMapData = (Map<String, Object>) resultMapData.get("accountIinfoMap");
		 	Map<String, Object> modelInfoMapData = (Map<String, Object>) resultMapData.get("modelIinfoMap");
		 	
		 	//getting Account nonIHB & IHB ID list
			List<Object> accountNonIHBIDList = (List<Object>) accountInfoMapData.get("nonIHBAccountIDList");
			System.out.println(accountNonIHBIDList.size());
			Map<String, List<String>> accountInfoListMap =  (Map<String, List<String>>) accountInfoMapData.get("accountInfoListMap");
			System.out.println(accountInfoListMap.size());
			//getting Model nonIHB & IHB ID list
			List<Object> modelNonIHBIDList = (List<Object>) modelInfoMapData.get("nonIHBModelIDList");
			System.out.println(modelNonIHBIDList.size());
			Map<String, List<String>> modelInfoListMap =  (Map<String, List<String>>) modelInfoMapData.get("modelInfoListMap");
			System.out.println(modelInfoListMap.size());
	 	}
	}
*/
}
