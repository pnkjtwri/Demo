package com.ge.treasury.payment.lookupservices;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
//@ImportResource("springConfig/spring-lookup-context.xml")
@ComponentScan("com.ge.treasury.payment.lookupservices")
public class LookupDataBootController extends SpringBootServletInitializer {
	
	public static void main(String[] args) {
		
		SpringApplication.run(LookupDataBootController.class, args);
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
		defaultProperties.put("spring.config.location", "file:/app/tsaweb/properties/lookupservice/application.yml");
        return application.sources(LookupDataBootController.class).properties(defaultProperties).web(true);
    }

}
