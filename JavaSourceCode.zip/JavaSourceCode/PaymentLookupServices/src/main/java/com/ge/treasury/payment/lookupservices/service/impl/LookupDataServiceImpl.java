package com.ge.treasury.payment.lookupservices.service.impl;

/**
 * Class designed for implementing the Lookup service method for AccontInfo and ModelInfo data 
 * @author Pankaj1.Tiwari
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.treasury.payment.lookupservices.dao.LookupDataRepository;
import com.ge.treasury.payment.lookupservices.model.AccountInfoBean;
import com.ge.treasury.payment.lookupservices.model.ModelInfoBean;
import com.ge.treasury.payment.lookupservices.service.LookupDataService;
@Service
public class LookupDataServiceImpl implements LookupDataService{

	private Logger logger = Logger.getLogger(LookupDataServiceImpl.class);
	
	@Autowired private LookupDataRepository repository;
	public void setRepository(LookupDataRepository repository) {
		this.repository = repository;
	}
	
	/**
	 * Method used for implementing the interface method
	 * Method used for getting the AccountInfo data into Map 
	 * @param accountIDList
	 * @return HashMap<Object, Object>
	 */
	@Override
	public Map<String, Object> accountLookupMethod(List<String> accountIDList){
		logger.info("[LookupDataServiceImpl.class] [Inside accountLookupMethod()]");
		Map<String, Object> accountInfoMapData = new HashMap<String, Object>();
		List<AccountInfoBean> accountLookupDataList = repository.accountInfoLookup(accountIDList);
		if(accountLookupDataList != null && accountLookupDataList.size() > 0){
			accountInfoMapData = getAccountTSAInstanceID(accountLookupDataList, accountIDList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside accountLookupMethod()] [Going to return Map data...]");
		return accountInfoMapData;
	}
	
	/**
	 * Method used for getting the NonIHBAccountID and List<AccountInfoBean> into Map<Object, Object>
	 * @param accountLookupDataList
	 * @param accountIDList
	 * @return Map<Object, Object>
	 */
	private Map<String, Object> getAccountTSAInstanceID(List<AccountInfoBean> accountLookupDataList,
			List<String> accountIDList){
		logger.info("[LookupDataServiceImpl.class] [Inside getAccountTSAInstanceID()]");
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		Map<Long, List<String>> tsaGroupedAccountInfoMap = new HashMap<Long, List<String>>();
		List<String> nonIHBRecordsList = new ArrayList<String>();
		
		for (Iterator<String> iterator = accountIDList.iterator(); iterator.hasNext();) {
			String accountIDStr = (String) iterator.next();
			boolean isFound=false;
			outerAccountBean:
			for (int i = 0; i < accountLookupDataList.size() ; i++) {
				AccountInfoBean accountInfo = accountLookupDataList.get(i);

				if(accountIDStr.equals(accountInfo.getAccountID())){
					//Grouping AcconutInfo by TSAID
					//tsaGroupedAccountInfoMap = groupedAccountInfoByTSAID(tsaGroupedAccountInfoMap, accountInfo);
					tsaGroupedAccountInfoMap = groupedAccountInfoIDByTSAID(tsaGroupedAccountInfoMap, accountInfo);
					isFound=true;
					break outerAccountBean;
				} 
			}
			if(!isFound){
				nonIHBRecordsList.add(accountIDStr);
			}
		}
		rtnMap.put("accountInfoListMap", tsaGroupedAccountInfoMap);
		rtnMap.put("nonIHBAccountIDList", nonIHBRecordsList);
		logger.info("[LookupDataServiceImpl.class] [Inside getAccountTSAInstanceID()] [Going to return prepared Map data]");
		return rtnMap;
	}
	
	/**
	 * Method used for grouping the List<AccountInfoBean> by TSAInstacesID
	 * @param tsaIDGroupedAccountInfoMap
	 * @param accountInfo
	 * @return  HashMap<Long, List<AccountInfoBean>>
	 */
	private Map<Long, List<Object>> groupedAccountInfoByTSAID(Map<Long, List<Object>> tsaGroupedAccountInfoMap, 
			AccountInfoBean accountInfo){
		logger.info("[LookupDataServiceImpl.class] [Inside groupedAccountInfoByTSAID()]");
		Long tsaID = accountInfo.gettInstancesID();
		if(tsaGroupedAccountInfoMap.containsKey(tsaID)){
			List<Object> accountInfoList = tsaGroupedAccountInfoMap.get(tsaID);
			accountInfoList.add(accountInfo);
			tsaGroupedAccountInfoMap.put(tsaID, accountInfoList);
		}else{
			List<Object> accountInfoList = new ArrayList<Object>();
			accountInfoList.add(accountInfo);
			tsaGroupedAccountInfoMap.put(tsaID, accountInfoList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside groupedAccountInfoByTSAID()] [Going to return prepared Map data]");
		return tsaGroupedAccountInfoMap;
		
	}
	
	/**
	 * Method used for grouping the Account_ID in List<Strign> by TSAInstacesID
	 * @param tsaGroupedAccountInfoMap
	 * @param accountInfo
	 * @return
	 */
	private Map<Long, List<String>> groupedAccountInfoIDByTSAID(Map<Long, List<String>> tsaGroupedAccountInfoMap, 
			AccountInfoBean accountInfo){
		logger.info("[LookupDataServiceImpl.class] [Inside groupedAccountInfoByTSAID()]");
		Long tsaID = accountInfo.gettInstancesID();
		if(tsaGroupedAccountInfoMap.containsKey(tsaID)){
			List<String> accountInfoList = tsaGroupedAccountInfoMap.get(tsaID);
			accountInfoList.add(accountInfo.getAccountID());
			tsaGroupedAccountInfoMap.put(tsaID, accountInfoList);
		}else{
			List<String> accountInfoList = new ArrayList<String>();
			accountInfoList.add(accountInfo.getAccountID());
			tsaGroupedAccountInfoMap.put(tsaID, accountInfoList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside groupedAccountInfoByTSAID()] [Going to return prepared Map data]");
		return tsaGroupedAccountInfoMap;
		
	}
	
	/**
	 * Method used for implementing the interface method
	 * Method used for getting the ModelInfoBean data into Map 
	 * @param modelIDList
	 * @return HashMap<Object, Object>
	 */
	@Override
	public Map<String, Object> modelLookupMethod(List<String> modelIDList){
		Map<String, Object> modelInfoMapData = new HashMap<String, Object>();
		logger.info("[LookupDataServiceImpl.class] [Inside modelLookupMethod()]");
		List<ModelInfoBean> modelLookupDataList = repository.modelInfoLookup(modelIDList);
		if(modelLookupDataList != null && modelLookupDataList.size() > 0){
			modelInfoMapData = getModelTSAInstanceID(modelLookupDataList, modelIDList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside modelLookupMethod()] [Going to return Map data...]");	
		return modelInfoMapData;
	}
	
	/**
	 * Method used for getting the NonIHBAccountID and Model_ID in List<Strnig> into Map<Object, Object>
	 * @param modelLookupDataList
	 * @param modelIDList
	 * @return Map<Object, Object>
	 */
	private Map<String, Object> getModelTSAInstanceID(List<ModelInfoBean> modelLookupDataList,
			List<String> modelIDList){
		logger.info("[LookupDataServiceImpl.class] [Inside getModelTSAInstanceID()]");
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		List<String> nonIHBRecordsList = new ArrayList<String>();
		
		Map<Long, List<String>> tsaGroupedModelInfoMap = new HashMap<Long, List<String>>();
		
		for (Iterator<String> iterator = modelIDList.iterator(); iterator.hasNext();) {
			String modelIDStr = (String) iterator.next();
			boolean isFound=false;
			outerModelInfo:
			for (int i = 0; i < modelLookupDataList.size() ; i++) {
				ModelInfoBean modelInfo = modelLookupDataList.get(i);

				if(modelIDStr.equals(modelInfo.getModelID())){
					//tsaGroupedModelInfoMap = groupModelInfoByTSAID(modelInfo, accountModelMapData);
					tsaGroupedModelInfoMap = groupModelInfoIDByTSAID(modelInfo, tsaGroupedModelInfoMap);
					isFound = true;
					break outerModelInfo;
				}
			}
			if(!isFound){
				nonIHBRecordsList.add(modelIDStr);
			}
		}
		
		rtnMap.put("modelInfoListMap", tsaGroupedModelInfoMap);
		rtnMap.put("nonIHBModelIDList", nonIHBRecordsList);
		
		logger.info("[LookupDataServiceImpl.class] [Inside getModelTSAInstanceID()] [Going to return prepared Map data]");
		return rtnMap;
	}

	/**
	 * Method used for grouping the List<ModelInfoBean> by TSAInstacesID
	 * @param tsaGroupedModelInfoMap
	 * @param modelInfo
	 * @return  HashMap<Long, List<ModelInfoBean>>
	 */
	private Map<Long, List<Object>> groupModelInfoByTSAID(ModelInfoBean modelInfo, Map<Long, List<Object>> accountModelMapData) {
		logger.info("[LookupDataServiceImpl.class] [Inside groupModelInfoByTSAID()]");
		Long tsaID = modelInfo.gettInstancesID();
		//Grouping ModelInfo by TSAID
		if(accountModelMapData.containsKey(tsaID)){
			List<Object> modelInfoList = accountModelMapData.get(tsaID);
			modelInfoList.add(modelInfo);
			accountModelMapData.put(tsaID, modelInfoList);
		}else{
			List<Object> modelInfoList = new ArrayList<Object>();
			modelInfoList.add(modelInfo);
			accountModelMapData.put(tsaID, modelInfoList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside groupModelInfoByTSAID()] [Going to return prepared Map data]");
		return accountModelMapData;
	}
	
	/**
	 * Method used for grouping the Model_ID in List<Strign> by TSAInstacesID
	 * @param modelInfo, accountModelMapData
	 * @return
	 */
	private Map<Long, List<String>> groupModelInfoIDByTSAID(ModelInfoBean modelInfo, Map<Long, List<String>> accountModelMapData) {
		logger.info("[LookupDataServiceImpl.class] [Inside groupModelInfoByTSAID()]");
		Long tsaID = modelInfo.gettInstancesID();
		//Grouping ModelInfo by TSAID
		if(accountModelMapData.containsKey(tsaID)){
			List<String> modelInfoList = accountModelMapData.get(tsaID);
			modelInfoList.add(modelInfo.getModelID());
			accountModelMapData.put(tsaID, modelInfoList);
		}else{
			List<String> modelInfoList = new ArrayList<String>();
			modelInfoList.add(modelInfo.getModelID());
			accountModelMapData.put(tsaID, modelInfoList);
		}
		logger.info("[LookupDataServiceImpl.class] [Inside groupModelInfoByTSAID()] [Going to return prepared Map data]");
		return accountModelMapData;
	}
	
}
