package com.ge.treasury.payment.lookupservices.model;

import java.util.Date;

public class ModelInfoBean {
	
	private Long modelInfoID;
	private Long tInstancesID;
	private String ModelID;
	private String status;
	private String activeIND;
	private String deleteFlag;
	private String createBy;
	private Date creationDate;
	private String lastModifiedBy;
	private Date lastModificationDate;
	
	public Long getModelInfoID() {
		return modelInfoID;
	}
	public void setModelInfoID(Long modelInfoID) {
		this.modelInfoID = modelInfoID;
	}
	public Long gettInstancesID() {
		return tInstancesID;
	}
	public void settInstancesID(Long tInstancesID) {
		this.tInstancesID = tInstancesID;
	}
	public String getModelID() {
		return ModelID;
	}
	public void setModelID(String modelID) {
		ModelID = modelID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActiveIND() {
		return activeIND;
	}
	public void setActiveIND(String activeIND) {
		this.activeIND = activeIND;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModificationDate() {
		return lastModificationDate;
	}
	public void setLastModificationDate(Date lastModificationDate) {
		this.lastModificationDate = lastModificationDate;
	}

}
