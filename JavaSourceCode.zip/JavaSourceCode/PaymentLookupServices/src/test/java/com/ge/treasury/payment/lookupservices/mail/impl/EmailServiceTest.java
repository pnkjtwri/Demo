/**
 * 
 */
package com.ge.treasury.payment.lookupservices.mail.impl;

import java.util.Locale;

import javax.mail.MessagingException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ge.treasury.payment.lookupservices.LookupDataBootController;
import com.ge.treasury.payment.lookupservices.mail.EmailService;

/**
 * @author padmajaarekuti
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(LookupDataBootController.class)
public class EmailServiceTest { 
	
	 @Autowired 
	 private EmailService emailService;
	 
	 @Value("${fromDL}")
	 private String senderDL;
	 
	 @Value("${recipientDL}")
	 private String recipientDL;

	@Test
	public void testSimpleEmail() {
		Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
		try {
			emailService.sendSimpleMail("email-simple2" ,bLocale, "Example HTML email (simple)", "Add Body Content Here...");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}