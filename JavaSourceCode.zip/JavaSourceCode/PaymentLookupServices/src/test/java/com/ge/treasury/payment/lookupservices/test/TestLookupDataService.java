package com.ge.treasury.payment.lookupservices.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ge.treasury.payment.lookupservices.LookupDataServiceController;
import com.ge.treasury.payment.lookupservices.dao.LookupDataRepository;
import com.ge.treasury.payment.lookupservices.mail.EmailService;
import com.ge.treasury.payment.lookupservices.model.AccountInfoBean;
import com.ge.treasury.payment.lookupservices.model.ModelInfoBean;
import com.ge.treasury.payment.lookupservices.service.impl.LookupDataServiceImpl;

public class TestLookupDataService {
	
	private static final Mockery context = new JUnit4Mockery();
	private static LookupDataServiceController serviceController;
	private static LookupDataRepository lookupDAo;
	private static EmailService mailer;
	private static LookupDataServiceImpl startLookupService;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		lookupDAo            = context.mock(LookupDataRepository.class);
		mailer            = context.mock(EmailService.class);
		startLookupService      = new LookupDataServiceImpl();
		serviceController = new LookupDataServiceController();
	}
	
	@Test
	@SuppressWarnings("serial")
	public void testLookupProcess() throws Exception{
		
		Map<Object, Object> rtnAccountModelMap = new HashMap<Object, Object>();
		final List<String> accountIDListID = new ArrayList<String>(){{
			add("AT31"); add("1896"); add("3036"); add("3037"); 
		}};
		final List<AccountInfoBean> accountInfoBeanList = new ArrayList<AccountInfoBean>();
		final List<String> modelIDListID = new ArrayList<String>(){{
			add("3034"); add("3035"); add("3036");
		}};
		final List<ModelInfoBean> modelInfoBeanList = new ArrayList<ModelInfoBean>();
		
		context.checking(new Expectations() {
	        {
	        	oneOf(lookupDAo).accountInfoLookup(accountIDListID);
	            will(returnValue(accountInfoBeanList));
	            
	            oneOf(lookupDAo).modelInfoLookup(modelIDListID);
	            will(returnValue(modelInfoBeanList));	
	            
	        }
		});
		
		startLookupService.setRepository(lookupDAo);
		//serviceController.setSendMail(mailer);
		Map<String, List<String>> inpurParam = new HashMap<String, List<String>>(){{
			put("accountIDList",accountIDListID);
			put("modelIDList",modelIDListID);
		}};
		rtnAccountModelMap = serviceController.callAccountAndModelLookupService(inpurParam);
		System.out.println("Returned Account map size --> "+rtnAccountModelMap.size());
	}

}
