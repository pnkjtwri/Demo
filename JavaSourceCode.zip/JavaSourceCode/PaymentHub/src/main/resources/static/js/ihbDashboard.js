

function setPageName(pageName){
	//alert(pageName);
	if(pageName == 'home'){
		//nothing
		document.title = "IHB Dashboard";
	}else if(pageName == 'account'){
		//nothing	
		document.title = "Account";
	}else if(pageName == 'businessUser'){
		$('th').css('height', 80);
		document.title = "Business User";
	}else if(pageName == 'fileProcessor'){
		$('th').css('height', 80);
		document.title = "File Processor";
	}else if(pageName == 'fileSeg'){
		$('th').css('height', 80);
		document.title = "File Segregator";
	}else if(pageName == 'fileSegTrans'){
		$('th').css('height', 80);
		document.title = "File Segregator Transation";
	}
}
