/*
 * Copyright 2012-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.ge.treasury.paymenthub.dashboard.model;


/**
 * 
 * @author pankaj1.tiwari
 *
 */
public class BusinessUserBean {
	
	/*private String wcBusiness;
	private String isIHBBUsiness;
	private String optionID;
	private String jobType;
	private String jobFilter;
	private String pluginID;
	private String trustedSource;*/
	private String cmmPaymentInputFolder;
	private String description;
	/*private String operatorID;
	private String operatorName;
	private String isFeedbackRequired;
	private Date auditTimeStamp;
	private String auditUSerSSO;
	private String gwixUser;*/
	
	/*public String getWcBusiness() {
		return wcBusiness;
	}
	public void setWcBusiness(String wcBusiness) {
		this.wcBusiness = wcBusiness;
	}
	public String getIsIHBBUsiness() {
		return isIHBBUsiness;
	}
	public void setIsIHBBUsiness(String isIHBBUsiness) {
		this.isIHBBUsiness = isIHBBUsiness;
	}
	public String getOptionID() {
		return optionID;
	}
	public void setOptionID(String optionID) {
		this.optionID = optionID;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobFilter() {
		return jobFilter;
	}
	public void setJobFilter(String jobFilter) {
		this.jobFilter = jobFilter;
	}
	public String getPluginID() {
		return pluginID;
	}
	public void setPluginID(String pluginID) {
		this.pluginID = pluginID;
	}
	public String getTrustedSource() {
		return trustedSource;
	}
	public void setTrustedSource(String trustedSource) {
		this.trustedSource = trustedSource;
	}*/
	public String getCmmPaymentInputFolder() {
		return cmmPaymentInputFolder;
	}
	public void setCmmPaymentInputFolder(String cmmPaymentInputFolder) {
		this.cmmPaymentInputFolder = cmmPaymentInputFolder;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	/*public String getOperatorID() {
		return operatorID;
	}
	public void setOperatorID(String operatorID) {
		this.operatorID = operatorID;
	}
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public String getIsFeedbackRequired() {
		return isFeedbackRequired;
	}
	public void setIsFeedbackRequired(String isFeedbackRequired) {
		this.isFeedbackRequired = isFeedbackRequired;
	}
	public Date getAuditTimeStamp() {
		return auditTimeStamp;
	}
	public void setAuditTimeStamp(Date auditTimeStamp) {
		this.auditTimeStamp = auditTimeStamp;
	}
	public String getAuditUSerSSO() {
		return auditUSerSSO;
	}
	public void setAuditUSerSSO(String auditUSerSSO) {
		this.auditUSerSSO = auditUSerSSO;
	}
	public String getGwixUser() {
		return gwixUser;
	}
	public void setGwixUser(String gwixUser) {
		this.gwixUser = gwixUser;
	}*/

}