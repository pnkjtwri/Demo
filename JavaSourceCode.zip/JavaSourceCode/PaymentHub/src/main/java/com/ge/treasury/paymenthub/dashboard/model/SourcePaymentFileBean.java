package com.ge.treasury.paymenthub.dashboard.model;

import java.util.Date;

/**
 * 
 * @author pankaj1.tiwari
 *
 */
public class SourcePaymentFileBean {
	
	private Long srcPaymentFileID;
	private String srcPaymentFileName;
	private String fileType;
	private String fileCreationModule;
	private String fileFormatVersion;
	private String trailerTotalRecords;
	private String trailerFileName;
	private String segregationFlag;
	private Long fileStatusID;
	private String segregationStatusMsg;
	private Long pfiBusinessID;
	private Date srcFileCreationTime;
	private String createdBy;
	private Date creationTime;
	private String lastModifiedBy;
	private Date lastModifiedTime;
	private String fileStatusDesc;
	private String pfiBusinessName;
	
	public Long getSrcPaymentFileID() {
		return srcPaymentFileID;
	}
	public void setSrcPaymentFileID(Long srcPaymentFileID) {
		this.srcPaymentFileID = srcPaymentFileID;
	}
	public String getSrcPaymentFileName() {
		return srcPaymentFileName;
	}
	public void setSrcPaymentFileName(String srcPaymentFileName) {
		this.srcPaymentFileName = srcPaymentFileName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileCreationModule() {
		return fileCreationModule;
	}
	public void setFileCreationModule(String fileCreationModule) {
		this.fileCreationModule = fileCreationModule;
	}
	public String getFileFormatVersion() {
		return fileFormatVersion;
	}
	public void setFileFormatVersion(String fileFormatVersion) {
		this.fileFormatVersion = fileFormatVersion;
	}
	public String getTrailerTotalRecords() {
		return trailerTotalRecords;
	}
	public void setTrailerTotalRecords(String trailerTotalRecords) {
		this.trailerTotalRecords = trailerTotalRecords;
	}
	public String getTrailerFileName() {
		return trailerFileName;
	}
	public void setTrailerFileName(String trailerFileName) {
		this.trailerFileName = trailerFileName;
	}
	public String getSegregationFlag() {
		return segregationFlag;
	}
	public void setSegregationFlag(String segregationFlag) {
		this.segregationFlag = segregationFlag;
	}
	public Long getFileStatusID() {
		return fileStatusID;
	}
	public void setFileStatusID(Long fileStatusID) {
		this.fileStatusID = fileStatusID;
	}
	public String getSegregationStatusMsg() {
		return segregationStatusMsg;
	}
	public void setSegregationStatusMsg(String segregationStatusMsg) {
		this.segregationStatusMsg = segregationStatusMsg;
	}
	public Long getPfiBusinessID() {
		return pfiBusinessID;
	}
	public void setPfiBusinessID(Long pfiBusinessID) {
		this.pfiBusinessID = pfiBusinessID;
	}
	public Date getSrcFileCreationTime() {
		return srcFileCreationTime;
	}
	public void setSrcFileCreationTime(Date srcFileCreationTime) {
		this.srcFileCreationTime = srcFileCreationTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}
	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}
	public String getFileStatusDesc() {
		return fileStatusDesc;
	}
	public void setFileStatusDesc(String fileStatusDesc) {
		this.fileStatusDesc = fileStatusDesc;
	}
	public String getPfiBusinessName() {
		return pfiBusinessName;
	}
	public void setPfiBusinessName(String pfiBusinessName) {
		this.pfiBusinessName = pfiBusinessName;
	}
	
	
}
