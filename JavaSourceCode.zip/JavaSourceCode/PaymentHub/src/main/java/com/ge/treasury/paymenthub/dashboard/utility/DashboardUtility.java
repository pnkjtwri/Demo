package com.ge.treasury.paymenthub.dashboard.utility;


import java.util.HashMap;
import java.util.Map;

public final class DashboardUtility {
	
	public static final String[] splitWhitespaceString(String strData){
		if(strData != null){
			return strData.split("\\s+");
		}else
			return null;
	   
	}
	
	/**
	 * Method has Business User Table Column Names
	 * @param beanColumnName
	 * @return
	 */
	public static final Integer getBusinessUserDataBaseColumnName(String beanColumnName){
		
		Map<String, Integer> columnData = new HashMap<String, Integer>();
		
		columnData.put("wcBusiness", 1);
		columnData.put("isIHBBUsiness", 2);
		columnData.put("optionID", 3);
		columnData.put("jobType", 4);
		columnData.put("jobFilter", 5);
		columnData.put("pluginID", 6);
		columnData.put("trustedSource", 7);
		columnData.put("cmmPaymentInputFolder", 8);
		columnData.put("description", 9);
		columnData.put("operatorID", 10);
		columnData.put("operatorName", 11);
		columnData.put("isFeedbackRequired", 12);
		columnData.put("auditTimeStamp", 13);
		columnData.put("auditUSerSSO", 14);
		columnData.put("gwixUser", 15);
		
		return columnData.get(beanColumnName);
	}
	
	public static final String getFileProcessorDataBaseColumnName(String beanColumnName){
		
		Map<String, String> columnData = new HashMap<String, String>();
		
		columnData.put("srcPaymentFileID", "SRC_PAYMENT_FILE_ID");
		columnData.put("srcPaymentFileName", "SRC_PAYMENT_FILE_NAME");
		columnData.put("fileType", "FILE_TYPE");
		columnData.put("fileCreationModule", "FILE_CREATION_MODULE");
		columnData.put("fileFormatVersion", "FILE_FORMAT_VERSION");
		columnData.put("trailerTotalRecords", "TRAILER_TOTAL_RECORDS");
		columnData.put("trailerFileName", "TRAILER_FILE_NAME");
		columnData.put("segregationFlag", "SEGREGATION_FLAG");
		columnData.put("fileStatusID", "FILESTATUS_ID");
		columnData.put("fileStatusDesc","FILESTATUS_ID");
		columnData.put("segregationStatusMsg", "SEGREGATION_STATUS_MSG");
		columnData.put("pfiBusinessID", "PFI_BUSINESS_ID");
		columnData.put("pfiBusinessName", "PFI_BUSINESS_ID");
		columnData.put("srcFileCreationTime", "SRC_FILE_CREATION_TIMESTAMP");
		columnData.put("createdBy", "CREATED_BY");
		columnData.put("creationTime", "CREATED_TIMESTAMP");
		columnData.put("lastModifiedBy", "LAST_MODIFIED_BY");
		columnData.put("lastModifiedTime", "LAST_MODIFIED_TIMESTAMP");
		
		return columnData.get(beanColumnName);
	}
	
	public static final String getFileSegregatorDataBaseColumnName(String beanColumnName){
		
		Map<String, String> columnData = new HashMap<String, String>();
		
		columnData.put("segregatorFileID","SEGREGATOR_FILE_ID");
		columnData.put("srcPaymentFileID","SRC_PAYMENT_FILE_ID");
		columnData.put("segregatorFileName","SEGREGATOR_FILE_NAME");
		columnData.put("paymentInstType","PAYMENT_INST_TYPE");
		columnData.put("tsaInstancesID","TSAINSTANCES_ID");
		columnData.put("tsaInstancesIdentifier","TSAINSTANCES_ID");
		columnData.put("fileStatusID","FILESTATUS_ID");
		columnData.put("fileStatusDesc","FILESTATUS_ID");
		columnData.put("importStatusFileName","IMPORT_STATUS_FILE_NAME");
		columnData.put("noOfTransactios","NO_OF_TRANSACTIONS");
		columnData.put("createdBy", "CREATED_BY");
		columnData.put("creationTime", "CREATED_TIMESTAMP");
		columnData.put("lastModifiedBy", "LAST_MODIFIED_BY");
		columnData.put("lastModifiedTime", "LAST_MODIFIED_TIMESTAMP");
		
		return columnData.get(beanColumnName);
	}
	
	
}
