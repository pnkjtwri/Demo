package com.ge.treasury.paymenthub.dashboard.model;

import java.util.Date;

/**
 * 
 * @author pankaj1.tiwari
 *
 */
public class PFITransactionsBean {
	
	private Long pfiTrsansationID;
	private Long srcPaymentFileID;
	private Long segregatorFileID;
	private String transactionType;
	private String modelID;
	private String accountID;
	private String debtorAccountID;
	private String trustedSource;
	private Date transValueDate;
	private String currency;
	private String transactionAmount;
	private String createdBy;
	private Date creationTime;
	private String lastModifiedBy;
	private Date lastModifiedTime;
	
	public Long getPfiTrsansationID() {
		return pfiTrsansationID;
	}
	public void setPfiTrsansationID(Long pfiTrsansationID) {
		this.pfiTrsansationID = pfiTrsansationID;
	}
	public Long getSrcPaymentFileID() {
		return srcPaymentFileID;
	}
	public void setSrcPaymentFileID(Long srcPaymentFileID) {
		this.srcPaymentFileID = srcPaymentFileID;
	}
	public Long getSegregatorFileID() {
		return segregatorFileID;
	}
	public void setSegregatorFileID(Long segregatorFileID) {
		this.segregatorFileID = segregatorFileID;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getModelID() {
		return modelID;
	}
	public void setModelID(String modelID) {
		this.modelID = modelID;
	}
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getDebtorAccountID() {
		return debtorAccountID;
	}
	public void setDebtorAccountID(String debtorAccountID) {
		this.debtorAccountID = debtorAccountID;
	}
	public String getTrustedSource() {
		return trustedSource;
	}
	public void setTrustedSource(String trustedSource) {
		this.trustedSource = trustedSource;
	}
	public Date getTransValueDate() {
		return transValueDate;
	}
	public void setTransValueDate(Date transValueDate) {
		this.transValueDate = transValueDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}
	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}
	
	}
