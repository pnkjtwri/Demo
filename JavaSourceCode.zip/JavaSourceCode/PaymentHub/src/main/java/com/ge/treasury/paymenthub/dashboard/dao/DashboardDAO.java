
package com.ge.treasury.paymenthub.dashboard.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.ge.treasury.paymenthub.dashboard.model.*;

/**
 * 
 * @author pankaj1.tiwari
 *
 */

public interface DashboardDAO {
	
	//queries are here...
	final String getBusinessUser = "SELECT * from "
			+"(Select M.*, Rownum R From IHB_BUSINESS_USER M  "
			+ "WHERE upper(M.WC_BUSINES) like '%' || #{wcBusiness,jdbcType=VARCHAR} || '%' AND upper(M.OPTION_ID) like '%' || #{optionID,jdbcType=VARCHAR} || '%' ) "
			+ "where R > #{startPageIndex,jdbcType=NUMERIC} and R <= #{recordsPerPage,jdbcType=NUMERIC} "
			+ "ORDER BY ${sortingColIndex} ${inOrder}";
	final String getBusinessUserCount = "SELECT count(*) COUNTER FROM IHB_BUSINESS_USER "
			+ "WHERE upper(WC_BUSINES) like '%' || #{wcBusiness,jdbcType=VARCHAR} || '%' AND upper(OPTION_ID) like '%' || #{optionID,jdbcType=VARCHAR} || '%'";
	final String updateBusinessUser = "UPDATE IHB_BUSINESS_USER SET WC_BUSINES= #{wcBusiness,jdbcType=VARCHAR}, IS_IHB_BUSINESS= #{isIHBBUsiness,jdbcType=VARCHAR}, OPTION_ID= #{optionID,jdbcType=VARCHAR}, "  
			+ "JOB_TYPE= #{jobType,jdbcType=VARCHAR}, JOB_FILTER= #{jobFilter,jdbcType=VARCHAR}, PLUGIN_ID= #{pluginID,jdbcType=VARCHAR}, "
			+ "TRUSTED_SOURCE= #{trustedSource,jdbcType=VARCHAR}, CMMPAYMENTINPUTFOLDER= #{cmmPaymentInputFolder,jdbcType=VARCHAR}, DESCRIPTION= #{description,jdbcType=VARCHAR}, "
			+ "OPERATOR_ID= #{operatorID,jdbcType=VARCHAR}, OPERATOR_NAME= #{operatorName,jdbcType=VARCHAR}, IS_FEEDBACK_REQUIRED= #{isFeedbackRequired,jdbcType=VARCHAR}, "
			+ "GWIX_USER= #{gwixUser,jdbcType=VARCHAR} "
			+ "WHERE WC_BUSINES = #{wcBusiness,jdbcType=VARCHAR}";
	
	final String getFileProcessor = "SELECT * from "
			+ " (SELECT ROW_NUMBER() OVER (ORDER BY A.${sortingColIndex} ${inOrder}) AS Row, "
			+ "A.*, B.FILESTATUS_SHORT_DESC, C.PFI_BUSINESS_NAME "
			+ "FROM "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SRC_PAYMENT_FILE A, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILESTATUS B, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS C " 
			+ "WHERE upper(A.SRC_PAYMENT_FILE_NAME) like '%${sourceFileName}%' "
			+ "AND A.FILESTATUS_ID = B.FILESTATUS_ID "
			+ "AND A.PFI_BUSINESS_ID = C.PFI_BUSINESS_ID ) AS srcPaymentFileWithRowNumbers " 
			+ "WHERE Row > #{startPageIndex,jdbcType=NUMERIC} and Row <= #{recordsPerPage,jdbcType=NUMERIC} ";
	final String getFileProcessorCount = "SELECT count(*) COUNTER FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SRC_PAYMENT_FILE "
		+ "WHERE upper(SRC_PAYMENT_FILE_NAME) like '%${sourceFileName}%' AND upper(PFI_BUSINESS_ID) like '%${optionID}%'";
	final String updateFileProcessor= "UPDATE IHB_FILE_PROCESSOR SET SOURCE_FILE_NAME= #{sourceFileName,JDBCTYPE=VARCHAR}, FILE_TYPE= #{fileType,JDBCTYPE=VARCHAR}, FILE_FORMAT_VERSION= #{fileFormatVersion,JDBCTYPE=VARCHAR}, "  
		+ "FILE_CREATION_MODULE= #{fileCreationModule,JDBCTYPE=VARCHAR}, FILE_TRAILER_FILE_NAME= #{fileTrailerFileName,JDBCTYPE=VARCHAR}, FILE_TRAILER_TOTAL_RECORDS= #{fileTrailerTotalRecords,JDBCTYPE=VARCHAR}, "
		+ "FILE_SEGREGATION_FLAG= #{fileSegregationFlag,JDBCTYPE=VARCHAR}, TOTAL_NUMBER_OF_PAYMENTS= #{totalNumberOfPayments,JDBCTYPE=VARCHAR}, SEGREGATION_STATUS= #{segregationStatus,JDBCTYPE=VARCHAR}, "
		+ "SEGREGATION_STATUS_DETAIL= #{segregationStatusDetails,JDBCTYPE=VARCHAR}, IMPORT_STATUS_WEBCASH= #{importStatusWebcash,JDBCTYPE=VARCHAR}, IMPORT_STATUS_WC_DETAIL= #{importStatusWebcashDetails,JDBCTYPE=VARCHAR}, "
		+ "IMPORT_STATUS_CMM= #{importStatusCMM,JDBCTYPE=VARCHAR}, IMPORT_STATUS_CMM_DETAIL= #{importStatusCMMDetails,JDBCTYPE=VARCHAR},  OPTION_ID= #{optionID,JDBCTYPE=VARCHAR} "
		+ "WHERE FILE_PROCESSING_UINQUE_KEY = #{fileProcessingUniqueKey,JDBCTYPE=VARCHAR} ";
	final String getFileProcessorByID = "SELECT A.* , B.FILESTATUS_SHORT_DESC, C.PFI_BUSINESS_NAME from "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SRC_PAYMENT_FILE A, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILESTATUS B, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_BUSINESS C "
			+ "WHERE A.FILESTATUS_ID = B.FILESTATUS_ID "
			+ "AND A.PFI_BUSINESS_ID = C.PFI_BUSINESS_ID "
			+ "AND A.SRC_PAYMENT_FILE_ID = #{fileProcessorKey,JDBCTYPE=NUMERIC}";
	
	final String getFileSegregator = "SELECT * from "
			+ "(SELECT ROW_NUMBER() OVER (ORDER BY A.${sortingColIndex} ${inOrder}) AS Row, "
			+ "A.*, B.FILESTATUS_SHORT_DESC, C.TSAINSTANCE_IDENTIFIER "
			+ "FROM "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SEGREGATOR_FILE A, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_FILESTATUS B, "
			+ "Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES C " 
			+ "WHERE SRC_PAYMENT_FILE_ID = #{fileProcessorId,JDBCTYPE=NUMERIC} "
			+ "AND B.FILESTATUS_ID = A.FILESTATUS_ID "
			+ "AND C.TSAINSTACES_ID = A.TSAINSTANCES_ID "
			+ ") AS SegregatorWithRowNumbers " 
			+ " where Row > #{startPageIndex,jdbcType=NUMERIC} and Row <= #{recordsPerPage,jdbcType=NUMERIC} ";
	final String getFileSegregatorCount = "SELECT count(*) COUNTER FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_SEGREGATOR_FILE " 
		+ "WHERE SRC_PAYMENT_FILE_ID = #{fileProcessorId,JDBCTYPE=NUMERIC} ";
	final String updateFileSegregator= "UPDATE IHB_FILE_SEGREGATOR SET SOURCE_FILE_NAME= #{sourceFileName,JDBCTYPE=VARCHAR}, OUTPUT_FILE_NAME= #{outputFileName,JDBCTYPE=VARCHAR}, PAYMENT_SYSTEM= #{paymentSystem,JDBCTYPE=VARCHAR}, "  
		+ "NUMBER_OF_PAYMENTS= #{numberOfPayments,JDBCTYPE=VARCHAR}, IMPORT_FILE_RECEIVED= #{importFileReceived,JDBCTYPE=VARCHAR}, IMPORT_FILENAME= #{importFileName,JDBCTYPE=VARCHAR}, "
		+ "WC_IMPORTING_FILENAME= #{wcImportFileName,JDBCTYPE=VARCHAR} "
		+ "WHERE FILE_SEGREGATOR_UNIQUE_KEY = #{fileSegUniqueKey,JDBCTYPE=VARCHAR}";
	
	final String getFileSegregatorTxn = "SELECT * from Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_PFI_TRANSACTIONS WHERE SEGREGATOR_FILE_ID = #{fileSegId,JDBCTYPE=NUMERIC} ORDER BY PFI_TRANSACTION_ID";
	
	@Select(getBusinessUser)
	//@ResultMap("businessUserResultMap")
	List<BusinessUserBean> getFilteredBusinessUserDetails(
			Map<String, Object> daoParameters);
	
	@Select(getBusinessUserCount)
	int getFilteredBusinessUserDetailsCount(Map<String, Object> daoParameters);
	
	@Update(updateBusinessUser)
	int updateBusinessUserDetails(BusinessUserBean businessUserBean);

	@Select(getFileProcessor)
	@ResultMap("sourcePaymentFileResultMap")
	List<SourcePaymentFileBean> getFilteredFileProcessorDetails(
			Map<String, Object> daoParameters);

	@Select(getFileProcessorCount)
	int getFilteredFileProcessorDetailsCount(Map<String, Object> daoParameters);
	
	@Update(updateFileProcessor)
	int updateFileProcessorDetails(SourcePaymentFileBean fileProcessorBean);
	
	@Select(getFileProcessorByID)
	@ResultMap("sourcePaymentFileResultMap")
	List<SourcePaymentFileBean> getFileProcessorDetailById(Long fileProcessorKey);

	@Select(getFileSegregator)
	@ResultMap("fileSegregatorResultMap")
	List<FileSegregatorBean> getFileSegregatorDetails(
			Map<String, Object> daoParameters);

	@Select(getFileSegregatorCount)
	int getFileSegregatorDetailsCount(Long fileProcessorId);
	
	@Update(updateFileSegregator)
	int updateFileSegregatorDetails(FileSegregatorBean fileSegregatorBean);
	
	@Select(getFileSegregatorTxn)
	@ResultMap("pfiTxnResultMap")
	List<PFITransactionsBean> getFileSegregatorTxnDetails(
			Long fileSegId);


}