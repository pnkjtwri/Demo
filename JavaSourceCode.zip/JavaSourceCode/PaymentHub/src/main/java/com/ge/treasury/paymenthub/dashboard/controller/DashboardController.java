
package com.ge.treasury.paymenthub.dashboard.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.treasury.paymenthub.dashboard.model.*;
import com.ge.treasury.paymenthub.dashboard.service.DashboardService;
import com.google.gson.Gson;

/**
 * @author pankaj1.tiwari
 */
@Controller
@RequestMapping("/")
public class DashboardController {
	
	@Autowired DashboardService dashboardService;
	@RequestMapping
	public ModelAndView list() {
		return new ModelAndView("jsp/dashoard");
	}

	@RequestMapping(value="/businessuser")
	public ModelAndView getBusinessUserPage() {
		return new ModelAndView("jsp/businessUser");
	}
	
	@RequestMapping(value="/fileprocessor")
	public ModelAndView getFileProcessorPage() {
		return new ModelAndView("jsp/fileProcessor");
	}
	
	@RequestMapping(value="/fileProcessorDetailPage")
	public ModelAndView fileProcessorDetailPage(HttpServletRequest request) {
		String fileProcessorKeyTxt = (String) (request.getParameter("processid"));
		
		Long fileProcessorKey = null;
		if(fileProcessorKeyTxt != null)fileProcessorKey = Long.parseLong(fileProcessorKeyTxt);
		
		System.out.println("File Process ID:" +fileProcessorKey);
		List<SourcePaymentFileBean> fileProcessorDataList = dashboardService.getFileProcessorDetailById(fileProcessorKey);
		SourcePaymentFileBean srcPaymentBean = new SourcePaymentFileBean();
		if(fileProcessorDataList != null && fileProcessorDataList.size() > 0)
			srcPaymentBean = fileProcessorDataList.get(0);
		
		return new ModelAndView("jsp/fileProcessorDetail", "srcPaymentBean", srcPaymentBean);
	}

	@RequestMapping(value="/getbusinessuserlist", method={RequestMethod.POST})
	@ResponseBody
	public String getBusinessUserDetails(HttpServletRequest request)  {
		
		 int startPageIndex = Integer.parseInt(request.getParameter("jtStartIndex"));
	     int recordsPerPage = Integer.parseInt(request.getParameter("jtPageSize"));
	     String wcBusinessData = (String) (request.getParameter("wcBusiness"));
	     String optionIDData = (String) (request.getParameter("optionID"));
	     String sortingOrder = (String) (request.getParameter("jtSorting"));
	     if(sortingOrder == null || sortingOrder == "")sortingOrder = "wcBusiness ASC";
	     
	     if(wcBusinessData == null)wcBusinessData="";
	     if(optionIDData == null)optionIDData="";
	     wcBusinessData = wcBusinessData.toUpperCase();
    	 optionIDData = optionIDData.toUpperCase();
    	//Fetch Data from DB
    	 List<BusinessUserBean> businesUserList = dashboardService.getFilteredBusinessUserDetails(wcBusinessData, 
    			 optionIDData, startPageIndex, recordsPerPage, sortingOrder);
    	 
    	 int totRecordCount = dashboardService.getFilteredBusinessUserDetailsCount(wcBusinessData, optionIDData);
	    
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		 JSONROOT.put("Result", "OK");
         JSONROOT.put("Records", businesUserList);
         JSONROOT.put("TotalRecordCount", totRecordCount);
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);
	        
		//Returning Json data
		 return jsonArray;
	    
	}
	
	@RequestMapping(value="/updatebusinessuser", method={RequestMethod.POST})
	@ResponseBody
	public String updateBusinessUserDetails(HttpServletRequest request)  {
		
		BusinessUserBean businessUserBean = new BusinessUserBean();
		
		/*businessUserBean.setWcBusiness( (String) (request.getParameter("wcBusiness")) );
		businessUserBean.setIsIHBBUsiness( (String) (request.getParameter("isIHBBUsiness")) );
		businessUserBean.setOptionID( (String) (request.getParameter("optionID")) );
		businessUserBean.setJobType( (String) (request.getParameter("jobType")) );
		businessUserBean.setJobFilter( (String) (request.getParameter("jobFilter")) );
		businessUserBean.setPluginID( (String) (request.getParameter("pluginID")) );
		businessUserBean.setTrustedSource( (String) (request.getParameter("trustedSource")) );
		businessUserBean.setCmmPaymentInputFolder( (String) (request.getParameter("cmmPaymentInputFolder")) );
		businessUserBean.setDescription( (String) (request.getParameter("description")) );
		businessUserBean.setOperatorID( (String) (request.getParameter("operatorID")) );
		businessUserBean.setOperatorName( (String) (request.getParameter("operatorName")) );
		businessUserBean.setIsFeedbackRequired( (String) (request.getParameter("isFeedbackRequired")) );
		businessUserBean.setGwixUser( (String) (request.getParameter("gwixUser")) );
		*/
		//Updating Data into DB
		boolean checkFlg = dashboardService.updateBusinessUserDetails(businessUserBean);
		 
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		// Return in the format required by jTable plugin
		 if(checkFlg){
			JSONROOT.put("Result", "OK");
			JSONROOT.put("Record", businessUserBean); 
		 }else{
			 JSONROOT.put("Result", "ERROR");
			 JSONROOT.put("Message", "Record(s) not saved successfully. Please try after some time.");
		 }
	    
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);

		//Returning Json Data......
		 return jsonArray;
	    
	}
	
	
	@RequestMapping(value="/getfileprocessorlist", method={RequestMethod.POST})
	@ResponseBody
	public String getFileProcessorDetails(HttpServletRequest request)  {
		
		 int startPageIndex = Integer.parseInt(request.getParameter("jtStartIndex"));
	     int recordsPerPage = Integer.parseInt(request.getParameter("jtPageSize"));
	     String sourceFileNameData = (String) (request.getParameter("sourceFileName"));
	     String optionIDData = (String) (request.getParameter("optionID"));
	     String sortingOrder = (String) (request.getParameter("jtSorting"));
	     if(sortingOrder == null || sortingOrder == "")sortingOrder = "fileProcessingUniqueKey ASC";
	     
	     if(sourceFileNameData == null)sourceFileNameData="";
	     if(optionIDData == null)optionIDData="";
	     sourceFileNameData = sourceFileNameData.toUpperCase();
    	 optionIDData = optionIDData.toUpperCase();
    	//Fetch Data from DB
    	 List<SourcePaymentFileBean> fileProcessorList = dashboardService.getFilteredFileProcessorDetails(sourceFileNameData, 
    			 optionIDData, startPageIndex, recordsPerPage, sortingOrder);
    	 
    	 int totRecordCount = dashboardService.getFilteredFileProcessorDetailsCount(sourceFileNameData, optionIDData);
	    
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		 JSONROOT.put("Result", "OK");
         JSONROOT.put("Records", fileProcessorList);
         JSONROOT.put("TotalRecordCount", totRecordCount);
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);
	        
		//Returning Json data
		 return jsonArray;
	    
	}
	
	
	@RequestMapping(value="/updatefileprocessor", method={RequestMethod.POST})
	@ResponseBody
	public String updateFileProcessorDetails(HttpServletRequest request)  {
		
		SourcePaymentFileBean fileProcessorBean = new SourcePaymentFileBean();
		
		/*fileProcessorBean.setFileProcessingUniqueKey( Long.parseLong((String) (request.getParameter("fileProcessingUniqueKey"))) );
		fileProcessorBean.setSourceFileName( (String) (request.getParameter("sourceFileName")) );
		fileProcessorBean.setFileType( (String) (request.getParameter("fileType")) );
		fileProcessorBean.setFileFormatVersion( (String) (request.getParameter("fileFormatVersion")) );
		fileProcessorBean.setFileCreationModule( (String) (request.getParameter("fileProcessingUniqueKey")) );
		fileProcessorBean.setFileTrailerFileName( (String) (request.getParameter("fileTrailerFileName")) );
		fileProcessorBean.setFileTrailerTotalRecords( Integer.parseInt((String) (request.getParameter("fileTrailerTotalRecords"))) );
		fileProcessorBean.setFileSegregationFlag( (String) (request.getParameter("fileSegregationFlag")) );
		fileProcessorBean.setTotalNumberOfPayments( Integer.parseInt((String) (request.getParameter("totalNumberOfPayments"))) );
		fileProcessorBean.setSegregationStatus( (String) (request.getParameter("segregationStatus")) );
		fileProcessorBean.setSegregationStatusDetails( (String) (request.getParameter("segregationStatusDetails")) );
		fileProcessorBean.setImportStatusWebcash( (String) (request.getParameter("importStatusWebcash")) );
		fileProcessorBean.setImportStatusWebcashDetails( (String) (request.getParameter("importStatusWebcashDetails")) );
		fileProcessorBean.setImportStatusCMM( (String) (request.getParameter("importStatusCMM")) );
		fileProcessorBean.setImportStatusCMMDetails( (String) (request.getParameter("importStatusCMMDetails")) );
		fileProcessorBean.setOptionID( (String) (request.getParameter("optionID")) );*/
		
		//Updating Data into DB
		boolean checkFlg = dashboardService.updateFileProcessorDetails(fileProcessorBean);
		 
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		// Return in the format required by jTable plugin
		 if(checkFlg){
			JSONROOT.put("Result", "OK");
			JSONROOT.put("Record", fileProcessorBean); 
		 }else{
			 JSONROOT.put("Result", "ERROR");
			 JSONROOT.put("Message", "Record(s) not saved successfully. Please try after some time.");
		 }
	    
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);

		//Returning Json Data......
		 return jsonArray;
	    
	}
	
	@RequestMapping(value="/getfileSegregatorlist", method={RequestMethod.POST})
	@ResponseBody
	public String getFileSegregatorDetails(HttpServletRequest request)  {
		
		 int startPageIndex = Integer.parseInt(request.getParameter("jtStartIndex"));
	     int recordsPerPage = Integer.parseInt(request.getParameter("jtPageSize"));
	     String sortingOrder = (String) (request.getParameter("jtSorting"));
	     if(sortingOrder == null || sortingOrder == "")sortingOrder = "segregatorFileID ASC";
	     Long fileProcessorId = Long.parseLong(request.getParameter("fileProcessorId"));
	     
    	 //Fetch Data from DB
    	 List<FileSegregatorBean> fileProcessorList = dashboardService.getFileSegregatorDetails(fileProcessorId, startPageIndex, recordsPerPage, sortingOrder);
    	 
    	 int totRecordCount = dashboardService.getFileSegregatorDetailsCount(fileProcessorId);
	    
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		 JSONROOT.put("Result", "OK");
         JSONROOT.put("Records", fileProcessorList);
         JSONROOT.put("TotalRecordCount", totRecordCount);
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);
	        
		//Returning Json data
		 return jsonArray;
	    
	}
	
	@RequestMapping(value="/updatefileSegregator", method={RequestMethod.POST})
	@ResponseBody
	public String updateFileSegregatorDetails(HttpServletRequest request)  {
		
		FileSegregatorBean fileSegregatorBean = new FileSegregatorBean();
		
		/*fileSegregatorBean.setFileSegUniqueKey( Long.parseLong((String) (request.getParameter("fileSegUniqueKey"))) );
		fileSegregatorBean.setSourceFileName( (String) (request.getParameter("sourceFileName")) );
		fileSegregatorBean.setOutputFileName( (String) (request.getParameter("outputFileName")) );
		fileSegregatorBean.setPaymentSystem( (String) (request.getParameter("paymentSystem")) );
		fileSegregatorBean.setNumberOfPayments( Integer.parseInt((String) (request.getParameter("numberOfPayments"))) );
		fileSegregatorBean.setImportFileReceived( (String) (request.getParameter("importFileReceived")) );
		fileSegregatorBean.setImportFileName( (String) (request.getParameter("importFileName")) );
		fileSegregatorBean.setWcImportFileName( (String) (request.getParameter("wcImportFileName")) );*/
		
		//Updating Data into DB
		boolean checkFlg = dashboardService.updateFileSegregatorDetails(fileSegregatorBean);
		 
		// Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		// Return in the format required by jTable plugin
		 if(checkFlg){
			JSONROOT.put("Result", "OK");
			JSONROOT.put("Record", fileSegregatorBean); 
		 }else{
			 JSONROOT.put("Result", "ERROR");
			 JSONROOT.put("Message", "Record(s) not saved successfully. Please try after some time.");
		 }
	    
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);

		//Returning Json Data......
		 return jsonArray;
	    
	}
	
	@RequestMapping(value="/getfileSegregatorTxnlist", method={RequestMethod.POST})
	@ResponseBody
	public String getFileSegregatorTxnDetails(HttpServletRequest request)  {
		
		 Long fileSegId = Long.parseLong(request.getParameter("fileSegId"));
	     //Fetch Data from DB
    	 List<PFITransactionsBean> fileProcessorList = dashboardService.getFileSegregatorTxnDetails(fileSegId);
    	 // Return in the format required by jTable plugin
		 HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
		 JSONROOT.put("Result", "OK");
         JSONROOT.put("Records", fileProcessorList);
         
       //Convert Java Object to Json
         Gson gson = new Gson();
         String jsonArray = gson.toJson(JSONROOT);
	        
		//Returning Json data
		 return jsonArray;
	    
	}

}