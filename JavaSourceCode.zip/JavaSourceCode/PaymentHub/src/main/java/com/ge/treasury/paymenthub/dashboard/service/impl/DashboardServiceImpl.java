package com.ge.treasury.paymenthub.dashboard.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ge.treasury.paymenthub.dashboard.dao.DashboardDAO;
import com.ge.treasury.paymenthub.dashboard.model.*;
import com.ge.treasury.paymenthub.dashboard.service.DashboardService;
import com.ge.treasury.paymenthub.dashboard.utility.DashboardUtility;

/**
 * 
 * @author pankaj1.tiwari
 *
 */
@Service
public class DashboardServiceImpl implements DashboardService {

	@Autowired DashboardDAO dashboardDAO;

	@Override
	@Transactional
	public boolean updateBusinessUserDetails(BusinessUserBean businessUserBean) {
		int returnValue =  dashboardDAO.updateBusinessUserDetails(businessUserBean);
		return (returnValue > 0 ? true : false);
	}

	@Override
	@Transactional(readOnly=true)
	public List<BusinessUserBean> getFilteredBusinessUserDetails(
			String wcBusiness, String optionID, int startPageIndex,
			int recordsPerPage, String sortingOrder) {
		
		String[] rtnData = DashboardUtility.splitWhitespaceString(sortingOrder);
		String sortingColumnName = "wcBusiness";
		String inOrder = "ASC"; 
		if(rtnData != null){
			sortingColumnName = rtnData[0];
			inOrder = rtnData[1];
		}
				
		int sortingColIndex = DashboardUtility.getBusinessUserDataBaseColumnName(sortingColumnName);
		
		recordsPerPage = startPageIndex + recordsPerPage;
		Map<String, Object> daoParameters = new HashMap<String, Object>();
		daoParameters.put("startPageIndex", startPageIndex);
		daoParameters.put("recordsPerPage", recordsPerPage);
		daoParameters.put("wcBusiness", wcBusiness);
		daoParameters.put("optionID", optionID);
		daoParameters.put("sortingColIndex", sortingColIndex);
		daoParameters.put("inOrder", inOrder);
		return  dashboardDAO.getFilteredBusinessUserDetails(daoParameters);
	}

	@Override
	@Transactional(readOnly=true)
	public int getFilteredBusinessUserDetailsCount(String wcBusinessData,
			String optionIDData) {
		Map<String, Object> daoParameters = new HashMap<String, Object>();
		daoParameters.put("wcBusiness", wcBusinessData);
		daoParameters.put("optionID", optionIDData);
		return dashboardDAO.getFilteredBusinessUserDetailsCount(daoParameters);
	}

	@Override
	@Transactional(readOnly=true)
	public List<SourcePaymentFileBean> getFilteredFileProcessorDetails(
			String sourceFileNameData, String optionIDData, int startPageIndex,
			int recordsPerPage, String sortingOrder) {
		
		String[] rtnData = DashboardUtility.splitWhitespaceString(sortingOrder);
		String sortingColumnName = "fileProcessingUniqueKey";
		String orderBy = "ASC"; 
		if(rtnData != null){
			sortingColumnName = rtnData[0];
			orderBy = rtnData[1];
		}
				
		String columnName = DashboardUtility.getFileProcessorDataBaseColumnName(sortingColumnName);
		
		recordsPerPage = startPageIndex + recordsPerPage;
		Map<String, Object> daoParameters = new HashMap<String, Object>();
		daoParameters.put("startPageIndex", startPageIndex);
		daoParameters.put("recordsPerPage", recordsPerPage);
		daoParameters.put("sourceFileName", sourceFileNameData);
		daoParameters.put("optionID", optionIDData);
		daoParameters.put("sortingColIndex", columnName);
		daoParameters.put("inOrder", orderBy);
		return  dashboardDAO.getFilteredFileProcessorDetails(daoParameters);
	}

	@Override
	@Transactional(readOnly=true)
	public int getFilteredFileProcessorDetailsCount(String sourceFileNameData,
			String optionIDData) {
		Map<String, Object> daoParameters = new HashMap<String, Object>();
		daoParameters.put("sourceFileName", sourceFileNameData);
		daoParameters.put("optionID", optionIDData);
		return dashboardDAO.getFilteredFileProcessorDetailsCount(daoParameters);
	}

	@Override
	@Transactional(readOnly=true)
	public List<SourcePaymentFileBean> getFileProcessorDetailById(
			Long fileProcessorKey) {
		return dashboardDAO.getFileProcessorDetailById(fileProcessorKey);
	}

	@Override
	@Transactional(readOnly=true)
	public List<FileSegregatorBean> getFileSegregatorDetails(Long fileProcessorId,
			int startPageIndex, int recordsPerPage, String sortingOrder) {
		String[] rtnData = DashboardUtility.splitWhitespaceString(sortingOrder);
		String sortingColumnName = "fileSegUniqueKey";
		String orderBy = "ASC"; 
		if(rtnData != null){
			sortingColumnName = rtnData[0];
			orderBy = rtnData[1];
		}
				
		String columnName = DashboardUtility.getFileSegregatorDataBaseColumnName(sortingColumnName);
		
		recordsPerPage = startPageIndex + recordsPerPage;
		Map<String, Object> daoParameters = new HashMap<String, Object>();
		daoParameters.put("fileProcessorId", fileProcessorId);
		daoParameters.put("startPageIndex", startPageIndex);
		daoParameters.put("recordsPerPage", recordsPerPage);
		daoParameters.put("sortingColIndex", columnName);
		daoParameters.put("inOrder", orderBy);
		return  dashboardDAO.getFileSegregatorDetails(daoParameters);
	}

	@Override
	@Transactional(readOnly=true)
	public int getFileSegregatorDetailsCount(Long fileProcessorId) {
		return dashboardDAO.getFileSegregatorDetailsCount(fileProcessorId);
	}

	@Override
	@Transactional(readOnly=true)
	public List<PFITransactionsBean> getFileSegregatorTxnDetails(Long fileSegId) {
		return  dashboardDAO.getFileSegregatorTxnDetails(fileSegId);
	}

	@Override
	@Transactional
	public boolean updateFileProcessorDetails(
			SourcePaymentFileBean fileProcessorBean) {
		int returnValue =  dashboardDAO.updateFileProcessorDetails(fileProcessorBean);
		return (returnValue > 0 ? true : false);
	}

	@Override
	@Transactional
	public boolean updateFileSegregatorDetails(
			FileSegregatorBean fileSegregatorBean) {
		int returnValue =  dashboardDAO.updateFileSegregatorDetails(fileSegregatorBean);
		return (returnValue > 0 ? true : false);
	}
	
	
}
