package com.ge.treasury.paymenthub.dashboard.service;

import java.util.List;

import com.ge.treasury.paymenthub.dashboard.model.*;

/**
 * 
 * @author pankaj1.tiwari
 *
 */
public interface DashboardService {
	
	public boolean updateBusinessUserDetails(BusinessUserBean businessUserBean);

	public List<BusinessUserBean> getFilteredBusinessUserDetails(
			String wcBusinessData, String optionIDData, int startPageIndex,
			int recordsPerPage, String sortingOrder);

	public int getFilteredBusinessUserDetailsCount(String wcBusinessData,
			String optionIDData);

	public List<SourcePaymentFileBean> getFilteredFileProcessorDetails(
			String sourceFileNameData, String optionIDData, int startPageIndex,
			int recordsPerPage, String sortingOrder);

	public int getFilteredFileProcessorDetailsCount(String sourceFileNameData,
			String optionIDData);

	public List<SourcePaymentFileBean> getFileProcessorDetailById(
			Long fileProcessorKey);

	public List<FileSegregatorBean> getFileSegregatorDetails(
			Long fileProcessorId, int startPageIndex, int recordsPerPage,
			String sortingOrder);
	
	public int getFileSegregatorDetailsCount(Long fileProcessorId);

	public List<PFITransactionsBean> getFileSegregatorTxnDetails(Long fileSegId);

	public boolean updateFileProcessorDetails(
			SourcePaymentFileBean fileProcessorBean);
	
	public boolean updateFileSegregatorDetails(
			FileSegregatorBean fileSegregatorBean);
}
