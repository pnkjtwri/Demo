package com.ge.treasury.paymenthub.dashboard.model;

import java.util.Date;

/**
 * 
 * @author pankaj1.tiwari
 *
 */
public class FileSegregatorBean {
	
	private Long segregatorFileID;
	private Long srcPaymentFileID;
	private String segregatorFileName;
	private String paymentInstType;
	private String tsaInstancesID;
	private Long fileStatusID;
	private String importStatusFileName;
	private String noOfTransactios;
	private String createdBy;
	private Date creationTime;
	private String lastModifiedBy;
	private Date lastModifiedTime;
	private String fileStatusDesc;
	private String tsaInstancesIdentifier;
	
	public Long getSegregatorFileID() {
		return segregatorFileID;
	}
	public void setSegregatorFileID(Long segregatorFileID) {
		this.segregatorFileID = segregatorFileID;
	}
	public Long getSrcPaymentFileID() {
		return srcPaymentFileID;
	}
	public void setSrcPaymentFileID(Long srcPaymentFileID) {
		this.srcPaymentFileID = srcPaymentFileID;
	}
	public String getSegregatorFileName() {
		return segregatorFileName;
	}
	public void setSegregatorFileName(String segregatorFileName) {
		this.segregatorFileName = segregatorFileName;
	}
	public String getPaymentInstType() {
		return paymentInstType;
	}
	public void setPaymentInstType(String paymentInstType) {
		this.paymentInstType = paymentInstType;
	}
	public String getTsaInstancesID() {
		return tsaInstancesID;
	}
	public void setTsaInstancesID(String tsaInstancesID) {
		this.tsaInstancesID = tsaInstancesID;
	}
	public Long getFileStatusID() {
		return fileStatusID;
	}
	public void setFileStatusID(Long fileStatusID) {
		this.fileStatusID = fileStatusID;
	}
	public String getImportStatusFileName() {
		return importStatusFileName;
	}
	public void setImportStatusFileName(String importStatusFileName) {
		this.importStatusFileName = importStatusFileName;
	}
	public String getNoOfTransactios() {
		return noOfTransactios;
	}
	public void setNoOfTransactios(String noOfTransactios) {
		this.noOfTransactios = noOfTransactios;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}
	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}
	public String getFileStatusDesc() {
		return fileStatusDesc;
	}
	public void setFileStatusDesc(String fileStatusDesc) {
		this.fileStatusDesc = fileStatusDesc;
	}
	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}
	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}
	
	
	

}
