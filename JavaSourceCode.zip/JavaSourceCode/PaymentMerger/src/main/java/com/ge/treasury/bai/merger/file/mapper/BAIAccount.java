package com.ge.treasury.bai.merger.file.mapper;
import java.util.List;

public class BAIAccount {
	private BAIAccountIdentifier accountIdentifier;
	private List<BAITransactionDetail> transactionDetails;
	private BAIAccountTrailer accountTrailer;
}
