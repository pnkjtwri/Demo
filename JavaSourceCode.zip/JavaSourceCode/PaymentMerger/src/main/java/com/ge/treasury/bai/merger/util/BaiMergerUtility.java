package com.ge.treasury.bai.merger.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ge.treasury.bai.merger.file.mapper.BAIFileHeader;
import com.ge.treasury.bai.merger.file.mapper.BAIFileTrailer;

public class BaiMergerUtility {
	final static Logger logger = Logger.getLogger(BaiMergerUtility.class);
	
	/*
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
	
	public static int getTotalNoOfRecods(String inputFile){
		logger.info("[BaiMergerUtility] - Going to get total no of records in the file - "+inputFile);
		int totalNoOfRecordsInFile 	= 0;
		BAIFileTrailer fileTrailer 	= null;
		BufferedReader br 			= null; 
		try {
			br = new BufferedReader(new FileReader(inputFile));
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
			    	logger.info("[BaiMergerUtility] - File Trailer Found With start - "+BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG);
			    	fileTrailer = new BAIFileTrailer();
			    	fileTrailer.populate(recordArray);
			    }
			}
			
			if(fileTrailer != null){
				if(fileTrailer.getNumberOfRecords().indexOf("/") > 0){
					totalNoOfRecordsInFile = Integer.parseInt(fileTrailer.getNumberOfRecords().replace("/", ""));
				}else{
					totalNoOfRecordsInFile = Integer.parseInt(fileTrailer.getNumberOfRecords());
				}
			}
			logger.info("[BaiMergerUtility] - "+inputFile+" has Total no of Records - "+totalNoOfRecordsInFile);
		}catch (FileNotFoundException e) {
			logger.info("[BaiMergerUtility] - "+inputFile+" File not found while getting total no of records ");
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch (IOException e) {
			logger.info("[BaiMergerUtility] - IO Exception Occeurred while getting total no of records file - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch(NumberFormatException e){
			logger.info("[BaiMergerUtility] - Number Format Exception while getting total no of records - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}finally{
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					logger.info("[BaiMergerUtility] - Reader closing error in total no of records");
				}
			}
		}
		
		return totalNoOfRecordsInFile;
	}
	
	public static String getFileTotalAmount(String inputFile){
		logger.info("[BaiMergerUtility] - Going to get total Amount in the file - "+inputFile);
		String amount 	= "0";
		BAIFileTrailer fileTrailer 	= null;
		BufferedReader br 			= null; 
		try {
			br = new BufferedReader(new FileReader(inputFile));
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
			    	logger.info("[BaiMergerUtility] - File Trailer Found With start - "+BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG);
			    	fileTrailer = new BAIFileTrailer();
			    	fileTrailer.populate(recordArray);
			    }
			}
			
			if(fileTrailer != null){
				amount = fileTrailer.getFileControlTotal();
				try{
					Long.parseLong(amount);
				}catch(Exception e){
					logger.info("[BaiMergerUtility] - Invalid total amount in footer - "+amount);
					amount = "0";
				}
			}
			logger.info("[BaiMergerUtility] - "+inputFile+" has Total Amount - "+amount);
		}catch (FileNotFoundException e) {
			logger.info("[BaiMergerUtility] - "+inputFile+" File not found while getting total amount ");
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch (IOException e) {
			logger.info("[BaiMergerUtility] - IO Exception Occeurred while getting total amount file - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch(NumberFormatException e){
			logger.info("[BaiMergerUtility] - Number Format Exception while getting total amount - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}finally{
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					logger.info("[BaiMergerUtility] - Reader closing error in total amount");
				}
			}
		}
		
		return amount;
	}
	
	
	/**
	 * to get source file details 
	 * 
	 * @param sourceFile
	 * @return String
	 */
	public static Timestamp getFileAttributes(File sourceFile){
		logger.info("[BaiMergerUtility] - Going to get source file attributes - "+sourceFile);
		Path filePath 			 = Paths.get(sourceFile.getPath());
        BasicFileAttributes attr = null;
        Timestamp srcFileCreationTime = null;
        
		try {
			attr                = Files.readAttributes(filePath, BasicFileAttributes.class);
			srcFileCreationTime =  new Timestamp(attr.creationTime().toMillis());
			logger.info("[BaiMergerUtility] - "+sourceFile+" Source file creation time - "+srcFileCreationTime);
		} catch (IOException e) {
			logger.info("[BaiMergerUtility] - Error while getting file attribute - "+sourceFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}
 		
		return srcFileCreationTime;
	}
	
	public static String getTsaIdentifierFromFileName(String sourceFile){
		String tsaInstance = "";
		
		if(sourceFile.indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_TYPE_EXTENSION) > 0){
			tsaInstance = sourceFile.substring(sourceFile.indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_TYPE_EXTENSION)+5, sourceFile.lastIndexOf("_"));
		}else if(sourceFile.toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()) > 0){
			tsaInstance = sourceFile.toLowerCase().substring(sourceFile.toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase())+5, sourceFile.lastIndexOf("_"));
		}
		
		return tsaInstance.toUpperCase();
	}
	
	public static void moveFile(File inputFile, String movedLocation, boolean isArchiveOrError, boolean trimTs){
		String actualfilename = "";
		if(trimTs){
			actualfilename=trimBAIFileTimeStamp(inputFile.getName());
		}else{
			actualfilename = inputFile.getName();
		}
		
		String todayDate  = new SimpleDateFormat("yyyyMMddhhmmssSSS").format(new Date());
		String renameFileName = movedLocation+actualfilename;
		if(isArchiveOrError){
			renameFileName = renameFileName+"_"+todayDate;
		}
		
		Path movedFileLocation = FileSystems.getDefault().getPath(renameFileName);
		Path fromFileLocation  = FileSystems.getDefault().getPath(inputFile.getAbsolutePath());
		
		try{
			logger.info("[BaiMergerUtility] - File Moving from  - "+inputFile.getAbsolutePath());
	        Files.move(fromFileLocation, movedFileLocation, StandardCopyOption.REPLACE_EXISTING);
	        logger.info("[BaiMergerUtility] - File Moved to  - "+renameFileName);
	    }catch (IOException e) {
	    	logger.info("[BaiMergerUtility] - Error in File Moving at location - "+renameFileName);
	    	logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
	    }
	}
	
	
	public static String getOriginatorIdentification(String inputFile){
		logger.info("[BaiMergerUtility] - Going to get originator identification from the file - "+inputFile);
		String originatorIdentification = "Not Found";
		//BAIFileTrailer fileTrailer 	= null;
		BAIFileHeader   fileHeader      = null;
		BufferedReader br 			= null; 
		try {
			br = new BufferedReader(new FileReader(inputFile));
			String line = "";
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG)){
			    	logger.info("[BaiMergerUtility] - File Trailer Found With start - "+BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG);
			    	fileHeader = new BAIFileHeader();
			    	fileHeader.populate(recordArray);
			    }
			}
			
			if(fileHeader.getReceiverIdentification().length() > 0){
				originatorIdentification = fileHeader.getReceiverIdentification();
			}
			
			logger.info("[BaiMergerUtility] - "+inputFile+" has Total no of Records - "+originatorIdentification);
		}catch (FileNotFoundException e) {
			logger.info("[BaiMergerUtility] - "+inputFile+" File not found while getting originatorIdentification ");
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch (IOException e) {
			logger.info("[BaiMergerUtility] - IO Exception Occeurred while originatorIdentification - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}catch(NumberFormatException e){
			logger.info("[BaiMergerUtility] - Number Format Exception while originatorIdentification - "+inputFile);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}finally{
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					logger.info("[BaiMergerUtility] - Reader closing error in originatorIdentification method");
				}
			}
		}
		
		return originatorIdentification;
	}
	
	public static int getNoOfFileReceived(String location, String fileFormat){
		logger.info("[BaiMergerUtility] - Going to get no of file received for file format - "+fileFormat);
		int count = 0;
		try{
			File f = new File(location);
		    File[] files = f.listFiles();
		    if (files != null)
		    for (int i = 0; i < files.length; i++) {
		        File file = files[i];
		        if(file.isFile() && file.getName().contains(fileFormat)){
		        	count++;
		        }
		    }
		    logger.info("[BaiMergerUtility] - No of files received - "+count);
		}catch(Exception e){
			logger.info("[BaiMergerUtility] - Error while getting no of received files");
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}
		return count;
	}
		
	public static void removeFile(String location){
		logger.info("[BaiMergerUtility] - Going to remove file - "+location);
		try{
			Path fileToDelete = Paths.get(location);
			boolean isDeleted = Files.deleteIfExists(fileToDelete);
		    logger.info("[BaiMergerUtility] - File deleted status - "+isDeleted);
		}catch(Exception e){
			logger.info("[BaiMergerUtility] - File deletion failed - "+location);
			logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
		}
	}
	
	public static void copyFile(File inputFile, String movedLocation, String acbsGEBAIfilesuffix, boolean isTsAdded) throws Exception{
		String todayDate  = new SimpleDateFormat(BaiMergerConstants.FileFormatTypConstants.LATEST_TIMESTAMP_DATEIME_FORMAT).format(new Date());
		String renameFileName = "";
		try{
			if(inputFile.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()) > 0){
				renameFileName = inputFile.getName().substring(0,inputFile.getName().toLowerCase().lastIndexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()));
			}
			
			if(isTsAdded){
				renameFileName = inputFile.getName().substring(0,inputFile.getName().indexOf("."));
				renameFileName = movedLocation + renameFileName+ BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV + acbsGEBAIfilesuffix;
			}else{
				renameFileName = movedLocation + renameFileName + BaiMergerConstants.FileFormatTypConstants.UNDER_SCORE+ todayDate + BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2+acbsGEBAIfilesuffix;
			}
			
			Path movedFileLocation = FileSystems.getDefault().getPath(renameFileName);
			Path fromFileLocation  = FileSystems.getDefault().getPath(inputFile.getAbsolutePath());
		
			logger.info("[BaiMergerUtility] - Starting File Copy from  - "+inputFile.getAbsolutePath());
			Files.move(fromFileLocation, movedFileLocation, StandardCopyOption.REPLACE_EXISTING);
	        logger.info("[BaiMergerUtility] - File Copied to  - "+renameFileName);
	    }catch (IOException e) {
	    	logger.info("[BaiMergerUtility] - IO Error in File Copying at location - "+renameFileName);
	    	logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
	    	throw new RuntimeException();
	    }catch (Exception e) {
	    	logger.info("[BaiMergerUtility] - Error in File Copying at location - "+renameFileName);
	    	logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
	    	throw new RuntimeException();
	    }
	}
	
	public static void renameFile(File inputFile, File movedLocation) throws Exception{
		
		Path copyFileLocation = FileSystems.getDefault().getPath(movedLocation.getAbsolutePath());
		Path fromFileLocation  = FileSystems.getDefault().getPath(inputFile.getAbsolutePath());
		
		try{
			logger.info("[BaiMergerUtility] - Starting File Copy from  - "+inputFile.getAbsolutePath());
			Files.copy(fromFileLocation, copyFileLocation, StandardCopyOption.REPLACE_EXISTING);
	        logger.info("[BaiMergerUtility] - File Copied to  - "+movedLocation.getAbsolutePath());
	    }catch (IOException e) {
	    	logger.info("[BaiMergerUtility] - IO Error in File Copying at location - "+movedLocation.getAbsolutePath());
	    	logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
	    	throw new RuntimeException();
	    }catch (Exception e) {
	    	logger.info("[BaiMergerUtility] - Error in File Copying at location - "+movedLocation.getAbsolutePath());
	    	logger.info("[BaiMergerUtility] - "+getErrorFormStackTrace(e));
	    	throw new RuntimeException();
	    }
	}
	
	/**
	 * Method used for getting BAI file name without timestamp.
	 * @param decryptFile
	 * @return
	 */
	public static String trimBAIFileTimeStamp(String filename) {
		int dotIdx = filename.lastIndexOf(".");
		String fileNameWithTimeStamp = filename.substring(0, dotIdx);
		int underscoreIdx = fileNameWithTimeStamp.lastIndexOf("_");
		String fileNameWithoutTimeStamp = fileNameWithTimeStamp.substring(0, underscoreIdx);
		
		return fileNameWithoutTimeStamp+filename.substring(dotIdx, filename.length());
	}
	
	public static String getFileName(File fileObj){
		String fileToCheckName = "";
		String fileToCheckBusName = "";
		
		if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()) > 0){
			fileToCheckName    = fileObj.getName().substring(0,fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()));
	 		fileToCheckName    = fileToCheckName.substring(0,fileToCheckName.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.UNDER_SCORE));
		}else if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV) > 0){
			fileToCheckName    = fileObj.getName().substring(0,fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()));
	 		fileToCheckName    = fileToCheckName.substring(0,fileToCheckName.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.UNDER_SCORE));
		}
 		
		if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()) > 0){
	 		fileToCheckBusName = fileObj.getName().substring(fileObj.getName().toLowerCase().lastIndexOf(BaiMergerConstants.FileFormatTypConstants.FILE_TYPE_EXTENSION.toLowerCase())+4,fileObj.getName().length());
	 		fileToCheckName    = fileToCheckName + BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2 + fileToCheckBusName;
		}else if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()) > 0){
			fileToCheckBusName = fileObj.getName().substring(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase())+4,fileObj.getName().length());
	 		fileToCheckName    = fileToCheckName + BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV + fileToCheckBusName;
		}
 		
 		return fileToCheckName;
	}
	
	public static String getTimeStampFromFile(File fileObj){
		String fileToCheckTS   = "";
		if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase()) > 0){
			fileToCheckTS   = fileObj.getName().toLowerCase().substring(0,(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2.toLowerCase())));
	 		fileToCheckTS		   = fileToCheckTS.substring(fileToCheckTS.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.UNDER_SCORE)+1,fileToCheckTS.length());
		}else if(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()) > 0){
			fileToCheckTS   = fileObj.getName().substring(0,(fileObj.getName().toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase())));
	 		fileToCheckTS		   = fileToCheckTS.substring(fileToCheckTS.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.UNDER_SCORE)+1,fileToCheckTS.length());
		}
 		return fileToCheckTS;
	}
	
	/**
	* delete file from given location
	* @param generatedFile, files to be deleted
	*/
	public static void deleteFile(File generatedFile){
		if(generatedFile.exists()){
			logger.info("[BaiMergerUtility] - Removing file - "+generatedFile.getName());
			if(generatedFile.delete()){
				logger.info("[BaiMergerUtility] - File - "+generatedFile.getName()+" deleted !!");
			}else{
				logger.info("[BaiMergerUtility] - Error deleting file - "+generatedFile.getName());
			}
		}else{
			logger.info("[BaiMergerUtility] - File - "+generatedFile.getName() +" Not found !!");
		}
		
	}
}
