package com.ge.treasury.bai.merger.dao;

import java.util.List;

import com.ge.treasury.bai.merger.dao.mapper.FileStatusMapper;

public interface FileProcessingStatusDao {
	public List<FileStatusMapper> getFileStatus();
}
