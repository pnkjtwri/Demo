package com.ge.treasury.bai.merger.dao;

import java.util.List;

import com.ge.treasury.bai.merger.dao.mapper.InboundConfigMapper;

public interface InboundConfigDao {
	public List<InboundConfigMapper> getFileInboundDetails();
	public String getFileListFormFilePattern(String fileNamePattern);
}
