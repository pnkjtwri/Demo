package com.ge.treasury.bai.merger.load.config;

public interface FileStausLoaderService {
	public int getFileStatus(String fileStatusKey);
}
