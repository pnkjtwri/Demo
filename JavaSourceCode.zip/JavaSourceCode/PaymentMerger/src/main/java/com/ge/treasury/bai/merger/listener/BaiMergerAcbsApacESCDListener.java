package com.ge.treasury.bai.merger.listener;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import com.ge.treasury.bai.merger.bean.FilePoolingDetailsForApac;
import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.exception.BaiMergeProcessException;
import com.ge.treasury.bai.merger.mail.service.BaiMergerMailService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.process.BaiFileMergingService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;
import com.ge.treasury.bai.merger.validation.BaiMergerFileValidator;

@MessageEndpoint
public class BaiMergerAcbsApacESCDListener {
	private static Logger logger = Logger.getLogger(BaiMergerAcbsApacESCDListener.class);
	
	@Autowired
	@Qualifier("BaiFileMerge")
	BaiFileMergingService mergingService;
	
	@Autowired BaiMergerProcessPersistanceService persistanceService;
	@Autowired BaiMergerMailService mailService;
	@Autowired BaiMergerFileValidator validatorService;
	@Autowired private ApplicationContext appContext;
	
	private FilePoolingDetailsForApac filePooledDetails;
	
	/**
	 * @return the filePooledDetails
	 */
	public synchronized FilePoolingDetailsForApac getFilePooledDetails() {
		return filePooledDetails;
	}

	/**
	 * @param filePooledDetails the filePooledDetails to set
	 */
	public synchronized void setFilePooledDetails(FilePoolingDetailsForApac filePooledDetails) {
		this.filePooledDetails = filePooledDetails;
	}


	@Value("${createdBy}")
	private String createdBy;
	
	@Value("${lastModifiedBy}")
	private String lastModifiedBy;
	
	@Value("${sourceFileProcessingLocation}")
	private String processingLocation;
	
	@Value("%{ACBS_APAC_CD_location}")
	private String receivedFileLocation;
	
	@Value("${tmpOutPutFileLocation}")
	private String tmpOutPutFileLocation;
	
	@Value("${archiveFileLocation}")
	private String archiveFileLocation;
	
	@Value("${errorFileLocation}")
	private String errorFileLocation;
	
	@Value("%{ACBS_APACES_CD_schedule}")
	private String schedule;
	
	@Value("%{ACBS_APAC_CD_pattern}")
	private String nasFileNamePattern;
	
	private List<String> listOfFilesRecieved = null;
	private List<String> listOfValidFilesRecieved = null;
	private List<String> listOfWrongFormatFilesRecieved = null;
	private List<Integer> srcInboundFileIdList = null;
	private List<JobConfigMapper> noOfFilesWillReceived = null;
	private List<String> listOfFilesToRelease = null;
	private Integer noOfFilesReceivedAtLocation = null;
	private Integer poolingId  = null;
	
	@ServiceActivator
	public void initiateMerger(File inputFile){
		if(inputFile != null && inputFile.exists() && inputFile.isFile()){
			String fileName = BaiMergerUtility.trimBAIFileTimeStamp(inputFile.getName());
			
			if(listOfFilesToRelease == null){
				listOfFilesToRelease = new ArrayList<String>();
			}
			
			logger.info("[BaiMergerNACDListener] - add file to release lock");
			listOfFilesToRelease.add(inputFile.getName());
			logger.info("[BaiMergerNACDListener] - file added to release lock - "+inputFile.getName());

			logger.info("No of file pooled from filter - "+getFilePooledDetails().getNoOfFilesPooledFromLocation());
			
			try{
				if(noOfFilesReceivedAtLocation == null){
					noOfFilesReceivedAtLocation = getFilePooledDetails().getNoOfFilesPooledFromLocation();
					logger.info("[BaiMergerAcbsApacESCDListener] - "+noOfFilesReceivedAtLocation+" No of file at location - "+receivedFileLocation +" received");
				}
				
				logger.info("[BaiMergerAcbsApacESCDListener] - File Received - "+fileName);
				logger.info("[BaiMergerAcbsApacESCDListener] - File Moving to processing folder - "+processingLocation);

				if(listOfValidFilesRecieved == null){
					listOfValidFilesRecieved = new ArrayList<String>();
				}
				if(listOfWrongFormatFilesRecieved == null){
					listOfWrongFormatFilesRecieved = new ArrayList<String>();
				}
				
				logger.info("[BaiMergerAcbsApacESCDListener] - Going to validate the file - "+fileName);
				boolean isValid = validatorService.validateFile(inputFile);
				if(isValid){
					logger.info("[BaiMergerAcbsApacESCDListener] - Validation done. File "+fileName+" Valid File !!");
					listOfValidFilesRecieved.add(processingLocation+fileName);
					logger.info("[BaiMergerAcbsApacESCDListener] - Added received file in the list");
				}else{
					logger.info("[BaiMergerAcbsApacESCDListener] - Validation done. File "+fileName+" Invalid File !!");
					listOfWrongFormatFilesRecieved.add(processingLocation+fileName);
				}
				
				//moving file to processing location
				BaiMergerUtility.moveFile(inputFile, processingLocation, false,true);
				
				if(srcInboundFileIdList == null){
					srcInboundFileIdList = new ArrayList<Integer>();
				}
				
				if(listOfFilesRecieved == null){
					listOfFilesRecieved = new ArrayList<String>();
					
					if(poolingId == null){
						logger.info("[BaiMergerAcbsApacESCDListener] - Going to persist details in Inbound Pooling Audit");
						//insert into pooling audit table
						poolingId = persistanceService.saveInboundPoolingAuditLog(fileName,schedule);
					}
				}
				
				
				//add no of received file which moved to processing location
				listOfFilesRecieved.add(processingLocation+fileName);
				logger.info("[BaiMergerAcbsApacESCDListener] - Added received file in the list");
				
				logger.info("[BaiMergerAcbsApacESCDListener] - Going to prepare bean for Src Inbound file");
				int srcFileId = persistanceService.saveSrcInboundFile((processingLocation+fileName),poolingId);
				srcInboundFileIdList.add(srcFileId);
				logger.info("[BaiMergerAcbsApacESCDListener] - Added generated Src inbound filr Id in the list");
				
				if(noOfFilesWillReceived == null){
					logger.info("[BaiMergerAcbsApacESCDListener] - going to get, no of file, we will received to merge from data base");
					noOfFilesWillReceived = persistanceService.getNoOfFilesToMerge(nasFileNamePattern, schedule);
				}
				
				List<String> misingFileList =  null;
				if(noOfFilesReceivedAtLocation != noOfFilesWillReceived.size() && listOfFilesRecieved.size() == noOfFilesReceivedAtLocation){
					logger.info("[BaiMergerAcbsApacESCDListener] - Checking received file is equals to expected receive file or not");
					misingFileList = checkForReceivedFile(poolingId, noOfFilesWillReceived, listOfFilesRecieved,noOfFilesReceivedAtLocation);
				}
				
				if(listOfWrongFormatFilesRecieved != null && listOfWrongFormatFilesRecieved.size() == noOfFilesReceivedAtLocation){
					//all received files in WF 
					logger.info("[BaiMergerPDListener] - File is moving to error, we have only 1 file and it's not in correct format");
					String subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_WRONG_FORMAT;
					String msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_WF_TWO,listOfWrongFormatFilesRecieved.size() ,noOfFilesWillReceived.size());
					
					logger.info("[BaiMergerNAPDListener] - Going to release lock on files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("[BaiMergerNAPDListener] - Lock Released");
					
					moveFiles(listOfFilesRecieved, false, null,inputFile);
					sendMailNotification(null,subject, listOfWrongFormatFilesRecieved,msg);
					logger.info("[BaiMergerNACDListener] - Complete file not Received for merge ");
					initObject();
				}else if(listOfValidFilesRecieved != null && listOfValidFilesRecieved.size() > 1 && listOfValidFilesRecieved.size() < listOfFilesRecieved.size()){
					logger.info("[BaiMergerAcbsApacESCDListener] - Starting Merge Process when we have some wrong format files");
					String mergeFile = "";
					try{
						mergeFile = mergingService.startMerging(listOfValidFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
					}catch(Exception e){
						logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in first attempt");
						try{
							mergeFile = mergingService.startMerging(listOfValidFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
						}catch(Exception ex){
							logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in second attempt");
							try{
								mergeFile = mergingService.startMerging(listOfValidFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
							}catch(Exception exp){
								logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in third attempt");
								throw new Exception(exp);
							}
						}
					}
					logger.info("[BaiMergerAcbsApacESCDListener] - Merge Process complete !!");
					
					logger.info("[BaiMergerAcbsApacESCDListener] - Going to release lock on files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("[BaiMergerAcbsApacESCDListener] - Lock Released");
					
					//moving file to archive
					moveFiles(listOfValidFilesRecieved, true, mergeFile,inputFile);
					
					if(listOfWrongFormatFilesRecieved != null && listOfWrongFormatFilesRecieved.size() > 0){
						logger.info("[BaiMergerAcbsApacESCDListener] - moving wrong format files to error");
						///send mail notification for WF
						sendMailNotification(null, BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_WRONG_FORMAT, listOfWrongFormatFilesRecieved,
								BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_WF_ONE);
						
						//moving wrong format files to error location
						moveFiles(listOfWrongFormatFilesRecieved,false,null,inputFile);
						logger.info("[BaiMergerAcbsApacESCDListener] - wrong format files moved to error");
					}
					
					//reset variables
					initObject();
					logger.info("[BaiMergerAcbsApacESCDListener] - Resetting list completed !!");
				}else if(listOfFilesRecieved.size() == noOfFilesReceivedAtLocation && listOfFilesRecieved.size() > 1 
						&& listOfValidFilesRecieved.size() == listOfFilesRecieved.size()){ 
					logger.info("[BaiMergerAcbsApacESCDListener] - Initiating File Merge Process..");
					String mergeFile = "";
					
					try{
						mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
					}catch(Exception e){
						logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in first attempt");
						try{
							mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
						}catch(Exception ex){
							logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in second attempt");
							try{
								mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
							}catch(Exception exp){
								logger.info("[BaiMergerAcbsApacESCDListener] - Merging process failed in third attempt");
								throw new Exception(exp);
							}
						}
					}
					logger.info("[BaiMergerAcbsApacESCDListener] - Merge Process complete !!");
					
					logger.info("[BaiMergerAcbsApacESCDListener] - Going to release lock on files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("[BaiMergerAcbsApacESCDListener] - Lock Released");
					
					//send mail notification in case of partial merge
					if(listOfFilesRecieved.size() < noOfFilesWillReceived.size()){
						logger.info("[BaiMergerAcbsApacESCDListener] - preparing mail content for partial merge.");
						String msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_PARTIAL_MERGE,listOfFilesRecieved.size(),noOfFilesWillReceived.size(), poolingId);
						sendMailNotification(null, BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_PARTIAL_MERGE, listOfFilesRecieved, msg);
						logger.info("[BaiMergerAcbsApacESCDListener] - mail notification for partial merge done.");
					}
					
					//moving file to archive
					moveFiles(listOfFilesRecieved, true, mergeFile,inputFile);
					
					//reset variables
					initObject();
					logger.info("[BaiMergerAcbsApacESCDListener] - Resetting list completed !!");
				}else if(listOfValidFilesRecieved.size() == 1 && noOfFilesReceivedAtLocation == listOfFilesRecieved.size() && listOfWrongFormatFilesRecieved.size() > 0){
					//suppose we have received 2 files and 1 of them is WF
					// we have to move to error folder
					logger.info("[BaiMergerAcbsApacESCDListener] - Received only one valid file");
					///send mail notification for WF
					sendMailNotification(null, BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_WRONG_FORMAT, 
							listOfWrongFormatFilesRecieved,String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_WF_TWO, listOfWrongFormatFilesRecieved.size(),listOfFilesRecieved.size()));
					
					logger.info("[BaiMergerNAPDListener] - Going to release lock on files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("[BaiMergerNAPDListener] - Lock Released");
					
					//moving wrong format files to error location
					moveFiles(listOfFilesRecieved,false,null,inputFile);
					logger.info("[BaiMergerAcbsApacESCDListener] - Merge process can not continue with one valid file");
					
					//reset variables
					initObject();
				} else if(noOfFilesReceivedAtLocation == 1 && noOfFilesWillReceived.size() > 1){
					logger.info("[BaiMergerAcbsApacESCDListener] - Received only 1 file");
					
					boolean isSent = false;
					if(noOfFilesWillReceived.size() == 2 && (listOfWrongFormatFilesRecieved == null || listOfWrongFormatFilesRecieved.size() == 0)){
						logger.info("[BaiMergerAcbsApacESCDListener] - Sending file to business");
						//send file to business
						isSent = sendFileToBusiness(new File(listOfFilesRecieved.get(0)), nasFileNamePattern);
					}
					
					logger.info("[BaiMergerAcbsApacESCDListener] - Going to release lock on files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("[BaiMergerAcbsApacESCDListener] - Lock Released");
					
					String msg     = "";
					String subject = "";
					
					if(isSent){
						logger.info("[BaiMergerAcbsApacESCDListener] - File sent to business");
						moveFiles(listOfFilesRecieved, true, null,inputFile);
						subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_SINGLE_FILE_FOUND;
						msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_SINGLE_FILE_ONE, poolingId);
					}else if(listOfWrongFormatFilesRecieved != null && listOfWrongFormatFilesRecieved.size() > 0){
						logger.info("[BaiMergerAcbsApacESCDListener] - File is moving to error, we have only 1 file and it's not in correct format");
						subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_WRONG_FORMAT;
						msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_WF_TWO,listOfWrongFormatFilesRecieved.size() ,noOfFilesWillReceived.size());
						moveFiles(listOfFilesRecieved, false, null,inputFile);
					}else{
						logger.info("[BaiMergerAcbsApacESCDListener] - File is moving to error, we have only 1 file");
						subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_SINGLE_FILE_FOUND;
						msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_SINGLE_FILE_TWO, poolingId,noOfFilesWillReceived.size());
						moveFiles(listOfFilesRecieved, false, null,inputFile);
					}
					
					sendMailNotification(null,subject, listOfFilesRecieved,msg);
					logger.info("[BaiMergerAcbsApacESCDListener] - Complete file not Received for merge ");
					initObject();
				}
			}catch(Exception e){
				//move filr to error
				//delete all no realted files
				logger.info("[BaiMergerAcbsApacESCDListener] - Going to release lock on files");
				persistanceService.releaseLockOnFile(listOfFilesToRelease);
				logger.info("[BaiMergerAcbsApacESCDListener] - Lock Released");
				
				moveFiles(listOfFilesRecieved, false, null,inputFile);
				sendMailNotification(e,BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_MERGE_PROCESS_ERROR,null,BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_MERGE_PROCESS_ERROR);
				initObject();
			}
		}
	}
	
	private List<String> checkForReceivedFile(Integer poolingId, List<JobConfigMapper> noOfFilesWillReceived, 
			List<String> listOfFilesRecieved, Integer noOfFilesReceivedAtPoolingLocation){
		logger.info("[BaiMergerAcbsApacESCDListener] - Inside checkForReceivedFile");
		List<String> missingFiles = null;
		try{
			if(noOfFilesWillReceived != null){
				logger.info("[BaiMergerAcbsApacESCDListener] - No of Expected files - "+noOfFilesWillReceived.size());
				missingFiles = new ArrayList<String>();
				if(noOfFilesWillReceived.size() == noOfFilesReceivedAtPoolingLocation.intValue()){
					return missingFiles;
				}else if(noOfFilesWillReceived.size() > noOfFilesReceivedAtPoolingLocation.intValue() && (noOfFilesReceivedAtPoolingLocation == listOfFilesRecieved.size())){
					logger.info("[BaiMergerAcbsApacESCDListener] - Expected and Received file list is not equals");
					
					for(JobConfigMapper beanConfig:noOfFilesWillReceived){
						boolean isMatchFound = false;
						for(String file : listOfFilesRecieved){
							String fileRecieved = "";
							if(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR) > 0 ){
								//fileRecieved = file.substring(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR)+1, file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2));
								fileRecieved = file.substring(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR)+1, file.length());
							}else if(file.lastIndexOf("\\") > 0 ){
								fileRecieved = file.substring(file.lastIndexOf("\\"), file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_2));
							}
							
							if(fileRecieved.equalsIgnoreCase(beanConfig.getNasFileNamePattern())){
								isMatchFound = true;
								break;
							}
						}
						if(!isMatchFound){
							missingFiles.add(beanConfig.getNasFileNamePattern());
						}
					}
					
					//sent mail notification with missing list
					if(missingFiles != null && missingFiles.size() > 0){
						String msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_FILE_NOT_FOUND, poolingId.intValue());
						String subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_FILE_NOT_FOUND;
						sendMailNotification(null, subject, missingFiles,msg);
					}
				}
			}
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDListener] - Error while validating received files ");
			logger.info("[BaiMergerAcbsApacESCDListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
		}
		return missingFiles;
	}
	
	
	private void sendMailNotification(Exception ex, String subject, List<String> misingFileList, String msg){
		try{
			logger.info("[BaiMergerAcbsApacESCDListener] - Going to send Email");
			mailService.sendErrorMail(ex, subject, misingFileList,msg);
			logger.info("[BaiMergerAcbsApacESCDListener] - Email Sent !!");
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDListener] - Email Sending process Error. Not able to send email alert !! ");
			logger.info("[BaiMergerAcbsApacESCDListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
		}
	}
	
	private void initObject(){
		logger.info("[BaiMergerAcbsApacESCDListener] - Resetting list");
		this.listOfFilesRecieved         = null;
		this.srcInboundFileIdList        = null;
		this.poolingId                   = null;
		this.noOfFilesWillReceived       = null;
		this.noOfFilesReceivedAtLocation = null;
		//this.nasFileNamePattern		     = null;
		this.listOfValidFilesRecieved    = null;
		this.listOfWrongFormatFilesRecieved = null;
		this.listOfFilesToRelease			= null;
		logger.info("[BaiMergerAcbsApacESCDListener] - Resetting object completed");
	}
	
	
	private void moveFiles(List<String> fileToMoveList, boolean isArchive, String mergedFile, File inputFile){
		File file = null;
		logger.info("Going to check decrypted file");
		for(String fileToMove : fileToMoveList){
			String fileExtension = fileToMove.substring(fileToMove.indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_TYPE_EXTENSION),fileToMove.length());
			for(String encFile : listOfFilesToRelease){
				String encFileFilePath = inputFile.getAbsolutePath().substring(0,inputFile.getAbsolutePath().lastIndexOf(File.separator)+1);
				encFileFilePath = encFileFilePath + encFile + BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION;
				
				file = new File(encFileFilePath);
				if(file.exists() && encFile.toLowerCase().contains(fileExtension.toLowerCase())){
					logger.info("decrypted file found - "+fileToMove);
					file = new File(fileToMove);
					if(isArchive){
						//Delete decrypted file
						BaiMergerUtility.deleteFile(file);
					}
				}
			}
		}
		logger.info("Decrypted file check complete");
		if(isArchive){
			for(String fileToMove : fileToMoveList){
				file = new File(fileToMove);
				if(file.exists()){
					logger.info("[BaiMergerAcbsApacESCDListener] - moving file to archive location - "+file.getAbsolutePath());
					BaiMergerUtility.moveFile(file, archiveFileLocation, isArchive,false);
				}
			}
			if(mergedFile != null){
				file = new File(mergedFile);
				logger.info("[BaiMergerAcbsApacESCDListener] - moving merge file to archive - "+file.getAbsolutePath());
				BaiMergerUtility.moveFile(file, archiveFileLocation, isArchive,false);
			}
		}else{
			for(String fileToMove : fileToMoveList){
				String fileExtension = fileToMove.substring(fileToMove.indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_TYPE_EXTENSION),fileToMove.length());
				String nameErrorFile = "";
				for(String encFile : listOfFilesToRelease){
					if(encFile.contains(fileExtension)){
						nameErrorFile = encFile;
						break;
					}
				}
				file = new File(fileToMove);
				try{
					File errorFileName = new File(file.getPath().substring(0, file.getPath().lastIndexOf(File.separator))+File.separator+nameErrorFile);
					Files.move(FileSystems.getDefault().getPath(file.getAbsolutePath()), FileSystems.getDefault().getPath(errorFileName.getAbsolutePath()),StandardCopyOption.REPLACE_EXISTING);
					file = errorFileName;
				}catch(Exception e){
					logger.info("error while renaming decrypted file - "+BaiMergerUtility.getErrorFormStackTrace(e));
					file = new File(fileToMove);
				}
				if(file.exists()){
					logger.info("[BaiMergerAcbsApacESCDListener] - moving file to error location - "+file.getAbsolutePath());
					BaiMergerUtility.moveFile(file, errorFileLocation, true,false);
				}
			}
			if(mergedFile != null){
				file = new File(mergedFile);
				
				logger.info("[BaiMergerAcbsApacESCDListener] - deleting merge file - "+file.getAbsolutePath());
				if(file.exists()){
					BaiMergerUtility.removeFile(file.getAbsolutePath());
				}
			}
		}
		logger.info("[BaiMergerAcbsApacESCDListener] - Going to check for temporary merge file");
		String tmpFileName  = "";
		if(mergedFile != null && mergedFile.lastIndexOf("/") > 0){
			tmpFileName = mergedFile.substring(mergedFile.lastIndexOf("/")+1,mergedFile.length());
		}else if(mergedFile != null && mergedFile.lastIndexOf("\\") > 0){
			tmpFileName = mergedFile.substring(mergedFile.lastIndexOf("\\")+1,mergedFile.length());
		}
		if(tmpFileName != null && tmpFileName.length() > 1){
			logger.info("[BaiMergerAcbsApacESCDListener] - tmp file - "+tmpFileName);
			file = new File(tmpOutPutFileLocation+tmpFileName+BaiMergerConstants.FileFormatTypConstants.TMP_FILE_EXTENSION);
			logger.info("[BaiMergerAcbsApacESCDListener] - tmp file - "+file.getAbsolutePath());
			logger.info("[BaiMergerAcbsApacESCDListener] - deleting temp file - "+file.getAbsolutePath());
			if(file.exists()){
				BaiMergerUtility.removeFile(file.getAbsolutePath());
				logger.info("[BaiMergerAcbsApacESCDListener] - temporary merge file removed");
			}
		}
		//moving encrypted file
		String encFileFilePath       = "";
		String encFileMovingLocation = "";
		
		if(isArchive){
			encFileMovingLocation = archiveFileLocation;
		}else{
			encFileMovingLocation = errorFileLocation;
		}
		
		logger.info("[BaiMergerAcbsApacESCDListener] - Going to move encrypted file at following locaiton - "+encFileMovingLocation);
		if(listOfFilesToRelease != null && listOfFilesToRelease.size() > 0){
			for(String encFile : listOfFilesToRelease){
				encFileFilePath = inputFile.getAbsolutePath().substring(0,inputFile.getAbsolutePath().lastIndexOf(File.separator)+1);
				encFileFilePath = encFileFilePath + encFile + BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION;
				File encFilePath = new File(encFileFilePath);
				if(encFilePath.exists()){
					logger.info("[BaiMergerAcbsApacESCDListener] - Encrypted file found");
					BaiMergerUtility.moveFile(encFilePath, encFileMovingLocation, isArchive, false);
				}else{
					logger.info("[BaiMergerAcbsApacESCDListener] - Encrypted file not found");
				}
			}
		}
	}
	
	
	/***
	 * Send merge file to business 
	 * @param inputFile
	 * @return
	 */
	private boolean sendFileToBusiness(File inputFile, String nasFileNamePattern) throws BaiMergeProcessException{
		List<JobConfigMapper>  configBeanList = null;
		try{
			//getting details from database
			configBeanList = persistanceService.getFileDetails(nasFileNamePattern);
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDListener] - Got Exception inside sendFileToBusiness()");
			logger.info("[BaiMergerAcbsApacESCDListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
		}
		File fileToSend = null;
		try{
			String fileLocation = "";
			if(inputFile.getPath().lastIndexOf("\\") > 0){
				fileLocation = inputFile.getPath().substring(0,inputFile.getPath().lastIndexOf("\\"));
			}else{
				fileLocation = inputFile.getPath().substring(0,inputFile.getPath().lastIndexOf("/"));
			}
			
			fileToSend =  new File(fileLocation+File.separator+configBeanList.get(0).getErpTargetFileName());
			//inputFile.renameTo(fileToSend);
			BaiMergerUtility.renameFile(inputFile, fileToSend);
			
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDListener] - Error while renaming the file to the Erp Target location");
			logger.info("[BaiMergerAcbsApacESCDListener] - Can not send file to Erp location");
			logger.info("[BaiMergerAcbsApacESCDListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			return false;
		}
		
		boolean isSent = false;
		String sendFileLocation = "";
		logger.info("Going to transfer file...."+fileToSend.getName());
		if(configBeanList != null){
			try{
				sendFileLocation = configBeanList.get(0).getErpTargetFileLocation();
				
				AtomicReference<String> targetDir = (AtomicReference<String>)appContext.getBean(BaiMergerConstants.FileBelongsTo.FILE_TARGET_DIR, AtomicReference.class);
				/*if(pathForOutboundChannel != null && pathForOutboundChannel.length() > 1){
					logger.info("[BaiFileMergingServiceImpl] - Merge file sending location - "+pathForOutboundChannel);
					targetDir.set(pathForOutboundChannel);
				}else*/{
					logger.info("[BaiMergerAcbsApacESCDListener] - Merge file sending location - "+sendFileLocation);
					targetDir.set(sendFileLocation);
				}
				
				Message<File> message = MessageBuilder.withPayload(fileToSend).build();
				final MessageChannel baiMergeFileOutboundChannel = appContext.getBean (BaiMergerConstants.FileBelongsTo.FILE_OUTBOUND_CHANNEL, MessageChannel.class);
				isSent = baiMergeFileOutboundChannel.send(message,1000);
			} catch (Exception e) {
				logger.info("[BaiMergerAcbsApacESCDListener] - Got Exception inside sendFileToBusiness()");
				logger.info("[BaiMergerAcbsApacESCDListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
				isSent = false;
				//throw new BaiMergeProcessException("Merge file sending failed to locations - "+sendFileLocation,e);
			}
			logger.info("[BaiMergerAcbsApacESCDListener] - inside sendFileToBusiness() sent status - "+isSent);
			
			if(fileToSend != null && fileToSend.isFile() && fileToSend.exists()){
				/*List<String> fileSentToBusList = new ArrayList<String>();
				fileSentToBusList.add(fileToSend.getAbsolutePath());*/
				try{
					logger.info("[BaiMergerAcbsApacESCDListener] -  fileSentToBussines - "+fileToSend.getName());
					if(isSent){
						//fileToSend.delete();
						//archive the file
						BaiMergerUtility.moveFile(fileToSend, archiveFileLocation, true,false);
					}else{
						//move to error
						BaiMergerUtility.moveFile(fileToSend, errorFileLocation, true,false);
					}
				}catch(Exception e){
					logger.info("[BaiMergerAcbsApacESCDListener] - Not able to remove created file");
				}
			}
		}
		return isSent; 
	}
}
