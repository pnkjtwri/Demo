package com.ge.treasury.bai.merger.dao.mapper;

import java.sql.Timestamp;

public class BaiFileLockMapper {
	public String lockedFileName;
	public Timestamp lockedFileProcessedTime;
	public Integer lockedFileSize;
	public String createdBy;
	public Timestamp createdTimestamp;
	public String lastModifiedBy;
	public Timestamp lastModifiedTimestamp;
	
	/**
	 * @return the lockedFileName
	 */
	public String getLockedFileName() {
		return lockedFileName;
	}
	/**
	 * @param lockedFileName the lockedFileName to set
	 */
	public void setLockedFileName(String lockedFileName) {
		this.lockedFileName = lockedFileName;
	}
	/**
	 * @return the lockedFileProcessedTime
	 */
	public Timestamp getLockedFileProcessedTime() {
		return lockedFileProcessedTime;
	}
	/**
	 * @param lockedFileProcessedTime the lockedFileProcessedTime to set
	 */
	public void setLockedFileProcessedTime(Timestamp lockedFileProcessedTime) {
		this.lockedFileProcessedTime = lockedFileProcessedTime;
	}
	/**
	 * @return the lockedFileSize
	 */
	public Integer getLockedFileSize() {
		return lockedFileSize;
	}
	/**
	 * @param lockedFileSize the lockedFileSize to set
	 */
	public void setLockedFileSize(Integer lockedFileSize) {
		this.lockedFileSize = lockedFileSize;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdTimestamp
	 */
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	/**
	 * @param createdTimestamp the createdTimestamp to set
	 */
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @return the lastModifiedTimestamp
	 */
	public Timestamp getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}
	/**
	 * @param lastModifiedTimestamp the lastModifiedTimestamp to set
	 */
	public void setLastModifiedTimestamp(Timestamp lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}
}
