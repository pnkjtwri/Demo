package com.ge.treasury.bai.merger.file.mapper;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;

public class BAIAccountTrailer {
	//private String recordCode = "49";
	private String recordCode = BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_IDENTIFIER; 
	private String accountControlTotal;
	private String numberOfRecords;
	private CSVRecord record;
	public String getRecordCode() {
		return recordCode;
	}
	public String getAccountControlTotal() {
		return accountControlTotal;
	}
	public void setAccountControlTotal(String accountControlTotal) {
		this.accountControlTotal = accountControlTotal;
	}
	public String getNumberOfRecords() {
		return numberOfRecords;
	}
	public void setNumberOfRecords(String numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setAccountControlTotal(record.get(1));
			setNumberOfRecords(record.get(2));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
