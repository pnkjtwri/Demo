package com.ge.treasury.bai.merger.mail.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.ge.treasury.bai.merger.mail.service.BaiMergerMailService;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component
public class BaiMergerMailServiceImpl implements BaiMergerMailService {
	final static Logger logger = Logger.getLogger(BaiMergerMailServiceImpl.class);
	
	@Value("${fromDL}")
	private String sender;
	@Value("${recipientDL}")
	private String reciver;
	
	@Autowired
	private JavaMailSender mailSender;
	
    @Autowired 
    private TemplateEngine templateEngine;
	    
    /* 
     * Send HTML mail (simple) 
     */
    private void sendMail(final String templateNm, String subject, Map<String,Object> bodyContent) throws MessagingException {
    	Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
        // Prepare the evaluation context
        final Context ctx = new Context(bLocale);
        /*ctx.setVariable("name", "Team");*/
        ctx.setVariable("bodyContent", bodyContent);
        ctx.addContextExecutionInfo(templateNm);
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(sender);
        String[] sendTo = reciver.split(",");
        //message.setTo(reciver);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);

    }
	
	@Override
	public void sendErrorMail(Exception ex, String mailSubject, List<String> listOfFileNotReceived, String msg) throws MessagingException {
		logger.info("[BaiMergerMailServiceImpl] - Start sending mail..");
		Map<String,Object> mailContent = mailContent(ex, listOfFileNotReceived, mailSubject, msg);
		sendMail("email-simple2", mailSubject, mailContent);
		logger.info("[BaiMergerMailServiceImpl] - Mail sending process complete !!");
	}
	
	private Map<String,Object> mailContent(Exception ex, List<String> listOfFileNotReceived, String shortMsg , String longMsg){
		logger.info("[BaiMergerMailServiceImpl] - Preparing Mail content..");
		/*StringBuffer mailContent = new StringBuffer();*/
		Map<String,Object> mailContent = new HashMap<String, Object>();
		
		InetAddress hostAndIP = null;
        try {
            hostAndIP = InetAddress.getLocalHost();
            logger.info("[BaiMergerMailServiceImpl] - current Hostname/IP address : " + hostAndIP);
        } catch (UnknownHostException e) {
        	logger.error(BaiMergerUtility.getErrorFormStackTrace(e));
        }
       
        //mailContent.put("sourceFileName", sourceFileName);
        mailContent.put("hostName", hostAndIP.getHostAddress());
        mailContent.put("shortMsg", shortMsg );
        if(ex != null){
	        mailContent.put("longMsg", BaiMergerUtility.getErrorFormStackTrace(ex));
        }else{
        	mailContent.put("longMsg", "");
        }
        
        if(listOfFileNotReceived != null && listOfFileNotReceived.size() > 0){
    		//mailContent.put("shortMsg", "System Did not Received the following no of Files - " );
        	mailContent.put("shortMsg", longMsg );
        }
        if(listOfFileNotReceived == null){
        	listOfFileNotReceived = new ArrayList<String>();
        }
        mailContent.put("failedFileList", listOfFileNotReceived);
        
		logger.info("[BaiMergerMailServiceImpl] - Mail content completed !!");
		return mailContent;
	}

	/**
	 * @param sender the sender to set
	 */
	public void setSender(String sender) {
		this.sender = sender;
	}

	/**
	 * @param reciver the reciver to set
	 */
	public void setReciver(String reciver) {
		this.reciver = reciver;
	}

}
