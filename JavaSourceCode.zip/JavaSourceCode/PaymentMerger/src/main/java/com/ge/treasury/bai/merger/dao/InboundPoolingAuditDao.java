package com.ge.treasury.bai.merger.dao;

import com.ge.treasury.bai.merger.dao.mapper.InboundPoolingAuditMapper;

public interface InboundPoolingAuditDao {
	public void savePoolingAudit(InboundPoolingAuditMapper poolingAuditBean);
}
