package com.ge.treasury.bai.merger.util;

public class BaiMergerConstants {
	public class FileStatusConstants{
		public static final String FILE_STATUS_READY_FOR_SPLIT		 							= "PFIReadyForSplit";
		public static final String FILE_STATUS_SPLIT_IN_PROGRESS	 							= "PFISplitInProgress";
		public static final String FILE_STATUS_SPLIT_COMPLETED		 							= "PFISplitCompleted";
		public static final String FILE_STATUS_SPLIT_FAILED 		 							= "PFISplitFailed";
		public static final String FILE_STATUS_PFI_TRANSFER_COMPLETED							= "PFITransferCompleted";
		public static final String FILE_STATUS_PFITransferFailed								= "PFITransferFailed";
		public static final String FILE_STATUS_PFI_IMPORT_STATUS_RECEIVED						= "PFIImportStatusReceived";
		public static final String FILE_STATUS_PFI_IMPORT_STATUS_SENT_TO_BUSINESS_COMPLETE		= "PFIImportStatusSentToBusinessCompleted";
		public static final String FILE_STATUS_PFI_IMPORT_STATUT_SENT_TO_BUSINESS_FAILED		= "PFIImportStatusSentToBusinessFailed";
		public static final String FILE_STATUS_SPLIT_FILE_READY_TO_TRANSFER						= "SplitFileReadyToTransfer";				
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_CMM_COMPLETE				= "SplitFileTransferToCMMCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_CMM_FAILED				= "SplitFileTransferToCMMFailed";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_COMPLETE				= "SplitFileTransferToWCCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_WC_FAILED					= "SplitFileTransferToWCFailed";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_COMPLETE		= "SplitFileTransferToTSAInstanceCompleted";
		public static final String FILE_STATUS_SPLIT_FILE_TRANSFER_TO_TSA_INSTANCE_FAILED		= "SplitFileTransferToTSAInstanceFailed";
		
		public static final String MERGE_PFI_IMPORT_STATUS_IN_PROGRESS                   		= "MergePFIImportStatusInProgress";
		public static final String MERGE_PFI_IMPORT_STATUS_COMPLETED                     		= "MergePFIImportStatusCompleted";
		public static final String MERGE_PFI_IMPORT_STATUS_FAILED                        		= "MergePFIImportStatusFailed";
		public static final String MERGE_PFI_IMPORT_STATUS_SENT_TO_BUSINESS_COMPLETED     		= "MergePFIImportStatusSentToBusinessCompleted";
		public static final String MERGE_PFI_IMPORT_STATUS_SENT_TO_BUSINESS_FAILED          	= "MergePFIImportStatusSentToBusinessFailed";
		public static final String SPLIT_FILE_CMM_IMPORT_STATUS_RECEIVED                        = "SplitFileCMMImportStatusReceived";
		public static final String SPLIT_FILE_WC_IMPORT_STATUS_RECEIVED                  		= "SplitFileWCImportStatusReceived";
		public static final String SPLIT_FILE_TSA_IMPORT_STATUS_RECEIVED                 		= "SplitFileTSAImportStatusReceived";
		public static final String SPLIT_FILE_TSA_IMPORT_STATUS_SLA_EXPIRED              		= "SplitFileTSAImportStatusSLAExpired";
		
		public static final String BAI_MERGE_FILE_COMPLETE				                        = "BaiMergeComplete";
		public static final String BAI_MERGE_FILE_IN_PROGRESS        	                 		= "BaiMergeInProgress";
		public static final String BAI_MERGE_FILE_FAILED                                 		= "BaiMergeFailed";
		public static final String BAI_FILE_READY_FOR_MERGE                              		= "BaiReadyForMerge";
		
	}
	
	public class FileFormatConstants{
		public static final String FILE_HEADER_TAG 						= "01";
		public static final String FILE_TRAILER_TAG 					= "99";
		public static final String GROUP_HEADER_TAG 					= "02";
		public static final String GROUP_TRAILER_TAG 					= "98";
		public static final String ACCOUNT_HEADER_TAG 					= "03";
		public static final String ACCOUNT_TRAILER_TAG 					= "49";
		public static final String TRANSACTION_DETAIL_TAG 				= "16";
		public static final String CONTINUATION_TAG 					= "88";
		public static final String ACCOUNT_IDENTIFIER					= "03";
		public static final String ACCOUNT_TRAILER_IDENTIFIER			= "49";
		public static final String RECORD_CONTINUTAION_IDENTIFIER		= "88";
	}
	
	
	/*public class DataBaseKeyConstants{
		public static final String SRC_FILE_NAME_KEY 						= "srcFileName";
		public static final String SRC_FILE_TYPE_KEY 	 					= "srcFileType";
		public static final String TSA_INSTANSE_IDENTIFIER_KEY				= "tsaInstacneIdentifier";
		public static final String ERP_NAME_KEY			 					= "erpName";
		public static final String AMOUNT_KEY			 					= "amount";
		public static final String NO_OF_TRANSACTION_KEY 					= "noOfTransaction";
		public static final String HASH_STRING_KEY			 				= "hashString";
		public static final String MERGED_FLAG_KEY		 					= "mergedFlag";
		public static final String FILE_STATUS_ID_KEY						= "fileStatusId";
		public static final String SRC_FILE_CREATION_TIMESTAMP_KEY			= "scrFileCreationTime";
		public static final String CREATED_BY_KEY							= "createdBy";
		public static final String CREATED_TIMESTAMP_KEY					= "createdTimestamp";
		public static final String LAST_MODIFIED_BY_KEY						= "lastModifiedBy";
		public static final String LAST_MODOFIED_TIMESTAMP_KEY				= "lastModifedTimestamp";
	}*/
	
	public class FileFormatTypConstants{
		//public static final String CURRENT_DAY_FILE 						= "Current Day";
	//	public static final String PRIOR_DAY_FILE	 	 					= "Prior Day";
		//public static final String CURRENT_DAY_FILE_TYPE					= "CD.txt_";
		//public static final String PRIOR_DAY_FILE_TYPE	 					= "PD.txt_";
		public static final String FILE_TYPE_EXTENSION	 					= ".txt_";
		
		public static final String FILE_MERGE_FLAG_N   	 					= "N";
		public static final String FILE_MERGE_FLAG_Y   	 					= "Y";
		public static final String SRC_FILE_FILE_TYPE  	 					= "BI";
		public static final String SRC_FILE_FILE_CR  	 					= "CR";
		public static final String SENDER_IDENTIFICATION 					= "GECCTREAS";
		public static final String MERGE_STAUTS 							= "Complete";
		public static final String BAI_END_LINE_CHAR						= "/";
		public static final String BAI_NEW_LINE_CHAR						= "\n";
		
		//public static final String FILE_EXTENSION_1							= ".txt_";
		public static final String FILE_EXTENSION_2							= ".txt";
		public static final String TMP_FILE_EXTENSION						= "_tmp";
		public static final String IS_GEWC_TSA						= "GE";
		public static final String UNDER_SCORE								= "_";
		public static final String LATEST_TIMESTAMP_DATEIME_FORMAT			= "YYYYMMddHHmmss";
		public static final String TIMESTAMP_DATEIME_FORMAT_CTYSTAL_REPORT	= "YYYY-MM-dd-HH-mm-ss";
		public static final String ENCRYPTED_FILE_EXTENSION                 = ".pgp";
		public static final String FILE_EXTENSION_CSV						= ".csv";
	}
	
	public class FileBelongsTo{
		//public static final String FILE_FOR_PGP_BAI_CFS						= "pgp-bai-cfs";
		public static final String FILE_OUTBOUND_CHANNEL					= "outputChannelToSendFile";
		public static final String FILE_TARGET_DIR      					= "targetDir";
		
	}
	
	public class MailMessageContent{
		public static final String MAIL_SUBJECT_FOR_WRONG_FORMAT					= "Received Wrong Format File";
		public static final String MAIL_SUBJECT_FOR_FILE_NOT_FOUND					= "All Files Not Received";
		public static final String MAIL_SUBJECT_FOR_SINGLE_FILE_FOUND				= "Received Only One File";
		public static final String MAIL_SUBJECT_FOR_MERGE_PROCESS_ERROR				= "Error while merging process";
		public static final String MAIL_SUBJECT_FOR_DISCARDED_FILES					= "Discarded file List";
		public static final String MAIL_SUBJECT_FOR_PARTIAL_MERGE					= "Merging completed with received partial files";
		
		public static final String MAIL_MESSAGE_WF_ONE								= "We have received files in wrong format. Merge process will continue with "
																						+ "rest of the valid files. Below files are not in correct format - ";
		public static final String MAIL_MESSAGE_WF_TWO								= "We have received %s Wrong format files. Out of - %s. Merger Process Can not continue, Below are the wrong format Files -";
		
		public static final String MAIL_MESSAGE_FOR_SINGLE_FILE_ONE					= "We have received only one file to process for the polling id - %s. File is sent to the corresponding business.";
		public static final String MAIL_MESSAGE_FOR_SINGLE_FILE_TWO					= "We have received only one file to process for the polling id - %s, But Excpecting %s file to merge, Merge process can not continue with 1 file.";
		
		public static final String MAIL_MESSAGE_FOR_FILE_NOT_FOUND					= "We have not received the following files for the pooling id - %s";
		public static final String MAIL_MESSAGE_FOR_FILE_NOT_FOUND_TWO				= "We have not received the following files - ";
		public static final String MAIL_MESSAGE_FOR_MERGE_PROCESS_ERROR				= "Merge Process can not continue. Received Error while merging the received files.";
		public static final String MAIL_MESSAGE_FOR_DISCARDED_FILES_ONE				= "We have received multiple files with same filename pattern but different timestamp during pool,"
																						+ " System is taking the file with latest timestamp and below is the list of discarded files -";
		public static final String MAIL_MESSAGE_FOR_DISCARDED_FILES_TWO				= "We have received multiple files with same filename pattern but different timestamp during pool, "
																					+ "Found error while getting latest timestamp file. Moving following list of files to discarded location - ";
		
		public static final String MAIL_SUBJECT_CRYSTAL_REPORT_MERGE_ERROR			= "Error while merging Crystal Report files";
		public static final String MAIL_SUBJECT_CRYSTAL_REPORT_SINGLE_FILE_FOUND	= "All expected model extracts crystal report not received";
		
		public static final String MAIL_MESSAGE_CRYSTAL_REPORT_MERGE_ERROR			= "Crystal Report Merge Process can not continue. Got error while merging process";
		public static final String MAIL_MESSAGE_CRYSTAL_REPORT_SINGLE_FILE			= "We have received only %s crystal report file to process for the polling id - %s, But Excpecting %s file to merge, Merge process can not continue with %s file.";
		public static final String MAIL_MESSAGE_FOR_DISCARDED_CR_FILES_ONE			= "We have received multiple Crystal Report files with same filename pattern but different timestamp during pool,"
																						+ " System is taking the file with latest timestamp and below is the list of discarded files -";
		public static final String MAIL_MESSAGE_FOR_DISCARDED_CR_FILES_TWO			= "We have received multiple Crystal Report files with same filename pattern but different timestamp during pool, "
																						+ "Found error while getting latest timestamp file. Moving following list of files to discarded location - ";
		public static final String MAIL_MESSAGE_FOR_PARTIAL_MERGE					= "We have received only %s files to process, But expecting %s no of files for the polling id - %s. Partial merge file is sent to the corresponding business, we have received following files for partial merge - ";
		
		
	}
}
