package com.ge.treasury.bai.merger.dao;

import java.util.List;
import java.util.Map;

import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;

public interface JobConfigDao {
	public List<JobConfigMapper> getNoOfFilesToMerge(Map<String,String> param );
	public int getInboundConfigIdForFile(Map<String,String> param);
	public List<JobConfigMapper> getFileDetails(String nasFileNamePattern);
}
