package com.ge.treasury.bai.merger.persitance;

import java.util.List;

import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;

public interface BaiMergerProcessPersistanceService {
	public int saveSrcInboundFile(String fileName,Integer poolingId) throws DataBaseProcessException;
	/*public String getFileListFormFilePattern(String nasSourceFileNamePattern);*/
	public List<JobConfigMapper> getNoOfFilesToMerge(String searchString, String schedule) throws DataBaseProcessException;
	public int saveInboundPoolingAuditLog(String nasFileNamePattern, String schedule)throws DataBaseProcessException;
	
	public int saveMergedFileDetails(String mergedFileLoc, String mergeFileName, long totalAmount, Integer totalRecords, String originatorIdentification)throws DataBaseProcessException;
	public void updateSrcInboundFile(List<Integer> srcInboundFileIdList, Integer mergeFileId, Integer fileStatus) throws DataBaseProcessException;
	
	public void updateSrcInboundFileStatus(List<Integer> srcInboundFileIdList, Integer mergeStatus)throws DataBaseProcessException;
	
	public List<JobConfigMapper> getFileDetails(String nasFileName)throws DataBaseProcessException;
	
	public void getLockOnFile(List<String> fileListToGetLock)throws DataBaseProcessException; 
	public void releaseLockOnFile(List<String> fileListToReleaseLock);
	
	public int saveSrcInboundCrystalReportFile(String fileName,Integer poolingId) throws DataBaseProcessException;
}
