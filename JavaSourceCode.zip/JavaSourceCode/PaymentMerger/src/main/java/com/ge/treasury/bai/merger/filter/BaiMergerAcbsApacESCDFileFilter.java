package com.ge.treasury.bai.merger.filter;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.file.filters.FileListFilter;

import com.ge.treasury.bai.merger.bean.FilePoolingDetailsForApac;
import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.mail.service.BaiMergerMailService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

public class BaiMergerAcbsApacESCDFileFilter<F> implements FileListFilter<F>{
	final static Logger logger = Logger.getLogger(BaiMergerAcbsApacESCDFileFilter.class);
	
	@Autowired BaiMergerProcessPersistanceService lockService;
	@Autowired BaiMergerMailService mailService;
	
	@Value("${discardedFileLocation}")
	private String discardedFileLocation;
	
	@Value("%{ACBS_APACES_CD_schedule}")
	private String schedule;
	
	private final Object monitor = new Object();
	private String nasfilenamepattern;
	public String getNasfilenamepattern() {
		return nasfilenamepattern;
	}
	public void setNasfilenamepattern(String nasfilenamepattern) {
		this.nasfilenamepattern = nasfilenamepattern;
	}
	
	private String isAllFileReceived;
	
	/**
	 * @return the isAllFileReceived
	 */
	public String getIsAllFileReceived() {
		return isAllFileReceived;
	}
	/**
	 * @param isAllFileReceived the isAllFileReceived to set
	 */
	public void setIsAllFileReceived(String isAllFileReceived) {
		this.isAllFileReceived = isAllFileReceived;
	}
	
	private FilePoolingDetailsForApac filePooledDetails;
	
	/**
	 * @param filePooledDetails the filePooledDetails to set
	 */
	public synchronized void setFilePooledDetails(
			FilePoolingDetailsForApac filePooledDetails) {
		this.filePooledDetails = filePooledDetails;
	}
	@Override
	public List<F> filterFiles(F[] files) {
		List<F> accepted = new ArrayList<F>();
		List<String> lockFileList = new ArrayList<String>();
		List<String> missingFile  = new ArrayList<String>();
		List<F> acceptedLatestTSFile = null;
		List<JobConfigMapper> noOfFilesWillReceived =  null;
		
		synchronized (this.monitor) {
	        if (files != null) {
	        	
	        	File fileRecieved = null;
	            for (F file : files) {
	            	fileRecieved = new File(file.toString());
	            	if(!file.toString().toLowerCase().contains(".writing") && fileRecieved.length() > 0 && fileRecieved.isFile()
	            			&& !fileRecieved.getName().toLowerCase().contains(BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION.toLowerCase())){
	            		if(noOfFilesWillReceived == null){
	            			try{
	        	    			noOfFilesWillReceived = lockService.getNoOfFilesToMerge(nasfilenamepattern, schedule);
	        	    		}catch(Exception e){
	        	    			logger.info("[BaiMergeACBSCDFileListFilter] - Error while getting no of files from data base");
	        	    		}
	            		}
	            		
	            		String nasFilePattern  = "";
	            		if(nasfilenamepattern.lastIndexOf(".txt")> 0){
	            			nasFilePattern = nasfilenamepattern.substring(0,nasfilenamepattern.lastIndexOf(".txt"));
	            		}
	            		
	            		if(fileRecieved.exists() && fileRecieved.getName().contains(nasFilePattern)){
            				accepted.add(file);
            				logger.info("File Received at BaiMergerAcbsApacESCDFileFilter is - "+fileRecieved.getName());
            				lockFileList.add(fileRecieved.getAbsolutePath());
	            		}
	            	}
	            }
	            
	          //get the lock on filenames
	            if(lockFileList != null && lockFileList.size() > 0 ){
	            	try{
	            		logger.info("[BaiMergerAcbsApacESCDFileFilter] - Going to get lock on received files");
						lockService.getLockOnFile(lockFileList);
						logger.info("[BaiMergerAcbsApacESCDFileFilter] - Lock on aquired");
					}catch (DataBaseProcessException e) {
						logger.info("[BaiMergerAcbsApacESCDFileFilter] - Lock on received files Failed");
						accepted = new ArrayList<F>(); 
					}
	            }
	            
	            if(accepted.size() > 0 && isAllFileReceived.equalsIgnoreCase("N")){
		            //Checking for missing File
		            for(JobConfigMapper item : noOfFilesWillReceived){
		            	boolean isMatchFound = false;
		            	for(F file : accepted){
		            		File received = new File(file.toString());
		            		String actualName = BaiMergerUtility.trimBAIFileTimeStamp(received.getName());
		            		if(actualName.equalsIgnoreCase(item.getNasFileNamePattern())){
								isMatchFound = true;
								break;
							}
		            	}
		            	
		            	if(!isMatchFound && !missingFile.contains(item.getNasFileNamePattern())){
		            		missingFile.add(item.getNasFileNamePattern());
						}
		            }
		            
		            //release lock if missing file list > 0
	            	if(missingFile.size() > 0){
	            		logger.info("[BaiMergerAcbsApacESCDFileFilter] - release lock we have missing file");
	            		lockService.releaseLockOnFile(lockFileList);
	            		accepted = new ArrayList<F>();
	            	}
	            }
	            
	          //compare the timestamp in filenames to get the latest file
	            if(accepted.size() > 0){
	            	if(!isAllFileReceived.equalsIgnoreCase("N") || missingFile.size() == 0){
	            		logger.info("Going to get latest timestamp file");
			            acceptedLatestTSFile = getLatestTimeStampFiles(accepted);
			            if(acceptedLatestTSFile != null && acceptedLatestTSFile.size() > 0){
				            logger.info("After getLatestTimeStampFiles method size - "+acceptedLatestTSFile.size());
			            }
	            	}
	            }
	        }
		}
	        
		if(acceptedLatestTSFile != null && acceptedLatestTSFile.size() > 0){
			if(filePooledDetails != null){
				logger.info("Setting pooled file size details - "+acceptedLatestTSFile.size());
				filePooledDetails.setNoOfFilesPooledFromLocation(acceptedLatestTSFile.size());
			}else{
				logger.info("Object is not initlized for pooling details");
			}
			return acceptedLatestTSFile;
		}else{
			return new ArrayList<F>();
		}
	}

	/**
	 * get the files with latest timestamp
	 * 
	 * @param accepted
	 * @return
	 */
	private List<F> getLatestTimeStampFiles(List<F> accepted){
		List<F> fileToProcessCD = new ArrayList<F>();
		List<F> listOfLatestFile = new ArrayList<F>();
		List<String> discardedFileList = new ArrayList<String>();
		boolean isErrorFound = false;
         try{
        	//getting latest time stamp file
         	Map<String,F> latestFileMap = getLatestFileMap(accepted);
         	 
         	 //preparing list of latest time stamp file
         	 if(latestFileMap != null && latestFileMap.size() > 0){
 	        	 for (Map.Entry<String, F> entry : latestFileMap.entrySet()){
 	        		 fileToProcessCD.add(entry.getValue());
 	        	 }
         	 }
		     
		     logger.info("[BaiMergerAcbsApacESCDFileFilter] - Identifying discarded File");
		     if(fileToProcessCD.size() == 0){
		    	 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Not able to find the latest timestamp file. moving file to discarded location");
		    	 getDiscardedFileList(accepted, discardedFileList);
		     }else{
		    	 Iterator<F> nasFileItr = accepted.iterator();
		    	 while(nasFileItr.hasNext()){
		    		 F nasFileObj = nasFileItr.next();
	    			 File fileRece = new File(nasFileObj.toString());
	    			 File encFileRece = new File(nasFileObj.toString()+BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION);
	    			 
	    			 Iterator<F> latestTsItr = fileToProcessCD.iterator();
	    			 while(latestTsItr.hasNext()){
	    				 F latestTsObj = latestTsItr.next();
	    				 File tmpFile = new File(latestTsObj.toString());
	    				 
	    				 if(!fileRece.getName().equalsIgnoreCase(tmpFile.getName()) && !fileToProcessCD.contains(nasFileObj)){
	    					 if(!discardedFileList.contains(fileRece.getName())){
	    						 discardedFileList.add(fileRece.getName());
	    						 if(encFileRece.exists()){
		    						 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Moving discarded encrypted file to discarded location");
		    						 BaiMergerUtility.moveFile(encFileRece, discardedFileLocation, false,false);
		    						 logger.info("[BaiMergerAcbsApacESCDFileFilter] - going to delete decrypted file");
		    						 BaiMergerUtility.deleteFile(fileRece);
	    						 }else{
	    							 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Moving decrypted file to discarded location");
		    						 BaiMergerUtility.moveFile(fileRece, discardedFileLocation, false,false);
	    						 }
	    					 }
	    				 }
	    			 }
	    		 }
		    	 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Identifying discarded File complete");
		     }
         }catch (ParseException e) {
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - Error parsing timestamp For CD");
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			isErrorFound = true;
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - Error while getting latest timestamp file");
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			isErrorFound = true;
        }
       
        if(discardedFileList.size() > 0){
   	    	logger.info("[BaiMergerAcbsApacESCDFileFilter] - releasing lock on discarded File");
   	    	lockService.releaseLockOnFile(discardedFileList);
   	    	logger.info("[BaiMergerAcbsApacESCDFileFilter] - releasing lock on discarded File complete");
   	    }
   	     
        if(discardedFileList.size() > 0){
   	    	if(!isErrorFound){
   	    	 sendMailNotification(null, BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_DISCARDED_FILES, discardedFileList, BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_DISCARDED_FILES_ONE);
   	    	}else{
   	    		sendMailNotification(null, BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_DISCARDED_FILES, discardedFileList, BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_DISCARDED_FILES_TWO);
   	    	}
   	    } 
         
		return fileToProcessCD;
	}
	
	
	/**
	 * method to get latest timestamp file map
	 * 
	 * @param accepted
	 * @return
	 * @throws ParseException
	 * @throws Exception
	 */
	private Map<String,F> getLatestFileMap(List<F> accepted) throws ParseException,Exception{
		logger.info("[BaiMergerAcbsApacESCDFileFilter] - inside getLatestFileMap method - no of files received - "+accepted.size());
		Map<String,F> latestTsFileMap = new TreeMap<String,F>();
		
		if(accepted.size() > 0 ){
	   		 Iterator<F> itrAcceptedNasFiles = accepted.listIterator();
	       	 while(itrAcceptedNasFiles.hasNext()){
		   		F nasFileObj 	 = itrAcceptedNasFiles.next();
		 		File fileToCheck = new File(nasFileObj.toString());
		 		
		 		String originalFileName = BaiMergerUtility.getFileName(fileToCheck);
		 		String timeStamp        = BaiMergerUtility.getTimeStampFromFile(fileToCheck);
		 		
		 		Iterator<F> itrCheckForFile = accepted.listIterator();
		 		 while(itrCheckForFile.hasNext()){
		 			F nasFileTmp 	 = itrCheckForFile.next();
		 			File fileToCheckTmp = new File(nasFileTmp.toString());
		 			
		 			String originalFileNameTmp = BaiMergerUtility.getFileName(fileToCheckTmp);
			 		String timeStampTmp        = BaiMergerUtility.getTimeStampFromFile(fileToCheckTmp);
			 		
			 		logger.info("[BaiMergerAcbsApacESCDFileFilter] - File outer loop - "+fileToCheck.getName() + ", time stamp - "+timeStamp);
			 		logger.info("[BaiMergerAcbsApacESCDFileFilter] - File outer loop - "+fileToCheckTmp.getName() + ", time stamp - "+timeStampTmp);
			 		
			 		if(originalFileName.equalsIgnoreCase(originalFileNameTmp)){
			 			SimpleDateFormat s1 = new SimpleDateFormat(BaiMergerConstants.FileFormatTypConstants.LATEST_TIMESTAMP_DATEIME_FORMAT);
 					    SimpleDateFormat s2 = new SimpleDateFormat(BaiMergerConstants.FileFormatTypConstants.LATEST_TIMESTAMP_DATEIME_FORMAT);
 					    
 					    Date dateOne = s1.parse(timeStamp);
						Date dateTwo = s2.parse(timeStampTmp);
						
						if(dateOne.after(dateTwo)){
							logger.info("[BaiMergerAcbsApacESCDFileFilter] - outer file ts is greater");
							if(latestTsFileMap.containsKey(originalFileName)){
								logger.info("[BaiMergerAcbsApacESCDFileFilter] - Entry found in map");
								String ts = BaiMergerUtility.getTimeStampFromFile(new File(latestTsFileMap.get(originalFileName).toString()));
								if(s1.parse(ts).before(dateOne)){
									logger.info("[BaiMergerAcbsApacESCDFileFilter] - replacing map entry, map ts - "+ts+", outer file ts - "+timeStamp);
									latestTsFileMap.put(originalFileName, nasFileObj);
								}
							}else{
								latestTsFileMap.put(originalFileName, nasFileObj);
							}
						}else{
							logger.info("[BaiMergerAcbsApacESCDFileFilter] - outer file ts is lower");
							if(latestTsFileMap.containsKey(originalFileName)){
								logger.info("[BaiMergerAcbsApacESCDFileFilter] - Entry found in map in else");
								String ts = BaiMergerUtility.getTimeStampFromFile(new File(latestTsFileMap.get(originalFileName).toString()));
								if(s1.parse(ts).before(dateOne)){
									logger.info("[BaiMergerAcbsApacESCDFileFilter] - replacing map entry in else, map ts - "+ts+", outer file ts - "+timeStamp);
									latestTsFileMap.put(originalFileName, nasFileObj);
								}
							}else{
								latestTsFileMap.put(originalFileName, nasFileTmp);
							}
						}
			 		}
		 		 }
		   	 }
		}
		return latestTsFileMap;
	}
	
	/**
	 * get discarded file list
	 * 
	 * @param fileReceived
	 * @param discardedFileList
	 */
	private void getDiscardedFileList(List<F> fileReceived, List<String> discardedFileList){
		logger.info("[BaiMergerAcbsApacESCDFileFilter] - Inside getDiscardedFileList method");
		for(F discFile : fileReceived){
	    	File fileRece = new File(discFile.toString());
	    	File encFileRece = new File(discFile.toString());
	    	 discardedFileList.add(fileRece.getName());
	    	 
	    	 if(encFileRece.exists()){
		    	 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Moving discarded encrypted file to discarded location");
				 BaiMergerUtility.moveFile(encFileRece, discardedFileLocation, false,false);
				 logger.info("[BaiMergerAcbsApacESCDFileFilter] - going to delete decrypted file");
				 BaiMergerUtility.deleteFile(fileRece);
	    	 }else{
	    		 logger.info("[BaiMergerAcbsApacESCDFileFilter] - Moving decrypted file to discarded location");
				 BaiMergerUtility.moveFile(fileRece, discardedFileLocation, false,false);
	    	 }
    	 }
	}
	
	/**
	 * Send mail notification
	 * 
	 * @param ex
	 * @param subject
	 * @param misingFileList
	 * @param msg
	 */
	private void sendMailNotification(Exception ex, String subject, List<String> misingFileList, String msg){
		try{
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - Going to send Email for discarder files");
			mailService.sendErrorMail(ex, subject, misingFileList,msg);
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - Email Sent !!");
		}catch(Exception e){
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - Email Sending process Error. Not able to send email alert !! ");
			logger.info("[BaiMergerAcbsApacESCDFileFilter] - "+BaiMergerUtility.getErrorFormStackTrace(e));
		}
	}

}
