/*package com.ge.treasury.bai.merger.load.config;

public interface TsaIndentifierLoaderService {
	public String getTsaIdentifier(int tsaInstanceId);
}
*/