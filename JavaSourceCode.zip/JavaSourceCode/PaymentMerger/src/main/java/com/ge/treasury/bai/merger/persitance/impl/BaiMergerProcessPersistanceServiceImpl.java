package com.ge.treasury.bai.merger.persitance.impl;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.dao.BaiFileLockDao;
import com.ge.treasury.bai.merger.dao.InboundConfigDao;
import com.ge.treasury.bai.merger.dao.InboundPoolingAuditDao;
import com.ge.treasury.bai.merger.dao.JobConfigDao;
import com.ge.treasury.bai.merger.dao.MergedInboundFileDao;
import com.ge.treasury.bai.merger.dao.SrcInboundFileDao;
import com.ge.treasury.bai.merger.dao.mapper.BaiFileLockMapper;
import com.ge.treasury.bai.merger.dao.mapper.InboundPoolingAuditMapper;
import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.dao.mapper.MergedInboundFileMapper;
import com.ge.treasury.bai.merger.dao.mapper.SrcInboundFileMapper;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.load.config.FileStausLoaderService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component
public class BaiMergerProcessPersistanceServiceImpl implements BaiMergerProcessPersistanceService {
	private static Logger logger = Logger.getLogger(BaiMergerProcessPersistanceServiceImpl.class);
	
	@Autowired SrcInboundFileDao srcInboundFileDao;
	@Autowired InboundConfigDao inboundConfigDao;
	@Autowired JobConfigDao jobConfigDao;
	@Autowired InboundPoolingAuditDao inboundPoolingAuditDao;
	@Autowired MergedInboundFileDao mergedInboundFileDao;
	/*@Autowired TsaIndentifierLoaderService tsaIdentifier;*/
	@Autowired FileStausLoaderService fileStatus;
	@Autowired BaiFileLockDao fileLockDao;
	
	@Value("${createdBy}")
	private String createdBy;
	
	@Value("${lastModifiedBy}")
	private String lastModifiedBy;

	@Override
	public int saveSrcInboundFile(String fileName,Integer poolingId) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Going to persist data in Src Inbound File");
		SrcInboundFileMapper detailsToPersist = null;
		try{
			 detailsToPersist = populateSrcInboundFileBean(fileName,poolingId,false);
			srcInboundFileDao.saveSrcInboundFileDetails(detailsToPersist);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - details persisted in Src Inbound File");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while persisting data in Src Inbound File");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error While persisting pool file details in src table",e);
		}
		
		return detailsToPersist.getSrcFileId();
	}

	/*@Override
	public String getFileListFormFilePattern(String nasSourceFileNamePattern) {
		String erpName = inboundConfigDao.getFileListFormFilePattern(nasSourceFileNamePattern);
		return erpName;
	}*/

	@Override
	public List<JobConfigMapper> getNoOfFilesToMerge(String searchString, String schedule) throws DataBaseProcessException{
		//String tmpString = "'%"+searchString+"%'";
		List<JobConfigMapper> noOFFilesToBeReceived = null;
		try{
		Map<String,String> param = new HashMap<String,String>();
		param.put("searchString", searchString);
		param.put("schedule", schedule);
		noOFFilesToBeReceived = jobConfigDao.getNoOfFilesToMerge(param);
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while getNoOfFilesToMerge");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while get No Of Files from data base",e);
		}
		return noOFFilesToBeReceived;
	}

	@Override
	public int saveInboundPoolingAuditLog(String nasFileNamePattern, String schedule) throws DataBaseProcessException{
		Timestamp defaultTime   = new Timestamp(System.currentTimeMillis());
		InboundPoolingAuditMapper inboundPoolingAuditBean = new InboundPoolingAuditMapper();
		try{
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Start process in saveInboundPoolingAuditLog");
			//nasFileNamePattern = nasFileNamePattern.substring(0,nasFileNamePattern.lastIndexOf(".txt"));
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - File Name Pattern - "+nasFileNamePattern);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - schedule - "+schedule);
			Map<String,String> param = new HashMap<String,String>();
			param.put("schedule", schedule);
			param.put("searchString", nasFileNamePattern);
			
			int inboundConfigId = jobConfigDao.getInboundConfigIdForFile(param);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Inbound Config Id "+inboundConfigId);
			
			inboundPoolingAuditBean.setInboundConfigId(inboundConfigId);
			inboundPoolingAuditBean.setPoolingTimeStamp(defaultTime);
			inboundPoolingAuditBean.setPoolingRunStatus(1); //Need to update the run status with correct one
			
			inboundPoolingAuditDao.savePoolingAudit(inboundPoolingAuditBean);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Persisted details in Inbound Pooling Audit table !!");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while Persisting details in Inbound Pooling Audit table.");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while persisting pooling information",e);
		}
		
		return inboundPoolingAuditBean.getInboundPoolingAuditId();
	}

	@Override
	public int saveMergedFileDetails(String mergedFileLoc, String mergeFileName, long totalAmount, 
			Integer totalRecords, String originatorIdentification) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Inside  saveMergedFileDetails method");
		Timestamp defaultTime   = new Timestamp(System.currentTimeMillis());
		MergedInboundFileMapper mergedInboundFileBean = new MergedInboundFileMapper();
		try{
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - preparing bean");
			mergedInboundFileBean.setMergeedFileName(mergeFileName);
			mergedInboundFileBean.setMergedFileLocation(mergedFileLoc);
			mergedInboundFileBean.setTotalAmount(totalAmount+"");
			mergedInboundFileBean.setTotalRecords(totalRecords+"");
			
			mergedInboundFileBean.setCreatedBy(createdBy);
			mergedInboundFileBean.setCreatedTimeStamp(defaultTime);
			mergedInboundFileBean.setLastModifiedBy(lastModifiedBy);
			mergedInboundFileBean.setLastModifiedTimeStamp(defaultTime);
			
			mergedInboundFileBean.setMergedFileType(BaiMergerConstants.FileFormatTypConstants.SRC_FILE_FILE_TYPE);
			mergedInboundFileBean.setFileStatusId(fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_MERGE_FILE_COMPLETE)); ///
			
			
			mergedInboundFileBean.setSenderIdentification(BaiMergerConstants.FileFormatTypConstants.SENDER_IDENTIFICATION);
			mergedInboundFileBean.setOriginatorIdentification(originatorIdentification);
			
			
			mergedInboundFileBean.setMergeStatus(BaiMergerConstants.FileFormatTypConstants.MERGE_STAUTS);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - going to persist merge file details");
			mergedInboundFileDao.saveMergedFileDetails(mergedInboundFileBean);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - merge file details persisted");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while Persisting details merge file details");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while persisting merge file information",e);
		}
		
		return mergedInboundFileBean.getMergedFileId();
	}

	@Override
	public void updateSrcInboundFile(List<Integer> srcInboundFileIdList, Integer mergeFileId, Integer fileStatus) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Inside updateSrcInboundFile method");
		Timestamp defaultTime   = new Timestamp(System.currentTimeMillis());
		try{
			Map<String,Object>  param = new HashMap<String,Object>();
			List<SrcInboundFileMapper> updateList = new ArrayList<SrcInboundFileMapper>();
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - preparing bean to update");
			for(Integer item :srcInboundFileIdList){
				SrcInboundFileMapper srcInboundFileBean = new SrcInboundFileMapper();
				srcInboundFileBean.setMergedFileId(mergeFileId+"");
				srcInboundFileBean.setLastModifiedTimestamp(defaultTime);
				srcInboundFileBean.setSrcFileId(item.intValue());
				srcInboundFileBean.setFileStatusId(fileStatus);
				srcInboundFileBean.setMergedFlag(BaiMergerConstants.FileFormatTypConstants.FILE_MERGE_FLAG_Y);
				
				updateList.add(srcInboundFileBean);
			}
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - list size to update merge id - "+updateList.size());
			
			param.put("updateList", updateList);
			srcInboundFileDao.updSrcInboundFile(param);
			
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - merge id updated in src inbound file");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while updating merge Id in the src inbound file");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while updating merge id into src inbound file",e);
		}
		
	}
	
	public void updateSrcInboundFileStatus(List<Integer> srcInboundFileIdList, Integer fileStatus) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Inside updateSrcInboundFile method");
		Timestamp defaultTime   = new Timestamp(System.currentTimeMillis());
		try{
			Map<String,Object>  param = new HashMap<String,Object>();
			List<SrcInboundFileMapper> updateList = new ArrayList<SrcInboundFileMapper>();
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - preparing bean to update");
			for(Integer item :srcInboundFileIdList){
				SrcInboundFileMapper srcInboundFileBean = new SrcInboundFileMapper();
				srcInboundFileBean.setLastModifiedTimestamp(defaultTime);
				srcInboundFileBean.setSrcFileId(item.intValue());
				srcInboundFileBean.setFileStatusId(fileStatus);
				srcInboundFileBean.setMergedFlag(BaiMergerConstants.FileFormatTypConstants.FILE_MERGE_FLAG_N);
				updateList.add(srcInboundFileBean);
			}
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - list size to update merge id - "+updateList.size());
			
			param.put("updateList", updateList);
			srcInboundFileDao.updSrcInboundFile(param);
			
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - merge id updated in src inbound file");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while updating merge Id in the src inbound file");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while updating file status information",e);
		}
		
	}
	
	private SrcInboundFileMapper populateSrcInboundFileBean(String inputFileName, Integer poolingId, boolean isCrystalReportFile) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Preparing bean inside populateSrcInboundFileBean");
		Timestamp defaultTime = new Timestamp(System.currentTimeMillis());
		SrcInboundFileMapper beanToPersist = new SrcInboundFileMapper();
		
		File inputFile = new File(inputFileName);
		
		beanToPersist.setSrcFileName(inputFile.getName());
		beanToPersist.setTsaInstanceIdentifier(BaiMergerUtility.getTsaIdentifierFromFileName(inputFile.getName()));
		if(!isCrystalReportFile){
			beanToPersist.setSrcFileType(BaiMergerConstants.FileFormatTypConstants.SRC_FILE_FILE_TYPE);
			beanToPersist.setNoOfTransactions(BaiMergerUtility.getTotalNoOfRecods(inputFile.getAbsolutePath())+"");
			beanToPersist.setAmount(BaiMergerUtility.getFileTotalAmount(inputFile.getAbsolutePath()));
		}else{
			beanToPersist.setSrcFileType(BaiMergerConstants.FileFormatTypConstants.SRC_FILE_FILE_CR);
			beanToPersist.setNoOfTransactions("N/A");
			beanToPersist.setAmount("N/A");
		}
		
		beanToPersist.setMergedFlag(BaiMergerConstants.FileFormatTypConstants.FILE_MERGE_FLAG_N);
		beanToPersist.setFileStatusId(fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_FILE_READY_FOR_MERGE));
		beanToPersist.setSrcFileCreationTimestamp(BaiMergerUtility.getFileAttributes(inputFile));
		beanToPersist.setCreatedBy(createdBy);
		beanToPersist.setCreatedTimestamp(defaultTime);
		beanToPersist.setLastmodifiedBy(lastModifiedBy);
		beanToPersist.setLastModifiedTimestamp(defaultTime);
		beanToPersist.setInboundPoolingAuditId(poolingId+"");
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Preparing bean for SrcInboundFileBean completed !!");
		return beanToPersist;
	}

	@Override
	public List<JobConfigMapper> getFileDetails(String nasFileName) throws DataBaseProcessException{
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Inside getFileDetails method");
		List<JobConfigMapper> configBeanList = null;
		try{
			configBeanList = jobConfigDao.getFileDetails(nasFileName);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - getFileDetails completed - list Size - "+configBeanList.size());
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while getting mapping order for the file - "+nasFileName);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while getting File details",e);
		}
		return configBeanList;
	}

	@Override
	public void getLockOnFile(List<String> fileListToGetLock) throws DataBaseProcessException {
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Going to get locks on file list");
		try{
			Timestamp defaultTime = new Timestamp(System.currentTimeMillis());
			Map<String,Object> param = new HashMap<String,Object>();
			List<BaiFileLockMapper> lockBeanList = new ArrayList<BaiFileLockMapper>();
			if(fileListToGetLock != null && fileListToGetLock.size() > 0){
				File fileToLock = null;
				BaiFileLockMapper lockBeanObj = null;
				for(String fileName:fileListToGetLock){
					fileToLock = new File(fileName);
					lockBeanObj = new BaiFileLockMapper();
					logger.info("[BaiMergerProcessPersistanceServiceImpl] - preparing bean to get lock for file - "+fileToLock.getName());
					lockBeanObj.setLockedFileName(fileToLock.getName());
					lockBeanObj.setLockedFileSize(Integer.parseInt(fileToLock.length()+""));
					lockBeanObj.setCreatedBy(createdBy);
					lockBeanObj.setCreatedTimestamp(defaultTime);
					lockBeanObj.setLastModifiedBy(lastModifiedBy);
					lockBeanObj.setLastModifiedTimestamp(defaultTime);
					lockBeanObj.setLockedFileProcessedTime(defaultTime);
					
					lockBeanList.add(lockBeanObj);
				}
			}
			param.put("lockFileList", lockBeanList);
			fileLockDao.getLockOnFileList(param);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Get Lock on file list");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while getting locks for the file");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error while getting Locks on File",e);
		}
		
	}
	

	public void releaseLockOnFile(List<String> fileListToReleaseLock) {
		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Going to release locks on file list");
		try{
			Map<String,Object> param = new HashMap<String,Object>();
			List<BaiFileLockMapper> lockBeanList = new ArrayList<BaiFileLockMapper>();
			if(fileListToReleaseLock != null && fileListToReleaseLock.size() > 0){
				File fileToLock = null;
				BaiFileLockMapper lockBeanObj = null;
				for(String fileName:fileListToReleaseLock){
					fileToLock = new File(fileName);
					lockBeanObj = new BaiFileLockMapper();
					logger.info("[BaiMergerProcessPersistanceServiceImpl] - preparing bean to release lock for file - "+fileToLock.getName());
					lockBeanObj.setLockedFileName(fileToLock.getName());
					lockBeanList.add(lockBeanObj);
				}
			}
			param.put("releaselockFileList", lockBeanList);
			fileLockDao.releaseLock(param);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Lock Released from file");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while releasing locks for the file");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			//throw new DataBaseProcessException("Error while releasing lock on File",e);
		}
		
	}

	@Override
	public int saveSrcInboundCrystalReportFile(String fileName, Integer poolingId) throws DataBaseProcessException {

		logger.info("[BaiMergerProcessPersistanceServiceImpl] - Going to persist data in Crystal Report File details - "+fileName);
		SrcInboundFileMapper detailsToPersist = null;
		try{
			 detailsToPersist = populateSrcInboundFileBean(fileName,poolingId,true);
			srcInboundFileDao.saveSrcInboundFileDetails(detailsToPersist);
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Crsytal Report File details persisted");
		}catch(Exception e){
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - Error while persisting data in Src Inbound File");
			logger.info("[BaiMergerProcessPersistanceServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new DataBaseProcessException("Error While persisting pool file details in src table",e);
		}
		
		return detailsToPersist.getSrcFileId();
	
	}
	
}
