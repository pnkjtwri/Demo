package com.ge.treasury.bai.merger.dao.mapper;

import java.sql.Timestamp;

public class InboundPoolingAuditMapper {
	public Integer inboundPoolingAuditId;
	public Timestamp poolingTimeStamp;
	public Integer poolingRunStatus;
	public Integer inboundConfigId;
	
	/**
	 * @return the poolingRunStatus
	 */
	public Integer getPoolingRunStatus() {
		return poolingRunStatus;
	}
	/**
	 * @param poolingRunStatus the poolingRunStatus to set
	 */
	public void setPoolingRunStatus(Integer poolingRunStatus) {
		this.poolingRunStatus = poolingRunStatus;
	}
	/**
	 * @return the inboundPoolingAuditId
	 */
	public Integer getInboundPoolingAuditId() {
		return inboundPoolingAuditId;
	}
	/**
	 * @param inboundPoolingAuditId the inboundPoolingAuditId to set
	 */
	public void setInboundPoolingAuditId(Integer inboundPoolingAuditId) {
		this.inboundPoolingAuditId = inboundPoolingAuditId;
	}
	/**
	 * @return the poolingTimeStamp
	 */
	public Timestamp getPoolingTimeStamp() {
		return poolingTimeStamp;
	}
	/**
	 * @param poolingTimeStamp the poolingTimeStamp to set
	 */
	public void setPoolingTimeStamp(Timestamp poolingTimeStamp) {
		this.poolingTimeStamp = poolingTimeStamp;
	}
	/**
	 * @return the inboundConfigId
	 */
	public Integer getInboundConfigId() {
		return inboundConfigId;
	}
	/**
	 * @param inboundConfigId the inboundConfigId to set
	 */
	public void setInboundConfigId(Integer inboundConfigId) {
		this.inboundConfigId = inboundConfigId;
	}
}
