package com.ge.treasury.bai.merger.listener;

import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;


@MessageEndpoint
public class BaiMergeSourceFileCopyListener {
	private static Logger logger = Logger.getLogger(BaiMergeSourceFileCopyListener.class);
	
	@Value("%{ACBS_NA_CD_location}")
	private String destinationLocation;
	
	@Value("${acbsGEBAIfilesuffix}")
	private String acbsGEBAIfilesuffix;
	
	
	@Autowired BaiMergerProcessPersistanceService lockService;
	
	@ServiceActivator
	public void copySourceFile(File inputFile){
		if(inputFile != null && inputFile.exists() && inputFile.length() > 0){
			logger.info("[BaiMergeSourceFileCopyListener] - source file received to copy - "+inputFile.getName());
			boolean isLockAcquired = false;
			ArrayList<String> fileListToGetLock = null;
			try {
				fileListToGetLock = new ArrayList<String>();
				fileListToGetLock.add(inputFile.getAbsolutePath());
				lockService.getLockOnFile(fileListToGetLock);
				isLockAcquired = true;
			} catch (DataBaseProcessException e1) {
				logger.info("[BaiMergeSourceFileCopyListener] - Error while getting lock on file "+inputFile.getName());
				isLockAcquired = false;
			}
			
			if(isLockAcquired){
				try{
					BaiMergerUtility.copyFile(inputFile, destinationLocation,acbsGEBAIfilesuffix,false);
				}catch(Exception e){
					logger.info("[BaiMergeSourceFileCopyListener] - Error while copying GE Bai File - "+inputFile.getName());
					logger.info("[BaiMergeSourceFileCopyListener] - "+BaiMergerUtility.getErrorFormStackTrace(e));
				}
				logger.info("[BaiMergeSourceFileCopyListener] - "+inputFile.getName()+" source file copied to - "+destinationLocation);
				
				if(fileListToGetLock != null && fileListToGetLock.size() > 0){
					logger.info("[BaiMergeSourceFileCopyListener] - Going to release lock on files");
					lockService.releaseLockOnFile(fileListToGetLock);
					logger.info("[BaiMergeSourceFileCopyListener] - Lock Released");
				}
			}
		}
	}
}
