package com.ge.treasury.bai.merger.validation;

import java.io.File;

public interface BaiMergerFileValidator {
	public boolean validateFile(File fileToValidate);
}
