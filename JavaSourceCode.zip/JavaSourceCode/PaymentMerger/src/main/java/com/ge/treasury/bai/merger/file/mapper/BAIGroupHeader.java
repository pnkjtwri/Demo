package com.ge.treasury.bai.merger.file.mapper;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;

public class BAIGroupHeader {
	//private String recordCode = "02"; 
	private String recordCode = BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG;
	private String ultimateReceiverIdentification;
	private String originatorIdentification;
	private String groupStatus;
	private String asOfDate;
	private String asOfTime;
	private String currencyCode;
	private String asOfDateModfier;
	private CSVRecord record;
	private String[] recordArray;
	
	public String getRecordCode() {
		return recordCode;
	}
	public String getUltimateReceiverIdentification() {
		return ultimateReceiverIdentification;
	}
	public void setUltimateReceiverIdentification(String ultimateReceiverIdentification) {
		this.ultimateReceiverIdentification = ultimateReceiverIdentification;
	}
	public String getOriginatorIdentification() {
		return originatorIdentification;
	}
	public void setOriginatorIdentification(String originatorIdentification) {
		this.originatorIdentification = originatorIdentification;
	}
	public String getGroupStatus() {
		return groupStatus;
	}
	public void setGroupStatus(String groupStatus) {
		this.groupStatus = groupStatus;
	}
	public String getAsOfDate() {
		return asOfDate;
	}
	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}
	public String getAsOfTime() {
		return asOfTime;
	}
	public void setAsOfTime(String asOfTime) {
		this.asOfTime = asOfTime;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getAsOfDateModfier() {
		return asOfDateModfier;
	}
	public void setAsOfDateModfier(String asOfDateModfier) {
		this.asOfDateModfier = asOfDateModfier;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}	
	public String[] getRecordArray() {
		return recordArray;
	}
	public void setRecordArray(String[] recordArray) {
		this.recordArray = recordArray;
	}
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setUltimateReceiverIdentification(record.get(1));
			setOriginatorIdentification(record.get(2));
			setGroupStatus(record.get(3));
			setAsOfDate(record.get(4));
			setAsOfTime(record.get(5));
			setCurrencyCode(record.get(6));
			setAsOfDateModfier(record.get(7));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String populate(String[] recordArray){
		String status = "success";
		try {		
			setRecordArray(recordArray);
			setUltimateReceiverIdentification(recordArray[1]);
			setOriginatorIdentification(recordArray[2]);
			setGroupStatus(recordArray[3]);
			setAsOfDate(recordArray[4]);
			setAsOfTime(recordArray[5]);
			setCurrencyCode(recordArray[6]);
			setAsOfDateModfier(recordArray[7]);
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	/*public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}*/
	public String toString(){
		String returnString = "";
		for(String text: recordArray){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
