package com.ge.treasury.bai.merger;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.jmx.config.EnableIntegrationMBeanExport;
import org.springframework.jmx.support.RegistrationPolicy;


@SpringBootApplication
@EnableAutoConfiguration
@EnableIntegrationMBeanExport(registration = RegistrationPolicy.REPLACE_EXISTING)
@ImportResource({"classpath:spring/integrationContext.xml"})

public class BaiFileMergerApplication extends SpringBootServletInitializer {
	final static Logger logger = Logger.getLogger(BaiFileMergerApplication.class);
	
	public static void main(String[] args) {
		logger.info("[BaiFileMergerApplication] - Going to load main method of BAI Merger");
		
		SpringApplication.run(BaiFileMergerApplication.class, args);
	}
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
		defaultProperties.put("spring.config.location", "file:/app/tsaweb/properties/paymentmerger/application.yml");
		return application.sources(BaiFileMergerApplication.class).properties(defaultProperties);
    }
}
