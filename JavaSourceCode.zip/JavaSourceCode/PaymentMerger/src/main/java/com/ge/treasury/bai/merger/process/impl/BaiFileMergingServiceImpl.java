package com.ge.treasury.bai.merger.process.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.exception.BaiMergeProcessException;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.file.mapper.BAIFile;
import com.ge.treasury.bai.merger.file.mapper.BAIFileHeader;
import com.ge.treasury.bai.merger.file.mapper.BAIFileTrailer;
import com.ge.treasury.bai.merger.file.mapper.BAIGroup;
import com.ge.treasury.bai.merger.file.mapper.BAIGroupHeader;
import com.ge.treasury.bai.merger.file.mapper.BAIGroupTrailer;
import com.ge.treasury.bai.merger.load.config.FileStausLoaderService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.process.BaiFileMergingService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component("BaiFileMerge")
public class BaiFileMergingServiceImpl implements BaiFileMergingService{
	private static Logger logger = Logger.getLogger(BaiFileMergingServiceImpl.class);
	
	@Autowired BaiMergerProcessPersistanceService persistanceService;
	@Autowired FileStausLoaderService fileStatus;
	@Autowired private ApplicationContext appContext;

	@Value("${sourceFileProcessingLocation}")
	private String processingLocation;
	
	@Value("${outPutFileLocation}")
	private String outPutFileLocation;
	
	@Value("${tmpOutPutFileLocation}")
	private String tmpOutPutFileLocation;
	
	@Value("${pathForOutboundChannel}")
	private String pathForOutboundChannel;
	
	@Override
	public String startMerging(List<String> listOfFilesRecieved, List<Integer> srcInboundFileIdList, String nasFileNamePattern) throws BaiMergeProcessException, DataBaseProcessException{
		logger.info("[BaiFileMergingServiceImpl] - Inside startMerging method");
		
		//getting details from database
		List<JobConfigMapper>  configBeanList = persistanceService.getFileDetails(nasFileNamePattern);
		
		if(configBeanList == null || configBeanList.size() <= 0 ){
			//error condition cannot continue
			throw new BaiMergeProcessException("No config details found in the job config table fro the file pattern - "+nasFileNamePattern,null);
		}
		
		logger.info("[BaiFileMergingServiceImpl] - updating status for merging process in progress");
		persistanceService.updateSrcInboundFileStatus(srcInboundFileIdList,fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_MERGE_FILE_IN_PROGRESS));
		logger.info("[BaiFileMergingServiceImpl] - src inbound status updated");

		String erpTargetOutputFileName = configBeanList.get(0).getErpTargetFileName();
		logger.info("[BaiFileMergingServiceImpl] - Erp target file name - "+erpTargetOutputFileName);
		
		logger.info("[BaiFileMergingServiceImpl] - File merging start");
		mergeListFile(listOfFilesRecieved,configBeanList,erpTargetOutputFileName);
		logger.info("[BaiFileMergingServiceImpl] - File merging done");
		
		logger.info("[BaiFileMergingServiceImpl] - merge group header");
		mergeGroup(erpTargetOutputFileName);
		logger.info("[BaiFileMergingServiceImpl] - merge group header done");
		
		logger.info("[BaiFileMergingServiceImpl] - Try to get merge file total amount");
		long amountAferMerge 	  = Long.parseLong(BaiMergerUtility.getFileTotalAmount(outPutFileLocation+erpTargetOutputFileName));
		logger.info("[BaiFileMergingServiceImpl] - Try to get merge file total record");
		int totalRecordsAferMerge = BaiMergerUtility.getTotalNoOfRecods(outPutFileLocation+erpTargetOutputFileName);
		
		String originatorIdentification = BaiMergerUtility.getOriginatorIdentification(outPutFileLocation+erpTargetOutputFileName);
		
		logger.info("[BaiFileMergingServiceImpl] - Going to persist merge file details");
		int mergeFileId = persistanceService.saveMergedFileDetails(outPutFileLocation, erpTargetOutputFileName, amountAferMerge, totalRecordsAferMerge, originatorIdentification);
		
		logger.info("[BaiFileMergingServiceImpl] - Going to update merge id in th src inbound file");
		persistanceService.updateSrcInboundFile(srcInboundFileIdList,mergeFileId,fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_MERGE_FILE_COMPLETE));
		logger.info("[BaiFileMergingServiceImpl] - update merge id in th src inbound file done");
		
		File fileSendToBusiness = new File(outPutFileLocation+erpTargetOutputFileName);
		//Call outbound method to transafer file
		sendFileToBusiness(fileSendToBusiness,configBeanList);
		
		return fileSendToBusiness.getAbsolutePath();
	}
	
	/***
	 * Merge all the received files
	 * @param listOfRecivedFiles
	 * @throws BaiMergeProcessException 
	 */
	private void mergeListFile(List<String> listOfRecivedFiles, List<JobConfigMapper>  configBeanList, String erpTargetOutputFileName) throws BaiMergeProcessException{
		logger.info("[BaiFileMergingServiceImpl] - merge process start, no of files received - "+listOfRecivedFiles.size());
		BAIGroupHeader groupHeader;
		BAIGroupTrailer groupTrailer;
		
		BAIFile baiFile 			= null;
		BAIFileHeader fileHeader 	= null;
		BAIFileTrailer fileTrailer 	= null;
		BAIGroup group 				= null;
		
		ArrayList<String> accountDataLines 		= null;
		ArrayList<BAIGroup> groups 				= null;
		ArrayList<BAIFile> baiFiles 			= new ArrayList<BAIFile>();
		
		BufferedReader br     =  null;
		BufferedWriter writer = null;
		long fileControlTotal = 0;
		long numberOfGroups   = 0;
		long numberOfRecords  = 0;
		StringBuffer fileMergeContent = new StringBuffer();
		
		try{
			logger.info("[BaiFileMergingServiceImpl] - Initilizing output file Object");
			writer = new BufferedWriter(new FileWriter(tmpOutPutFileLocation+erpTargetOutputFileName+BaiMergerConstants.FileFormatTypConstants.TMP_FILE_EXTENSION));
			
			String headerLineForOutputFile = "";
			String mappingOrderDb = "0";
			String prevMappingOrder = "0";
			
			for(String file: listOfRecivedFiles){
				baiFile = new BAIFile();
				String line = "";
				br = new BufferedReader(new FileReader(file));
				String status = "success";
				String fileRecieved= "";
				
				if(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR) > 0 ){
					//fileRecieved = file.substring(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR)+1, file.lastIndexOf(".txt"));
					fileRecieved = file.substring(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR)+1, file.length());
				}else if(file.lastIndexOf("\\") > 0 ){
					fileRecieved = file.substring(file.lastIndexOf("\\"), file.lastIndexOf(".txt"));
				}
				
				while ((line = br.readLine()) != null) {
					String[] recordArray = line.split(",");
				    String firstValue = recordArray[0];
				    
				    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG)){
				    	logger.info("[BaiFileMergingServiceImpl] - Header Tag Found for the file - "+file);
				    	fileHeader = new BAIFileHeader();
				    	groups = new ArrayList<BAIGroup>();
				    		
				    	for(JobConfigMapper configBean : configBeanList){
				    		if(fileRecieved.equalsIgnoreCase(configBean.getNasFileNamePattern())){
				    			mappingOrderDb = configBean.getMappingOrder();
				    			if(Integer.parseInt(prevMappingOrder) == 0){
				    				prevMappingOrder = mappingOrderDb;
				    				headerLineForOutputFile = line;
				    			}
				    		}
				    	}
				    	
				    	if(mappingOrderDb != null && Integer.parseInt(prevMappingOrder) > Integer.parseInt(mappingOrderDb)){
				    		headerLineForOutputFile = line;
				    		prevMappingOrder = mappingOrderDb;
				    	}
				    	
				    	status = fileHeader.populate(recordArray);
				    	baiFile.setFileHeader(fileHeader);
				    	logger.info("[BaiFileMergingServiceImpl] - Header Tag value - "+fileHeader.toString());
				    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG)){
				    	logger.info("[BaiFileMergingServiceImpl] - Group Header Found for the file - "+file);
				    	group = new BAIGroup();				    	
				    	groupHeader = new BAIGroupHeader();		
				    	accountDataLines = new ArrayList<String>();
				    	status = groupHeader.populate(recordArray);
				    	group.setGroupHeader(groupHeader);
				    	logger.info("[BaiFileMergingServiceImpl] - Group Header value - "+groupHeader.toString());
				    }else if(  firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG) 
				    		|| firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_TAG)
				    		|| firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.TRANSACTION_DETAIL_TAG) 
				    		|| firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.CONTINUATION_TAG)){
				    	accountDataLines.add(line);
				    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG)){
				    	logger.info("[BaiFileMergingServiceImpl] - Group Trailer Found for the file - "+file);
				    	groupTrailer = new BAIGroupTrailer();
				    	status = groupTrailer.populate(recordArray);
				    	fileControlTotal += new Long(groupTrailer.getGroupControlTotal());
				    	numberOfGroups ++;
				    	group.setGroupTrailer(groupTrailer);
				    	group.setAccountDataLines(accountDataLines);
				    	groups.add(group);
				    	logger.info("[BaiFileMergingServiceImpl] - Group Trailer value - "+groupTrailer.toString());
				    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
				    	logger.info("[BaiFileMergingServiceImpl] - File Trailer Found for the file - "+file);
				    	fileTrailer = new BAIFileTrailer();
				    	status = fileTrailer.populate(recordArray);
				    	baiFile.setFileTrailer(fileTrailer);
				    	baiFile.setGroups(groups);
				    	baiFiles.add(baiFile);
				    	logger.info("[BaiFileMergingServiceImpl] - File Trailer value - "+fileTrailer.toString());
				    }
					
					if(    !firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG) 
						&& !firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
						fileMergeContent.append(line);
						fileMergeContent.append(BaiMergerConstants.FileFormatTypConstants.BAI_NEW_LINE_CHAR);
					}
					
					numberOfRecords ++;
				}
				numberOfRecords = numberOfRecords -2;
				br.close();
			}
			numberOfRecords = numberOfRecords + 2;
			
			if(fileTrailer != null){
				logger.info("[BaiFileMergingServiceImpl] - Writing File Header value ");
				writer.write(headerLineForOutputFile);
				logger.info("[BaiFileMergingServiceImpl] - File Header writing complete");
				writer.newLine();
				logger.info("[BaiFileMergingServiceImpl] - Writing File body value ");
				writer.write(fileMergeContent.toString());
				logger.info("[BaiFileMergingServiceImpl] - File Body writing complete");
				
				logger.info("[BaiFileMergingServiceImpl] - Setting Final File Trailer value ");
				fileTrailer.setFileControlTotal(String.valueOf(fileControlTotal));
				fileTrailer.setNumberOfRecords(String.valueOf(numberOfRecords));
				fileTrailer.setNumberOfGroups(String.valueOf(numberOfGroups));
				logger.info("[BaiFileMergingServiceImpl] - Writing File Trailer value ");
				writer.write(fileTrailer.toString()+BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR);
			}
			
			writer.flush();
			//writer.close();
		}catch(Exception e){
			logger.info("[BaiFileMergingServiceImpl] - Error while Merging process");
			logger.info("[BaiFileMergingServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new BaiMergeProcessException("Error while merging all files",e);
		}finally{
			try{
				if(br != null){
					br.close();
				}
				
				if(writer != null){
					writer.close();
				}
			}catch(Exception e){
				logger.info("[BaiFileMergingServiceImpl] - Error while closing writer and reader");
				logger.info("[BaiFileMergingServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			}
		}
	}
	
	/***
	 * Merge the group header if found matching
	 * @param inPutFile
	 * @throws BaiMergeProcessException 
	 */
	private void mergeGroup(String erpTargetFileName) throws BaiMergeProcessException{
		BufferedReader br     = null;
		BufferedWriter writer = null;
		int totalNoOfFileRec  = 0 ;
		int noOfGroups        = 0;
		try{
			br = new BufferedReader(new FileReader(tmpOutPutFileLocation+erpTargetFileName+BaiMergerConstants.FileFormatTypConstants.TMP_FILE_EXTENSION));
			writer = new BufferedWriter(new FileWriter(outPutFileLocation+erpTargetFileName));
			
			//Map<String,List<String>> groupHeaderMap = new HashMap<String,List<String>>();
			Map<String,Map<String,List<String>>> groupHeaderMap = new HashMap<String,Map<String,List<String>>>();
			
			String fileHeaderLine = "";
			
			String line = "";
			String groupHEaderKey  = "";
			String groupHEaderLine = "";
			
			List<String> groupLines = new ArrayList<String>();
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG)){
			    	logger.info("[BaiFileMergingServiceImpl] - File Header Found during group merge ");
			    	fileHeaderLine = line;
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG)){
			    	logger.info("[BaiFileMergingServiceImpl] - Group Header Found during group merge ");
			    	//groupHeader.put(line, value)
			    	if(recordArray[7].indexOf("/") > 0){
			    		recordArray[7] = recordArray[7].substring(0,recordArray[7].indexOf("/"));
			    	}
			    	
			    	//adding grop header in one for comparing with other Group Hearder
			    	//adding Originator Identification, As-of-Date, As-of-Date Modifier
			    	//groupHEaderKey = recordArray[2]+recordArray[4]+recordArray[7];
			    	//adding Originator Identification, As-of-Date
			    	groupHEaderKey = recordArray[2]+recordArray[4];
			    	groupHEaderLine = line;
			    	groupLines = new ArrayList<String>();
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG)){
			    	logger.info("[BaiFileMergingServiceImpl] - Group Trailer Found during group merge ");
			    	
			    	long groupAmountTotal = 0l;
			    	int totalAccountCount = 0; //assuming that there will be always one "03" tag
			    	String groupLine      = "";
			    	
			    	if(!groupHeaderMap.containsKey(groupHEaderKey)){
			    		groupLines.add(line);
			    		Map<String,List<String>> groupValueMap = new HashMap<String,List<String>>();
			    		groupValueMap.put(groupHEaderLine, groupLines);
			    		groupHeaderMap.put(groupHEaderKey, groupValueMap);
			    		noOfGroups ++;
			    	}else{
			    		List<String> mergedLineList = new ArrayList<String>();
			    		List<String> tmpRecords =  (groupHeaderMap.get(groupHEaderKey)).get(groupHEaderLine);
			    		int noOfAccountsInMap = getAccountCount(groupHeaderMap, groupHEaderKey, groupHEaderLine);
			    		int totalNoOfGroupRec = 0;
			    		int accountLoopCount = 0;
			    		for(String lineTmp : tmpRecords){
			    			String[] recordTmpArray = lineTmp.split(",");
						    String firstTmpValue 	= recordTmpArray[0];
						    
						    if(firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_TAG)){
						    	groupAmountTotal += Long.parseLong(recordTmpArray[1]);
						    	
						    	if(recordTmpArray[2].indexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR) > 0){
				    				String tmpAmt  = recordTmpArray[2].substring(0,recordTmpArray[2].indexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR));
				    				totalNoOfGroupRec += Integer.parseInt(tmpAmt);
				    			}else{
				    				totalNoOfGroupRec += Integer.parseInt(recordTmpArray[2]);
				    			}
						    	mergedLineList.add(lineTmp); //add accountTrailer to the list
						    	
						    	if(noOfAccountsInMap==accountLoopCount)for(String lineToMerge : groupLines){//going to iterate current account data
						    		mergedLineList.add(lineToMerge);
						    		String[] recordToMergeArray = lineToMerge.split(",");
						    		String fisrtToMergeValue    = recordToMergeArray[0];
						    		if(fisrtToMergeValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG)){
						    			totalAccountCount ++; 
						    		}
						    		if(fisrtToMergeValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_TAG)){
						    			groupAmountTotal += Long.parseLong(recordToMergeArray[1]);
						    			if(recordToMergeArray[2].indexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR) > 0){
						    				String tmpAmt  = recordToMergeArray[2].substring(0,recordToMergeArray[2].indexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR));
						    				totalNoOfGroupRec += Integer.parseInt(tmpAmt);
						    			}else{
						    				totalNoOfGroupRec += Integer.parseInt(recordToMergeArray[2]);
						    			}
						    		}
						    	}
						    }
						    
						    if(!firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_TAG) &&
						       !firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG)){
						    	mergedLineList.add(lineTmp); //adding other rows
						    	
						    	if(firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG)){
						    		 accountLoopCount ++;
						    	 }
						    	
						    }
						    
						    if(firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG)){
						    	totalNoOfGroupRec += 2;
						    	totalAccountCount = totalAccountCount+noOfAccountsInMap;
						    	//groupLine += BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG+","+groupAmountTotal+","+recordTmpArray[2]+","+totalNoOfGroupRec+BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR;
						    	groupLine += BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG+","+groupAmountTotal+","+totalAccountCount+","+totalNoOfGroupRec+BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR;
						    }
			    		}
			    		mergedLineList.add(groupLine);
			    		//groupHeaderMap.put(groupHEaderKey, mergedLineList);
			    		groupHeaderMap.get(groupHEaderKey).put(groupHEaderLine, mergedLineList);
			    	}
			    }
			    
			    if(!firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG) && 
			       !firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG) &&
			       !firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG) &&
			       !firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
				       groupLines.add(line);
					}
			    
			    //totalNoOfFileRec ++;
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG) ){
			    	writer.write(fileHeaderLine);
			    	writer.newLine();
			    	totalNoOfFileRec ++;
			    	/*for (Map.Entry<String, List<String>> entry : groupHeaderMap.entrySet()){
			    		writer.write(entry.getKey());
				    	writer.newLine();
				    	for(String contentToWrite : entry.getValue()){
				    		writer.write(contentToWrite);
					    	writer.newLine();
				    	}
			    	}*/
			    	
			    	for(String headerKey : groupHeaderMap.keySet()){
			    		Map<String,List<String>> groupValueMap = groupHeaderMap.get(headerKey);
			    		for (Map.Entry<String, List<String>> entry : groupValueMap.entrySet()){
				    		writer.write(entry.getKey());
					    	writer.newLine();
					    	totalNoOfFileRec ++;
					    	for(String contentToWrite : entry.getValue()){
					    		writer.write(contentToWrite);
						    	writer.newLine();
						    	totalNoOfFileRec ++;
					    	}
				    	}
			    	}
			    	
			    	
			    	totalNoOfFileRec = totalNoOfFileRec + 1;
			    	
			    	String fileTrailer = BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG+","
			    			+recordArray[1]+","+noOfGroups+","+totalNoOfFileRec+BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR;
			    	writer.write(fileTrailer);
			    	writer.flush();
				 }
			}
		}catch(Exception e){
			logger.info("[BaiFileMergingServiceImpl] - Error while merging group headers");
			logger.info("[BaiFileMergingServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			throw new BaiMergeProcessException("Error while merging group header tag",e);
		}finally{
			try{
				if(writer != null){
					writer.close();
				}
				if(br != null){
					br.close();
				}
			}catch(Exception e){
				logger.info("[BaiFileMergingServiceImpl] - Error while closing writer and reader in group merging");
				logger.info("[BaiFileMergingServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			}
		}
	}
	
	/***
	 * Send merge file to business 
	 * @param inputFile
	 * @return
	 */
	private boolean sendFileToBusiness(File inputFile, List<JobConfigMapper>  configBeanList) throws BaiMergeProcessException{
		boolean isSent = false;
		String sendFileLocation = "";
		logger.info("Going to transfer file...."+inputFile.getName());
		try{
			sendFileLocation = configBeanList.get(0).getErpTargetFileLocation();
			
			AtomicReference<String> targetDir = (AtomicReference<String>)appContext.getBean(BaiMergerConstants.FileBelongsTo.FILE_TARGET_DIR, AtomicReference.class);
			/*if(pathForOutboundChannel != null && pathForOutboundChannel.length() > 1){
				logger.info("[BaiFileMergingServiceImpl] - Merge file sending location - "+pathForOutboundChannel);
				targetDir.set(pathForOutboundChannel);
			}else*/{
				logger.info("[BaiFileMergingServiceImpl] - Merge file sending location - "+sendFileLocation);
				targetDir.set(sendFileLocation);
			}
			
			Message<File> message = MessageBuilder.withPayload(inputFile).build();
			final MessageChannel baiMergeFileOutboundChannel = appContext.getBean (BaiMergerConstants.FileBelongsTo.FILE_OUTBOUND_CHANNEL, MessageChannel.class);
			isSent = baiMergeFileOutboundChannel.send(message,1000);
		} catch (Exception e) {
			logger.info("[BaiFileMergingServiceImpl] - Got Exception inside sendFileToBusiness()");
			logger.info("[BaiFileMergingServiceImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			isSent = false;
			throw new BaiMergeProcessException("Merge file sending failed to locations - "+sendFileLocation,e);
		}
		logger.info("[BaiFileMergingServiceImpl] - inside sendFileToBusiness() sent status - "+isSent);
		return isSent;  
	}
	
	private int getAccountCount(Map<String,Map<String,List<String>>> groupHeaderMap, String groupHEaderKey, 
			String groupHEaderLine){
		int noOfAccounts = 0;
		List<String> tmpRecords =  (groupHeaderMap.get(groupHEaderKey)).get(groupHEaderLine);
		for(String lineTmp : tmpRecords){
			String[] recordTmpArray = lineTmp.split(",");
		    String firstTmpValue 	= recordTmpArray[0];
		    
		    if(firstTmpValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG)){
	    		 noOfAccounts ++;  
	    	 }
		}
		return noOfAccounts;
	}
}
