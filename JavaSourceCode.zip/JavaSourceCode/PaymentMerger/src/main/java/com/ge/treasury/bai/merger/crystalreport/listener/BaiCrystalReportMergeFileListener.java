package com.ge.treasury.bai.merger.crystalreport.listener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.bai.merger.bean.FilePoolingDetailsCrystalReport;
import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.mail.service.BaiMergerMailService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.process.BaiFileMergingService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;
import com.ge.treasury.bai.merger.validation.BaiMergerFileValidator;

@MessageEndpoint
public class BaiCrystalReportMergeFileListener {

	private static Logger logger = Logger.getLogger(BaiCrystalReportMergeFileListener.class);
	
	@Autowired
	@Qualifier("BaiCrystalReportMerge")
	BaiFileMergingService mergingService;
	
	@Autowired BaiMergerProcessPersistanceService persistanceService;
	@Autowired BaiMergerMailService mailService;
	@Autowired BaiMergerFileValidator validatorService;
	@Autowired private ApplicationContext appContext;
	
	private FilePoolingDetailsCrystalReport filePooledDetails;
	
	/**
	 * @param filePooledDetails the filePooledDetails to set
	 */
	public synchronized void setFilePooledDetails(FilePoolingDetailsCrystalReport filePooledDetails) {
		this.filePooledDetails = filePooledDetails;
	}

	/**
	 * @return the filePooledDetails
	 */
	public synchronized FilePoolingDetailsCrystalReport getFilePooledDetails() {
		return filePooledDetails;
	}

	@Value("${createdBy}")
	private String createdBy;
	
	@Value("${lastModifiedBy}")
	private String lastModifiedBy;
	
	@Value("${crProcessingLocation}")
	private String processingLocation;
	
	@Value("%{ACBS_CR_CR_location}")
	private String receivedFileLocation;
	
	/*@Value("${tmpOutPutFileLocation}")
	private String tmpOutPutFileLocation;*/
	
	@Value("${crArchiveFileLocation}")
	private String archiveFileLocation;
	
	@Value("${crErrorFileLocation}")
	private String errorFileLocation;
	
	@Value("%{ACBS_CR_CR_schedule}")
	private String schedule;
	
	@Value("%{ACBS_CR_CR_pattern}")
	private String nasFileNamePattern;
	
	private List<String> listOfFilesRecieved = null;
	private List<Integer> srcInboundFileIdList = null;
	private List<JobConfigMapper> noOfFilesWillReceived = null;
	private List<String> listOfFilesToRelease = null;
	private Integer noOfFilesReceivedAtLocation = null;
	private Integer poolingId  = null;
	
	@ServiceActivator
	public void initiateMerger(File inputFile){
		if(inputFile != null && inputFile.exists() && inputFile.isFile()){
			//String fileName = BaiMergerUtility.trimBAIFileTimeStamp(inputFile.getName());
			String fileName = inputFile.getName();
			String mergeFile = null;
			
			if(listOfFilesToRelease == null){
				listOfFilesToRelease = new ArrayList<String>();
			}
			
			logger.info("add Crystal Report file to release lock");
			listOfFilesToRelease.add(inputFile.getName());
			logger.info("Crystal Report file added to release lock - "+inputFile.getName());
			
			logger.info("No of Crystal Report file pooled from filter - "+getFilePooledDetails().getNoOfFilesPooledFromLocation());
			
			try{
				if(noOfFilesReceivedAtLocation == null){
					noOfFilesReceivedAtLocation = getFilePooledDetails().getNoOfFilesPooledFromLocation();
					logger.info(""+noOfFilesReceivedAtLocation+" No of Crystal Report file at location - "+receivedFileLocation +" received");
				}
				
				logger.info("Crystal Report File Received - "+fileName);
				logger.info("Crystal Report File Moving to processing folder - "+processingLocation);
				//moving file to processing location
				BaiMergerUtility.moveFile(inputFile, processingLocation, false,false);
				
				if(srcInboundFileIdList == null){
					srcInboundFileIdList = new ArrayList<Integer>();
				}
				
				if(listOfFilesRecieved == null){
					listOfFilesRecieved = new ArrayList<String>();
					
					if(poolingId == null){
						logger.info("Going to persist details in Inbound Pooling Audit");
						//insert into pooling audit table
						poolingId = persistanceService.saveInboundPoolingAuditLog(BaiMergerUtility.trimBAIFileTimeStamp(inputFile.getName()),schedule);
					}
				}
				//add no of received file which moved to processing location
				listOfFilesRecieved.add(processingLocation+fileName);
				logger.info("Added received Crystal Report file in the list");
				
				logger.info("Going to prepare bean for Src Inbound file");
				int srcFileId = persistanceService.saveSrcInboundCrystalReportFile((processingLocation+fileName), poolingId);
				srcInboundFileIdList.add(srcFileId);
				logger.info("Added generated Srcinbound fileId, for Crystal Report file, in the list");
				
				if(noOfFilesWillReceived == null){
					logger.info("going to get, no of Crystal Report file, we will received to merge from data base");
					noOfFilesWillReceived = persistanceService.getNoOfFilesToMerge(nasFileNamePattern, schedule);
				}
				
				List<String> misingFileList =  null;
				if(noOfFilesReceivedAtLocation != noOfFilesWillReceived.size() && listOfFilesRecieved.size() == noOfFilesReceivedAtLocation){
					logger.info("Checking received Crystal Report file is equals to expected receive file or not");
					misingFileList = checkForReceivedFile(poolingId, noOfFilesWillReceived, listOfFilesRecieved,noOfFilesReceivedAtLocation);
				}
				
				if(listOfFilesRecieved.size() == noOfFilesReceivedAtLocation 
						&& noOfFilesWillReceived.size() == listOfFilesRecieved.size()){ 
					logger.info("Initiating File Crystal Report Merge Process..");
					
					try{
						mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
					}catch(Exception e){
						logger.info("Crystal Report Merging process failed in first attempt");
						try{
							mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
						}catch(Exception ex){
							logger.info("Crystal Report Merging process failed in second attempt");
							try{
								mergeFile = mergingService.startMerging(listOfFilesRecieved,srcInboundFileIdList,nasFileNamePattern);
							}catch(Exception exp){
								logger.info("Crystal Report Merging process failed in third attempt");
								throw new Exception(exp);
							}
						}
					}
					logger.info("Crystal Report Merge Process complete !!");
					
					logger.info("Going to release lock on Crystal Report files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("Lock Released on Crystal Report files");
					
					//moving file to archive
					moveFiles(listOfFilesRecieved, true, mergeFile,inputFile);
					
					//reset variables
					initObject();
					logger.info("Resetting list completed !!");
				}else if(noOfFilesReceivedAtLocation != noOfFilesWillReceived.size() && noOfFilesReceivedAtLocation == listOfFilesRecieved.size()){
					logger.info("[BaiMergerPDListener] - Did not receive all expected file for Crystal Report merge");
					
					logger.info("Going to release lock on Crystal Report files");
					persistanceService.releaseLockOnFile(listOfFilesToRelease);
					logger.info("Lock Released");
					
					logger.info("[BaiMergerPDListener] - File is moving to error, we have only "+ noOfFilesReceivedAtLocation +" file");
					String subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_CRYSTAL_REPORT_SINGLE_FILE_FOUND;
					String msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_CRYSTAL_REPORT_SINGLE_FILE, noOfFilesReceivedAtLocation, poolingId,noOfFilesWillReceived.size(),noOfFilesReceivedAtLocation);
					
					moveFiles(listOfFilesRecieved, false, null,inputFile);
					
					sendMailNotification(null,subject, listOfFilesRecieved,msg);
					logger.info("All Crystal Report file not Received for merge ");
					initObject();
				}
			}catch(Exception e){
				//move file to error
				//delete all no realted files
				logger.info("Going to release lock on Crystal Report files");
				persistanceService.releaseLockOnFile(listOfFilesToRelease);
				logger.info("Crystal Report File Lock Released");
				
				moveFiles(listOfFilesRecieved, false, null,inputFile);
				sendMailNotification(e,BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_CRYSTAL_REPORT_MERGE_ERROR,listOfFilesToRelease,BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_CRYSTAL_REPORT_MERGE_ERROR);
				initObject();
			}
		}
	}
	
	private List<String> checkForReceivedFile(Integer poolingId, List<JobConfigMapper> noOfFilesWillReceived, 
			List<String> listOfFilesRecieved, Integer noOfFilesReceivedAtPoolingLocation){
		logger.info("Inside checkForReceivedFile");
		List<String> missingFiles = null;
		try{
			if(noOfFilesWillReceived != null){
				logger.info("No of Expected files for Crystal Report- "+noOfFilesWillReceived.size());
				missingFiles = new ArrayList<String>();
				if(noOfFilesWillReceived.size() == noOfFilesReceivedAtPoolingLocation.intValue()){
					return missingFiles;
				}else if(noOfFilesWillReceived.size() > noOfFilesReceivedAtPoolingLocation.intValue() && (noOfFilesReceivedAtPoolingLocation == listOfFilesRecieved.size())){
					logger.info("Expected and Received file list is not equals for Crystal Report merge");
					
					for(JobConfigMapper beanConfig:noOfFilesWillReceived){
						boolean isMatchFound = false;
						for(String file : listOfFilesRecieved){
							String fileRecieved = "";
							if(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR) > 0 ){
								fileRecieved = file.substring(file.lastIndexOf(BaiMergerConstants.FileFormatTypConstants.BAI_END_LINE_CHAR)+1, file.length());
							}else if(file.lastIndexOf("\\") > 0 ){
								fileRecieved = file.substring(file.lastIndexOf("\\"), file.toLowerCase().lastIndexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()));
							}
							fileRecieved = BaiMergerUtility.trimBAIFileTimeStamp(fileRecieved);
							if(fileRecieved.equalsIgnoreCase(beanConfig.getNasFileNamePattern())){
								isMatchFound = true;
								break;
							}
						}
						if(!isMatchFound){
							missingFiles.add(beanConfig.getNasFileNamePattern());
						}
					}
					
					//sent mail notification with missing list
					if(missingFiles != null && missingFiles.size() > 0){
						String msg = String.format(BaiMergerConstants.MailMessageContent.MAIL_MESSAGE_FOR_FILE_NOT_FOUND, poolingId.intValue());
						String subject = BaiMergerConstants.MailMessageContent.MAIL_SUBJECT_FOR_FILE_NOT_FOUND;
						sendMailNotification(null, subject, missingFiles,msg);
					}
				}
			}
		}catch(Exception e){
			logger.info("Error while getting missing files for Crystal Report");
			logger.info(""+BaiMergerUtility.getErrorFormStackTrace(e));
		}
		return missingFiles;
	}
	
	
	private void sendMailNotification(Exception ex, String subject, List<String> misingFileList, String msg){
		try{
			logger.info("Going to send Email");
			mailService.sendErrorMail(ex, subject, misingFileList,msg);
			logger.info("Email Sent !!");
		}catch(Exception e){
			logger.info("Email Sending process Error. Not able to send email alert !! ");
			logger.info(""+BaiMergerUtility.getErrorFormStackTrace(e));
		}
	}
	
	private void initObject(){
		logger.info("Resetting list");
		this.listOfFilesRecieved         = null;
		this.srcInboundFileIdList        = null;
		this.poolingId                   = null;
		this.noOfFilesWillReceived       = null;
		this.noOfFilesReceivedAtLocation = null;
		//this.nasFileNamePattern		     = null;
		//this.listOfValidFilesRecieved    = null;
		//this.listOfWrongFormatFilesRecieved = null;
		this.listOfFilesToRelease			= null;
		logger.info("Resetting object completed");
	}
	
	
	private void moveFiles(List<String> fileToMoveList, boolean isArchive, String mergedFile, File inputFile){
		logger.info("Going to move files - inside moveFiles method");
		File file = null;
		if(isArchive){
			for(String fileToMove : fileToMoveList){
				file = new File(fileToMove);
				if(file.exists()){
					String encFileFilePath = inputFile.getAbsolutePath().substring(0,inputFile.getAbsolutePath().lastIndexOf(File.separator)+1);
					encFileFilePath = encFileFilePath + file.getName() + BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION;
					logger.info("Checking for Encrypted file - "+encFileFilePath );
					if((new File(encFileFilePath)).exists()){
						logger.info("Found Encrypted file, removing decrypted file to - "+file.getAbsolutePath());
						BaiMergerUtility.removeFile(file.getAbsolutePath());
					}else{
						logger.info("moving file to archive - "+file.getAbsolutePath());
						BaiMergerUtility.moveFile(file, archiveFileLocation, isArchive,false);
					}
				}
			}
			if(mergedFile != null){
				file = new File(mergedFile);
				logger.info("moving merge file to archive - "+file.getAbsolutePath());
				BaiMergerUtility.moveFile(file, archiveFileLocation, isArchive,false);
			}
		}else{
			for(String fileToMove : fileToMoveList){
				file = new File(fileToMove);
				if(file.exists()){
					logger.info("moving file to error location - "+file.getAbsolutePath());
					BaiMergerUtility.moveFile(file, errorFileLocation, true,false);
				}
			}
			if(mergedFile != null){
				file = new File(mergedFile);
				
				logger.info("deleting merge file - "+file.getAbsolutePath());
				if(file.exists()){
					BaiMergerUtility.removeFile(file.getAbsolutePath());
				}
			}
		}
		
		//moving encrypted file
		String encFileFilePath       = "";
		String encFileMovingLocation = "";
		
		if(isArchive){
			encFileMovingLocation = archiveFileLocation;
		}else{
			encFileMovingLocation = errorFileLocation;
		}
		
		logger.info("Going to move encrypted file at following locaiton - "+encFileMovingLocation);
		if(listOfFilesToRelease != null && listOfFilesToRelease.size() > 0){
			for(String encFile : listOfFilesToRelease){
				encFileFilePath = inputFile.getAbsolutePath().substring(0,inputFile.getAbsolutePath().lastIndexOf(File.separator)+1);
				encFileFilePath = encFileFilePath + encFile + BaiMergerConstants.FileFormatTypConstants.ENCRYPTED_FILE_EXTENSION;
				File encFilePath = new File(encFileFilePath);
				if(encFilePath.exists()){
					logger.info("Encrypted file found - "+encFileFilePath);
					BaiMergerUtility.moveFile(encFilePath, encFileMovingLocation, isArchive, false);
				}else{
					logger.info("Encrypted file not found");
				}
			}
		}
	}
}
