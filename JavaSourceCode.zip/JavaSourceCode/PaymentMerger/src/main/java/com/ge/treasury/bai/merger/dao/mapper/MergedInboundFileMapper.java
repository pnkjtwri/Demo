package com.ge.treasury.bai.merger.dao.mapper;

import java.sql.Timestamp;

public class MergedInboundFileMapper {
	public Integer mergedFileId;
	public String mergeedFileName;
	public String mergedFileType;
	public Integer fileStatusId;
	public String mergeStatus;
	public String mergedFileLocation;
	public String originatorIdentification;
	public String senderIdentification;
	public String totalAmount;
	public String totalRecords;
	public String hashString;
	public String createdBy;
	public Timestamp createdTimeStamp;
	public String lastModifiedBy;
	public Timestamp lastModifiedTimeStamp;
	
	/**
	 * @return the mergedFileId
	 */
	public Integer getMergedFileId() {
		return mergedFileId;
	}
	/**
	 * @param mergedFileId the mergedFileId to set
	 */
	public void setMergedFileId(Integer mergedFileId) {
		this.mergedFileId = mergedFileId;
	}
	/**
	 * @return the mergeedFileName
	 */
	public String getMergeedFileName() {
		return mergeedFileName;
	}
	/**
	 * @param mergeedFileName the mergeedFileName to set
	 */
	public void setMergeedFileName(String mergeedFileName) {
		this.mergeedFileName = mergeedFileName;
	}
	/**
	 * @return the mergedFileType
	 */
	public String getMergedFileType() {
		return mergedFileType;
	}
	/**
	 * @param mergedFileType the mergedFileType to set
	 */
	public void setMergedFileType(String mergedFileType) {
		this.mergedFileType = mergedFileType;
	}
	/**
	 * @return the fileStatusId
	 */
	public Integer getFileStatusId() {
		return fileStatusId;
	}
	/**
	 * @param fileStatusId the fileStatusId to set
	 */
	public void setFileStatusId(Integer fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	/**
	 * @return the mergeStatus
	 */
	public String getMergeStatus() {
		return mergeStatus;
	}
	/**
	 * @param mergeStatus the mergeStatus to set
	 */
	public void setMergeStatus(String mergeStatus) {
		this.mergeStatus = mergeStatus;
	}
	/**
	 * @return the mergedFileLocation
	 */
	public String getMergedFileLocation() {
		return mergedFileLocation;
	}
	/**
	 * @param mergedFileLocation the mergedFileLocation to set
	 */
	public void setMergedFileLocation(String mergedFileLocation) {
		this.mergedFileLocation = mergedFileLocation;
	}
	/**
	 * @return the originatorIdentification
	 */
	public String getOriginatorIdentification() {
		return originatorIdentification;
	}
	/**
	 * @param originatorIdentification the originatorIdentification to set
	 */
	public void setOriginatorIdentification(String originatorIdentification) {
		this.originatorIdentification = originatorIdentification;
	}
	/**
	 * @return the senderIdentification
	 */
	public String getSenderIdentification() {
		return senderIdentification;
	}
	/**
	 * @param senderIdentification the senderIdentification to set
	 */
	public void setSenderIdentification(String senderIdentification) {
		this.senderIdentification = senderIdentification;
	}
	/**
	 * @return the totalAmount
	 */
	public String getTotalAmount() {
		return totalAmount;
	}
	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	/**
	 * @return the totalRecords
	 */
	public String getTotalRecords() {
		return totalRecords;
	}
	/**
	 * @param totalRecords the totalRecords to set
	 */
	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	/**
	 * @return the hashString
	 */
	public String getHashString() {
		return hashString;
	}
	/**
	 * @param hashString the hashString to set
	 */
	public void setHashString(String hashString) {
		this.hashString = hashString;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdTimeStamp
	 */
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	/**
	 * @param createdTimeStamp the createdTimeStamp to set
	 */
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @return the lastModifiedTimeStamp
	 */
	public Timestamp getLastModifiedTimeStamp() {
		return lastModifiedTimeStamp;
	}
	/**
	 * @param lastModifiedTimeStamp the lastModifiedTimeStamp to set
	 */
	public void setLastModifiedTimeStamp(Timestamp lastModifiedTimeStamp) {
		this.lastModifiedTimeStamp = lastModifiedTimeStamp;
	}
}
