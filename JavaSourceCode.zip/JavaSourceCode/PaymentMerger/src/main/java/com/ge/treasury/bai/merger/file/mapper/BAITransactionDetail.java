package com.ge.treasury.bai.merger.file.mapper;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;

public class BAITransactionDetail {
	//private String recordCode = "16"; 
	private String recordCode = BaiMergerConstants.FileFormatConstants.TRANSACTION_DETAIL_TAG;
	private String typeCode;
	private String amount;
	private String fundsType;
	private String bankReferenceNumber;
	private String customerReferenceNumber;
	private String text;
	private CSVRecord record;
	
	public String getRecordCode() {
		return recordCode;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getFundsType() {
		return fundsType;
	}
	public void setFundsType(String fundsType) {
		this.fundsType = fundsType;
	}
	public String getBankReferenceNumber() {
		return bankReferenceNumber;
	}
	public void setBankReferenceNumber(String bankReferenceNumber) {
		this.bankReferenceNumber = bankReferenceNumber;
	}
	public String getCustomerReferenceNumber() {
		return customerReferenceNumber;
	}
	public void setCustomerReferenceNumber(String customerReferenceNumber) {
		this.customerReferenceNumber = customerReferenceNumber;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setTypeCode(record.get(1));
			setAmount(record.get(2));
			setFundsType(record.get(3));
			setBankReferenceNumber(record.get(4));
			setCustomerReferenceNumber(record.get(5));
			setText(record.get(6));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
