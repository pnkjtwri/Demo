package com.ge.treasury.bai.merger.crystalreport.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.dao.mapper.JobConfigMapper;
import com.ge.treasury.bai.merger.exception.BaiMergeProcessException;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.load.config.FileStausLoaderService;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.process.BaiFileMergingService;
import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component("BaiCrystalReportMerge")
public class BaiCrystalReportMergeImpl implements BaiFileMergingService{
	private static Logger logger = Logger.getLogger(BaiCrystalReportMergeImpl.class);
	
	@Autowired BaiMergerProcessPersistanceService persistanceService;
	@Autowired FileStausLoaderService fileStatus;
	@Autowired private ApplicationContext appContext;

	@Value("${crOutPutFileLocation}")
	private String outPutFileLocation;
	
	/*@Value("${sourceFileProcessingLocation}")
	private String processingLocation;
	
	@Value("${tmpOutPutFileLocation}")
	private String tmpOutPutFileLocation;
	
	@Value("${pathForOutboundChannel}")
	private String pathForOutboundChannel;*/

	@Override
	public String startMerging(List<String> listOfFilesRecieved, List<Integer> srcInboundFileIdList, String nasFileNamePattern)	throws BaiMergeProcessException, DataBaseProcessException {
		
		logger.info("Crystal Report Merge implementation start");
		//getting details from database
		List<JobConfigMapper>  configBeanList = persistanceService.getFileDetails(nasFileNamePattern);
		
		if(configBeanList == null || configBeanList.size() <= 0 ){
			//error condition cannot continue
			throw new BaiMergeProcessException("No config details found in the job config table fro the file pattern - "+nasFileNamePattern,null);
		}
		
		logger.info(" updating status for merging process in progress");
		persistanceService.updateSrcInboundFileStatus(srcInboundFileIdList,fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_MERGE_FILE_IN_PROGRESS));
		logger.info(" src inbound status updated");

		
		//going to get target file name by their type...
		//String erpTargetOutputFileName = configBeanList.get(0).getErpTargetFileName();
		String erpTargetOutputFileName = null;
		String tsaName = configBeanList.get(0).getTsaName();
		for (String srcFileName : listOfFilesRecieved) {
			if(srcFileName.toUpperCase().contains("_"+tsaName.toUpperCase()+"_")){
				int idx = srcFileName.lastIndexOf("\\");
				if(idx < 0)
					idx = srcFileName.lastIndexOf("/");
				erpTargetOutputFileName = srcFileName.substring(idx+1, srcFileName.toLowerCase().indexOf(BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV.toLowerCase()));
				break;
			}
		}
		if(erpTargetOutputFileName == null){
			erpTargetOutputFileName = configBeanList.get(0).getErpTargetFileName();
		}
		//code end here for getting target file name
		
		logger.info(" Erp target file name - "+erpTargetOutputFileName);
		
		logger.info(" File merging start");
		Map<String,Object> mergeFileDetails = mergeListFile(listOfFilesRecieved,configBeanList,erpTargetOutputFileName);
		logger.info(" File merging done");
		
		String originatorIdentification = BaiMergerConstants.FileFormatTypConstants.SENDER_IDENTIFICATION;
		
		logger.info(" Going to persist merge file details");
		Integer totalRecordsAferMerge = Integer.parseInt(mergeFileDetails.get("lineMerge")+"");
		int mergeFileId = persistanceService.saveMergedFileDetails(outPutFileLocation, erpTargetOutputFileName, 0, totalRecordsAferMerge, originatorIdentification);
		
		File fileSendToBusiness = new File(outPutFileLocation+erpTargetOutputFileName+BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV);
		//Call outbound method to transafer file
		sendFileToBusiness(fileSendToBusiness,configBeanList);
		
		logger.info(" Going to update merge id in th src inbound file");
		persistanceService.updateSrcInboundFile(srcInboundFileIdList,mergeFileId,fileStatus.getFileStatus(BaiMergerConstants.FileStatusConstants.BAI_MERGE_FILE_COMPLETE));
		logger.info(" update merge id in th src inbound file done");
		logger.info("Crystal Report Merge implementation ends");
		return mergeFileDetails.get("mergeFilePath").toString();
	}
	
	/***
	 * Merge all the received files
	 * @param listOfRecivedFiles
	 * @throws BaiMergeProcessException 
	 */
	private Map<String,Object> mergeListFile(List<String> listOfRecivedFiles, List<JobConfigMapper>  configBeanList, String erpTargetOutputFileName) throws BaiMergeProcessException{
			logger.info("starting crystal report file merging process");
			Map<String,Object> fileDetailsAfterMerge = null;
			Iterator<String> iterFiles;
			File fileOutput;
			int lineWritten=0;
			// initialize buffer and start reading data
	        BufferedWriter  out = null;
			BufferedReader in = null;
			//outPutFileLocation = outPutFileLocation + erpTargetOutputFileName;
			// Files: Output
			fileOutput = new File(outPutFileLocation+erpTargetOutputFileName+BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV);
			if (fileOutput.exists()) {
				fileOutput.delete();
			}
			try {
				fileOutput.createNewFile();
				iterFiles = listOfRecivedFiles.iterator();
				//out = new BufferedWriter(new FileWriter(fileOutput,true));
				out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileOutput,true), "UTF-8"));
				
				
				while (iterFiles.hasNext()) {
				  File filebeingIterated = new File(iterFiles.next());
				  logger.info("-- Starting Writing : '" + filebeingIterated.getName() + "' to merged file "+ fileOutput.getName());
				  //in = new BufferedReader(new FileReader(filebeingIterated));
				  in = new BufferedReader(new InputStreamReader(new FileInputStream(filebeingIterated), "UTF-8"));
				  
		          String txt = null;
		          while ((txt=in.readLine())!=null) {
		              out.write(txt);
		              out.newLine();
		              out.flush();
		              lineWritten++;
		          } 
		          in.close();
		          logger.info("-- Finished Writing: '" + filebeingIterated.getName() + "'");
				}
			    logger.info("Completed crystal report file merging process");
			    logger.info("total lines written in crystal report merged file: '" + lineWritten + "'");
				} catch (FileNotFoundException err ) {
					logger.info("Error while merging crystal report files");
					logger.info(BaiMergerUtility.getErrorFormStackTrace(err));
					throw new BaiMergeProcessException("Crystal Report file merge process can not continue. We have received error while merging process",err);
		        } 
		        catch (IOException err ) {
		        	logger.info("Error while merging crystal report files");
					logger.info(BaiMergerUtility.getErrorFormStackTrace(err));
					throw new BaiMergeProcessException("Crystal Report file merge process can not continue. We have received error while merging process",err);
		        }
		        finally{
		            try {
		                if(out!=null) {
		                    out.close();
		                } 
		                if(in!=null) {
		                    in.close();
		                } 
		            }
		            catch (IOException ignored ) {
		            	logger.info("Error while closing open streams");
						logger.info(BaiMergerUtility.getErrorFormStackTrace(ignored));
		            }
		        } 
			
			if(lineWritten > 0 ){
				logger.info("Merge of file done. Merge file name - "+(outPutFileLocation+erpTargetOutputFileName+BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV));
				fileDetailsAfterMerge = new HashMap<String, Object>(); 
				fileDetailsAfterMerge.put("mergeFilePath", (outPutFileLocation+erpTargetOutputFileName+BaiMergerConstants.FileFormatTypConstants.FILE_EXTENSION_CSV));
				logger.info("Merge file path - "+outPutFileLocation);
				fileDetailsAfterMerge.put("lineMerge", lineWritten);
				logger.info("No Of line merged - "+lineWritten);
			}
		
			return fileDetailsAfterMerge;
	}
	
	/***
	 * Send merge file to business 
	 * @param inputFile
	 * @return
	 */
	private boolean sendFileToBusiness(File inputFile, List<JobConfigMapper>  configBeanList) throws BaiMergeProcessException{
		boolean isSent = false;
		String sendFileLocation = "";
		logger.info("Going to transfer crystal report merged file...."+inputFile.getName());
		try{
			sendFileLocation = configBeanList.get(0).getErpTargetFileLocation();
			
			AtomicReference<String> targetDir = (AtomicReference<String>)appContext.getBean(BaiMergerConstants.FileBelongsTo.FILE_TARGET_DIR, AtomicReference.class);
			/*if(pathForOutboundChannel != null && pathForOutboundChannel.length() > 1){
				logger.info(" Merge file sending location - "+pathForOutboundChannel);
				targetDir.set(pathForOutboundChannel);
			}else*/{
				logger.info("crystal report Merge file sending location - "+sendFileLocation);
				targetDir.set(sendFileLocation);
			}
			
			Message<File> message = MessageBuilder.withPayload(inputFile).build();
			final MessageChannel baiMergeFileOutboundChannel = appContext.getBean (BaiMergerConstants.FileBelongsTo.FILE_OUTBOUND_CHANNEL, MessageChannel.class);
			isSent = baiMergeFileOutboundChannel.send(message,1000);
		} catch (Exception e) {
			logger.info(" Got Exception while sending crystal report file");
			logger.info(" "+BaiMergerUtility.getErrorFormStackTrace(e));
			isSent = false;
			throw new BaiMergeProcessException("crystal report Merge file sending failed to locations - "+sendFileLocation,e);
		}
		logger.info(" crystal report merge file sent status - "+isSent);
		return isSent;  
	}

}
