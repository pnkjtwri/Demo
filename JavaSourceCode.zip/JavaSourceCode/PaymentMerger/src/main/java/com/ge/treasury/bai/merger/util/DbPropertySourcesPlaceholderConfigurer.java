package com.ge.treasury.bai.merger.util;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;


public class DbPropertySourcesPlaceholderConfigurer extends PropertySourcesPlaceholderConfigurer{
	@Override 
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException 
	    { 
		 	PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
		 	YamlPropertiesFactoryBean yaml= new YamlPropertiesFactoryBean();
		 	yaml.setResources(new FileSystemResource("/app/tsaweb/properties/paymentmerger/application.yml"));
		 	propertySourcesPlaceholderConfigurer.setProperties(yaml.getObject()); 
	        DbProperties dbProps = new DbProperties(); 
	        setProperties(dbProps); 
	        super.postProcessBeanFactory(beanFactory);
	    } 

}
