package com.ge.treasury.bai.merger.dao;

import java.util.Map;

import com.ge.treasury.bai.merger.dao.mapper.SrcInboundFileMapper;

public interface SrcInboundFileDao {
	public void saveSrcInboundFileDetails(SrcInboundFileMapper detailsToPersist);
	public void updSrcInboundFile(Map<String,Object> param);
	public void updSrcInboundFileStatus(Map<String,Object> param);
}
