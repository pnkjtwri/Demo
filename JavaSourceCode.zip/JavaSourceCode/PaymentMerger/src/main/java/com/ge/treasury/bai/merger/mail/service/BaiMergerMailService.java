package com.ge.treasury.bai.merger.mail.service;

import java.util.List;

import javax.mail.MessagingException;

public interface BaiMergerMailService {
	public void sendErrorMail(Exception ex,String mailSubject, List<String> listOfFileNotReceived, String msg) throws MessagingException;
}
