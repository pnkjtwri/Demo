package com.ge.treasury.bai.merger.file.mapper;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;

public class BAIFileHeader {
	//private String recordCode = "01"; 
	private String recordCode = BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG;
	private String senderIdentification;
	private String receiverIdentification;
	private String fileCreationDate;
	private String fileCreationTime;
	private String fileIdentificaitonNumber;
	private String physicalRecordLength;
	private String blockSize;
	private String versionNumber;
	private CSVRecord record;
	private String[] recordArray;
	
	public String getRecordCode() {
		return recordCode;
	}
	public String getSenderIdentification() {
		return senderIdentification;
	}
	public void setSenderIdentification(String senderIdentification) {
		this.senderIdentification = senderIdentification;
	}
	public String getReceiverIdentification() {
		return receiverIdentification;
	}
	public void setReceiverIdentification(String receiverIdentification) {
		this.receiverIdentification = receiverIdentification;
	}
	public String getFileCreationDate() {
		return fileCreationDate;
	}	
	public String getFileCreationTime() {
		return fileCreationTime;
	}
	public void setFileCreationTime(String fileCreationTime) {
		this.fileCreationTime = fileCreationTime;
	}
	public void setFileCreationDate(String fileCreationDate) {
		this.fileCreationDate = fileCreationDate;
	}
	public String getFileIdentificaitonNumber() {
		return fileIdentificaitonNumber;
	}
	public void setFileIdentificaitonNumber(String fileIdentificaitonNumber) {
		this.fileIdentificaitonNumber = fileIdentificaitonNumber;
	}
	public String getPhysicalRecordLength() {
		return physicalRecordLength;
	}
	public void setPhysicalRecordLength(String physicalRecordLength) {
		this.physicalRecordLength = physicalRecordLength;
	}
	public String getBlockSize() {
		return blockSize;
	}
	public void setBlockSize(String blockSize) {
		this.blockSize = blockSize;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}	
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}	
	public String[] getRecordArray() {
		return recordArray;
	}
	public void setRecordArray(String[] recordArray) {
		this.recordArray = recordArray;
	}
	
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setSenderIdentification(record.get(1));
			setReceiverIdentification(record.get(2));
			setFileCreationDate(record.get(3));
			setFileCreationTime(record.get(4));
			setFileIdentificaitonNumber(record.get(5));
			setPhysicalRecordLength(record.get(6));
			setBlockSize(record.get(7));
			setVersionNumber(record.get(8));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String populate(String[] recordArray){
		String status = "success";
		try {		
			setRecordArray(recordArray);
			setSenderIdentification(recordArray[1]);
			setReceiverIdentification(recordArray[2]);
			setFileCreationDate(recordArray[3]);
			setFileCreationTime(recordArray[4]);
			setFileIdentificaitonNumber(recordArray[5]);
			setPhysicalRecordLength(recordArray[6]);
			setBlockSize(recordArray[7]);
			setVersionNumber(recordArray[8]);
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	/*public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}*/
	public String toString(){
		String returnString = "";
		for(String text: recordArray){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}
}
