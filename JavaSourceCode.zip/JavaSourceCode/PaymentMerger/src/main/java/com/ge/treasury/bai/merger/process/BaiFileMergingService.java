package com.ge.treasury.bai.merger.process;

import java.util.List;

import com.ge.treasury.bai.merger.exception.BaiMergeProcessException;
import com.ge.treasury.bai.merger.exception.DataBaseProcessException;

public interface BaiFileMergingService {
	public String startMerging(List<String> listOfFilesRecieved, List<Integer>srcInboundFileIdList, String nasFileNamePattern)  throws BaiMergeProcessException, DataBaseProcessException;
}
