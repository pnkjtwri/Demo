package com.ge.treasury.bai.merger.crystalreport.listener;

import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.ge.treasury.bai.merger.exception.DataBaseProcessException;
import com.ge.treasury.bai.merger.persitance.BaiMergerProcessPersistanceService;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@MessageEndpoint
public class BaiCrystalReportMergeGeCopyFileListener {
	private static Logger logger = Logger.getLogger(BaiCrystalReportMergeGeCopyFileListener.class);
	
	@Autowired BaiMergerProcessPersistanceService lockService;
	
	@Value("%{ACBS_CR_CR_location}")
	private String destinationLocation;
	
	@Value("${acbsGECrystalReportfilesuffix}")
	private String acbsGEBAIfilesuffix;
	
	@ServiceActivator
	public void copyCrystalReportFile(File inputFile){
		if(inputFile != null && inputFile.exists() && inputFile.length() > 0){
			logger.info("Crystal Report file received to copy - "+inputFile.getName());
			boolean isLockAcquired = false;
			ArrayList<String> fileListToGetLock = null;
			try {
				logger.info("Going to get lock on Crystal Report file - "+inputFile.getName());
				fileListToGetLock = new ArrayList<String>();
				fileListToGetLock.add(inputFile.getAbsolutePath());
				lockService.getLockOnFile(fileListToGetLock);
				isLockAcquired = true;
			} catch (DataBaseProcessException e1) {
				logger.info("Error while getting lock on Crystal Report file "+inputFile.getName());
				isLockAcquired = false;
			}
			
			if(isLockAcquired){
				logger.info("lock acquired on Crystal Report file - "+inputFile.getName());
				try{
					BaiMergerUtility.copyFile(inputFile, destinationLocation,acbsGEBAIfilesuffix,true);
				}catch(Exception e){
					logger.info("Error while copying Crystal report GE file - "+inputFile.getName());
					logger.info(""+BaiMergerUtility.getErrorFormStackTrace(e));
				}
				logger.info(inputFile.getName()+" crystal report file copied to - "+destinationLocation);
				
				if(fileListToGetLock != null && fileListToGetLock.size() > 0){
					logger.info("Going to release lock on crystal report files");
					lockService.releaseLockOnFile(fileListToGetLock);
					logger.info("Lock Released on crystal report file");
				}
			}
		}
		
	}
}
