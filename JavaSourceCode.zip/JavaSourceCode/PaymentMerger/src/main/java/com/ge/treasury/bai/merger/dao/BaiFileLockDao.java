package com.ge.treasury.bai.merger.dao;

import java.util.Map;

public interface BaiFileLockDao {
	public void getLockOnFileList(Map<String,Object> param);
	public void releaseLock(Map<String,Object> param);
}
