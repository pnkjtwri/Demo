package com.ge.treasury.bai.merger.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

public class DbProperties extends Properties {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(DbProperties.class);

	public DbProperties()
	{
		super();
		ResultSet rs = null;
		ResultSet rsge = null;
		Connection conn = null;
		Statement sta = null;
		try{
		TreeMap<String, String> map = getProperties("/app/tsaweb/properties/paymentmerger/jdbc.properties");
		// load a properties file
    	Class.forName(map.get("driverclassname"));	
		conn = DriverManager.getConnection(map.get("connectionurl"));
		sta = conn.createStatement();
		String Sql = map.get("loadquery");
		rs = sta.executeQuery(Sql);
		while (rs.next()) {
			setProperty(rs.getString("CHANNELKEY")+"_schedule", rs.getString("SCHEDULE"));
			setProperty(rs.getString("CHANNELKEY")+"_schedule_recovery_1", rs.getString("SCHEDULE_RECOVERY_1"));
			setProperty(rs.getString("CHANNELKEY")+"_schedule_recovery_2", rs.getString("SCHEDULE_RECOVERY_2"));
			setProperty(rs.getString("CHANNELKEY")+"_location", rs.getString("NAS_FILE_LOCATION"));
			setProperty(rs.getString("CHANNELKEY")+"_pattern", rs.getString("NAS_FILENAME_PATTERN"));
		}
		
		String geSql = map.get("loadgequery");
		rsge = sta.executeQuery(geSql);
		while (rsge.next()) {
			setProperty(rsge.getString("CHANNELKEY")+"_schedule", rsge.getString("GE_SCHEDULE"));
			setProperty(rsge.getString("CHANNELKEY")+"_location", rsge.getString("SOURCE_FILE_LOCATION"));
		}
		}
		catch(Exception e){
			logger.error("Not able to load Inbound channels properties");
			throw new RuntimeException("Not able to load Inbound channels properties.");
		}
		finally{
			try{
			 rs.close();
			 rsge.close();
		     sta.close();
		     conn.close();
			}
			catch(Exception e){
				logger.error("Not able to close connection");
				throw new RuntimeException("Not able to close connection.");
			}
			
		}
	}
	public static TreeMap<String, String> getProperties(String infile) throws IOException {
        final int lhs = 0;
        final int rhs = 1;

        TreeMap<String, String> map = new TreeMap<String, String>();
        BufferedReader  bfr = new BufferedReader(new FileReader(new File(infile)));

        String line;
        while ((line = bfr.readLine()) != null) {
            if (!line.startsWith("#") && !line.isEmpty()) {
                String[] pair = line.trim().split("=",2);
                map.put(pair[lhs].trim(), pair[rhs].trim());
            }
        }

        bfr.close();

        return(map);
    }

}
