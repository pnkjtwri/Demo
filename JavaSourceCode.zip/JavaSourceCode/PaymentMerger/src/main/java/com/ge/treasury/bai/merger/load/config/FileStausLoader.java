package com.ge.treasury.bai.merger.load.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.dao.FileProcessingStatusDao;
import com.ge.treasury.bai.merger.dao.mapper.FileStatusMapper;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component
public class FileStausLoader implements FileStausLoaderService {
	final static Logger logger = Logger.getLogger(FileStausLoader.class);
	private Map<String,Integer> fileStatus = null;
	@Autowired FileProcessingStatusDao fileStausDao;
	
	@PostConstruct
	private void loadFileStatus(){
		if(fileStatus == null){
			try{
				logger.info("[FileStatusLoader] - Loading file status...");
			
				fileStatus = new HashMap<String, Integer>();
				List<FileStatusMapper> fileStatusList = fileStausDao.getFileStatus();
				if(fileStatusList != null && fileStatusList.size() > 0){
					for(FileStatusMapper item :  fileStatusList) {
						fileStatus.put(item.getFileStatusShortDesc(), Integer.parseInt(item.getFileStatusId()));
					}
				}
				if(fileStatus== null || fileStatus.size() <= 0){
					logger.error("Not able to load file status. File status not found in data base.");
					throw new RuntimeException("Not able to load File status.");
				}
				logger.info("[FileStatusLoader] - File status loaded!!");
			}catch(Exception e){
				logger.error("Not able to load file status.");
				logger.error(BaiMergerUtility.getErrorFormStackTrace(e));
				throw new RuntimeException("Not able to load File status.");
			}
		}
	}

	@Override
	public int getFileStatus(String fileStatusKey) {
		return fileStatus.get(fileStatusKey);
	}
	
}
