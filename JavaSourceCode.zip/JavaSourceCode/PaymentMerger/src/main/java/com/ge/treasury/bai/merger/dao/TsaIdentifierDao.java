package com.ge.treasury.bai.merger.dao;

import java.util.List;

import com.ge.treasury.bai.merger.dao.mapper.TsaIdentifierMapper;

public interface TsaIdentifierDao {
	public List<TsaIdentifierMapper> getAllTsaIdentifier();
}
