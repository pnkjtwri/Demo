package com.ge.treasury.bai.merger.dao.mapper;

public class TsaIdentifierMapper {
	public Integer tsaInstanceId;
	public String tsaIdentifier;
	
	
	/**
	 * @return the tsaInstanceId
	 */
	public Integer getTsaInstanceId() {
		return tsaInstanceId;
	}
	/**
	 * @param tsaInstanceId the tsaInstanceId to set
	 */
	public void setTsaInstanceId(Integer tsaInstanceId) {
		this.tsaInstanceId = tsaInstanceId;
	}
	/**
	 * @return the tsaIdentifier
	 */
	public String getTsaIdentifier() {
		return tsaIdentifier;
	}
	/**
	 * @param tsaIdentifier the tsaIdentifier to set
	 */
	public void setTsaIdentifier(String tsaIdentifier) {
		this.tsaIdentifier = tsaIdentifier;
	}
	
}
