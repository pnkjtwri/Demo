package com.ge.treasury.bai.merger.file.mapper;
import org.apache.commons.csv.CSVRecord;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;

public class BAIGroupTrailer {
	//private String recordCode = "98";
	private String recordCode = BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG;
	private String groupControlTotal;
	private String numberOfAccounts;
	private String numberOfRecords;
	private CSVRecord record;
	private String[] recordArray;
	public String getRecordCode() {
		return recordCode;
	}
	public String getGroupControlTotal() {
		return groupControlTotal;
	}
	public void setGroupControlTotal(String groupControlTotal) {
		this.groupControlTotal = groupControlTotal;
	}
	public String getNumberOfAccounts() {
		return numberOfAccounts;
	}
	public void setNumberOfAccounts(String numberOfAccounts) {
		this.numberOfAccounts = numberOfAccounts;
	}
	public String getNumberOfRecords() {
		return numberOfRecords.substring(0,numberOfRecords.indexOf("/"));
	}
	public void setNumberOfRecords(String numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}
	public CSVRecord getRecord() {
		return record;
	}
	public void setRecord(CSVRecord record) {
		this.record = record;
	}
	
	public String[] getRecordArray() {
		return recordArray;
	}
	public void setRecordArray(String[] recordArray) {
		this.recordArray = recordArray;
	}
	public String populate(CSVRecord record){
		String status = "success";
		try {		
			setRecord(record);
			setGroupControlTotal(record.get(1));
			setNumberOfAccounts(record.get(2));
			setNumberOfRecords(record.get(3));
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	public String populate(String[] recordArray){
		String status = "success";
		try {		
			setRecordArray(recordArray);
			setGroupControlTotal(recordArray[1]);
			setNumberOfAccounts(recordArray[2]);
			setNumberOfRecords(recordArray[3]);
		} catch (Exception e) {
			status = e.getMessage();
			e.printStackTrace();
		}
		return status;
	}
	/*public String toString(){
		String returnString = "";
		for(String text: record){
			returnString += text + ",";
		}
		return returnString.substring(0,returnString.length()-1);
	}*/
public String toString(){
	String returnString = "";
	for(String text: recordArray){
		returnString += text + ",";
	}
	return returnString.substring(0,returnString.length()-1);
}
}
