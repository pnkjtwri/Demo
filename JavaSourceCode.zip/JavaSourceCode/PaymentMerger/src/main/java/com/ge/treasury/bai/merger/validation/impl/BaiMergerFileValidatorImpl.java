package com.ge.treasury.bai.merger.validation.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Stack;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.util.BaiMergerConstants;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;
import com.ge.treasury.bai.merger.validation.BaiMergerFileValidator;

@Component
public class BaiMergerFileValidatorImpl implements BaiMergerFileValidator{
	private static Logger logger = Logger.getLogger(BaiMergerFileValidatorImpl.class);

	@Override
	public boolean validateFile(File fileToValidate) {
		BufferedReader br       =  null;
		boolean isValidBaiFile  = false;
		
		boolean isFileHeaderFound 		= false;
		boolean isFileTrailerFound 		= false;
		boolean isGroupHeaderFound 		= false;
		boolean isAccountHeaderFound 	= false;
		boolean isAccountHeaderExists 	= false;
		boolean isGroupHeaderExists 	= false;
		
		Stack<String> groupFounds 	= new Stack<String>();
		Stack<String> accountFounds = new Stack<String>();
		
		try{
			String line = "";
			br 	= new BufferedReader(new FileReader(fileToValidate));
			
			while ((line = br.readLine()) != null) {
				String[] recordArray = line.split(",");
			    String firstValue = recordArray[0];
			    
			    if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_HEADER_TAG)){
			    	isFileHeaderFound = true;
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG)){
			    	isGroupHeaderExists = true;
			    	groupFounds.push(BaiMergerConstants.FileFormatConstants.GROUP_HEADER_TAG);
			    	if(recordArray[2] == null || recordArray[2].length() <= 0){
			    		break;
			    	} 
			        if(recordArray[4] == null || recordArray[4].length() <= 0 ){
			        	break;
			        }
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG)){
			    	isAccountHeaderExists = true;
			    	accountFounds.push(BaiMergerConstants.FileFormatConstants.ACCOUNT_HEADER_TAG);
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.FILE_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[3])){
			    		break;
			    	}
			    	isFileTrailerFound = true;
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.GROUP_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[3])){
			    		break;
			    	}
			    	groupFounds.pop();
			    }else if(firstValue.equalsIgnoreCase(BaiMergerConstants.FileFormatConstants.ACCOUNT_TRAILER_TAG)){
			    	if(!validateValues(recordArray[1])){
			    		break;
			    	}
			    	if(!validateValues(recordArray[2])){
			    		break;
			    	}
			    	accountFounds.pop();
			    	
			    }
			}
			
			logger.info("[BaiMergerFileValidatorImpl] - Size of account - "+accountFounds.size());
			if(accountFounds.size() == 0 && isAccountHeaderExists){
				isAccountHeaderFound = true;
			}
			logger.info("[BaiMergerFileValidatorImpl] - Size of groups - "+groupFounds.size());
			if(groupFounds.size() == 0 && isGroupHeaderExists){
				isGroupHeaderFound = true;
			}

			logger.info("[BaiMergerFileValidatorImpl] - isFileHeaderFound -> "+isFileHeaderFound+
					" isFileTrailerFound -> "+isFileTrailerFound+" isGroupHeaderFound -> "+isGroupHeaderFound+" isAccountHeaderFound -> "+isAccountHeaderFound);
			
			if(isFileHeaderFound && isFileTrailerFound && isGroupHeaderFound && isAccountHeaderFound){
				isValidBaiFile = true;
			}
		}catch(Exception e){
			logger.info("[BaiMergerFileValidatorImpl] - Error in file validation - "+fileToValidate.getName());
			logger.info("[BaiMergerFileValidatorImpl] - "+BaiMergerUtility.getErrorFormStackTrace(e));
			isValidBaiFile = false;
		}finally{
			if(br != null){
				try{
					br.close();
				}catch(Exception e){
					logger.info("[BaiFileMergingServiceImpl] - Error in closing reader");	
				}
			}
		}
		return isValidBaiFile;
	}
	
	
	private boolean validateValues(String value){
		boolean isValid = false;
		if(value.indexOf("/") > 0){
			value = value.substring(0,value.indexOf("/"));
		}
		
		if(value != null && value.length() > 0){
			try{
				Long.parseLong(value);
				isValid = true;
			}catch(Exception e){
				isValid = false;
			}
		}
		return isValid;
	}

}
