package com.ge.treasury.bai.merger.dao.mapper;

import java.sql.Timestamp;

public class SrcInboundFileMapper {
	public Integer srcFileId; 
	public String srcFileName;
	public String srcFileType;
	public String tsaInstanceIdentifier;
	public String erpName;
	public String amount;
	public String noOfTransactions;
	public String hashString;
	public String mergedFlag;
	public Integer fileStatusId;
	public Timestamp srcFileCreationTimestamp;
	public String createdBy;
	public Timestamp createdTimestamp;
	public String lastmodifiedBy;
	public Timestamp lastModifiedTimestamp;
	public String inboundPoolingAuditId;
	public String mergedFileId;
	
	/**
	 * @return the srcFileId
	 */
	public Integer getSrcFileId() {
		return srcFileId;
	}
	/**
	 * @param srcFileId the srcFileId to set
	 */
	public void setSrcFileId(Integer srcFileId) {
		this.srcFileId = srcFileId;
	}
	/**
	 * @return the srcFileName
	 */
	public String getSrcFileName() {
		return srcFileName;
	}
	/**
	 * @param srcFileName the srcFileName to set
	 */
	public void setSrcFileName(String srcFileName) {
		this.srcFileName = srcFileName;
	}
	/**
	 * @return the srcFileType
	 */
	public String getSrcFileType() {
		return srcFileType;
	}
	/**
	 * @param srcFileType the srcFileType to set
	 */
	public void setSrcFileType(String srcFileType) {
		this.srcFileType = srcFileType;
	}
	/**
	 * @return the tsaInstanceIdentifier
	 */
	public String getTsaInstanceIdentifier() {
		return tsaInstanceIdentifier;
	}
	/**
	 * @param tsaInstanceIdentifier the tsaInstanceIdentifier to set
	 */
	public void setTsaInstanceIdentifier(String tsaInstanceIdentifier) {
		this.tsaInstanceIdentifier = tsaInstanceIdentifier;
	}
	/**
	 * @return the erpName
	 */
	public String getErpName() {
		return erpName;
	}
	/**
	 * @param erpName the erpName to set
	 */
	public void setErpName(String erpName) {
		this.erpName = erpName;
	}
	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}
	/**
	 * @return the noOfTransactions
	 */
	public String getNoOfTransactions() {
		return noOfTransactions;
	}
	/**
	 * @param noOfTransactions the noOfTransactions to set
	 */
	public void setNoOfTransactions(String noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}
	/**
	 * @return the hashString
	 */
	public String getHashString() {
		return hashString;
	}
	/**
	 * @param hashString the hashString to set
	 */
	public void setHashString(String hashString) {
		this.hashString = hashString;
	}
	/**
	 * @return the mergedFlag
	 */
	public String getMergedFlag() {
		return mergedFlag;
	}
	/**
	 * @param mergedFlag the mergedFlag to set
	 */
	public void setMergedFlag(String mergedFlag) {
		this.mergedFlag = mergedFlag;
	}
	/**
	 * @return the fileStatusId
	 */
	public Integer getFileStatusId() {
		return fileStatusId;
	}
	/**
	 * @param fileStatusId the fileStatusId to set
	 */
	public void setFileStatusId(Integer fileStatusId) {
		this.fileStatusId = fileStatusId;
	}
	/**
	 * @return the srcFileCreationTimestamp
	 */
	public Timestamp getSrcFileCreationTimestamp() {
		return srcFileCreationTimestamp;
	}
	/**
	 * @param srcFileCreationTimestamp the srcFileCreationTimestamp to set
	 */
	public void setSrcFileCreationTimestamp(Timestamp srcFileCreationTimestamp) {
		this.srcFileCreationTimestamp = srcFileCreationTimestamp;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdTimestamp
	 */
	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}
	/**
	 * @param createdTimestamp the createdTimestamp to set
	 */
	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	/**
	 * @return the lastmodifiedBy
	 */
	public String getLastmodifiedBy() {
		return lastmodifiedBy;
	}
	/**
	 * @param lastmodifiedBy the lastmodifiedBy to set
	 */
	public void setLastmodifiedBy(String lastmodifiedBy) {
		this.lastmodifiedBy = lastmodifiedBy;
	}
	/**
	 * @return the lastModifiedTimestamp
	 */
	public Timestamp getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}
	/**
	 * @param lastModifiedTimestamp the lastModifiedTimestamp to set
	 */
	public void setLastModifiedTimestamp(Timestamp lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}
	/**
	 * @return the inboundPoolingAuditId
	 */
	public String getInboundPoolingAuditId() {
		return inboundPoolingAuditId;
	}
	/**
	 * @param inboundPoolingAuditId the inboundPoolingAuditId to set
	 */
	public void setInboundPoolingAuditId(String inboundPoolingAuditId) {
		this.inboundPoolingAuditId = inboundPoolingAuditId;
	}
	/**
	 * @return the mergedFileId
	 */
	public String getMergedFileId() {
		return mergedFileId;
	}
	/**
	 * @param mergedFileId the mergedFileId to set
	 */
	public void setMergedFileId(String mergedFileId) {
		this.mergedFileId = mergedFileId;
	}
}
