package com.ge.treasury.bai.merger;


/*@SpringBootApplication
@IntegrationComponentScan  */
public class PaymentMergerBootController {/*

        public static void main(String[] args) {
            new SpringApplicationBuilder(PaymentMergerBootController.class).web(false).run(args);
            //transferFlow2();
        }
        
        @ServiceActivator(inputChannel = "archiveFile.input")
        public Message<File> myMethod (File inputFile){
            Map<String, Object> contextHeader = new HashMap<String, Object>();
            return new GenericMessage<File>(inputFile, contextHeader);
        }
        
        @MessagingGateway
        public interface Archive {
            @Gateway(requestChannel = "archiveFile.input")
            void archiveFile();
        }

        @Bean
        public IntegrationFlow archiveFile() {
          return IntegrationFlows.from(Files.inboundAdapter(new File("E:/data/datafeed/BAI")).patternFilter("*.xml"),e -> e.poller(Pollers.fixedDelay(200).maxMessagesPerPoll(20)))
            .handle(Files.outboundAdapter(new File("E:/data/datafeed/BAI/outbound")).deleteSourceFiles(true).autoCreateDirectory(true)).get();
            
        }
        
        
        
        @Bean
        public IntegrationFlow transferFlow() {
            return IntegrationFlows.from(Files.inboundAdapter(new File("E:/data/datafeed/BAI/input_1")),
	            new Consumer<SourcePollingChannelAdapterSpec>() {
	                @Override
	                public void accept(SourcePollingChannelAdapterSpec e) {
	                    e.autoStartup(true).poller(Pollers.fixedDelay(500).maxMessagesPerPoll(1));
	                }}).handle(Files.outboundAdapter(new File("E:/data/datafeed/BAI/outbound")).deleteSourceFiles(true).autoCreateDirectory(false)).get();
        }
        
        
        @Bean
        public IntegrationFlow transferFlow2(){
           return IntegrationFlows.from(Files.inboundAdapter(new File("E:/data/datafeed/BAI/input_1")),
	            new Consumer<SourcePollingChannelAdapterSpec>() {
	                @Override
	                public void accept(SourcePollingChannelAdapterSpec e) {
	                    e.autoStartup(true).poller(Pollers.fixedDelay(500).maxMessagesPerPoll(1));
	                }}).handle(Files.outboundAdapter(new File("E:/data/datafeed/BAI/outbound")).deleteSourceFiles(true).autoCreateDirectory(false)).get();
        }
        
*/}
