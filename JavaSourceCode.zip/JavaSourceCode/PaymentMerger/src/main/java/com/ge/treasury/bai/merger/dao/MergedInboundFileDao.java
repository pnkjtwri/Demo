package com.ge.treasury.bai.merger.dao;

import com.ge.treasury.bai.merger.dao.mapper.MergedInboundFileMapper;

public interface MergedInboundFileDao {
	public int saveMergedFileDetails(MergedInboundFileMapper mergedInboundFileBean);
}
