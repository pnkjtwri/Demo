/*package com.ge.treasury.bai.merger.load.config;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.treasury.bai.merger.dao.TsaIdentifierDao;
import com.ge.treasury.bai.merger.dao.mapper.TsaIdentifierMapper;
import com.ge.treasury.bai.merger.util.BaiMergerUtility;

@Component
public class TsaIdentifierLoader implements TsaIndentifierLoaderService {

	final static Logger logger = Logger.getLogger(TsaIdentifierLoader.class);
	private Map<Integer,String> tsaIdentifier = null;
	@Autowired TsaIdentifierDao tsaIdentifierDao;
	
	@Override
	public String getTsaIdentifier(int tsaInstanceId) {
		return tsaIdentifier.get(tsaInstanceId);
	}
	
	@PostConstruct
	private void loadTsaIdentifier(){
		if(tsaIdentifier == null){
			try{
				logger.info("[FileStatusLoader] - Loading file status...");
			
				tsaIdentifier = new HashMap<Integer, String>();
				List<TsaIdentifierMapper> fileStatusList = tsaIdentifierDao.getAllTsaIdentifier();
				if(fileStatusList != null && fileStatusList.size() > 0){
					for(TsaIdentifierMapper item :  fileStatusList) {
						tsaIdentifier.put(item.getTsaInstanceId(), item.getTsaIdentifier());
					}
				}
				if(tsaIdentifier== null || tsaIdentifier.size() <= 0){
					logger.error("Not able to load Tsa Identifier.");
					throw new RuntimeException("Not able to load Tsa Indentifier.");
				}
				logger.info("[TsaIdentifierLoader] - Tsa Identifier loaded!!");
			}catch(Exception e){
				logger.error("Not able to load Tsa Indentifier");
				logger.error(BaiMergerUtility.getErrorFormStackTrace(e));
				throw new RuntimeException("Not able to load Tsa Indentifier");
			}
		}
	}
}
*/