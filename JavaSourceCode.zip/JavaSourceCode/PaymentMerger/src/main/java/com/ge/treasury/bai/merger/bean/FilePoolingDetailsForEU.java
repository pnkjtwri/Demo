package com.ge.treasury.bai.merger.bean;

public class FilePoolingDetailsForEU {
	private int noOfFilesPooledFromLocation = 0;

	/**
	 * @return the noOfFilesPooledFromLocation
	 */
	public int getNoOfFilesPooledFromLocation() {
		return noOfFilesPooledFromLocation;
	}

	/**
	 * @param noOfFilesPooledFromLocation the noOfFilesPooledFromLocation to set
	 */
	public void setNoOfFilesPooledFromLocation(
			int noOfFilesPooledFromLocation) {
		this.noOfFilesPooledFromLocation = noOfFilesPooledFromLocation;
	}
	
	public FilePoolingDetailsForEU() {
		super();
	}

}
