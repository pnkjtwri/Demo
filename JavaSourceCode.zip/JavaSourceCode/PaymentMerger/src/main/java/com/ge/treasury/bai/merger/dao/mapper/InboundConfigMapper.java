package com.ge.treasury.bai.merger.dao.mapper;

public class InboundConfigMapper {
	private String erpName;
	private String nasSourceFileNamepattern;
	private String schedule;
	private String tsaName;
	private String jobName;
	private String sourceFileLocation;
	private String sourceFileNamePattern;
	private String nasFileLocation;
	private String erpTargetFileName;
	private String erpTargetFileLocation;
	
	/**
	 * @return the erpName
	 */
	public String getErpName() {
		return erpName;
	}
	/**
	 * @param erpName the erpName to set
	 */
	public void setErpName(String erpName) {
		this.erpName = erpName;
	}
	/**
	 * @return the nasSourceFileNamepattern
	 */
	public String getNasSourceFileNamepattern() {
		return nasSourceFileNamepattern;
	}
	/**
	 * @param nasSourceFileNamepattern the nasSourceFileNamepattern to set
	 */
	public void setNasSourceFileNamepattern(String nasSourceFileNamepattern) {
		this.nasSourceFileNamepattern = nasSourceFileNamepattern;
	}
	/**
	 * @return the schedule
	 */
	public String getSchedule() {
		return schedule;
	}
	/**
	 * @param schedule the schedule to set
	 */
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	/**
	 * @return the tsaName
	 */
	public String getTsaName() {
		return tsaName;
	}
	/**
	 * @param tsaName the tsaName to set
	 */
	public void setTsaName(String tsaName) {
		this.tsaName = tsaName;
	}
	/**
	 * @return the jobName
	 */
	public String getJobName() {
		return jobName;
	}
	/**
	 * @param jobName the jobName to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	/**
	 * @return the sourceFileLocation
	 */
	public String getSourceFileLocation() {
		return sourceFileLocation;
	}
	/**
	 * @param sourceFileLocation the sourceFileLocation to set
	 */
	public void setSourceFileLocation(String sourceFileLocation) {
		this.sourceFileLocation = sourceFileLocation;
	}
	/**
	 * @return the sourceFileNamePattern
	 */
	public String getSourceFileNamePattern() {
		return sourceFileNamePattern;
	}
	/**
	 * @param sourceFileNamePattern the sourceFileNamePattern to set
	 */
	public void setSourceFileNamePattern(String sourceFileNamePattern) {
		this.sourceFileNamePattern = sourceFileNamePattern;
	}
	/**
	 * @return the nasFileLocation
	 */
	public String getNasFileLocation() {
		return nasFileLocation;
	}
	/**
	 * @param nasFileLocation the nasFileLocation to set
	 */
	public void setNasFileLocation(String nasFileLocation) {
		this.nasFileLocation = nasFileLocation;
	}
	/**
	 * @return the erpTargetFileName
	 */
	public String getErpTargetFileName() {
		return erpTargetFileName;
	}
	/**
	 * @param erpTargetFileName the erpTargetFileName to set
	 */
	public void setErpTargetFileName(String erpTargetFileName) {
		this.erpTargetFileName = erpTargetFileName;
	}
	/**
	 * @return the erpTargetFileLocation
	 */
	public String getErpTargetFileLocation() {
		return erpTargetFileLocation;
	}
	/**
	 * @param erpTargetFileLocation the erpTargetFileLocation to set
	 */
	public void setErpTargetFileLocation(String erpTargetFileLocation) {
		this.erpTargetFileLocation = erpTargetFileLocation;
	}
}
