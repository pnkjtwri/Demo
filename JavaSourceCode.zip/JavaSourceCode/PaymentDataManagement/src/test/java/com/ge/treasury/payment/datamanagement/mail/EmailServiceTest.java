/**
 * 
 */
package com.ge.treasury.payment.datamanagement.mail;

import java.util.Locale;

import javax.mail.MessagingException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ge.treasury.payment.datamanagement.DataManagementApplication;

/**
 * @author padmajaarekuti
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(DataManagementApplication.class)
public class EmailServiceTest { 
	
	 @Autowired 
	 private EmailService emailService;

	@Test
	public void testSimpleEmail() {
		Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
		String subject = "Subject content";
		String bodyContent = "Body content here";
		try {
			//emailService.sendSimpleMail("Padmaja Arekuti", "padmaja.arekuti@ge.com","email-simple2" ,bLocale);
			emailService.sendSimpleMail("Webcash TSA Support Team", "email-simple2" ,bLocale,subject ,bodyContent);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
