package com.ge.treasury.payment.datamanagement.decryptservices.service;

import java.io.File;

import com.ge.treasury.payment.datamanagement.decryptservices.exception.FileEncryptionDecryptionException;

public interface FileDecryptionService {
	
	public String decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException;
	
}
