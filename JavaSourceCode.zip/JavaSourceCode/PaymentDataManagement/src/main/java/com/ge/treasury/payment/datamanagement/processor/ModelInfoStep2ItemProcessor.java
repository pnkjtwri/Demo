package com.ge.treasury.payment.datamanagement.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;
/**
 * Batch Processor for step2: Used to set duplicate flag to identify invalid records in the input file and used in classifier writer.
 * @author senthilkumar.raman
 *
 */
public class ModelInfoStep2ItemProcessor implements ItemProcessor<ModelInfo, ModelInfo> {

    private static final Logger logger = LoggerFactory.getLogger(ModelInfoStep2ItemProcessor.class);
	@Value("${modelActiveIndicatorFlag}")
	private String modelActiveIndicatorFlag;
    
    public ModelInfo process(final ModelInfo modelInfo) throws Exception {
    	logger.debug("process() Enter");
    	logger.debug("Before Processing modelInfo temp table data :"+modelInfo);
    	
    	if("Y".equalsIgnoreCase(modelInfo.getDuplicateFlag())){
    		modelInfo.setOpCode("INVALID");
    	}else{
    		modelInfo.setOpCode("VALID");
    		modelInfo.setActiveInd(modelActiveIndicatorFlag);
    		modelInfo.setDeleteFlag("N");
    	}
    	logger.debug("After Processing modelInfo temp table data :"+modelInfo);
    	logger.debug("process() Exit");
        return modelInfo;
    }

}
