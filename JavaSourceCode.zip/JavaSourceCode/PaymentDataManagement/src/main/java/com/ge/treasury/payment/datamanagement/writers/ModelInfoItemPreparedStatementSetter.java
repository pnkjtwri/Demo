package com.ge.treasury.payment.datamanagement.writers;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;

public class ModelInfoItemPreparedStatementSetter implements ItemPreparedStatementSetter<ModelInfo> {
	
	private static final Logger logger= Logger.getLogger(ModelInfoItemPreparedStatementSetter.class);

	public void setValues(ModelInfo modelInfo, PreparedStatement ps) throws SQLException {
		logger.debug("setValues() Enter"); 
		logger.debug("setValues() for TSAId-AcctId:"+modelInfo.getTsaInstancesId()+"-"+modelInfo.getModelId()); 
        ps.setInt(1, modelInfo.getTsaInstancesId());
        ps.setString(2, modelInfo.getModelId());
        ps.setString(3, modelInfo.getInstrumentType());
        ps.setString(4, modelInfo.getDescription());
        ps.setString(5, modelInfo.getActiveInd());
        ps.setString(6, modelInfo.getDeleteFlag());
        ps.setString(7, modelInfo.getCreatedBy());
        ps.setTimestamp(8, modelInfo.getCreatedTimeStamp());
        ps.setString(9, modelInfo.getLastModifiedBy());
        ps.setTimestamp(10, modelInfo.getLastModifedTimestamp());
        logger.debug("setValues() Exit"); 
	}
}
