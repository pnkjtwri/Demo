package com.ge.treasury.payment.datamanagement.decryptservices.service.impl;

import java.io.File;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.treasury.payment.datamanagement.decryptservices.exception.FileEncryptionDecryptionException;
import com.ge.treasury.payment.datamanagement.decryptservices.service.FileDecryptionService;
import com.ge.treasury.payment.datamanagement.decryptservices.util.PGPFileProcessor;

@Service
public class FileDecryptionServiceImpl implements
		FileDecryptionService {
	final static Logger logger = Logger.getLogger(FileDecryptionServiceImpl.class);

	@Value("${nasLocation}")
	private String nasLocationPath;
	@Value("${privateKeyPath}")
	private String privateKeyPath;
	@Value("${passphrase}")
	private String passphrase;
	
	@Autowired PGPFileProcessor pgpProcessor;

	//@Override
	public String decryptFile(File fileToDecrypt) throws FileEncryptionDecryptionException {
		String outPutFileName = fileToDecrypt.getName();
		outPutFileName = outPutFileName.replace(".pgp", "");
		boolean rtnFlag = pgpProcessor.decrypt(fileToDecrypt, (nasLocationPath+outPutFileName), privateKeyPath, passphrase);
		if(rtnFlag){
			return nasLocationPath+outPutFileName;
		}else{
			throw null;
		}
	}

	/**
	 * @param privateKeyPath
	 *            the privateKeyPath to set
	 */
	public void setPrivateKeyPath(String privateKeyPath) {
		this.privateKeyPath = privateKeyPath;
	}

	/**
	 * @param passphrase
	 *            the passphrase to set
	 */
	public void setPassphrase(String passphrase) {
		this.passphrase = passphrase;
	}

	/**
	 * @param nasLocationPath
	 *            the nasLocationPath to set
	 */
	public void setnasLocationPath(String nasLocationPath) {
		this.nasLocationPath = nasLocationPath;
	}

	/**
	 * @param pgpProcessor the pgpProcessor to set
	 */
	public void setPgpProcessor(PGPFileProcessor pgpProcessor) {
		this.pgpProcessor = pgpProcessor;
	}

}
