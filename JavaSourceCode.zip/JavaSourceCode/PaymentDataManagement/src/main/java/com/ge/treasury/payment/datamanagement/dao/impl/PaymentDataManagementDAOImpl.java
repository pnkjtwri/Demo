package com.ge.treasury.payment.datamanagement.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;

import com.ge.treasury.payment.datamanagement.dao.PaymentDataManagementDAO;
import com.ge.treasury.payment.datamanagement.mapper.WebcashTSAInstancesRowMapper;
import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.model.LockedFiles;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.model.WebcashTSAinstances;

@Repository
public class PaymentDataManagementDAOImpl implements PaymentDataManagementDAO {
	
	@Autowired private DataSource dataSource;
	@Autowired private JdbcTemplate jdbcTemplete;
	
	/*private static final String insertAccountInfoQuery =
            "INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO (TSAINSTANCES_ID,ACCOUNT_ID,ACCOUNT_NUMBER,ACCOUNT_FORMAT,"
            + "ACCT_OPEN_DATE,ACCT_CLOSED_DATE,BANK_ID,BANK_NAME,COUNTRY,ACTIVE_IND,DELETE_FLAG,CREATED_BY,CREATED_TIMESTAMP,"
            + "LAST_MODIFIED_BY,LAST_MODIFIED_TIMESTAMP) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";*/
	private static final String insertAccountInfoQuery =
            "INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO (TSAINSTANCES_ID,ACCOUNT_ID,ACCOUNT_NUMBER,ACCOUNT_FORMAT,"
            + "BANK_ID,BANK_NAME,COUNTRY,ACTIVE_IND,DELETE_FLAG,CREATED_BY,CREATED_TIMESTAMP,"
            + "LAST_MODIFIED_BY,LAST_MODIFIED_TIMESTAMP) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String insertModelInfoQuery =
            "INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO (TSAINSTANCES_ID,MODEL_ID,ACTIVE_IND,DELETE_FLAG,"
            + "INSTRUMENT_TYPE,DESCRIPTION,CREATED_BY,CREATED_TIMESTAMP,LAST_MODIFIED_BY,LAST_MODIFIED_TIMESTAMP) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	private static final String insertLockTableQuery = 
			"INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES (LOCKED_FILE_NAME, LOCKED_FILE_PROCESSED_TIME, "
			+ "LOCKED_FILE_SIZE, CREATED_BY, CREATED_TIMESTAMP,LAST_MODIFIED_BY, LAST_MODIFIED_TIMESTAMP) "
			+"VALUES (?, ?, ?, ?, ?, ?, ?) ";
	private static final String deleteRecLockTableQuery = 
			"DELETE FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES WHERE LOCKED_FILE_NAME LIKE ? ";
			
	
	public int insertAccountInfoDetails(AccountInfo accountInfo){
		/*Object[] accountParams = new Object[] {
				accountInfo.getTsaInstancesId(), accountInfo.getAccountId(), accountInfo.getAccountNumber(), accountInfo.getAccountFormat(), 
				accountInfo.getAcctOpenDate(), accountInfo.getAcctClosedDate(), accountInfo.getBankId(), accountInfo.getBankName(),
				accountInfo.getCountry(), accountInfo.getActiveInd(), accountInfo.getDeleteFlag(), accountInfo.getCreatedBy(), accountInfo.getCreatedTimeStamp(), 
				accountInfo.getLastModifiedBy(), accountInfo.getLastModifedTimestamp() };*/
		Object[] accountParams = new Object[] {
				accountInfo.getTsaInstancesId(), accountInfo.getAccountId(), accountInfo.getAccountNumber(), accountInfo.getAccountFormat(), 
				accountInfo.getBankId(), accountInfo.getBankName(),
				accountInfo.getCountry(), accountInfo.getActiveInd(), accountInfo.getDeleteFlag(), accountInfo.getCreatedBy(), accountInfo.getCreatedTimeStamp(), 
				accountInfo.getLastModifiedBy(), accountInfo.getLastModifedTimestamp() };
		
		/*int[] paraTypes = new int[] {
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.TIMESTAMP, Types.TIMESTAMP, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, 
                Types.VARCHAR, Types.TIMESTAMP };*/
		int[] paraTypes = new int[] {
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, 
                Types.VARCHAR, Types.TIMESTAMP };
		
		return jdbcTemplete.update(insertAccountInfoQuery, accountParams, paraTypes);
	}
	
	public int insertModelInfoDetails(ModelInfo modelInfo){
		Object[] modelParams = new Object[] {
				modelInfo.getTsaInstancesId(), modelInfo.getModelId(), modelInfo.getActiveInd(), modelInfo.getDeleteFlag(), 
				modelInfo.getInstrumentType(), modelInfo.getDescription(), modelInfo.getCreatedBy(), modelInfo.getCreatedTimeStamp(),
				modelInfo.getLastModifiedBy(), modelInfo.getLastModifedTimestamp() };
		
		int[] paraTypes = new int[] {
                Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP
        };
		
		return jdbcTemplete.update(insertModelInfoQuery, modelParams, paraTypes);
	}
	
	@SuppressWarnings("unchecked")
	public List<WebcashTSAinstances> getTSAInstanceDetails(String tsaIdentifier) {
		return jdbcTemplete.query("SELECT * FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES WHERE TSAINSTANCE_IDENTIFIER = '"+tsaIdentifier+"' ", 
				new WebcashTSAInstancesRowMapper());
	}
	
	public boolean checkLockTable(String inputFileName){
		String sqlCheckLockTable = "SELECT LOCKED_FILE_NAME FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES "
				+ "WHERE upper(LOCKED_FILE_NAME) = '"+inputFileName+"'";
		
		Boolean isLocked = jdbcTemplete.execute(sqlCheckLockTable, new PreparedStatementCallback<Boolean>(){
			public Boolean doInPreparedStatement(PreparedStatement ps)  
		            throws SQLException, DataAccessException {
				boolean result = false;
		        ResultSet rs = ps.executeQuery();
		        while(rs.next()) {
		        	 rs.getString("LOCKED_FILE_NAME");
		        	 result = true;
		        	 break;
		        }
		        rs.close();
		        
		        return result;  
		              
		    }  
		});  
		
		return isLocked;
	}
	
	public int insertInputFileInfoForLock(LockedFiles lockedFiles){
		
		Object[] lockTableParams = new Object[] {
				lockedFiles.getLockedFileName(), lockedFiles.getLockedFileProcessedTime(), 
				lockedFiles.getLockedFileSize(),  lockedFiles.getCreatedBy(), lockedFiles.getCreatedTimeStamp(), lockedFiles.getLastModifiedBy(), lockedFiles.getLastModifedTimestamp() };
		
		int[] paraTypes = new int[] {
                Types.VARCHAR, Types.TIMESTAMP,
                Types.DOUBLE, Types.VARCHAR, Types.TIMESTAMP, Types.VARCHAR, Types.TIMESTAMP
        };
		
		return jdbcTemplete.update(insertLockTableQuery, lockTableParams, paraTypes);
		
	}
	
	public int deleteInputFileInfofromLockTbl(LockedFiles lockedFiles){
		
		Object[] unlockTableParams = new Object[] { lockedFiles.getLockedFileName() };
		
		int[] paraTypes = new int[] {
                Types.VARCHAR
        };
		
		return jdbcTemplete.update(deleteRecLockTableQuery, unlockTableParams, paraTypes);
		
	}
}
