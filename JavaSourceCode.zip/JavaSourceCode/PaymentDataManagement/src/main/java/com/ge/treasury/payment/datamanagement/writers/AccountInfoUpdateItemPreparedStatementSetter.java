package com.ge.treasury.payment.datamanagement.writers;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;

public class AccountInfoUpdateItemPreparedStatementSetter implements ItemPreparedStatementSetter<AccountInfo> {
	
	private static final Logger logger= Logger.getLogger(AccountInfoUpdateItemPreparedStatementSetter.class);
	List<String> currentColumnNameList=null;
	public AccountInfoUpdateItemPreparedStatementSetter(List<String> currentColumnNameList){
		this.currentColumnNameList=currentColumnNameList;
	}
	public AccountInfoUpdateItemPreparedStatementSetter() {
		// TODO Auto-generated constructor stub
	}
	public void setValues(AccountInfo accInfo, PreparedStatement ps) throws SQLException {
		logger.debug("setValues() Enter"); 
		logger.debug("setValues() for TSAId-AcctId:"+accInfo.getTsaInstancesId()+"-"+accInfo.getAccountId()); 
        
        int length = currentColumnNameList.size();
        for( int c = 0; c< length; c++){
        	String colName = currentColumnNameList.get(c);
        	if("ACCOUNT_NUMBER".equalsIgnoreCase(colName)){
        		ps.setString(c+1, accInfo.getAccountNumber());
        	}else if("ACCOUNT_FORMAT".equalsIgnoreCase(colName)){
        		ps.setString(c+1, accInfo.getAccountFormat());
        	}else if("BANK_ID".equalsIgnoreCase(colName)){
        		ps.setString(c+1, accInfo.getBankId());
        	}else if("BANK_NAME".equalsIgnoreCase(colName)){
        		ps.setString(c+1, accInfo.getBankName());
        	}else if("COUNTRY".equalsIgnoreCase(colName)){
        		ps.setString(c+1, accInfo.getCountry());
        	}
        }
       
        ps.setString(length+1, accInfo.getLastModifiedBy());
        ps.setTimestamp(length+2, accInfo.getLastModifedTimestamp());
        ps.setInt(length+3, accInfo.getTsaInstancesId());
        ps.setString(length+4, accInfo.getAccountId());
        
        logger.debug("setValues() Exit"); 
	}
}
