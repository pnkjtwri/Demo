package com.ge.treasury.payment.datamanagement.filter;

import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.integration.file.filters.FileListFilter;

import com.ge.treasury.payment.datamanagement.dao.impl.PaymentDataManagementDAOImpl;
import com.ge.treasury.payment.datamanagement.model.LockedFiles;
import com.ge.treasury.payment.datamanagement.util.PDMInit;

public class CustomFileListFilter <F> implements FileListFilter<F>{
	final static Logger logger = Logger.getLogger(CustomFileListFilter.class);
	
	private final Integer maxCapacity = 3;
	private Set<F> fileRead = new HashSet<F>();
	private Queue<F> seen   = new LinkedBlockingQueue<F>(maxCapacity);
	private final Object monitor = new Object();
	
	@Autowired private PaymentDataManagementDAOImpl daoImpl;
	
	@Value("${userid.created.by}")
	private String createdBy;
	@Value("${userid.last.modified.by}")
	private String lastModifiedBy;
	
	@Override
	public List<F> filterFiles(F[] files) {
		List<F> accepted = new ArrayList<F>();
		synchronized (this.monitor) {
	        if (files != null) {
	        	boolean isFileLocked = false;
	        	File fileRecieved = null;
	            for (F file : files) {
	            	fileRecieved = new File(file.toString());
	            	if(!this.fileRead.contains(file) && fileRecieved.isFile()  && !file.toString().toLowerCase().contains(".writing") 
	            			&& file.toString().toLowerCase().endsWith(".csv.pgp") && fileRecieved.length() > 0){
		            	isFileLocked = false;
		            	try{
		            		logger.info("[CustomFileListFilter] - Going to get the file Lock for file - "+fileRecieved.getName());
			            	int rows = daoImpl.insertInputFileInfoForLock(prepareFileLockBean(fileRecieved));
			            	if(rows > 0 ){
			            		isFileLocked = true;
			            		logger.info("[CustomFileListFilter] - File Lock Acquired for - "+fileRecieved.getName());
			            	}
		            	}catch(DuplicateKeyException e){
		            		isFileLocked = false;
		            		logger.info("[CustomFileListFilter] - "+fileRecieved.getName()+" File is already Locked.. ");
		            		logger.info("[CustomFileListFilter] - "+PDMInit.getErrorFormStackTrace(e));
		            	}catch(Exception e){
		            		isFileLocked = false;
		            		logger.info("[CustomFileListFilter] - Getting error while going for file lock");
		            		logger.info("[CustomFileListFilter] - "+PDMInit.getErrorFormStackTrace(e));
		            	}
		            	
		            	if(isFileLocked){
		            		accepted.add(file);
		            		this.remove(file);
		            		this.fileRead.add(file);
		            		logger.info("[CustomFileListFilter] - File Recived - "+file);
		            		break;
		            	}else{
		            		//in case if file is already processed by other instance
		            		//we are not going to check for the same file
		            		this.fileRead.add(file);
		            	}
	            	}
	            }
	        }
		}
        return accepted;
	}
	
	private void remove(F fileToRemove){
		if(this.seen.size() == (maxCapacity-2)){
			F removed = this.seen.poll();
			if(removed != null){
				logger.info("[CustomFileListFilter] - File Removed  - "+removed);
				this.fileRead.remove(removed);
			}
		}
		this.seen.offer(fileToRemove);
	}

	
	/**
	 * Method used for preparing the FileLock object
	 * @param inputFileName
	 * @return
	 */
	private LockedFiles prepareFileLockBean(File inputFileName){
		logger.info("[CustomFileListFilter.class] [inside prepareFileLockBean()]");
		LockedFiles lock = new LockedFiles();
		lock.setLockedFileName(inputFileName.getName());
		lock.setLockedFileProcessedTime(new Timestamp(new java.util.Date().getTime()));
		lock.setLockedFileSize((double)inputFileName.length());
		lock.setCreatedBy(createdBy);
		lock.setLastModifiedBy(lastModifiedBy);
		logger.info("[CustomFileListFilter.class] [inside prepareFileLockBean()] [returning FileLock object]");
		return lock;
	}
}
