package com.ge.treasury.payment.datamanagement.model;

import java.util.Date;
/**
 * Java bean used to map Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES table
 * @author senthilkumar.raman
 *
 */
public class WebcashTSAinstances {
	
	private int tsaInstancesId;
	private String tsaInstancesIdentifier;
	private String hostName;
	private String userId;
	private String pfiLocation;
	private String pfiRespFilesLocation;
	private String pfiPublicKeyPath;
	private String pfiRespFilePrivateKeyPath;
	private String activeInd;
	private String deleteFlag;
	private String createdBy;
	private Date createdTimeStamp;
	private String lastModifiedBy;
	private Date lastModifedTimestamp;
	
	public int getTsaInstancesId() {
		return tsaInstancesId;
	}
	public void setTsaInstancesId(int tsaInstancesId) {
		this.tsaInstancesId = tsaInstancesId;
	}
	
	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}
	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}
	
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getPfiLocation() {
		return pfiLocation;
	}
	public void setPfiLocation(String pfiLocation) {
		this.pfiLocation = pfiLocation;
	}
	
	public String getPfiRespFilesLocation() {
		return pfiRespFilesLocation;
	}
	public void setPfiRespFilesLocation(String pfiRespFilesLocation) {
		this.pfiRespFilesLocation = pfiRespFilesLocation;
	}
	
	public String getPfiPublicKeyPath() {
		return pfiPublicKeyPath;
	}
	public void setPfiPublicKeyPath(String pfiPublicKeyPath) {
		this.pfiPublicKeyPath = pfiPublicKeyPath;
	}
	
	public String getPfiRespFilePrivateKeyPath() {
		return pfiRespFilePrivateKeyPath;
	}
	public void setPfiRespFilePrivateKeyPath(String pfiRespFilePrivateKeyPath) {
		this.pfiRespFilePrivateKeyPath = pfiRespFilePrivateKeyPath;
	}
	
	public String getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}
	
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
	public Date getLastModifedTimestamp() {
		return lastModifedTimestamp;
	}
	public void setLastModifedTimestamp(Date lastModifedTimestamp) {
		this.lastModifedTimestamp = lastModifedTimestamp;
	}
	
}
