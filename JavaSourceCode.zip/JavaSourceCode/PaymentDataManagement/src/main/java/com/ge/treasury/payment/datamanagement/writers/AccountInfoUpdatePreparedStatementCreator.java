package com.ge.treasury.payment.datamanagement.writers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementCreator;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;

public class AccountInfoUpdatePreparedStatementCreator implements PreparedStatementCreator,PDMConstants {
	
	private static final Logger logger= Logger.getLogger(AccountInfoUpdatePreparedStatementCreator.class);
	@SuppressWarnings("unused")
	private AccountInfo acctInfo;
	private List<AccountInfo> existingAccountList;
	private String level;
	
	public AccountInfoUpdatePreparedStatementCreator(AccountInfo accountInfo, List<AccountInfo> existingAccountList){
		logger.info("AccountInfoUpdatePreparedStatementCreator constructor Enter");
		this.acctInfo = accountInfo;
		this.existingAccountList=existingAccountList;
		logger.info("AccountInfoUpdatePreparedStatementCreator constructor Exit");
	}
	
	public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
		logger.info("createPreparedStatement() Enter");
		int size = existingAccountList.size();
		String SELECT_QUERY =updateMasterTableQuery(size);
		
		PreparedStatement ps = connection.prepareStatement(SELECT_QUERY);
		
		//Set Where condition value dynamically
		
		if(level!=null &&(PDMConstants.TEMP_TABLE).equalsIgnoreCase(level)){
			
	        ps.setString(1, existingAccountList.get(0).getTsaInstancesIdentifier());
	        ps.setString(2, existingAccountList.get(0).getJobId());
			
			int increasedSize = size+2;
			int acidIndex = (increasedSize-size)+1;
			for(int acid = acidIndex; acid <=increasedSize; acid++){
	            ps.setString(acid, existingAccountList.get(acid-acidIndex).getAccountId());
	        }
		}
		
		if(level!=null && (PDMConstants.MASTER_TABLE).equalsIgnoreCase(level)){
			
			for(int acid = 1; acid <=size; acid++){
	            ps.setString(acid, existingAccountList.get(acid-1).getAccountId());
	        }
		}
		
		logger.info("createPreparedStatement() Exit");
		return ps;
	}
	
	/*Expected Query with sample data
	 * 	UPDATE Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO A 
		SET A.ACCOUNT_NUMBER = ?, A.ACCOUNT_FORMAT = ?,  
			A.BANK_ID = ?, A.BANK_NAME = ?, A.COUNTRY = ? 
	 		A.LAST_MODIFIED_BY = ?, LAST_MODIFIED_TIMESTAMP = ? 
		WHERE A.TSAINSTANCES_ID =? AND A.ACCOUNT_ID = ? */
	
	//Create PreparedStatement Query dynamically to update AccountInfo master table.
	private static String updateMasterTableQuery(int length) {
		logger.info("updateMasterTableQuery() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("UPDATE Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO ");
        sbQuery.append("SET  ACCOUNT_NUMBER = ?, ACCOUNT_FORMAT = ?, ");
        sbQuery.append("BANK_ID = ?, BANK_NAME = ?, COUNTRY = ?, ");
        sbQuery.append("LAST_MODIFIED_BY = ?, LAST_MODIFIED_TIMESTAMP = ? ");
        sbQuery.append("WHERE ");
        sbQuery.append("TSAINSTANCES_ID =? AND ACCOUNT_ID = ? ");
        
        for( int j = 0; j< length; j++){
        	sbQuery.append("?");
            if(j != length -1) sbQuery.append(",");
        }
        
        sbQuery.append(" ) ");
        String updateQuery = sbQuery.toString();
        sbQuery=null;
        logger.debug("updateQuery: "+updateQuery);
        logger.info("updateMasterTableQuery() Exit");
        return updateQuery;
    }
	
}
