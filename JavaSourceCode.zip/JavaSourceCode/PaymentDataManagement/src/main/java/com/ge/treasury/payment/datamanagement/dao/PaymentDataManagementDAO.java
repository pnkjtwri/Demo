package com.ge.treasury.payment.datamanagement.dao;

import java.util.List;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.model.LockedFiles;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.model.WebcashTSAinstances;

public interface PaymentDataManagementDAO {

	public int insertAccountInfoDetails(AccountInfo accountInfo);

	int insertModelInfoDetails(ModelInfo modelInfo);

	List<WebcashTSAinstances> getTSAInstanceDetails(String tsaIdentifier);

	boolean checkLockTable(String inputFileName);

	int insertInputFileInfoForLock(LockedFiles lockedFiles);

}
