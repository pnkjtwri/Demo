package com.ge.treasury.payment.datamanagement;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;


@SpringBootApplication 
@ImportResource("classpath:spring/datamanagenent-integration-context.xml")
public class DataManagementApplication extends SpringBootServletInitializer{
	
	private final static Logger logger= Logger.getLogger(DataManagementApplication.class);

	public static void main(String[] args) throws Exception {
	logger.debug("Main () called"); 
	
	SpringApplication.run(DataManagementApplication.class, args);
	
	logger.debug("Main () Exit"); 
	
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
		defaultProperties.put("spring.config.location", "file:/app/tsaweb/properties/paymentdatamanagemnt/application.yml");
		return application.sources(DataManagementApplication.class).properties(defaultProperties);
    }
	
}
