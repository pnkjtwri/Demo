package com.ge.treasury.payment.datamanagement.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;
/**
 * Batch Processor for step2: Used to set duplicate flag to identify invalid records in the input file and used in classifier writer.
 * @author senthilkumar.raman
 *
 */
public class AccountInfoStep2ItemProcessor implements ItemProcessor<AccountInfo, AccountInfo> {

    private static final Logger logger = LoggerFactory.getLogger(AccountInfoStep2ItemProcessor.class);
	@Value("${accountActiveIndicatorFlag}")
	private String accountActiveIndicatorFlag;
	
    public AccountInfo process(final AccountInfo accountInfo) throws Exception {
    	logger.debug("process() Enter");
    	logger.debug("Processing accountInfo temp table data :"+accountInfo);
    	
    	if("Y".equalsIgnoreCase(accountInfo.getDuplicateFlag())){
    		accountInfo.setOpCode("INVALID");
    	}else{
    		accountInfo.setOpCode("VALID");
    		accountInfo.setActiveInd(accountActiveIndicatorFlag);
    		accountInfo.setDeleteFlag("N");
    	}
    	
    	logger.debug("process() Exit");
        return accountInfo;
    }

}
