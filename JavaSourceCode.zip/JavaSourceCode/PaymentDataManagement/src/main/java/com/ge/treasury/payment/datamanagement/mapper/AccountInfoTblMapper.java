package com.ge.treasury.payment.datamanagement.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;

/**
 * Used to map result set of T_WEBCASHTSA_ACCOUNT_INFO_TEMP and T_WEBCASHTSA_ACCOUNT_INFO table
 * 
 * @author senthilkumar.raman
 *
 */

public class AccountInfoTblMapper implements RowMapper<AccountInfo>{
	
	public AccountInfo mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
		final Logger logger= Logger.getLogger(AccountInfoTblMapper.class);
		logger.debug("mapRow() Enter");
		logger.debug("Set value for executed query with resultSet. rowNumber="+rowNumber);
		
		int tsaInstancesId = resultSet.getInt("TSAINSTANCES_ID");
		String accountId = resultSet.getString("ACCOUNT_ID");
		String accountNo = resultSet.getString("ACCOUNT_NUMBER");
		String accountFormat = resultSet.getString("ACCOUNT_FORMAT");
		String bankId = resultSet.getString("BANK_ID");
		String bankName = resultSet.getString("BANK_NAME");
		String country = resultSet.getString("COUNTRY");
		String activeInd = resultSet.getString("ACTIVE_IND");
		String deleteFlag = resultSet.getString("DELETE_FLAG");
		String duplicateFlag = resultSet.getString("DUPLICATE_FLAG");
		String comments = resultSet.getString("COMMENTS");
		String createdBy = resultSet.getString("CREATED_BY");
		Timestamp createdTS = resultSet.getTimestamp("CREATED_TIMESTAMP");
		String lastModifiedBy = resultSet.getString("LAST_MODIFIED_BY");
		Timestamp lastModifiedTS = resultSet.getTimestamp("LAST_MODIFIED_TIMESTAMP");
		String actionInd = resultSet.getString("ACTION_IND");
		
		AccountInfo acctInfo = new AccountInfo();
		acctInfo.setTsaInstancesId(tsaInstancesId);
		acctInfo.setAccountId(accountId);
		acctInfo.setAccountNumber(accountNo);
		acctInfo.setAccountFormat(accountFormat);
		acctInfo.setBankId(bankId);
		acctInfo.setBankName(bankName);
		acctInfo.setCountry(country);
		acctInfo.setActiveInd(activeInd);
		acctInfo.setDeleteFlag(deleteFlag);
		acctInfo.setDuplicateFlag(duplicateFlag);
		acctInfo.setComments(comments);
		acctInfo.setCreatedBy(createdBy);
		acctInfo.setCreatedTimeStamp(createdTS);
		acctInfo.setLastModifiedBy(lastModifiedBy);
		acctInfo.setLastModifedTimestamp(lastModifiedTS);
		acctInfo.setActionInd(actionInd);
		
		logger.debug("mapRow() Exit");
		return acctInfo;
	}


}
