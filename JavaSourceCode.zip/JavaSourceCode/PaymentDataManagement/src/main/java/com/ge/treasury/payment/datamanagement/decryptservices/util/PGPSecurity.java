package com.ge.treasury.payment.datamanagement.decryptservices.util;

import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;

/**
 * @author padmajaarekuti
 *
 */
public class PGPSecurity {
	
	private PGPEncryptedDataList encryptedData;
	private PGPPublicKeyEncryptedData pkEncryptedData;
	private PGPPrivateKey secretKey;
	private PGPObjectFactory pgpFactory;
	
	public PGPSecurity(){
		encryptedData=null;
		pkEncryptedData=null;
		secretKey=null;
		pgpFactory=null;
	}
	
	/**
	 * @return the pkEncryptedData
	 */
	public PGPPublicKeyEncryptedData getPkEncryptedData() {
		return pkEncryptedData;
	}
	/**
	 * @param pkEncryptedData the pkEncryptedData to set
	 */
	public void setPkEncryptedData(PGPPublicKeyEncryptedData pkEncryptedData) {
		this.pkEncryptedData = pkEncryptedData;
	}
	/**
	 * @return the encryptedData
	 */
	public PGPEncryptedDataList getEncryptedData() {
		return encryptedData;
	}
	/**
	 * @param encryptedData the encryptedData to set
	 */
	public void setEncryptedData(PGPEncryptedDataList encryptedData) {
		this.encryptedData = encryptedData;
	}
	/**
	 * @return the secretKey
	 */
	public PGPPrivateKey getSecretKey() {
		return secretKey;
	}
	/**
	 * @param secretKey the secretKey to set
	 */
	public void setSecretKey(PGPPrivateKey secretKey) {
		this.secretKey = secretKey;
	}

	/**
	 * @return the pgpFactory
	 */
	public PGPObjectFactory getPgpFactory() {
		return pgpFactory;
	}

	/**
	 * @param pgpFactory the pgpFactory to set
	 */
	public void setPgpFactory(PGPObjectFactory pgpFactory) {
		this.pgpFactory = pgpFactory;
	} 

}
