/**
 * 
 */
package com.ge.treasury.payment.datamanagement.mail;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.ge.treasury.payment.datamanagement.batch.listeners.AccountInfoJobListener;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;

/**
 * @author padmajaarekuti
 *
 */
@Service
public class EmailService {

    @Autowired 
    private JavaMailSender mailSender;
    
    @Autowired 
    private TemplateEngine templateEngine;

    
    private static final Logger logger= Logger.getLogger(AccountInfoJobListener.class);

    
    @Value("${recipientDL}")
   	private String recipientEmail;
       
   @Value("${fromDL}")
   	private String fromDL;

 
    /* 
     * Send HTML mail (simple) 
     */
   public void sendSimpleMail(
    		final String recipientName, final String templateNm,final Locale locale, String subject, String bodyContent) 
            throws MessagingException {
    	logger.debug("sendSimpleMail() Enter");
        // Prepare the evaluation context
        final Context ctx = new Context(locale);
        ctx.setVariable("name", recipientName);
        ctx.setVariable("bodyContent", bodyContent);
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, "UTF-8");
        message.setSubject(subject);
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process(templateNm, ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Send email
        this.mailSender.send(mimeMessage);
        logger.debug("sendSimpleMail() Exit");
    }
 
    
    /* 
     * Send HTML mail with attachment. 
     */
    public void sendMailWithAttachment(
            final String recipientName, final String recipientEmail, final String attachmentFileName, 
            final byte[] attachmentBytes, final String attachmentContentType, final Locale locale) 
            throws MessagingException {
    	logger.debug("sendMailWithAttachment() Enter");
        // Prepare the evaluation context
        final Context ctx = new Context(locale);
        ctx.setVariable("name", recipientName);
        ctx.setVariable("subscriptionDate", new Date());
        ctx.setVariable("hobbies", Arrays.asList("Cinema", "Sports", "Music"));
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = 
                new MimeMessageHelper(mimeMessage, true /* multipart */, "UTF-8");
        message.setSubject("Example HTML email with attachment");
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);
        

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process("email-withattachment.html", ctx);
        message.setText(htmlContent, true /* isHtml */);
        
        // Add the attachment
        final InputStreamSource attachmentSource = new ByteArrayResource(attachmentBytes);
        message.addAttachment(
                attachmentFileName, attachmentSource, attachmentContentType);
        
        // Send mail
        this.mailSender.send(mimeMessage);
        logger.debug("sendMailWithAttachment() Exit");
    }
    
    /**
     * Send HTML mail with attachment with file info. 
     * @author senthilkumar.raman
     */
    public void sendMailWithAttachmentAndFileInfo(
            final String recipientName, final String recipientEmail, 
            final String attachmentInputFileName,final byte[] attachmentInputBytes, 
            final String attachmentReportFileName,final byte[] attachmentReportBytes,
            final String attachmentContentType,final BatchStatus batchStatus,
            final String batchMessage) 
            throws MessagingException {
    	
    	logger.debug("sendMailWithAttachmentAndFileInfo() Enter");
    	Locale locale = new Locale.Builder().setLanguage("en").setRegion("US").build();
    	GregorianCalendar gcalendar = new GregorianCalendar();
    	String months[] = {"Jan", "Feb", "Mar", "Apr","May", "Jun", "Jul", "Aug","Sep", "Oct", "Nov", "Dec"};
    	String batchDate = months[gcalendar.get(Calendar.MONTH)]+ " " + gcalendar.get(Calendar.DATE) + " "+gcalendar.get(Calendar.YEAR);
    	String batchTime =gcalendar.get(Calendar.HOUR) + ":"+gcalendar.get(Calendar.MINUTE) + ":"+gcalendar.get(Calendar.SECOND);
        
        // Prepare the evaluation context
        final Context ctx = new Context(locale);
        ctx.setVariable("name", recipientName);
        ctx.setVariable("FileName",attachmentInputFileName==null?"File Name not found":attachmentInputFileName);
        ctx.setVariable("BatchDate",batchDate);
        ctx.setVariable("BatchTime",batchTime);
        ctx.setVariable("BatchStatus",batchStatus==null?"":batchStatus);
        ctx.setVariable("BatchMessage",batchMessage==null?"":batchMessage);
        logger.debug("sendMailWithAttachmentAndFileInfo() :Evaluation context prepared.");
        
        // Prepare message using a Spring helper
        final MimeMessage mimeMessage = this.mailSender.createMimeMessage();
        final MimeMessageHelper message = 
                new MimeMessageHelper(mimeMessage, true /* multipart */, "UTF-8");
        if(attachmentReportBytes == null){
        	message.setSubject("Payment Data Management's Notification email for "+attachmentInputFileName+".");
        }
        else{
        	message.setSubject("Error during process file : "+attachmentInputFileName+" failed with data validation errors in Data Management.");
        	ctx.setVariable("BatchMessage",PDMConstants.BATCH_ERROR_MSG);
        }
        message.setFrom(fromDL);
        String[] sendTo = recipientEmail.split(",");
        //message.setTo(recipientEmail);
        message.setTo(sendTo);
        logger.debug("sendMailWithAttachmentAndFileInfo() :Message created using a Spring helper");

        // Create the HTML body using Thymeleaf
        final String htmlContent = this.templateEngine.process("PDM-Email-Notification", ctx);
        message.setText(htmlContent, true /* isHtml */);
        logger.debug("sendMailWithAttachmentAndFileInfo() :Created the HTML body using Thymeleaf");
        
        // Add the attachment
        final InputStreamSource attachmentInputSource = new ByteArrayResource(attachmentInputBytes);
        message.addAttachment(attachmentInputFileName, attachmentInputSource, attachmentContentType);
        logger.debug("sendMailWithAttachmentAndFileInfo() : "+attachmentInputFileName+" added in the attachment");
        
        // Add batch invalid records reports as attachment
        if(BatchStatus.COMPLETED.equals(batchStatus) && StringUtils.isNotBlank(attachmentReportFileName) && attachmentReportBytes!=null){
        	final InputStreamSource attachmentReportSource = new ByteArrayResource(attachmentReportBytes);
        	message.addAttachment(attachmentReportFileName, attachmentReportSource, attachmentContentType);
        	logger.debug("sendMailWithAttachmentAndFileInfo() : "+attachmentReportFileName+" added in the attachment");
        }
        // Send mail
        this.mailSender.send(mimeMessage);
        logger.debug("sendMailWithAttachmentAndFileInfo() : email Sent Successfully");
        logger.debug("sendMailWithAttachmentAndFileInfo() Exit");
        
    }

}