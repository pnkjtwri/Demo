package com.ge.treasury.payment.datamanagement.service;

import java.io.File;

public interface AccountModelFileService {

	public void processSourceFile(File inputFile);

}

