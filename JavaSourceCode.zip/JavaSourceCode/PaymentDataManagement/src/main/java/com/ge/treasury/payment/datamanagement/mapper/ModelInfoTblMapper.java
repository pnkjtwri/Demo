package com.ge.treasury.payment.datamanagement.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;

/**
 * Used to map result set of T_WEBCASHTSA_MODEL_INFO_TEMP and T_WEBCASHTSA_MODEL_INFO table
 * 
 * @author senthilkumar.raman
 *
 */

public class ModelInfoTblMapper implements RowMapper<ModelInfo>{
	
	public ModelInfo mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
		final Logger logger= Logger.getLogger(ModelInfoTblMapper.class);
		logger.debug("mapRow() Enter");
		logger.debug("Set value for executed query with resultSet. rowNumber="+rowNumber);
		
		int tsaInstancesId = resultSet.getInt("TSAINSTANCES_ID");
		//String tsaInstancesIdentifier = resultSet.getString("TSAINSTANCE_IDENTIFIER");
		String modelId = resultSet.getString("MODEL_ID");
		String intrumentType = resultSet.getString("INSTRUMENT_TYPE");
		String description = resultSet.getString("DESCRIPTION");
		String activeInd = resultSet.getString("ACTIVE_IND");
		String deleteFlag = resultSet.getString("DELETE_FLAG");
		String duplicateFlag = resultSet.getString("DUPLICATE_FLAG");
		String comments = resultSet.getString("COMMENTS");
		String createdBy = resultSet.getString("CREATED_BY");
		Timestamp createdTS = resultSet.getTimestamp("CREATED_TIMESTAMP");
		String lastModifiedBy = resultSet.getString("LAST_MODIFIED_BY");
		Timestamp lastModifiedTS = resultSet.getTimestamp("LAST_MODIFIED_TIMESTAMP");
		
		ModelInfo modelInfo = new ModelInfo();
		modelInfo.setTsaInstancesId(tsaInstancesId);
		//modelInfo.setTsaInstancesIdentifier(tsaInstancesIdentifier);
		modelInfo.setModelId(modelId);
		modelInfo.setInstrumentType(intrumentType);;
		modelInfo.setDescription(description);
		modelInfo.setActiveInd(activeInd);
		modelInfo.setDeleteFlag(deleteFlag);
		modelInfo.setDuplicateFlag(duplicateFlag);
		modelInfo.setComments(comments);
		modelInfo.setCreatedBy(createdBy);
		modelInfo.setCreatedTimeStamp(createdTS);
		modelInfo.setLastModifiedBy(lastModifiedBy);
		modelInfo.setLastModifedTimestamp(lastModifiedTS);
		
		logger.debug("mapRow() Exit");
		return modelInfo;
	}


}
