package com.ge.treasury.payment.datamanagement.model;
/**
 * Java bean used for duplication record validation in TEMP table.
 * @author senthilkumar.raman
 *
 */
public class AccountInfoPK {
	
	private String tsaInstancesIdentifier;
	private String accountId;
	private String jobId;
	private String actionId;
	
	public AccountInfoPK(){
		
	}
	
	public AccountInfoPK(String tsaInstancesIdentifier, String accountId){
		this.tsaInstancesIdentifier=tsaInstancesIdentifier;
		this.accountId=accountId;
	}
	
	
	
	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}



	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}



	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	
	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	@Override
	public String toString() {
		return "AccountInfoPK [ tsaInstancesIdentifier="+ tsaInstancesIdentifier+ ", accountId=" + accountId + ", jobId=" + jobId +", actionId=" + actionId +"]";
				
	}
	
}
