package com.ge.treasury.payment.datamanagement.util;

/**
 * Constants for Payment Data Management Project
 * 
 * @author senthilkumar.raman
 *
 */
public interface PDMConstants {
	public static final String TEMP_TABLE="Temp";
	public static final String MASTER_TABLE="Master";
	public static final String UPDATE_TABLE="Update";
	public static final String JOB_ID_KEY="JOB_ID_KEY";
	public static final String NEWLY_CREATED="C";
	public static final String UPDATED="U";
	public static final String [] ACCINFO_COLS= {"ACCOUNT_NUMBER", "ACCOUNT_FORMAT", "BANK_ID", "BANK_NAME", "COUNTRY"};
	public static final String ACCOUNT_DATA_COLUMN_HEADER="ACCTID,ACCTNUM,ACCOUNTFORMAT,BANKID,NAME,COUNTRY,ACTIONIND,COMMENTS";
	public static final int BUSINESS_ERROR_CODE =100;
	public static final String CONTENT_TYPE_HTML = "text/csv";
	public static final String BATCH_COMPLETED_MSG = "Batch completed successfully";
	public static final String BATCH_ERROR_MSG = "Batch process completed with errors.";
	public static final String BATCH_FAILED_MSG = "Batch encounter system error. Please check the application log for detail.";
	public static final String INDICATOR_Y="Y";
	public static final String INDICATOR_N="N";
	public static final String VAL_ACCOUNT_FEED="_ACCOUNT_FEED";
	public static final String VAL_MODEL_FEED="_MODEL_FEED";
	public static final String CURRENT_LINE = "CURRENT_LINE";
}
