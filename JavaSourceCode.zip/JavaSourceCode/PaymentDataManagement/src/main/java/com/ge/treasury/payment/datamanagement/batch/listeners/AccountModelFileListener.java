package com.ge.treasury.payment.datamanagement.batch.listeners;

/**
 * @author Pankaj1.Tiwari
 * Class designed for process the AccountInfo and ModelInfo file from source location
 */

import org.apache.commons.lang.exception.ExceptionUtils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.mail.MessagingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ConfigurableApplicationContext;

import au.com.bytecode.opencsv.CSVReader;

import com.ge.treasury.payment.datamanagement.dao.impl.PaymentDataManagementDAOImpl;
import com.ge.treasury.payment.datamanagement.decryptservices.service.impl.FileDecryptionServiceImpl;
import com.ge.treasury.payment.datamanagement.mail.EmailService;
import com.ge.treasury.payment.datamanagement.model.LockedFiles;
import com.ge.treasury.payment.datamanagement.service.AccountModelFileService;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;

public class AccountModelFileListener implements PDMConstants{
	
	private static Logger logger = Logger.getLogger(AccountModelFileListener.class);
	
	@Autowired private AccountModelFileService accountModelFileService;
	@Autowired private PaymentDataManagementDAOImpl daoImpl;
	@Autowired private ConfigurableApplicationContext ctx;
	@Autowired private EmailService emailService;
	@Autowired private FileDecryptionServiceImpl decryptionService;
	
	private Locale bLocale = new Locale.Builder().setLanguage("en").setRegion("US").build();
	private String headerValidationMessage = "";
	
	@Value("${account.data.column.header}")
	private String accColsHeader;
	@Value("${model.data.column.header}")
	private String modelColsHeader;
	@Value("${userid.created.by}")
	private String createdBy;
	@Value("${userid.last.modified.by}")
	private String lastModifiedBy;
	@Value("${errorLocation}")
	private String errorLocation;
	@Value("${archiveLocation}")
	private String archiveLocation;
	@Value("${keepPlainFile}")
	private String keepPlainFile;
	
	/**
	 * Method used for processing the input file..
	 * @param inputFile
	 */

	public void processSourceFile(File inputFile){
		logger.info("[AccountModelFileListener.class] [inside processSourceFile()]");
		logger.info("[AccountModelFileListener.class] [inside processSourceFile()]"+inputFile.getPath());
		boolean fileHeaderCheck = false;
		File decryptFile = null;
		try {
			logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to get file lock on input file...]");
			
			//sending file to Archive location...
			sendFilestoArchiveLocation(inputFile);
			
			if(inputFile.length() > 0){
				/*if(doFileLockCheck(inputFile))*/{
					logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to check file naming convention...]");
					if(inputFile.length() > 0 && doFileNameValidation(inputFile.getName())){
						
						//after file naming validation....Going to decrypt the file.
						String decryptFileName = decryptionService.decryptFile(inputFile);
						//String decryptFileName = inputFile.getAbsolutePath();
						logger.info("decryptFileName="+decryptFileName);
						if(decryptFileName != null){
							decryptFile = new File(decryptFileName);
							
							//sending decrypted file into archive location..
							if(keepPlainFile.equals("Y") && decryptFile != null && decryptFile.exists())
								sendFilestoArchiveLocation(decryptFile);
							
							//checkmarx:Fix for Stored XSS\Path 1
							CSVReader reader = new CSVReader(new FileReader(decryptFile));
							List<String[]> records = reader.readAll();
							int noOfcolumns =0;
							if(records.size()==1 && records.get(0).length==1 && records.get(0)[0].isEmpty()){
								reader.close();
								throw new RuntimeException("File has not enough records to process.");
							}else{
								String[] cols = records.get(0);
								noOfcolumns = cols.length;
							}
							reader.close();
							//going/ to check file header..
							logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to check file header...]");
							if(StringUtils.contains(decryptFile.getName(), VAL_ACCOUNT_FEED)){
								logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to check file header for AccountInfo file]");
								fileHeaderCheck = validateAccountInfoFileHeader(noOfcolumns);
							}
							
							if(StringUtils.contains(decryptFile.getName(), VAL_MODEL_FEED)){
								logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to check file header for ModelInfo file]");
								fileHeaderCheck = validateModelInfoFileHeader(noOfcolumns);
							}
								
							if(fileHeaderCheck){
								logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [All validation happened successfully...]");
								logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Going to process input file...]");
								
								//validation process done...
								//Launch batch process
								
								String inputpathFile = decryptFile.getAbsolutePath();
								JobParametersBuilder jobParameterBuilder = new JobParametersBuilder()
								.addString("inputFileName",inputpathFile )//CSV file
								.addString("pgpFilePath", inputFile.getPath());//PGP file
								
								JobLauncher launcher = ctx.getBean(JobLauncher.class);
								
								if(StringUtils.contains(inputpathFile, VAL_ACCOUNT_FEED)){
									if(decryptFile.exists()){
										JobParameters jobParameters = jobParameterBuilder.toJobParameters();
										Job job = (Job) ctx.getBean("AccountFeedJob");
										JobExecution accoutJobExec = launcher.run(job, jobParameters);
										logger.debug("AccountFeedJob ExitStatus ="+accoutJobExec.getExitStatus());
										logger.debug("AccountFeedJob  JobExecution is Running ? "+accoutJobExec.isRunning());
										
									}else{
										logger.debug("Account Batch input file not exists");
									}
									
								}else if(StringUtils.contains(inputpathFile, VAL_MODEL_FEED)){
									if(decryptFile.exists()){
										JobParameters jobParameters = jobParameterBuilder.toJobParameters();
										Job job = (Job) ctx.getBean("ModelFeedJob");
										JobExecution modelJobExec =launcher.run(job, jobParameters);
										logger.debug("ModelFeedJob ExitStatus ="+modelJobExec.getExitStatus());
										logger.debug("ModelFeedJob  JobExecution is Running ? "+modelJobExec.isRunning());
									}else{
										logger.debug("Account Batch input file not exists");
									}
								}
								logger.info("Come to an end of current Batch Process. Listening for Next input file... ");
								
							}else{//Send email notification if Header validation failed.
								logger.error("[Header validation failed.] [Going to send email..]");
								String subject = "Error during process file : "+inputFile.getName()+" in Payment Data Management.";
								doFileUnLockCheck(inputFile);
								String bodyContent = headerValidationMessage;
								try {
									if(emailService == null)emailService = new EmailService();
									emailService.sendSimpleMail("WebcashTSA", "email-simple2", bLocale, subject, bodyContent);
								} catch (MessagingException e1) {
									e1.printStackTrace();
								}
								logger.error("Header Validation failed...Going to move file into error location.....");
								sendFilestoErrorLocation(inputFile);
								//sending decrypted file into archive location..
								if(keepPlainFile.equals("Y") && decryptFile != null && decryptFile.exists())
									sendFilestoErrorLocation(decryptFile);
								deleteSrouceFile(inputFile, decryptFile);
							}
						}else{
							logger.info("decryptFileName not found to initiate validaion process. ");
						}
					}
				}
			}
			
		} /*catch(FileEncryptionDecryptionException ex){
			logger.info("[AccountModelFileListener.class] [inside processSourceFile()] [Got FileEncryptionDecryptionException Exception.]");
			String bodyContent = "Got FileEncryptionDecryptionException Error in decrypting source file : ";
			bodyContent += ex.toString();
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("WebcashTSA", "email-simple2", bLocale, "File Decryption Error", bodyContent);
			} catch (MessagingException e1) {
				e1.printStackTrace();
			}
			logger.error("Got Exception...Going to move file into error location.....");
			sendFilestoErrorLocation(inputFile);
		}*/catch (Exception e) {
			logger.error("[AccountModelFileListener.class] [inside processSourceFile()] [Got Exception. Going to send email..]");
			logger.error(e.toString());
			String subject = "Error during process file : "+inputFile.getName()+" in Data Management.";
			//doFileUnLockCheck(inputFile);
			String bodyContent = e.getMessage();
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("WebcashTSA", "email-simple2", bLocale, subject, bodyContent);
			} catch (MessagingException e1) {
				e1.printStackTrace();
			}
			logger.error("Got Exception...Going to move file into error location.....");
			sendFilestoErrorLocation(inputFile);
			//sending decrypted file into archive location..
			if(keepPlainFile.equals("Y") && decryptFile != null && decryptFile.exists())
				sendFilestoErrorLocation(decryptFile);
			deleteSrouceFile(inputFile, decryptFile);
		}
		doFileUnLockCheck(inputFile);
	}
	
	public String getSuffix_yyyyMMddHHmmss(){
		logger.debug("getSuffix_yyyyMMddHHmmss() Enter");
		String result = new SimpleDateFormat("yyyyMMddHHmmss").format(new DateTime(DateTimeZone.UTC).toDate());
		logger.debug("getSuffix_yyyyMMddHHmmss() Exit");
	    return result;
	}
	
	/**
	 * Method used for checking the naming convention of input file
	 * @param fileName
	 * @return
	 */
	private boolean doFileNameValidation(String fileName) {
		logger.info("[AccountModelFileListener.class] [inside doFileNameValidation()]");
		boolean fileNameValidation = true;
    	if(StringUtils.isNotBlank(fileName)){//returns true if the string not null, its length is greater than 0
    		String tsaId ="";
    		if(StringUtils.contains(fileName, VAL_ACCOUNT_FEED)){
    			tsaId = fileName.substring(0, fileName.indexOf(VAL_ACCOUNT_FEED));
    		}else if(StringUtils.contains(fileName, VAL_MODEL_FEED)){
    			tsaId = fileName.substring(0, fileName.indexOf(VAL_MODEL_FEED));
    		}else if(!StringUtils.contains(fileName, VAL_ACCOUNT_FEED) && !StringUtils.contains(fileName, VAL_MODEL_FEED)){
				fileNameValidation=false;
				logger.info("[AccountModelFileListener.class] [inside doFileNameValidation()] [File format validation failed: File Name does not contains "+VAL_ACCOUNT_FEED+"]");
				throw new RuntimeException("File Format Validation Failed: File Name does not contains TSAIDENTIFIER"+VAL_ACCOUNT_FEED+" or TSAIDENTIFIER"+VAL_MODEL_FEED+" Format.");
			}
    		logger.info("tsaId ="+tsaId);
			if(StringUtils.isBlank(tsaId) ){
				fileNameValidation=false;
				logger.info("[AccountModelFileListener.class] [inside doFileNameValidation()] [File format validation failed: File Name does not contains proper TSAID] [ "+tsaId+" ]");
				throw new RuntimeException("File Format Validation Failed: File Name does not contains TSAIDENTIFIER"+VAL_ACCOUNT_FEED+" or TSAIDENTIFIER"+VAL_MODEL_FEED+" Format.");
				
			}
    	}
    	return fileNameValidation;
    }
	
	/**
	 * Method used for checking file header of AccountInfo file
	 * @param line
	 * @return
	 */
	public boolean validateAccountInfoFileHeader(int noOfFileColumn) {
		logger.info("[AccountModelFileListener.class] [inside validateAccountInfoFileHeader()]");
		boolean rntFlag = true;
		String [] propColNames = accColsHeader.split(",");
		int noOfPropColumn = propColNames.length;
		if(noOfFileColumn != noOfPropColumn){
			//process should fail and send email with file name
			rntFlag = false;
			logger.info("[AccountModelFileListener.class] [inside validateAccountInfoFileHeader()] [Expected number of columns in File is] [ "+noOfPropColumn+" ] [And file has] [ "+noOfFileColumn+" ]");
			headerValidationMessage="Header Validation Failed: Expected number of columns in Account Feed File is "+noOfPropColumn+" but it contains "+noOfFileColumn+".";
		}

		return rntFlag;
	}
	
	/**
	 * Method used for checking file header of ModelInfo file
	 * @param line
	 * @return
	 */
	public boolean validateModelInfoFileHeader(int noOfFileColumn) {
		logger.info("[AccountModelFileListener.class] [inside validateModelInfoFileHeader()]");
		boolean rntFlag = true;
		String [] propColNames = modelColsHeader.split(",");
		int noOfPropColumn = propColNames.length;
		if(noOfFileColumn != noOfPropColumn){
			//process should fail and send email with file name
			rntFlag = false;
			logger.info("[AccountModelFileListener.class] [inside validateModelInfoFileHeader()] [Expected number of columns in File is] [ "+noOfPropColumn+". ] [But it has ] [ "+noOfFileColumn+" ]");
			headerValidationMessage="Header Validation Failed: Expected number of columns in Model Feed File is "+noOfPropColumn+" but it contains "+noOfFileColumn+".";
		}
		
		return rntFlag;
	}
	
	/**
	 * Method used for locking the source file
	 * @param inputFileName
	 * @return
	 */
	private boolean doFileLockCheck(File inputFileName){
		logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()]");
		logger.info("[AccountModelFileListener.class] [inputFile"+inputFileName.getAbsolutePath()+"]");
		try{
			if(daoImpl.checkLockTable(inputFileName.getName().toUpperCase())){
				logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [File is already processed.]");
				logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [Going to skip this input file.]");
				return false;
			}else{
				//do have a lock on input file
				logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [File is not processed yet.]");
				logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [Going to have lock on this file.]");
				int rows = daoImpl.insertInputFileInfoForLock(prepareFileLockBean(inputFileName));
				if(rows>0){
					logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [Got the lock on input file successfully]");
					return true;
				}
				else{
					logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [Didn't get lock on input file]");
					return false;
				}
			}
		}catch(Exception ex){
			logger.info("[FileLockingService.class] [inside doFileLockCheck()] [File is already locked...]");
			return false;
		}
	}
	
	/**
	 * Method used for locking the source file
	 * @param inputFileName
	 * @return
	 */
	private void doFileUnLockCheck(File inputFileName){
		logger.info("[AccountModelFileListener.class] [inside doFileUnLockCheck()]");
		logger.info("[AccountModelFileListener.class] [inputFile:"+inputFileName.getName()+"]");
		//do have a unlock on input file
		logger.info("[AccountModelFileListener.class] [inside doFileLockCheck()] [Going to un lock on this file.]");
		
		int rows = daoImpl.deleteInputFileInfofromLockTbl(prepareFileToUnLockBean(inputFileName));
		
		logger.info("[AccountModelFileListener.class] [inside doFileUnLockCheck()] ["+rows+" input file(s) unlocked.]");
	}
	
	/**
	 * Method used for preparing the FileLock object
	 * @param inputFileName
	 * @return
	 */
	private LockedFiles prepareFileLockBean(File inputFileName){
		logger.info("[AccountModelFileListener.class] [inside prepareFileLockBean()]");
		LockedFiles lock = new LockedFiles();
		lock.setLockedFileName(inputFileName.getName());
		lock.setLockedFileProcessedTime(new Timestamp(new java.util.Date().getTime()));
		lock.setLockedFileSize((double)inputFileName.length());
		lock.setCreatedBy(createdBy);
		lock.setLastModifiedBy(lastModifiedBy);
		logger.info("[AccountModelFileListener.class] [inside prepareFileLockBean()] [returning FileLock object]");
		return lock;
	}
	/**
	 * Method used for preparing the FileLock object
	 * @param inputFileName
	 * @return
	 */
	private LockedFiles prepareFileToUnLockBean(File inputFileName){
		logger.info("[AccountModelFileListener.class] [inside prepareFileToUnLockBean()]");
		LockedFiles lock = new LockedFiles();
		lock.setLockedFileName(inputFileName.getName());
		logger.info("[AccountModelFileListener.class] [inside prepareFileToUnLockBean()] [returning FileLock object]");
		return lock;
	}
	
	/**
	 * Method used for sending source file to Archive location
	 * @param inputFile
	 * @return
	 */
	private boolean sendFilestoArchiveLocation(File inputFile){
		logger.info("[AccountModelFileListener.class] [Inside sendFilestoArchiveLocation()]");
		File archiveFileLocation = new File(archiveLocation+inputFile.getName());
		try {
			Files.copy (inputFile.toPath(), archiveFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			return true;
		} catch (IOException ex) {
			String bodyContent = "Got IOException in copying file to Archive location : ";
			String strStackTrace = ExceptionUtils.getStackTrace(ex);
			logger.info("inputFile.toPath(): "+inputFile.toPath()+"\n"+"errorFileLocation.toPath(): "+archiveFileLocation.toPath()+"\n strStackTrace: "+strStackTrace);
			bodyContent += ex.getMessage()+"\n"+strStackTrace;
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("WebcashTSA", "email-simple2", bLocale, "Error occurred while copying input file to Archive location", bodyContent);
			} catch (MessagingException e1) {
				e1.printStackTrace();
			}
			return false;
		} 
	}
	
	/**
	 * Method used for sending source file to Error location
	 * @param inputFile
	 * @return
	 */
	private boolean sendFilestoErrorLocation(File inputFile){
		logger.info("[AccountModelFileListener.class] [Inside sendFilestoErrorLocation()]");
		File errorFileLocation = new File(errorLocation+inputFile.getName());
		try {
			Files.copy (inputFile.toPath(), errorFileLocation.toPath(), StandardCopyOption.REPLACE_EXISTING);
			return true;
		} catch (IOException ex) {
			String bodyContent = "Got IOException in copying file to NAS location : ";
			String strStackTrace = ExceptionUtils.getStackTrace(ex);
			logger.info("inputFile.toPath(): "+inputFile.toPath()+"\n"+"errorFileLocation.toPath(): "+errorFileLocation.toPath()+"\n strStackTrace: "+strStackTrace);
			bodyContent += ex.getMessage()+"\n"+strStackTrace;
			try {
				if(emailService == null)emailService = new EmailService();
				emailService.sendSimpleMail("WebcashTSA", "email-simple2", bLocale, "Error occurred while copying input file to Error location", bodyContent);
			} catch (MessagingException e1) {
				e1.printStackTrace();
			}
			return false;
		} 
	}
	
	/**
	 * Method used for deleting the source file and decrypted file.
	 * @param srcFile
	 * @param decryptedFile
	 */
	private void deleteSrouceFile(File srcFile, File decryptedFile){
		logger.info("deleteSrouceFile Enter");
		if(srcFile.exists()){
			logger.info("is deleted? "+srcFile.delete());
			logger.info("Source File deleted.");
		}else{
			logger.info(srcFile+" :srcFile does not exists");
		}
		
		if(decryptedFile!= null && decryptedFile.exists()){
			logger.info("is deleted? "+decryptedFile.delete());
			logger.info("PGP decrypted File deleted.");
		}
		logger.info("deleteSrouceFile Exit");
		logger.info("Come to an end of current Batch Process. Listening for Next input file... ");
	}

}
