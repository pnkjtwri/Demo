package com.ge.treasury.payment.datamanagement.model;

import java.sql.Timestamp;
/**
 * Java bean used to map Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO table.
 * @author senthilkumar.raman
 *
 */
public class ModelInfo {
	
	private long modelInfoId;
	private int tsaInstancesId;
	private String tsaInstancesIdentifier;
	private String jobId;//For Temp table
	private String instrumentType;
	private String modelId;
	private String description;
	private String activeInd;
	private String deleteFlag;
	private String duplicateFlag="N";//For Temp table
	private String comments="";//For Temp table
	private String createdBy;
	private Timestamp createdTimeStamp = new Timestamp(new java.util.Date().getTime());
	private String lastModifiedBy;
	private Timestamp lastModifedTimestamp = new Timestamp(new java.util.Date().getTime());
	private String OpCode;//For CompositWritter
	private String fileName;
	
	public ModelInfo(){
		
	}
	
	public long getModelInfoId() {
		return modelInfoId;
	}
	public void setModelInfoId(long modelInfoId) {
		this.modelInfoId = modelInfoId;
	}
	
	public int getTsaInstancesId() {
		return tsaInstancesId;
	}
	public void setTsaInstancesId(int tsaInstancesId) {
		this.tsaInstancesId = tsaInstancesId;
	}
	
	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}

	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}

	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	public String getInstrumentType() {
		return instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}
	
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
	public Timestamp getLastModifedTimestamp() {
		return lastModifedTimestamp;
	}

	public void setLastModifedTimestamp(Timestamp lastModifedTimestamp) {
		this.lastModifedTimestamp = lastModifedTimestamp;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDuplicateFlag() {
		return duplicateFlag;
	}

	public void setDuplicateFlag(String duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getOpCode() {
		return OpCode;
	}

	public void setOpCode(String opCode) {
		OpCode = opCode;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "ModelInfo [tsaInstancesId="+ tsaInstancesId+", tsaInstancesIdentifier="+tsaInstancesIdentifier+", modelId=" + modelId + ", jobId=" + jobId+ ", OpCode=" + OpCode
				+ ", instrumentType=" + instrumentType + ", duplicateFlag=" + duplicateFlag+ ", description=" + description
				+ ", activeInd=" + activeInd + ", deleteFlag=" + deleteFlag+ ", comments=" + comments+ ", fileName=" + fileName
				+ ", createdBy=" + createdBy + ", createdTimeStamp=" + createdTimeStamp
				+ ", lastModifiedBy=" + lastModifiedBy + ", lastModifedTimestamp=" + lastModifedTimestamp+ "]";
	}
	
}
