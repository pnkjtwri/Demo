package com.ge.treasury.payment.datamanagement.batch;

import java.text.SimpleDateFormat;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.listener.ExecutionContextPromotionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.treasury.payment.datamanagement.batch.listeners.ModelInfoJobListener;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.processor.ModelInfoStep2ItemProcessor;
import com.ge.treasury.payment.datamanagement.reader.ModelInfoStep1ItemReader;
import com.ge.treasury.payment.datamanagement.reader.ModelInfoStep2ItemReader;
import com.ge.treasury.payment.datamanagement.writers.ModelInfoStep1ItemWriter;

/**
 * Batch configuration for Model data feed.
 * @author senthilkumar.raman
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfigurationForModelInfo {
	
	@Value("${spring-config.server.node1}")
	private String snode1;
	
	//private String inputFilePath="";
	@Value("${batch.chunk.value}")
	private int chunkValue;
	
    @Autowired 
    private DataSource dataSource;
    @Autowired
    private JobBuilderFactory modelJobBuildFactory;
    @Autowired
	private JobRepository modelJobRepository;
    @Autowired
    private StepBuilderFactory modelStepBuilderFactory;
    @Autowired
    private FlatFileItemWriter<ModelInfo> modelErrorDelegateWriter;
    @Autowired
    private JdbcBatchItemWriter<ModelInfo> modelDelegateForMasterTbl;
    private String jobUniqueId=null;
	
	private static final Logger logger= Logger.getLogger(BatchConfigurationForModelInfo.class);
	
    @Bean
    @StepScope
    public FlatFileItemReader<ModelInfo> modelStep1Reader(@Value("#{jobParameters[inputFileName]}") String inputFilePath)  {
    	logger.debug("modelStep1Reader called");
    	return new ModelInfoStep1ItemReader().getModelInfoDataFromCSVFile(inputFilePath);
    }
    
    @Bean
    public ExecutionContextPromotionListener modelExecutionContextPromotionListener() {
        ExecutionContextPromotionListener executionContextPromotionListener=new ExecutionContextPromotionListener();
        executionContextPromotionListener.setKeys(new String[]{"JOB_ID_KEY"});
        return executionContextPromotionListener;
    }
    
    @Bean
    public ItemWriter<ModelInfo> modelStep1Writer() {
    	logger.debug("modelStep1Writer called");
    	ModelInfoStep1ItemWriter modelFeedStep1writter = new ModelInfoStep1ItemWriter(dataSource);
        return modelFeedStep1writter;
    }
   
    @Bean
    @StepScope
    public JdbcCursorItemReader<ModelInfo> modelStep2Reader(@Value("#{jobParameters[inputFileName]}") String inputFilePath) throws UnexpectedInputException, ParseException, Exception {
    	logger.debug("modelStep2Reader called");
    	logger.debug("jobExecutionContext ['JOB_ID_KEY'] = "+jobUniqueId);
        return new ModelInfoStep2ItemReader().getJdbcCursorDelegate(dataSource,inputFilePath);
    }
    
    @Bean
    public ItemProcessor<ModelInfo, ModelInfo> modelStep2Processor() {
    	logger.debug("modelStep2Processor called");
        return new ModelInfoStep2ItemProcessor();
    }
    
    @Bean 
	 public ClassifierCompositeItemWriter<ModelInfo> createModelClassifier(){
    	logger.debug("createModelClassifier called");
		 ClassifierCompositeItemWriter<ModelInfo> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<ModelInfo>();      
	 	classifierCompositeItemWriter.setClassifier(new Classifier<ModelInfo, ItemWriter<? super ModelInfo>>() {          
	 	    @Override
	 	    public ItemWriter<? super ModelInfo> classify(ModelInfo classifiable) {
	 	        ItemWriter<? super ModelInfo> itemWriter = null;
	 	        if("VALID".equalsIgnoreCase(classifiable.getOpCode())) { // condition
	 	            itemWriter = modelDelegateForMasterTbl; // I use compositeItemWriter to write on A and B
	 	        } else {
	 	            itemWriter = modelErrorDelegateWriter; // I use single JdbcBatchItemWriter to write only on A
	 	        } 
	 	        return itemWriter;
	 	    }
	 	});
	 	
	 	return classifierCompositeItemWriter;
	 }
   
    @Bean
	public ModelInfoJobListener modelInfoJobListener() {
		return new ModelInfoJobListener();
	}
    
	@Bean
    public Job ModelFeedJob() throws UnexpectedInputException, ParseException, Exception {
    	logger.debug("ModelInfoJob() called");
    	return modelJobBuildFactory.get("ModelFeedJob"+getSuffix_yyyyMMddHHmmss())
    						  .incrementer(new RunIdIncrementer())
    						  .listener(modelInfoJobListener())
				    		  .start(modelStep1(modelStep1Reader(""),null, modelStep1Writer()))
				    		  .next (modelStep2(modelStep2Reader(""),modelStep2Processor(),createModelClassifier()))
				    		  .build();
    		
    }
	
    @Bean
    protected Step modelStep1(ItemReader<ModelInfo> modelStep1reader, ItemProcessor<ModelInfo, ModelInfo>
    modelStep1processor, ItemWriter<ModelInfo> modelStep1writer) {
    	logger.debug("modelStep1() called");
	    return modelStepBuilderFactory.get("modelStep1")
	    						 .<ModelInfo, ModelInfo> chunk(chunkValue)
	    						 .reader(modelStep1reader)
	    						 .processor(modelStep1processor)
	    						 .writer(modelStep1writer)
	    						 .allowStartIfComplete(true)
	    						 .build();
    }
    
    @Bean
    protected Step modelStep2(ItemReader<ModelInfo> modelStep2reader, ItemProcessor<ModelInfo, ModelInfo>
    modelStep2processor, ItemWriter<ModelInfo> modelStep2Writer) {
    	logger.debug("modelStep2() called");
    	return modelStepBuilderFactory.get("modelStep2")
    							 .transactionManager(modelInfoTransactionManager())
				    			 .repository(modelJobRepository)
					    		 .<ModelInfo, ModelInfo> chunk(chunkValue) 
							     .reader(modelStep2reader)
							     .processor(modelStep2processor)
							     .writer(modelStep2Writer) 
							     .listener(modelExecutionContextPromotionListener())
							     .stream(modelErrorDelegateWriter)  
							     .allowStartIfComplete(true)
							     .build();
    }

    @Bean
	public PlatformTransactionManager  modelInfoTransactionManager(){
    	logger.debug("modelInfoTransactionManager() called");
		return new DataSourceTransactionManager (dataSource);
	}
    
    public String getSuffix_yyyyMMddHHmmss(){
		logger.debug("getSuffix_yyyyMMddHHmmss() Enter");
		String result = new SimpleDateFormat("yyyyMMddHHmmss").format(new DateTime(DateTimeZone.UTC).toDate());
		logger.debug("getSuffix_yyyyMMddHHmmss() Exit");
	    return result;
	}
   
}
