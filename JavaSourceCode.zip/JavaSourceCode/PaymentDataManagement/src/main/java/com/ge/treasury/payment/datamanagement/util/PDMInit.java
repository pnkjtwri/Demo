package com.ge.treasury.payment.datamanagement.util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;


/**
 * @author senthilkumar.raman
 * Get TSA Instance Identifier from input file name.
 */

public class PDMInit  {
	private  final Logger logger= Logger.getLogger(PDMInit.class);
	private  String inputFilePath;
	private  String tsaInstanceIdentifier="";
	
	public PDMInit(String inputFile){
		inputFilePath=inputFile;
		setTsaInstanceIdentifier(getTSAInstanceIdFromFileName());
	}
	
	public  String getTSAInstanceIdFromFileName(){
		logger.debug("getTSAInstanceIdFromFileName() Enter");
		//Get tsaInstanceIdentifier from input file name
	      Resource inpuResource = new FileSystemResource(inputFilePath);
	      if (inpuResource.exists()){ //check resource actually exists in physical form
	  		String fileName = inpuResource.getFilename();// get the filename for this resource
	  		
				if(StringUtils.isNotBlank(fileName) && fileName.contains("_")){
					tsaInstanceIdentifier = fileName.substring(0, fileName.indexOf("_"));
					
					logger.debug("tsaInstanceIdentifier: "+tsaInstanceIdentifier+" :File Name :"+fileName);
					
				}else{
					logger.debug("File Name "+fileName+" does not contain '_' to identify tsaIdFromFileName.");
				}
	      }
	      logger.debug("getTSAInstanceIdFromFileName() Exit");
	      return tsaInstanceIdentifier;
	}
	
	public  String getTSAInstanceIdFromFileName(String pmInputFilepath){
		logger.debug("getTSAInstanceIdFromFileName() Enter");
		//Get tsaInstanceIdentifier from input file name
		 if(StringUtils.isNotBlank(pmInputFilepath)){
			 Resource inpuResource = new FileSystemResource(pmInputFilepath); 
			 if (inpuResource.exists()){ //check resource actually exists in physical form
			  		String fileName = inpuResource.getFilename();// get the filename for this resource
			  		
						if(StringUtils.isNotBlank(fileName) && fileName.contains("_")){
							tsaInstanceIdentifier = fileName.substring(0, fileName.indexOf("_"));
							
							logger.debug("tsaInstanceIdentifier: "+tsaInstanceIdentifier+" :File Name :"+fileName);
							
						}else{
							logger.debug("File Name "+fileName+" does not contain '_' to identify tsaIdFromFileName.");
						}
			      }
		 }
	      
	      
	      logger.debug("getTSAInstanceIdFromFileName() Exit");
	      return tsaInstanceIdentifier;
	}
	
	public  String getFileName(){
		logger.debug("getFileName() Enter");
		//Get tsaInstanceIdentifier from input file name
		  String fileName = null;
	      Resource inpuResource = new FileSystemResource(inputFilePath);
	      if (inpuResource.exists()){ //check resource actually exists in physical form
	  		fileName = inpuResource.getFilename();// get the filename for this resource
	  		logger.debug("Name of the Input File: "+fileName);
	      }
	      logger.debug("getFileName() Exit");
	      return fileName;
	}
	
	public String getSuffix_yyyyMMddHHmmss(){
		logger.debug("getSuffix_yyyyMMddHHmmss() Enter");
		String result = new SimpleDateFormat("yyyyMMddHHmmss").format(new DateTime(DateTimeZone.UTC).toDate());
		logger.debug("getSuffix_yyyyMMddHHmmss() Exit");
	    return result;
	}
	
	public long getFileSize(String inputFile) throws IOException {
		logger.debug("getFileSize() Enter");
		File file =null;
	    Resource inpuResource = new FileSystemResource(inputFile);
	    if (inpuResource.exists()){ //check resource actually exists in physical form
	    	 file =inpuResource.getFile();
	    	 
	    	 if (!file.exists() || !file.isFile()) {
	   	      logger.debug("File doesn\'t exist");
	   	      return -1;
	   	    }
	    }
	    logger.debug("getFileSize() Exit");
	    return file.length();
	}
	
	public String getReportFileName(String reportDirectory){
		logger.debug("getReportFileName() Enter");
		String inputFileNm = getFileName();
		String reportFileName = (reportDirectory==null?"":reportDirectory);
		inputFileNm = inputFileNm.substring(0, inputFileNm.lastIndexOf("."));
		logger.debug("getReportFileName() inputFileNm="+inputFileNm);
		reportFileName +=  inputFileNm+"_InvalidRecords"+".csv";
		logger.debug("getReportFileName() reportFileName="+reportFileName);
		logger.debug("getReportFileName() Exit");
		return reportFileName;
	}
	
	public String getTsaInstanceIdentifier() {
		return tsaInstanceIdentifier;
	}
	public void setTsaInstanceIdentifier(String tsaInstanceId) {
		tsaInstanceIdentifier = tsaInstanceId;
	}
	
	/*
	* get stack trace logs into string
	* @param Exception e, generated exception object
	* @return String, stack trace message
	*/
	public static String getErrorFormStackTrace(Exception ex){
		StringWriter errors = new StringWriter();
		ex.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
}
