package com.ge.treasury.payment.datamanagement.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.payment.datamanagement.model.ModelInfoPK;
import com.ge.treasury.payment.datamanagement.writers.ModelInfoPKPreparedStatementCreator;

/**
 * Used to check Duplicate record validation at Temp table and Master table level
 * 
 * @author senthilkumar.raman
 *
 */

public class ModelInfoPKMapper implements RowMapper<ModelInfoPK>{
	
	public ModelInfoPK mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
		final Logger logger= Logger.getLogger(ModelInfoPKPreparedStatementCreator.class);
		logger.debug("mapRow() Enter");
		logger.debug("Set value for executed query with resultSet.");
		String modelId = resultSet.getString("MODEL_ID");
		
		ModelInfoPK modelInfoPK = new ModelInfoPK();
		modelInfoPK.setModelId(modelId);
		
		logger.debug("mapRow() Exit");
		return modelInfoPK;
	}


}
