package com.ge.treasury.payment.datamanagement.writers;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;

public class AccountInfoItemPreparedStatementSetter implements ItemPreparedStatementSetter<AccountInfo> {
	
	private static final Logger logger= Logger.getLogger(AccountInfoItemPreparedStatementSetter.class);

	public void setValues(AccountInfo accInfo, PreparedStatement ps) throws SQLException {
		logger.debug("setValues() Enter"); 
		logger.debug("setValues() for TSAId-AcctId:"+accInfo.getTsaInstancesId()+"-"+accInfo.getAccountId()); 
        ps.setInt(1, accInfo.getTsaInstancesId());
        ps.setString(2, accInfo.getAccountId());
        ps.setString(3, accInfo.getAccountNumber());
        ps.setString(4, accInfo.getAccountFormat());
        ps.setString(5, accInfo.getBankId());
        ps.setString(6, accInfo.getBankName());
        ps.setString(7, accInfo.getCountry());
        ps.setString(8, accInfo.getActiveInd());
        ps.setString(9, accInfo.getDeleteFlag());
        ps.setString(10, accInfo.getCreatedBy());
        ps.setTimestamp(11, accInfo.getCreatedTimeStamp());
        ps.setString(12, accInfo.getLastModifiedBy());
        ps.setTimestamp(13, accInfo.getLastModifedTimestamp());
        logger.debug("setValues() Exit"); 
	}
}
