/**
 * 
 */
package com.ge.treasury.payment.datamanagement.writers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ge.treasury.payment.datamanagement.mapper.ModelInfoPKMapper;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.model.ModelInfoPK;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;
import com.ge.treasury.payment.datamanagement.util.PDMInit;

/**
 * @author senthilkumar.raman
 * This class to write valid access records to a file.
 */

public class ModelInfoStep1ItemWriter implements ItemWriter<ModelInfo>, PDMConstants{
	
	private static final Logger logger= Logger.getLogger(ModelInfoStep1ItemWriter.class);
	@Value("${spring-config.server.node1}")
	private String snode1;
	@Value("${model.data.column.length}")
	private String dataLengthDetails;
	
	@Value("${userid.created.by}")
	private String createdBy;
	@Value("${userid.last.modified.by}")
	private String lastModifiedBy;
	@Value("${modelActiveIndicatorFlag}")
	private String modelActiveIndicatorFlag;

	
	@Autowired 
    private JdbcTemplate jdbcTemplate;
	
	private JdbcBatchItemWriter<ModelInfo> delegate;
	private String jobUniqueId=null;
	private String tsaInstanceIdentifier=null;
	private String fileName =null;
	private List<ModelInfoPK> existingModelList = new ArrayList<ModelInfoPK>();
    private ModelInfoPK modelpk = null;
    private List<String> duplicateFoundList = new ArrayList<String>();
    private boolean isMasterDataAvailable = false;
    private List<ModelInfoPK> modelInfoPkDBList = null;
	
	public ModelInfoStep1ItemWriter(DataSource dataSource) {
		logger.debug("ModelInfoWriter constructor Enter");
		logger.debug("Set JDBC delegate");
		delegate=getJdbcBatchDelegate(dataSource);
		logger.debug("ModelInfoWriter constructor Exit");
	}
	
	@BeforeStep
    public void beforeStep(StepExecution stepExecution) {
	  logger.debug("beforeStep() Entered");
      Long  jobId = stepExecution.getJobExecution().getJobId();
      JobParameters jobPm = stepExecution.getJobParameters();
      
      String pminputFilePath = jobPm.getString("inputFileName");
      PDMInit pdmInit = new PDMInit(pminputFilePath);
      this.tsaInstanceIdentifier = pdmInit.getTSAInstanceIdFromFileName();
      
      Resource inpuResource = new FileSystemResource(pminputFilePath);
      this.fileName=inpuResource.getFilename();
      jobUniqueId=jobId+snode1;
      setJobUniqueId(jobUniqueId);
      logger.debug("job id:"+jobUniqueId);
      logger.debug("beforeStep() Exit");
	}
	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution){
		logger.debug("afterStep() Enter");
		stepExecution.getJobExecution().getExecutionContext().put(PDMConstants.JOB_ID_KEY, jobUniqueId);
		existingModelList.clear();
		duplicateFoundList.clear();
		modelInfoPkDBList = null;
		isMasterDataAvailable = false;
		logger.debug("existingAccountList and duplicateFoundList is cleared.");
		logger.debug("afterStep() Exit");
		return ExitStatus.EXECUTING;
	}
	private JdbcBatchItemWriter<ModelInfo> getJdbcBatchDelegate(DataSource dataSource) { 
		logger.debug("getJdbcBatchDelegate() Entered");
		JdbcBatchItemWriter<ModelInfo> jdbcWriter = new JdbcBatchItemWriter<ModelInfo>();
		jdbcWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<ModelInfo>());
	        StringBuilder sb=new StringBuilder(10);
	        sb.append("INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO_TEMP ");
	        sb.append("(JOB_ID, TSAINSTANCE_IDENTIFIER, MODEL_ID, INSTRUMENT_TYPE, DESCRIPTION, ");
	        sb.append("ACTIVE_IND, DELETE_FLAG, DUPLICATE_FLAG, COMMENTS, CREATED_BY, CREATED_TIMESTAMP, ");
	        sb.append("LAST_MODIFIED_BY, LAST_MODIFIED_TIMESTAMP, FILE_NAME ");
	        sb.append(") ");
	        sb.append("VALUES ");
	        sb.append("( ");
	        sb.append("?, ?, ?, ?, ?, ");
	        sb.append("?, ?, ?, ?, ?, ?, ");
	        sb.append("?, ?, ? ");
	        sb.append(") ");
        jdbcWriter.setSql(sb.toString());
        jdbcWriter.setItemPreparedStatementSetter(new ModelInfoTempItemPreparedStatementSetter());
        jdbcWriter.setDataSource(dataSource);
        
       logger.debug("SQL: "+sb.toString());
    	sb=null;
    	logger.debug("getJdbcBatchDelegate() Exit");
        return jdbcWriter; 
	}
	
	@Override
	public void write(List<? extends ModelInfo> items) throws Exception { 
		
		if(logger.isDebugEnabled()){
			logger.debug("write: Enter");
		}
        
        Calendar calendar = Calendar.getInstance();
        java.sql.Timestamp currentTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
        
        //Follow the column order
        String [] modelDataLength = dataLengthDetails.split(",");
        int instrumentTypeLength = getDefinedColumnLength(modelDataLength, 0);
        int modelIdLength = getDefinedColumnLength(modelDataLength, 1);
        int descLength = getDefinedColumnLength(modelDataLength, 2);
        
		int chunkRecord = 0;
		int recordCount = 0;
		for (ModelInfo item : items) { 
			
			item.setJobId(jobUniqueId);
			item.setTsaInstancesIdentifier(StringUtils.isNotBlank(tsaInstanceIdentifier)?tsaInstanceIdentifier:"");
			item.setFileName(StringUtils.isNotBlank(fileName)?fileName:"");
	        item.setActiveInd(modelActiveIndicatorFlag);
	        item.setDeleteFlag(INDICATOR_Y);
	        item.setCreatedBy(createdBy==null?"":createdBy);
	        item.setCreatedTimeStamp(currentTimestampObject);
	        item.setLastModifiedBy(lastModifiedBy==null?"":lastModifiedBy);
	        item.setLastModifedTimestamp(currentTimestampObject);
	        
	        if(logger.isDebugEnabled()){
	        	logger.info("ModelInfo data values (" + item.toString() + ")");
			}
	        
	        //Check file input data's length
	        item.setInstrumentType(checkDataLength(item.getInstrumentType(), instrumentTypeLength));
	        item.setModelId(checkDataLength(item.getModelId(), modelIdLength));
	        item.setDescription(checkDataLength(item.getDescription(), descLength));
	        
	        String modelId = item.getModelId();
	        if(StringUtils.isBlank(modelId)){
				item.setDuplicateFlag(INDICATOR_Y);
				item.setComments("Model Id is required");
				logger.debug("Model Id can not be blank. So it is an invalid record.");
			}else{
				//File Level duplication check
		        boolean result=checkDuplicateRecordsInFile(item,existingModelList);
		        
		        if(result){
		        	modelpk = new ModelInfoPK();
			        modelpk.setTsaInstancesIdentifier(item.getTsaInstancesIdentifier());
			        modelpk.setModelId(item.getModelId());
			        modelpk.setJobId(jobUniqueId);
		        	existingModelList.add(modelpk);
		        }
			}
	        
			chunkRecord++;
		}
		
		if(existingModelList!=null && existingModelList.size()>0){
			//Temp table Level duplication check
			List<ModelInfoPK> modelInfoPkFileList = getTempTableDuplicateRecords(new ModelInfoPK(), existingModelList);
			checkDuplicateRecordsInDB(modelInfoPkFileList,items,PDMConstants.TEMP_TABLE);
			
			//Master table level check
			
			if (!isMasterDataAvailable){//Ensure that we get master data only once, not for each chunk
				modelInfoPkDBList = getMasterTableDuplicateRecords(new ModelInfoPK(), existingModelList);
				isMasterDataAvailable = true;
				logger.debug("isMasterDataAvailable value set to :"+isMasterDataAvailable);
			}
			if(modelInfoPkDBList!=null){
				checkDuplicateRecordsInDB(modelInfoPkDBList,items,PDMConstants.MASTER_TABLE);
			}else{
				logger.debug("modelInfoPkDBList value is null ");
			}
		}
		delegate.write(items);
		recordCount += chunkRecord;
		logger.debug("No of chunkRecord processed: "+recordCount);
		
		//Duplicate found details
		if(duplicateFoundList!=null&duplicateFoundList.size()>0){
			Iterator<String> itr = duplicateFoundList.iterator();
			logger.debug("Duplicate Record found details:");
			while(itr.hasNext()){
	           logger.debug(itr.next());
	        }
		}else{
			logger.debug("Duplicate Records not found.");
		}
		
		
		if(logger.isDebugEnabled()){
			logger.debug("write: Exit");
		}
	}
	
	//Get column length based on properties value.
	private int getDefinedColumnLength(String [] modelDataLength, int colNum){
		int length=0;
		if(modelDataLength != null){
			String [] currentColumn = modelDataLength[colNum].split("=");
			length = Integer.parseInt(currentColumn[1]);
		}
		return length;
	}
	
	//If data length is more than expected length, get truncate the data to expected length.
	private String checkDataLength(String data, int expectedLength){
		String resultData ="";
		if (StringUtils.isNotBlank(data)){
			
			if(expectedLength < data.length()){
				resultData = data.substring(0, expectedLength);
			}else{
				resultData = data;
			}
				
		}
		return resultData;
	}
	
	private boolean checkDuplicateRecordsInFile(ModelInfo item,List<ModelInfoPK> existingModelList){
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInFile() Enter");
		}
		boolean result=true;
		for (ModelInfoPK tempModelPK : existingModelList) {
        	String tempTSAid = tempModelPK.getTsaInstancesIdentifier();
        	String tempModelId = tempModelPK.getModelId();
        	String currtTSAid = item.getTsaInstancesIdentifier();
        	String currtModelId = item.getModelId();
        	if(tempTSAid.equalsIgnoreCase(currtTSAid) && tempModelId.equalsIgnoreCase(currtModelId)){
        		duplicateFoundList.add("Batch Level: "+currtTSAid+"-"+currtModelId);
        		item.setDuplicateFlag(INDICATOR_Y);
	        	item.setComments("Duplicate Found in batch");
	        	result=false;
	        	break;
        	} else {
        		result=true;
	        }
		}
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInFile() Exit");
		}
		return result;
	}
	
	private List<ModelInfoPK> getTempTableDuplicateRecords(ModelInfoPK modelInfoPK, List<ModelInfoPK> existingModelList){
		if(logger.isDebugEnabled()){
			logger.debug("getTempTableDuplicateRecords() Enter");
		}
		ModelInfoPKPreparedStatementCreator creator = new ModelInfoPKPreparedStatementCreator
																(modelInfoPK, existingModelList,PDMConstants.TEMP_TABLE);
		List<ModelInfoPK> modelInfoPkList = jdbcTemplate.query(creator, new ModelInfoPKMapper());
		if(logger.isDebugEnabled()){
			logger.debug("getTempTableDuplicateRecords() Enter");
		}
		return modelInfoPkList;
	}
	
	private List<ModelInfoPK> getMasterTableDuplicateRecords(ModelInfoPK modelInfoPK, List<ModelInfoPK> existingModelList){
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Enter");
		}
		ModelInfoPKPreparedStatementCreator creator = new ModelInfoPKPreparedStatementCreator
																(modelInfoPK, existingModelList,PDMConstants.MASTER_TABLE);
		List<ModelInfoPK> modelInfoPkList = jdbcTemplate.query(creator, new ModelInfoPKMapper());
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Exit");
		}
		return modelInfoPkList;
	}
	
	private void checkDuplicateRecordsInDB(List<ModelInfoPK> modelInfoPkList, List<? extends ModelInfo> items, String level){
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInDB() Enter");
		}
		if(modelInfoPkList!=null&&modelInfoPkList.size()>0){
			logger.debug("No of record found in "+level+" table: "+modelInfoPkList.size());
			//Set Duplicate Flag and comments for duplicate records found in DB.
			for (ModelInfoPK modelInfoPK : modelInfoPkList){
				String tempModelId = modelInfoPK.getModelId();
				
				for (ModelInfo item : items) {
					String currtModelId = item.getModelId();
					if(tempModelId.equalsIgnoreCase(currtModelId)){
						duplicateFoundList.add(level+" table Level: "+currtModelId);
						item.setDuplicateFlag(INDICATOR_Y);
						if(PDMConstants.TEMP_TABLE.equalsIgnoreCase(level)){
							item.setComments("Duplicate Found in batch");
						}else{
							item.setComments("Duplicate Found in "+level+" Table");
						}
					}
				}
			}
		}else{
			logger.debug(level+" table does not contains any duplicate record.");
		}
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInDB() Exit");
		}
	}
	public String getJobUniqueId() {
		return jobUniqueId;
	}
	public void setJobUniqueId(String jobUniqueId) {
		this.jobUniqueId = jobUniqueId;
	}

}
