package com.ge.treasury.payment.datamanagement.model;

import java.util.Date;
/**
 * Java bean used to map Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO_TEMP table
 * @author senthilkumar.raman
 *
 */

public class AccountInfoTempTbl {
	
	private int accountInfoTempId;
	private int jobId;
	private int tsaInstancesId;
	private String accountId;
	private String accountNumber;
	private String accountFormat;
	private String bankId;
	private String bankName;
	private String country;
	private String activeInd;
	private String deleteFlag;
	private String duplicateFlag;
	private String comments;
	private String createdBy;
	private Date createdTimeStamp;
	private String lastModifiedBy;
	private String lastModifedTimestamp;
	
	public AccountInfoTempTbl(){
		
	}
	
	public int getAccountInfoTempId() {
		return accountInfoTempId;
	}



	public void setAccountInfoTempId(int accountInfoTempId) {
		this.accountInfoTempId = accountInfoTempId;
	}



	public int getJobId() {
		return jobId;
	}



	public void setJobId(int jobId) {
		this.jobId = jobId;
	}



	public int getTsaInstancesId() {
		return tsaInstancesId;
	}



	public void setTsaInstancesId(int tsaInstancesId) {
		this.tsaInstancesId = tsaInstancesId;
	}



	public String getAccountId() {
		return accountId;
	}



	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}



	public String getAccountNumber() {
		return accountNumber;
	}



	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getAccountFormat() {
		return accountFormat;
	}



	public void setAccountFormat(String accountFormat) {
		this.accountFormat = accountFormat;
	}
	
	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getActiveInd() {
		return activeInd;
	}

	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getDuplicateFlag() {
		return duplicateFlag;
	}

	public void setDuplicateFlag(String duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifedTimestamp() {
		return lastModifedTimestamp;
	}

	public void setLastModifedTimestamp(String lastModifedTimestamp) {
		this.lastModifedTimestamp = lastModifedTimestamp;
	}


	@Override
	public String toString() {
		return "AccountInfoTempTbl [accountInfoTempId=" + accountInfoTempId + ", tsaInstancesId=" + tsaInstancesId
				+ ", jobId=" + jobId 
				+ ", accountId=" + accountId + ", accountNumber=" + accountNumber
				+ ", accountFormat=" + accountFormat + ", bankId=" + bankId
				+ ", bankName=" + bankName + ", country=" + country
				+ ", activeInd=" + activeInd + ", deleteFlag=" + deleteFlag
				+ ", duplicateFlag=" + duplicateFlag + ", comments=" + comments 
				+ ", createdBy=" + createdBy + ", createdTimeStamp=" + createdTimeStamp
				+ ", lastModifiedBy=" + lastModifiedBy + ", lastModifedTimestamp=" + lastModifedTimestamp+ "]";
	}
	
}
