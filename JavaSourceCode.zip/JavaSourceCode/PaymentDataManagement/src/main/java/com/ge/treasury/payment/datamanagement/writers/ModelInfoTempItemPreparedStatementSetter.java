package com.ge.treasury.payment.datamanagement.writers;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;

public class ModelInfoTempItemPreparedStatementSetter implements ItemPreparedStatementSetter<ModelInfo> {
	
	private static final Logger logger= Logger.getLogger(ModelInfoTempItemPreparedStatementSetter.class);

	public void setValues(ModelInfo modelInfo, PreparedStatement ps) throws SQLException {
		logger.debug("setValues() Enter"); 
		logger.debug("setValues() for ModelId:"+modelInfo.getModelId());
		ps.setString(1, modelInfo.getJobId());
		ps.setString(2, modelInfo.getTsaInstancesIdentifier());
        ps.setString(3, modelInfo.getModelId());
        ps.setString(4, modelInfo.getInstrumentType());
        ps.setString(5, modelInfo.getDescription());
        ps.setString(6, modelInfo.getActiveInd());
        ps.setString(7, modelInfo.getDeleteFlag());
        ps.setString(8, modelInfo.getDuplicateFlag());
        ps.setString(9, modelInfo.getComments());
        ps.setString(10, modelInfo.getCreatedBy());
        ps.setTimestamp(11, modelInfo.getCreatedTimeStamp());
        ps.setString(12, modelInfo.getLastModifiedBy());
        ps.setTimestamp(13, modelInfo.getLastModifedTimestamp());
        ps.setString(14, modelInfo.getFileName());
        logger.debug("setValues() Exit"); 
	}
}
