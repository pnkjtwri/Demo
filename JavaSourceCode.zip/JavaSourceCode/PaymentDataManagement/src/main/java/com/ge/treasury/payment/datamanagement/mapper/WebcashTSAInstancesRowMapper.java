package com.ge.treasury.payment.datamanagement.mapper;

/**
 * Class designed for mapping the resultset data into Object(AccountInfoBean)
 * @author Pankaj1.Tiwari
 */

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.datamanagement.model.WebcashTSAinstances;

@SuppressWarnings("rawtypes")
@Component
public class WebcashTSAInstancesRowMapper implements RowMapper {

	private Logger logger = Logger.getLogger(WebcashTSAInstancesRowMapper.class);
	
	/**
	 * Method used for mapping the resultset data into AccountInfoBean object
	 */
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		logger.info("[WebcashTSAInstancesRowMapper.class] [Inside mapRow()] [Going to map Resultset Data into WebcashTSAinstances..]");
		WebcashTSAinstances tsaInstanceBean = new WebcashTSAinstances();
		tsaInstanceBean.setTsaInstancesId(rs.getInt("TSAINSTACES_ID"));
		tsaInstanceBean.setTsaInstancesIdentifier(rs.getString("TSAINSTANCE_IDENTIFIER"));
		tsaInstanceBean.setPfiLocation(rs.getString("PFI_LOCATION"));
		tsaInstanceBean.setPfiRespFilesLocation(rs.getString("PFI_RESP_FILES_LOCATION"));
		tsaInstanceBean.setPfiPublicKeyPath(rs.getString("PFI_PUBLIC_KEY_PATH"));
		tsaInstanceBean.setPfiRespFilePrivateKeyPath(rs.getString("PFI_RESP_FILE_PRIVATE_KEY_PATH"));
		tsaInstanceBean.setDeleteFlag(rs.getString("DELETE_FLAG"));
		tsaInstanceBean.setHostName(rs.getString("HOST_NAME"));
		tsaInstanceBean.setUserId(rs.getString("USER_ID"));
		tsaInstanceBean.setCreatedBy(rs.getString("CREATED_BY"));
		tsaInstanceBean.setCreatedTimeStamp(rs.getDate("CREATED_TIMESTAMP"));
		tsaInstanceBean.setLastModifiedBy(rs.getString("LAST_MODIFIED_BY"));
		tsaInstanceBean.setLastModifedTimestamp(rs.getDate("LAST_MODIFIED_TIMESTAMP"));
		logger.info("[WebcashTSAInstancesRowMapper.class] [Inside mapRow()] [Going to return WebcashTSAinstances..]");
		return tsaInstanceBean;
	}
}
