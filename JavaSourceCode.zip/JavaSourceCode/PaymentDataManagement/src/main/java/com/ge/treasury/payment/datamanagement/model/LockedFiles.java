
package com.ge.treasury.payment.datamanagement.model;

import java.sql.Timestamp;

public class LockedFiles {

	private String lockedFileName;
	private Timestamp lockedFileProcessedTime;
	private double lockedFileSize;
	private String createdBy;
	private Timestamp createdTimeStamp = new Timestamp(new java.util.Date().getTime());
	private String lastModifiedBy;
	private Timestamp lastModifedTimestamp = new Timestamp(new java.util.Date().getTime());
	
	
	public String getLockedFileName() {
		return lockedFileName;
	}
	public void setLockedFileName(String lockedFileName) {
		this.lockedFileName = lockedFileName;
	}
	public Timestamp getLockedFileProcessedTime() {
		return lockedFileProcessedTime;
	}
	public void setLockedFileProcessedTime(Timestamp lockedFileProcessedTime) {
		this.lockedFileProcessedTime = lockedFileProcessedTime;
	}
	public double getLockedFileSize() {
		return lockedFileSize;
	}
	public void setLockedFileSize(double lockedFileSize) {
		this.lockedFileSize = lockedFileSize;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifedTimestamp() {
		return lastModifedTimestamp;
	}
	public void setLastModifedTimestamp(Timestamp lastModifedTimestamp) {
		this.lastModifedTimestamp = lastModifedTimestamp;
	}
	
}

