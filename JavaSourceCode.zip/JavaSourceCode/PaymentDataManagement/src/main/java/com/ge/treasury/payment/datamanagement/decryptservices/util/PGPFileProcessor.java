package com.ge.treasury.payment.datamanagement.decryptservices.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.bouncycastle.openpgp.PGPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ge.treasury.payment.datamanagement.decryptservices.exception.FileEncryptionDecryptionException;

@Component
public class PGPFileProcessor {
	private static final Logger logger = LoggerFactory.getLogger(PGPFileProcessor.class);
    private StringBuffer decryptedData=new StringBuffer();

        /**
     * 
     * @return
     * @throws IOException 
     * @throws PGPException 
     * @throws Exception
     */
    public boolean decrypt(File inputFileName, String outputFileName, String secretKeyFileName, String passphrase) throws FileEncryptionDecryptionException  {
    	logger.info("[PGPFileProcessor] - decrypt: entered");
    	FileInputStream in = null;
    	FileInputStream keyIn = null;
    	try{
	        in = new FileInputStream(inputFileName);  
	        keyIn = new FileInputStream(secretKeyFileName);
	        PGPUtils.decryptFile(in, decryptedData, keyIn, passphrase.toCharArray(),outputFileName);
	        keyIn.close();
	        in.close();
    	}catch(Exception e){
    		logger.error("[PGPFileProcessor] - Decryption Failed !!");
    		logger.error("[PGPFileProcessor] - "+PaymentDecryptionUtility.getErrorFormStackTrace(e));
    		//logger.error("[PGPFileProcessor] - Going to delete encrypted file - "+inputFileName.getName());
    		try{
    			if(keyIn != null){
    				keyIn.close();
    			}
    			if(in != null){
    				in.close();
    			}
    		}catch(Exception ex){
    			logger.error("[PGPFileProcessor] - Error closing Stream");
    			logger.error("[PGPFileProcessor] - "+PaymentDecryptionUtility.getErrorFormStackTrace(ex));
    		}
    		//PaymentDecryptionUtility.deleteFile(inputFileName);
            throw new FileEncryptionDecryptionException("Decryption process is failed.",e);
    	}
    	finally{
    		try{
    			if(keyIn != null){
    				keyIn.close();
    			}
    			if(in != null){
    				in.close();
    			}
    		}catch(Exception e){
    			logger.error("[PGPFileProcessor] - Error closing Stream");
    		}
    	}
        
        logger.info("[PGPFileProcessor] - decrypt: exit");
        return true;
    } 

    /**
	 * @return the decryptedData
	 */
	public StringBuffer getDecryptedData() {
		return decryptedData;
	}

	/**
	 * @param decryptedData the decryptedData to set
	 */
	public void setDecryptedData(StringBuffer decryptedData) {
		this.decryptedData = decryptedData;
	}

}
