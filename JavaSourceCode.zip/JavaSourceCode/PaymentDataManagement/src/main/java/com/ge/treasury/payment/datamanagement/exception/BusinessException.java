package com.ge.treasury.payment.datamanagement.exception;

import org.springframework.beans.factory.annotation.Value;

import com.ge.treasury.payment.datamanagement.util.PDMConstants;

/**
 * This class handles all the Business exceptions for the PaymentDataManagment application
 * @author senthilkumar.raman
 */

public class BusinessException extends RuntimeException implements PDMConstants {
	
	private static final long serialVersionUID = -6397562910889452660L;
	private int errorCode = PDMConstants.BUSINESS_ERROR_CODE;
	@Value("${error.message.100}")
	private String errorMessage100;
	
	private String errorMessage;
	
	
	/**
	 * Constructor with no arguments
	 */
	public BusinessException() {
		super();
	}
	
	/**
	 * Constructor with only errorCode as argument
	 * @param errorCode
	 */
	public BusinessException(int errorCode) {
		super();
		this.setErrorCode(errorCode);
		if(errorCode==100){
			this.setErrorMessage(errorMessage100);
		}
	}
	
	/**
	 * Constructor with only message as argument
	 * @param message
	 */
	public BusinessException(String message) {
		super(message);
		this.errorMessage=message;
	}
	
	public BusinessException(Throwable cause) {
        super(cause);
    }
	
	@Override
    public String toString() {
        return errorMessage;
    }
	@Override
    public String getMessage() {
        return errorMessage;
    }

	
	/**
	 * Constructor with both errorCode and message as argument
	 * @param errorCode
	 */
	public BusinessException(int errorCode, String message) {
		super();
		this.setErrorCode(errorCode);
		this.setErrorMessage(message);
	}
	/**
	 * @return the errorCode
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public final void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
}

