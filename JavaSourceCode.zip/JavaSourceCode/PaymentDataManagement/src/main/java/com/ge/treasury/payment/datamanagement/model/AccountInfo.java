package com.ge.treasury.payment.datamanagement.model;

import java.sql.Timestamp;

/**
 * Java Bean for Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO table
 * @author senthilkumar.raman
 *
 */
public class AccountInfo {
	
	private int accountInfoId;
	private int accountInfoTempId;//For Temp table
	private String jobId;//For Temp table
	private int tsaInstancesId;// For Master table
	private String tsaInstancesIdentifier;
	private String accountId;
	private String accountNumber;
	private String accountFormat;
	private String bankId;
	private String bankName;
	private String country;
	private String activeInd;
	private String deleteFlag;
	private String duplicateFlag="N";//For Temp table
	private String comments="No comments";//For Temp table
	private String createdBy;
	private Timestamp createdTimeStamp = new Timestamp(new java.util.Date().getTime());
	private String lastModifiedBy;
	private Timestamp lastModifedTimestamp = new Timestamp(new java.util.Date().getTime());
	private String OpCode;//For CompositWritter
	private String actionInd;
	private String fileName;
	
	public AccountInfo(){
		
	}
	
	public AccountInfo(String tsaInstancesIdentifier, String accountId){
		this.tsaInstancesIdentifier=tsaInstancesIdentifier;
		this.accountId=accountId;
	}
	
	public int getAccountInfoId() {
		return accountInfoId;
	}
	public void setAccountInfoId(int accountInfoId) {
		this.accountInfoId = accountInfoId;
	}

	public int getTsaInstancesId() {
		return tsaInstancesId;
	}

	public void setTsaInstancesId(int tsaInstancesId) {
		this.tsaInstancesId = tsaInstancesId;
	}

	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}

	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}

	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getAccountFormat() {
		return accountFormat;
	}
	public void setAccountFormat(String accountFormat) {
		this.accountFormat = accountFormat;
	}
	

	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getActiveInd() {
		return activeInd;
	}
	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}
	
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
	public Timestamp getLastModifedTimestamp() {
		return lastModifedTimestamp;
	}

	public void setLastModifedTimestamp(Timestamp lastModifedTimestamp) {
		this.lastModifedTimestamp = lastModifedTimestamp;
	}

	public int getAccountInfoTempId() {
		return accountInfoTempId;
	}

	public void setAccountInfoTempId(int accountInfoTempId) {
		this.accountInfoTempId = accountInfoTempId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getDuplicateFlag() {
		return duplicateFlag;
	}

	public void setDuplicateFlag(String duplicateFlag) {
		this.duplicateFlag = duplicateFlag;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public String getOpCode() {
		return OpCode;
	}

	public void setOpCode(String opCode) {
		OpCode = opCode;
	}

	public String getActionInd() {
		return actionInd;
	}

	public void setActionInd(String actionInd) {
		this.actionInd = actionInd;
	}
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "AccountInfo [accountInfoId=" + accountInfoId + ", jobId=" + jobId+ ", fileName=" + fileName
				+ ", accountInfoTempId=" + accountInfoTempId + ", duplicateFlag=" + duplicateFlag+ ", comments=" + comments
				+ ", tsaInstancesIdentifier=" + tsaInstancesIdentifier+", accountId=" + accountId + ", accountNumber=" + accountNumber
				+ ", accountFormat=" + accountFormat +  ", actionInd=" + actionInd
				+ ", bankId=" + bankId+ ", bankName=" + bankName + ", country=" + country
				+ ", activeInd=" + activeInd + ", deleteFlag=" + deleteFlag
				+ ", createdBy=" + createdBy + ", createdTimeStamp=" + createdTimeStamp
				+ ", lastModifiedBy=" + lastModifiedBy + ", lastModifedTimestamp=" + lastModifedTimestamp+ "]";
	}
	
}
