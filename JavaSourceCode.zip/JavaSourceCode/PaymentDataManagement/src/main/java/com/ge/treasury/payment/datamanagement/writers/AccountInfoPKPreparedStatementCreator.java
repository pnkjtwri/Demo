package com.ge.treasury.payment.datamanagement.writers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementCreator;

import com.ge.treasury.payment.datamanagement.model.AccountInfoPK;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;

public class AccountInfoPKPreparedStatementCreator implements PreparedStatementCreator,PDMConstants {
	
	private static final Logger logger= Logger.getLogger(AccountInfoPKPreparedStatementCreator.class);
	@SuppressWarnings("unused")
	private AccountInfoPK acctInfoPK;
	private List<AccountInfoPK> existingAccountList;
	private String level;
	
	public AccountInfoPKPreparedStatementCreator(AccountInfoPK accounttInfoPK, List<AccountInfoPK> existingAccountList, String lvl){
		logger.info("AccountInfoPKPreparedStatementCreator constructor Enter");
		this.acctInfoPK = accounttInfoPK;
		this.existingAccountList=existingAccountList;
		this.level=lvl;
		logger.info("AccountInfoPKPreparedStatementCreator constructor Exit");
	}
	
	public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
		logger.info("createPreparedStatement() Enter");
		String SELECT_QUERY =null;
		
		if(level!=null && (PDMConstants.MASTER_TABLE).equalsIgnoreCase(level)){
			SELECT_QUERY=createMasterTableQuery();
		}else if(level!=null &&(PDMConstants.TEMP_TABLE).equalsIgnoreCase(level)){
			SELECT_QUERY=createTempTableQuery();
		}else if(level!=null &&(PDMConstants.UPDATE_TABLE).equalsIgnoreCase(level)){
			SELECT_QUERY=createQueryForUpdateRecords();
		}else{
			logger.debug("Invalid level value. SELECT_QUERY value is null.");
		}
		PreparedStatement ps = connection.prepareStatement(SELECT_QUERY);
		
		//Set Where condition value dynamically
		
		if(level!=null &&(PDMConstants.TEMP_TABLE).equalsIgnoreCase(level)){
			
	        ps.setString(1, existingAccountList.get(0).getTsaInstancesIdentifier());
	        ps.setString(2, existingAccountList.get(0).getJobId());

		}
		
		if(level!=null && (PDMConstants.UPDATE_TABLE).equalsIgnoreCase(level)){
			
			String tsaIndentifier = existingAccountList.get(0).getTsaInstancesIdentifier();
			ps.setString(1, tsaIndentifier);
			
		}
		
		logger.info("createPreparedStatement() Exit");
		return ps;
	}
	
	/*Expected Query with sample data
	 * SELECT TSAINSTANCE_IDENTIFIER,ACCOUNT_ID FROM
	 Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO_TEMP
	 WHERE TSAINSTANCE_IDENTIFIER = ? 
	 AND 
	 JOB_ID = ? ;*/
	
	//Create PreparedStatement Query dynamically for Temp table validation.
	private static String createTempTableQuery() {
		logger.info("createTempTableQuery() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("SELECT ");
        sbQuery.append("TSAINSTANCE_IDENTIFIER, ");
        sbQuery.append("ACCOUNT_ID ");
        sbQuery.append("FROM ");
        sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO_TEMP ");
        sbQuery.append("WHERE ");
        sbQuery.append("TSAINSTANCE_IDENTIFIER = ? ");
        sbQuery.append("AND ");
        sbQuery.append("JOB_ID = ? ");
        
        String tempTableQuery = sbQuery.toString();
        sbQuery=null;
        logger.debug("tempTableQuery: "+tempTableQuery);
        logger.info("createTempTableQuery() Exit");
        return tempTableQuery;
    }
	
	 /*Expected Query with sample data
	  * SELECT INFO.ACCOUNT_ID FROM 
	 Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO INFO ;*/
	
	//Create PreparedStatement Query dynamically for Master table validation.
	private static String createMasterTableQuery() {
		logger.info("createMasterTableQuery() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("SELECT ");
        sbQuery.append("INFO.ACCOUNT_ID ");
        sbQuery.append("FROM ");
        sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO INFO ");
        
        String masterTableQuery = sbQuery.toString();
        sbQuery=null;
        logger.debug("masterTableQuery: "+masterTableQuery);
        logger.info("createMasterTableQuery() Exit");
        return masterTableQuery;
    }
	
	private static String createQueryForUpdateRecords() {
		logger.info("createQueryForUpdateRecords() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("SELECT ");
        sbQuery.append("INFO.ACCOUNT_ID ");
        sbQuery.append("FROM ");
        sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO INFO ");
        sbQuery.append("WHERE ");
        sbQuery.append("INFO.TSAINSTANCES_ID = (SELECT W.TSAINSTACES_ID FROM Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES W ");
        sbQuery.append("WHERE W.TSAINSTANCE_IDENTIFIER = ? ) ");
        String queryForUpdateRecords = sbQuery.toString();
        sbQuery=null;
        logger.debug("queryForUpdateRecords: "+queryForUpdateRecords);
        logger.info("createQueryForUpdateRecords() Exit");
        return queryForUpdateRecords;
    }
	
}
