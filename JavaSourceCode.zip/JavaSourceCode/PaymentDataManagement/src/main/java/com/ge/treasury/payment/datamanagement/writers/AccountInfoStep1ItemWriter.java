/**
 * 
 */
package com.ge.treasury.payment.datamanagement.writers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ge.treasury.payment.datamanagement.mapper.AccountInfoPKMapper;
import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.model.AccountInfoPK;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;
import com.ge.treasury.payment.datamanagement.util.PDMInit;

/**
 * @author senthilkumar.raman
 * This class to write valid access records to a file.
 */

public class AccountInfoStep1ItemWriter implements ItemWriter<AccountInfo>, PDMConstants{
	
	private static final Logger logger= Logger.getLogger(AccountInfoStep1ItemWriter.class);
	@Value("${spring-config.server.node1}")
	private String snode1;
	
	@Value("${userid.created.by}")
	private String createdBy;
	@Value("${userid.last.modified.by}")
	private String lastModifiedBy;
	@Value("${account.data.column.length}")
	private String dataLengthDetails;
	@Value("${accountActiveIndicatorFlag}")
	private String accountActiveIndicatorFlag;
	
	@Autowired 
    private JdbcTemplate jdbcTemplate;
	
	
	private JdbcBatchItemWriter<AccountInfo> delegate;
	private String jobUniqueId=null;
	private String fileName=null;
	private String tsaInstanceIdentifier=null;
	private List<AccountInfoPK> existingAccountList = new ArrayList<AccountInfoPK>();
	private List<AccountInfoPK> updateAccountList = null;
    private AccountInfoPK accpk = null;
    private AccountInfoPK updateAccpk = null;
    private List<String> duplicateFoundList = new ArrayList<String>();
    private boolean isMasterDataAvailable = false;
    List<AccountInfoPK> acctInfoPkDBList = null;
	
	public AccountInfoStep1ItemWriter(DataSource dataSource) {
		logger.debug("AccountInfoWriter constructor Enter");
		logger.debug("Set JDBC delegate");
		delegate=getJdbcBatchDelegate(dataSource);
		logger.debug("AccountInfoWriter constructor Exit");
	}
	
	@BeforeStep
    public void beforeStep(StepExecution stepExecution) {
	  logger.debug("beforeStep() Entered");
     
	  Long  jobId = stepExecution.getJobExecution().getJobId();
      JobParameters jobPm = stepExecution.getJobParameters();
      
      String pminputFilePath = jobPm.getString("inputFileName");
      PDMInit pdmInit = new PDMInit(pminputFilePath);
      this.tsaInstanceIdentifier = pdmInit.getTSAInstanceIdFromFileName();
      
      Resource inpuResource = new FileSystemResource(pminputFilePath);
      this.fileName=inpuResource.getFilename();
      
      jobUniqueId=jobId+snode1;
      setJobUniqueId(jobUniqueId);
      logger.debug("job id:"+jobUniqueId);
      logger.debug("beforeStep() Exit");
	}
	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution){
		logger.debug("afterStep() Entered");
		stepExecution.getJobExecution().getExecutionContext().put(PDMConstants.JOB_ID_KEY, jobUniqueId);
		logger.debug("Set Job Id in JobExecution context : JOB_ID_KEY="+jobUniqueId);
		existingAccountList.clear();
		duplicateFoundList.clear();
		acctInfoPkDBList = null;
		isMasterDataAvailable=false;
		logger.debug("existingAccountList and duplicateFoundList is cleared.");
		logger.debug("afterStep() Exit");
		return ExitStatus.EXECUTING;
	}
	private JdbcBatchItemWriter<AccountInfo> getJdbcBatchDelegate(DataSource dataSource) { 
		logger.debug("getJdbcBatchDelegate() Entered");
		JdbcBatchItemWriter<AccountInfo> jdbcWriter = new JdbcBatchItemWriter<AccountInfo>();
		jdbcWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<AccountInfo>());
	        StringBuilder sb=new StringBuilder(10);
	        sb.append("INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO_TEMP ");
	        sb.append("(JOB_ID, TSAINSTANCE_IDENTIFIER, ACCOUNT_ID, ACCOUNT_NUMBER, ACCOUNT_FORMAT, ");
	        sb.append("BANK_ID, BANK_NAME, COUNTRY, ");
	        sb.append("ACTIVE_IND, DELETE_FLAG, DUPLICATE_FLAG, COMMENTS, CREATED_BY, CREATED_TIMESTAMP, ");
	        sb.append("LAST_MODIFIED_BY, LAST_MODIFIED_TIMESTAMP, ACTION_IND, FILE_NAME ");
	        sb.append(") ");
	        sb.append("VALUES ");
	        sb.append("( ?, ?, ?, ?, ?, ");
	        sb.append("?, ?, ?, ");
	        sb.append("?, ?, ?, ?, ?, ?, ");
	        sb.append("?, ?, ?, ? ) ");
        jdbcWriter.setSql(sb.toString());
        jdbcWriter.setItemPreparedStatementSetter(new AccountInfoTempItemPreparedStatementSetter());
        jdbcWriter.setDataSource(dataSource);
        
       logger.debug("SQL: "+sb.toString());
    	sb=null;
    	logger.debug("getJdbcBatchDelegate() Exit");
        return jdbcWriter; 
	}
	
	@Override
	public void write(List<? extends AccountInfo> items) throws Exception { 
		
		if(logger.isDebugEnabled()){
			logger.debug("write: Enter");
		}
		logger.debug("No of items found in write() is "+items==null?"0":items.size());
		
        Calendar calendar = Calendar.getInstance();
        java.sql.Timestamp currentTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());
        //Follow the column order
        String [] acctDataLength = dataLengthDetails.split(",");
        int accountIdLength = getDefinedColumnLength(acctDataLength, 0);
        int accountNumberLength = getDefinedColumnLength(acctDataLength, 1);
        int accountFormatLength = getDefinedColumnLength(acctDataLength, 2);
        int bankIdLength = getDefinedColumnLength(acctDataLength, 3);
        int bankNameLength = getDefinedColumnLength(acctDataLength, 4);
        int countryLength = getDefinedColumnLength(acctDataLength, 5);
        int actionIndicatorLength = getDefinedColumnLength(acctDataLength, 6);
        
		int chunkRecord = 0;
		int recordCount = 0;
		for (AccountInfo item : items) { 
			
			item.setJobId(jobUniqueId);
			item.setTsaInstancesIdentifier(StringUtils.isNotBlank(tsaInstanceIdentifier)?tsaInstanceIdentifier:"");
			item.setFileName(StringUtils.isNotBlank(fileName)?fileName:"");
	        item.setActiveInd(accountActiveIndicatorFlag); 
	        item.setDeleteFlag(INDICATOR_Y);
	        item.setCreatedBy(createdBy==null?"":createdBy);
	        item.setCreatedTimeStamp(currentTimestampObject);
	        item.setLastModifiedBy(lastModifiedBy==null?"":lastModifiedBy);
	        item.setLastModifedTimestamp(currentTimestampObject);
	        
	        //Check file input data's length
	        item.setAccountId( checkDataLength(item.getAccountId(), accountIdLength));
	        item.setAccountNumber( checkDataLength(item.getAccountNumber(), accountNumberLength));
	        item.setAccountFormat( checkDataLength(item.getAccountFormat(), accountFormatLength));
	        item.setBankId( checkDataLength(item.getBankId(), bankIdLength));
	        item.setBankName( checkDataLength(item.getBankName(), bankNameLength));
	        item.setCountry( checkDataLength(item.getCountry(), countryLength));
	        item.setActionInd( checkDataLength(item.getActionInd(), actionIndicatorLength));
	        
	        //Create List which contains only records for update in this batch file.
	        if(StringUtils.isNotBlank(item.getActionInd()) && UPDATED.equalsIgnoreCase(item.getActionInd())){
	        	updateAccpk = new AccountInfoPK();
	        	updateAccpk.setTsaInstancesIdentifier(item.getTsaInstancesIdentifier());
	        	updateAccpk.setAccountId(item.getAccountId());
	        	updateAccountList=new ArrayList<AccountInfoPK>();
	        	updateAccountList.add(updateAccpk);
	        }
	        
	        if(logger.isDebugEnabled()){
	        	logger.info("AccountInfo data values (" + item.toString() + ")");
			}
	        String actionIndicator = item.getActionInd();
	        if(StringUtils.isBlank(actionIndicator)){
				item.setDuplicateFlag(INDICATOR_Y);
				item.setComments("Action Indicator is required for Create/Update");
				logger.debug("Action Indicator can not be blank. So it is an invalid record.");
			}else if( ! (NEWLY_CREATED.equalsIgnoreCase(actionIndicator) || UPDATED.equalsIgnoreCase(actionIndicator)) ){
				item.setDuplicateFlag(INDICATOR_Y);
				item.setComments("Action Indicator is either C or U only");
				logger.debug("Account Id not found to Update current Row. So it is an invalid record.");
			}
	        else{
	        	String currtAcctId = item.getAccountId();
				if( NEWLY_CREATED.equalsIgnoreCase(actionIndicator) && StringUtils.isBlank(currtAcctId)){
					item.setDuplicateFlag(INDICATOR_Y);
					item.setComments("Account Id is required");
					logger.debug("Account Id not found for creation. So it is an invalid record.");
				}else{
					//File Level duplication check
			        boolean result=checkDuplicateRecordsInFile(item,existingAccountList);
			        
			        if(result){
			        	accpk = new AccountInfoPK();
				        accpk.setTsaInstancesIdentifier(item.getTsaInstancesIdentifier());
				        accpk.setAccountId(item.getAccountId());
				        accpk.setJobId(jobUniqueId);
			        	existingAccountList.add(accpk);
			        }
				}
			}
	        
			chunkRecord++;
		}
		
		if(existingAccountList!=null && existingAccountList.size()>0){
			//Temp table Level duplication check
			List<AccountInfoPK> acctInfoPkFileList = getTempTableDuplicateRecords(new AccountInfoPK(), existingAccountList);
			checkDuplicateRecordsInDB(acctInfoPkFileList,items,PDMConstants.TEMP_TABLE);
			
			//Master table level check
			if(!isMasterDataAvailable){
				acctInfoPkDBList = getMasterTableDuplicateRecords(new AccountInfoPK(), existingAccountList);
				isMasterDataAvailable=true;
				logger.debug("isMasterDataAvailable value set to :"+isMasterDataAvailable);
			}
			if(acctInfoPkDBList != null){
				checkDuplicateRecordsInDB(acctInfoPkDBList,items,PDMConstants.MASTER_TABLE);
			}else{
				logger.debug("acctInfoPkDBList is null");
			}
			
		}
		//check requested update records found in master table.
		if (updateAccountList!=null && updateAccountList.size()>0){//Identify update record available in input file.
			List<AccountInfoPK> acctInfoPkUpdatableRecordList = getMasterDataforUpdateRecords(new AccountInfoPK(), updateAccountList);
			updateAccountList=null;
			validateUpdateRecords(acctInfoPkUpdatableRecordList,items);
		}
      
		delegate.write(items);
		recordCount += chunkRecord;
		logger.debug("No of chunkRecord processed: "+recordCount);
		
		//Duplicate found details
		if(duplicateFoundList!= null && duplicateFoundList.size()>0){
			Iterator<String> itr = duplicateFoundList.iterator();
			logger.debug("Duplicate Record found details:");
			while(itr.hasNext()){
	           logger.debug(itr.next());
	        }
		}else{
			logger.debug("Duplicate Records not found. ");
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("write: Exit");
		}
	}
	//If data length is more than expected length, get truncate the data to expected length.
	private String checkDataLength(String data, int expectedLength){
		String resultData ="";
		if (StringUtils.isNotBlank(data)){
			
			if(expectedLength < data.length()){
				resultData = data.substring(0, expectedLength);
			}else{
				resultData =data;
			}
		}
		return resultData;
	}
	
	//Get column length based on properties value.
	private int getDefinedColumnLength(String [] acctDataLength, int colNum){
		int length=0;
		if(acctDataLength != null){
			String [] currentColumn = acctDataLength[colNum].split("=");
			length = Integer.parseInt(currentColumn[1]);
		}
		return length;
	}
	
	private boolean checkDuplicateRecordsInFile(AccountInfo item,List<AccountInfoPK> existingAccountList){
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInFile() Enter");
		}
		boolean result=true;
		for (AccountInfoPK tempAcctPK : existingAccountList) {
        	String tempTSAid = tempAcctPK.getTsaInstancesIdentifier();
        	String tempAcctId = tempAcctPK.getAccountId();
        	String currtTSAid = item.getTsaInstancesIdentifier();
        	String currtAcctId = item.getAccountId();
        	String currtActionInd = item.getActionInd();
        	
        	if((tempTSAid.equalsIgnoreCase(currtTSAid) && tempAcctId.equalsIgnoreCase(currtAcctId) 
					&& PDMConstants.NEWLY_CREATED.equalsIgnoreCase(currtActionInd) )){
        		duplicateFoundList.add("Batch Level: "+currtTSAid+"-"+currtAcctId);
        		item.setDuplicateFlag(INDICATOR_Y);
	        	item.setComments("Duplicate Found in batch");
	        	result=false;
	        	break;
        	} else {
        		result=true;
	        }
		}
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInFile() Exit");
		}
		return result;
	}
	
	private List<AccountInfoPK> getTempTableDuplicateRecords(AccountInfoPK acctInfoPK, List<AccountInfoPK> existingAccountList){
		if(logger.isDebugEnabled()){
			logger.debug("getTempTableDuplicateRecords() Enter");
		}
		AccountInfoPKPreparedStatementCreator creator = new AccountInfoPKPreparedStatementCreator
																(acctInfoPK, existingAccountList,PDMConstants.TEMP_TABLE);
		List<AccountInfoPK> acctInfoPkList = jdbcTemplate.query(creator, new AccountInfoPKMapper());
		if(logger.isDebugEnabled()){
			logger.debug("getTempTableDuplicateRecords() Enter");
		}
		return acctInfoPkList;
	}
	
	private List<AccountInfoPK> getMasterTableDuplicateRecords(AccountInfoPK acctInfoPK, List<AccountInfoPK> existingAccountList){
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Enter");
		}
		AccountInfoPKPreparedStatementCreator creator = new AccountInfoPKPreparedStatementCreator
																(acctInfoPK, existingAccountList,PDMConstants.MASTER_TABLE);
		List<AccountInfoPK> acctInfoPkList = jdbcTemplate.query(creator, new AccountInfoPKMapper());
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Exit");
		}
		return acctInfoPkList;
	}
	
	private List<AccountInfoPK> getMasterDataforUpdateRecords(AccountInfoPK acctInfoPK, List<AccountInfoPK> updateAccList){
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Enter");
		}
		AccountInfoPKPreparedStatementCreator creator = new AccountInfoPKPreparedStatementCreator
																(acctInfoPK, updateAccList,PDMConstants.UPDATE_TABLE);
		List<AccountInfoPK> acctInfoPkList = jdbcTemplate.query(creator, new AccountInfoPKMapper());
		if(logger.isDebugEnabled()){
			logger.debug("getMasterTableDuplicateRecords() Exit");
		}
		return acctInfoPkList;
	}
	
	private void checkDuplicateRecordsInDB(List<AccountInfoPK> acctInfoPkList, List<? extends AccountInfo> items, String level){
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInDB() Enter");
		}
		if(acctInfoPkList!=null&&acctInfoPkList.size()>0){
			logger.debug("No of record found in "+level+" table: "+acctInfoPkList.size());
			//Set Duplicate Flag and comments for duplicate records found in DB.
			for (AccountInfoPK acctInfoPK : acctInfoPkList){
				String tempAcctId = acctInfoPK.getAccountId();
				
				for (AccountInfo item : items) {
					String currtAcctId = item.getAccountId();
					String currtActionInd = item.getActionInd();
					if((tempAcctId.equalsIgnoreCase(currtAcctId) && PDMConstants.NEWLY_CREATED.equalsIgnoreCase(currtActionInd))){
						duplicateFoundList.add(level+" table Level: "+currtAcctId);
						item.setDuplicateFlag(INDICATOR_Y);
						if(PDMConstants.TEMP_TABLE.equalsIgnoreCase(level)){
							item.setComments("Duplicate Found in batch");
						}else{
							item.setComments("Duplicate Found in "+level+" Table");
						}
					}
				}
			}
		}else{
			logger.debug(level+" table does not contains any duplicate record.");
		}
		if(logger.isDebugEnabled()){
			logger.debug("checkDuplicateRecordsInDB() Exit");
		}
	}
	
	private void validateUpdateRecords(List<AccountInfoPK> acctInfoPkUpdatableRecordList, List<? extends AccountInfo> items){
		if(logger.isDebugEnabled()){
			logger.debug("validateUpdateRecords() Enter");
		}
		logger.debug("No of record found in AccountInfo table for update records: "+acctInfoPkUpdatableRecordList.size());
		//Set Duplicate Flag and comments for duplicate records found in DB.
		for (AccountInfo item : items) {
			String currtAcctId = item.getAccountId();
			String currtActionInd = item.getActionInd();
			boolean result = false;
			
			if(PDMConstants.UPDATED.equalsIgnoreCase(currtActionInd)){
				
				if(StringUtils.isBlank(currtAcctId)){
					item.setDuplicateFlag(INDICATOR_Y);
					item.setComments("Account Id is required for Update");
					logger.debug("Account Id not found to Update current Row. So it is an invalid record.");
				}else{
					for (AccountInfoPK acctInfoPK : acctInfoPkUpdatableRecordList){
						String tempAcctId = acctInfoPK.getAccountId();
						if((tempAcctId.equalsIgnoreCase(currtAcctId))){
							result = true;
							break;
						}
					}
					if(!result){
						item.setDuplicateFlag(INDICATOR_Y);
						item.setComments("Account Id not found in Master Table");
						logger.debug(currtAcctId+" is not found in master table to update. So it is an invalid record.");
					}
				}
			}
		}

		if(logger.isDebugEnabled()){
			logger.debug("validateUpdateRecords() Exit");
		}
	}
	
	public String getJobUniqueId() {
		return jobUniqueId;
	}
	public void setJobUniqueId(String jobUniqueId) {
		this.jobUniqueId = jobUniqueId;
	}

}
