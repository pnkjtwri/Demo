package com.ge.treasury.payment.datamanagement.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.treasury.payment.datamanagement.dao.impl.PaymentDataManagementDAOImpl;
import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.model.WebcashTSAinstances;
import com.ge.treasury.payment.datamanagement.service.AccountModelFileService;

@Service
public class AccountModelFileServiceImpl implements AccountModelFileService {
	
	private static Logger logger = Logger.getLogger(AccountModelFileServiceImpl.class);
	@Value("${modelActiveIndicatorFlag}")
	private String modelActiveIndicatorFlag;
	@Value("${accountActiveIndicatorFlag}")
	private String accountActiveIndicatorFlag;
	@Autowired PaymentDataManagementDAOImpl daoImpl;

	public void processSourceFile(File inputFile) {
		logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()]");
		String srcFileName = inputFile.getName();
		logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()] [Input File Name] : [ "+srcFileName+" ]");
		int underscoreIdx = srcFileName.indexOf("_");
		String tsaIdentifier = srcFileName.substring(0, underscoreIdx);
		logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()] [TSA Instances Identifier] : [ "+tsaIdentifier+" ]");
		String fileTypeName = srcFileName.substring(underscoreIdx+1, srcFileName.length());
		
		//going to check file is valid or not?
		if(srcFileName.toUpperCase().startsWith("TSA")){
			//going to check...file is which type
			int tsaID = getTSAInstanceIDByIdentifier(tsaIdentifier);
			if(tsaID > 0){
				if(fileTypeName.toUpperCase().startsWith("ACCOUNT")){
					logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()] [Going to process AccountInfo file]");
					List<AccountInfo> accountInfoList = processAccountInfoCSVFile(inputFile.getPath(), tsaID);
					if(accountInfoList != null && accountInfoList.size() > 0)insertAccountInfoDetails(accountInfoList);
				}
				if(fileTypeName.toUpperCase().startsWith("MODEL")){
					logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()] [Going to process ModelInfo file]");
					List<ModelInfo> modelInfoList = processModelInfoCSVFile(inputFile.getPath(), tsaID);
					if(modelInfoList != null && modelInfoList.size() > 0)insertModelInfoDetails(modelInfoList);
				}
			}
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside processSourceFile()] [return to Listener after successfull file processing.]");
	}
	
	/**
	 * Method used for processing ModelInfo file
	 * @param modelFilePath, tsaID
	 * @return
	 */
	private List<ModelInfo> processModelInfoCSVFile(String modelFilePath, int tsaID){
		logger.info("[AccountModelFileServiceImpl.class] [inside processModelInfoCSVFile()]");
		BufferedReader br = null;
		List<ModelInfo> modelInfoList = new ArrayList<ModelInfo>();
		int lineCount = 0;
		try {
			br = new BufferedReader(new FileReader(modelFilePath));
			String line = "";
			while ((line = br.readLine()) != null) {
				lineCount++;
				if(lineCount==1)continue;
			    // use comma as separator
				String[] modelDtls = line.split(",");
				modelInfoList.add(prepareModelInfoBean(modelDtls, tsaID));
			}
		} catch (FileNotFoundException e) {
			logger.error(e.toString());
		} catch (IOException e) {
			logger.error(e.toString());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					logger.error(e.toString());
				}
			}
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside processModelInfoCSVFile()] [return with ModelInfo data from file]");
		return modelInfoList;
	}
	
	/**
	 * Method used for processing the AccountInfo file
	 * @param accountFilePath, tsaID
	 * @return
	 */
	private List<AccountInfo> processAccountInfoCSVFile(String accountFilePath, int tsaID){
		logger.info("[AccountModelFileServiceImpl.class] [inside processAccountInfoCSVFile()]");
		BufferedReader br = null;
		List<AccountInfo> accountInfoList = new ArrayList<AccountInfo>();
		int lineCount = 0;
		try {

			br = new BufferedReader(new FileReader(accountFilePath));
			String line = "";
			while ((line = br.readLine()) != null) {
				lineCount++;
				if(lineCount==1)continue;
			    // use comma as separator
				String[] accountDtls = line.split(",");
				accountInfoList.add(prepareAccountInfoBean(accountDtls, tsaID));
			}

		} catch (FileNotFoundException e) {
			logger.error(e.toString());
		} catch (IOException e) {
			logger.error(e.toString());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					logger.error(e.toString());
				}
			}
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside processAccountInfoCSVFile()] [return with AccountInfo data from file]");
		return accountInfoList;
	}
	
	/**
	 * Method used for preparing AccountInfo bean
	 * @param accountDtls
	 * @return
	 */
	private AccountInfo prepareAccountInfoBean(String[] accountDtls, int tsaID){
		logger.info("[AccountModelFileServiceImpl.class] [inside prepareAccountInfoBean()]");
		AccountInfo accountInfo = new AccountInfo();
		
		accountInfo.setTsaInstancesId(tsaID);
		accountInfo.setAccountId(accountDtls[0]);
		accountInfo.setAccountNumber(accountDtls[1]);
		accountInfo.setAccountFormat(accountDtls[2]);
		/*accountInfo.setAcctOpenDate(parseStringIntoDate(accountDtls[3]));
		accountInfo.setAcctClosedDate(parseStringIntoDate(accountDtls[4]));*/
		accountInfo.setBankId(accountDtls[3]);
		accountInfo.setBankName(accountDtls[4]);
		accountInfo.setCountry(accountDtls[5]);
		accountInfo.setActionInd(accountDtls[6]);
		//accountInfo.setActiveInd("N");
		// As per business need to load all models as active by default
		accountInfo.setActiveInd(accountActiveIndicatorFlag);
		accountInfo.setDeleteFlag("N");
		accountInfo.setCreatedBy("9999999");
		accountInfo.setLastModifiedBy("9999999");
		logger.info("[AccountModelFileServiceImpl.class] [inside prepareAccountInfoBean()] [return with AccountInfo bean object]");
		return accountInfo;
	}
	
	/**
	 * Method used for preparing the ModelInfo bean
	 * @param modelDtls, 1tsaID
	 * @return
	 */
	private ModelInfo prepareModelInfoBean(String[] modelDtls, int tsaID){
		logger.info("[AccountModelFileServiceImpl.class] [inside prepareModelInfoBean()]");
		ModelInfo modelInfo = new ModelInfo();
		
		modelInfo.setTsaInstancesId(tsaID);
		modelInfo.setInstrumentType(modelDtls[0]);
		modelInfo.setModelId(modelDtls[1]);
		modelInfo.setDescription(modelDtls[2]);
		//modelInfo.setActiveInd("N");
		// As per business need to load all models as active by default
		modelInfo.setActiveInd(modelActiveIndicatorFlag);
		modelInfo.setDeleteFlag("N");
		modelInfo.setCreatedBy("9999999");
		modelInfo.setLastModifiedBy("9999999");
		logger.info("[AccountModelFileServiceImpl.class] [inside prepareModelInfoBean()] [return with ModelInfo bean object]");
		return modelInfo;
	}
	
	/**
	 * Method used for getting the TSA-Instance Id by TSA-Instance Identifier
	 * @param tsaIdentifier
	 * @return
	 */
	private int getTSAInstanceIDByIdentifier(String tsaIdentifier){
		logger.info("[AccountModelFileServiceImpl.class] [inside getTSAInstanceIDByIdentifier()]");
		int tsaID = 0;
		List<WebcashTSAinstances> tsaInstancesList = daoImpl.getTSAInstanceDetails(tsaIdentifier);
		if(tsaInstancesList != null && tsaInstancesList.size() > 0){
			WebcashTSAinstances tsaBean = tsaInstancesList.get(0);
			tsaID = tsaBean.getTsaInstancesId();
		}else{
			throw new RuntimeException("Didn't found record for TSA Instances Identifier : [ "+tsaIdentifier+" ] ");
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside getTSAInstanceIDByIdentifier()] [retun with TSA Instances ID] : [ "+tsaID+" ]");
		return tsaID;
	}
	
	/**
	 * Method used for insertion record into T_WEBCASHTSA_ACCOUNT_INFO
	 * @param accountInfoList
	 */
	private void insertAccountInfoDetails(List<AccountInfo> accountInfoList){
		logger.info("[AccountModelFileServiceImpl.class] [inside insertAccountInfoDetails()]");
		for (AccountInfo accountInfo : accountInfoList) {
			daoImpl.insertAccountInfoDetails(accountInfo);
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside insertAccountInfoDetails()] [record inserted successfully]");
	}
	
	/**
	 * Method used for insertion record into T_WEBCASHTSA_MODEL_INFO
	 * @param modelInfoList
	 */
	private void insertModelInfoDetails(List<ModelInfo> modelInfoList){
		logger.info("[AccountModelFileServiceImpl.class] [inside insertModelInfoDetails()]");
		for (ModelInfo modelInfo : modelInfoList) {
			daoImpl.insertModelInfoDetails(modelInfo);
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside insertModelInfoDetails()] [record inserted successfully]");
	}
	
	
	/**
	 * Method used for parsing the given string data into Date
	 * @param StringDate
	 * @return Date
	 */
	/*private Date parseStringIntoDate(String date){
		logger.info("[AccountModelFileServiceImpl.class] [inside parseStringIntoDate()]");
		Date parseSQLDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		try {

			java.util.Date utilDate = formatter.parse(date);
			parseSQLDate = new Date(utilDate.getTime());
			System.out.println(parseSQLDate);
			System.out.println(formatter.format(parseSQLDate));

		} catch (ParseException e) {
			logger.error(e.toString());
		}
		logger.info("[AccountModelFileServiceImpl.class] [inside parseStringIntoDate()] [return with java.sql.Date] : [ "+parseSQLDate+" ]");
		return parseSQLDate;	
	}*/

}

