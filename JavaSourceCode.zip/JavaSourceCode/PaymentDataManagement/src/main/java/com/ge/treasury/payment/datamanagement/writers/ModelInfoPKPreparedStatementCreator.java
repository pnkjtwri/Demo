package com.ge.treasury.payment.datamanagement.writers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.PreparedStatementCreator;

import com.ge.treasury.payment.datamanagement.model.ModelInfoPK;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;

public class ModelInfoPKPreparedStatementCreator implements PreparedStatementCreator,PDMConstants {
	
	private static final Logger logger= Logger.getLogger(ModelInfoPKPreparedStatementCreator.class);
	@SuppressWarnings("unused")
	private ModelInfoPK modelInfoPK;
	private List<ModelInfoPK> existingModelList;
	private String level;
	
	public ModelInfoPKPreparedStatementCreator(ModelInfoPK modelPK, List<ModelInfoPK> existingModelList, String level){
		logger.info("ModelInfoPKPreparedStatementCreator constructor Enter");
		this.modelInfoPK = modelPK;
		this.existingModelList=existingModelList;
		this.level=level;
		logger.info("ModelInfoPKPreparedStatementCreator constructor Exit");
	}
	
	public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
		logger.info("createPreparedStatement() Enter");
		String SELECT_QUERY =null;
		
		if(level!=null && (PDMConstants.MASTER_TABLE).equalsIgnoreCase(level)){
			SELECT_QUERY=createMasterTableQuery();
		}else if(level!=null &&(PDMConstants.TEMP_TABLE).equalsIgnoreCase(level)){
			SELECT_QUERY=createTempTableQuery();
		}else{
			logger.debug("Invalid level value. SELECT_QUERY value is null.");
		}
		PreparedStatement ps = connection.prepareStatement(SELECT_QUERY);
		
		//Set Where condition value dynamically
		
		if(level!=null &&(PDMConstants.TEMP_TABLE).equalsIgnoreCase(level)){
			
	        ps.setString(1, existingModelList.get(0).getTsaInstancesIdentifier());
	        ps.setString(2, existingModelList.get(0).getJobId());
			
		}
		logger.info("createPreparedStatement() Exit");
		return ps;
	}
	
	/*Expected Query with sample data
	 * SELECT TSAINSTANCE_IDENTIFIER,MODEL_ID FROM
	 Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO_TEMP
	 WHERE TSAINSTANCE_IDENTIFIER = ? 
	 AND 
	 JOB_ID = ? ;*/
	
	//Create PreparedStatement Query dynamically for Temp table validation.
	private static String createTempTableQuery() {
		logger.info("createTempTableQuery() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("SELECT ");
        sbQuery.append("TSAINSTANCE_IDENTIFIER, ");
        sbQuery.append("MODEL_ID ");
        sbQuery.append("FROM ");
        sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO_TEMP ");
        sbQuery.append("WHERE ");
        sbQuery.append("TSAINSTANCE_IDENTIFIER = ? ");
        sbQuery.append("AND ");
        sbQuery.append("JOB_ID = ? ");
        
        String tempTableQuery = sbQuery.toString();
        sbQuery=null;
        logger.debug("tempTableQuery: "+tempTableQuery);
        logger.info("createTempTableQuery() Exit");
        return tempTableQuery;
    }
	
	 /*Expected Query with sample data
	  * SELECT MODEL_ID FROM 
	 Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO INFO ;*/
	
	//Create PreparedStatement Query dynamically for Master table validation.
	private static String createMasterTableQuery() {
		logger.info("createMasterTableQuery() Enter");
        StringBuilder sbQuery = new StringBuilder(100);
        sbQuery.append("SELECT ");
        sbQuery.append("M.MODEL_ID ");
        sbQuery.append("FROM ");
        sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO M ");
        
        String masterTableQuery = sbQuery.toString();
        sbQuery=null;
        logger.debug("masterTableQuery: "+masterTableQuery);
        logger.info("createMasterTableQuery() Exit");
        return masterTableQuery;
    }
	
}
