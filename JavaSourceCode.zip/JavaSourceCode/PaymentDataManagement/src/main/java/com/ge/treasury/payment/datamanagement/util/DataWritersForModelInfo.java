/**
 * 
 */
package com.ge.treasury.payment.datamanagement.util;

import java.io.IOException;
import java.io.Writer;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;
import com.ge.treasury.payment.datamanagement.writers.ModelInfoItemPreparedStatementSetter;

/**
 * Valid records will be inserted into master table and invalid records writes to report CSV file.
 * @author senthilkumar.raman
 *
 */
@Configuration
public class DataWritersForModelInfo {
	
	private static final Logger logger= Logger.getLogger(DataWritersForModelInfo.class);
	
	@Value("${model.data.report.column.header}")
	private String colsHeader; 
	
	@Value("${NAS.dataFeed.Report.Path}")
	private String reportDirectory;
	
	/**
	 * Bean for creating FlatFileItemWriter to write invalid records to the .csv file
	 * @return  FlatFileItemWriter<ModelInfo>
	 */
	@Bean
	@StepScope
	 public FlatFileItemWriter<ModelInfo> modelErrorDelegateWriter(@Value("#{jobParameters[inputFileName]}") String inputFilePath) {
		logger.debug("modelErrorDelegateWriter() Entered");
		PDMInit utilInit = new PDMInit(inputFilePath);
		String resourcePath = utilInit.getReportFileName(reportDirectory);
		logger.debug("Report resourcePath: "+resourcePath);
		
    	Resource fileRes=new FileSystemResource(resourcePath);
		   //FlatFileItemWriter writer
			FlatFileItemWriter<ModelInfo> errorDelegateWriter = new FlatFileItemWriter<ModelInfo>();
			errorDelegateWriter.setResource(fileRes);
			errorDelegateWriter.setHeaderCallback(new FlatFileHeaderCallback(){
				@Override
				public void writeHeader(Writer writer) throws IOException {
					writer.write(colsHeader);
				}
				}	
			);
			
			BeanWrapperFieldExtractor<ModelInfo> fieldExtractor = new BeanWrapperFieldExtractor<ModelInfo>();
			fieldExtractor.setNames(new String[] {"instrumentType", "modelId","description","comments"});

			DelimitedLineAggregator<ModelInfo> delLineAgg = new DelimitedLineAggregator<ModelInfo>();
	    	delLineAgg.setDelimiter(",");
			delLineAgg.setFieldExtractor(fieldExtractor);

			errorDelegateWriter.setLineAggregator(delLineAgg);
			
			logger.debug("modelErrorDelegateWriter() Exit");
			
			return  errorDelegateWriter;
		} 
	 
	/**
	 * Bean to create JDBC Item writer to write valid records to the model master table.
	 * @param dataSource
	 * @return
	 */
	 @Bean
	 public JdbcBatchItemWriter<ModelInfo> modelDelegateForMasterTbl(DataSource dataSource) { 
			logger.debug("modelDelegateForMasterTbl() Entered");
			JdbcBatchItemWriter<ModelInfo> jdbcWriter = new JdbcBatchItemWriter<ModelInfo>();
			jdbcWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<ModelInfo>());
		        StringBuilder sb=new StringBuilder(10);
		        sb.append("INSERT INTO Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO ");
		        sb.append("( ");
		        sb.append("TSAINSTANCES_ID, MODEL_ID, INSTRUMENT_TYPE, DESCRIPTION, ");
		        sb.append("ACTIVE_IND, DELETE_FLAG, CREATED_BY, CREATED_TIMESTAMP, ");
		        sb.append("LAST_MODIFIED_BY, LAST_MODIFIED_TIMESTAMP ");
		        sb.append(") ");
		        sb.append("VALUES ");
		        sb.append("( ");
		        sb.append("?, ?, ?, ?, ");
		        sb.append("?, ?, ?, ?, ");
		        sb.append("?, ? ");
		        sb.append(") ");
	        jdbcWriter.setSql(sb.toString());
	        jdbcWriter.setItemPreparedStatementSetter(new ModelInfoItemPreparedStatementSetter());
	        jdbcWriter.setDataSource(dataSource);
	        
	        logger.debug("Model Master Insert SQL: "+sb.toString());
	    	sb=null;
	    	logger.debug("modelDelegateForMasterTbl() Exit");
	        return jdbcWriter; 
	}
	 
}
