package com.ge.treasury.payment.datamanagement.reader;
/**
 * Reader for Step 1: which reads all records from the account data input file.
 * @author senthilkumar.raman
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;
/**
 * Batch Reader for step1: Its reads the input file and validate the file.
 * @author senthilkumar.raman
 *
 */
public class AccountInfoStep1ItemReader implements ItemReader<AccountInfo>  {
	
private static final Logger logger = LoggerFactory.getLogger(AccountInfoStep1ItemReader.class);
@Autowired private ConfigurableApplicationContext ctx;


	public FlatFileItemReader<AccountInfo> getAccountInfoDataFromCSVFile(String inputFilePath)  {
		
		logger.debug("getAccountInfoDataFromCSVFile(): Enter");
    	
		Resource inpuResource = new FileSystemResource(inputFilePath);
    	FlatFileItemReader<AccountInfo> reader = new FlatFileItemReader<AccountInfo>();
    	if (inpuResource.exists()){ //check resource actually exists in physical form
    		logger.debug("Name of the Input File: "+inpuResource.getFilename());
			
	        reader.setResource(inpuResource);
	        reader.setLineMapper(new DefaultLineMapper<AccountInfo>() {{
	            setLineTokenizer(new DelimitedLineTokenizer() {{
	                setNames(new String[] {
	                		"accountId",
	                		"accountNumber",
	                		"accountFormat",
	                		"bankId",
	                		"bankName",
	                		"country",
	                		"actionInd"});
	            }});
	            setFieldSetMapper(new BeanWrapperFieldSetMapper<AccountInfo>() {{
	                setTargetType(AccountInfo.class);
	            }});
	        }});
	        logger.debug("getAccountInfoDataFromCSVFile(): Exit");
		}
    	return reader;
	}

	@Override
	public AccountInfo read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		logger.debug("read() Enter");
		
		logger.debug("read() Exit");
		return null;
	}

}
