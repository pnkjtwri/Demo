package com.ge.treasury.payment.datamanagement.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.ge.treasury.payment.datamanagement.mapper.AccountInfoTblMapper;
import com.ge.treasury.payment.datamanagement.model.AccountInfo;
/**
 * Batch reader for step 2: Get all the records related to current batch process file from TEMP table as a part of Duplicate record validation.
 * @author senthilkumar.raman
 *
 */
public class AccountInfoStep2ItemReader implements ItemReader<AccountInfo>  {
	
	private static final Logger logger = LoggerFactory.getLogger(AccountInfoStep2ItemReader.class);
	
	private String currfileName;
	private JdbcCursorItemReader<AccountInfo> reader;
	
	public JdbcCursorItemReader<AccountInfo> getJdbcCursorDelegate(DataSource dataSource, String fileName) throws UnexpectedInputException, ParseException, Exception {
		Resource inpuResource = new FileSystemResource(fileName); 
		currfileName=inpuResource.getFilename();
		logger.debug("step2reader() Enter");
    	reader = new JdbcCursorItemReader<AccountInfo>();
    	reader.setDataSource(dataSource);
    	StringBuilder sbQuery = new StringBuilder();
    	sbQuery.append("SELECT ");	
    	sbQuery.append("TSA.TSAINSTACES_ID AS TSAINSTANCES_ID, ");	
    	sbQuery.append("TEMP.ACCOUNT_ID, ");				
    	sbQuery.append("TEMP.ACCOUNT_NUMBER, ");			
    	sbQuery.append("TEMP.ACCOUNT_FORMAT, ");			
    	sbQuery.append("TEMP.BANK_ID, ");					
    	sbQuery.append("TEMP.BANK_NAME, ");				
    	sbQuery.append("TEMP.COUNTRY, ");					
    	sbQuery.append("TEMP.ACTIVE_IND, ");				
    	sbQuery.append("TEMP.DELETE_FLAG, ");				
    	sbQuery.append("TEMP.DUPLICATE_FLAG, ");			
    	sbQuery.append("TEMP.COMMENTS, ");				
    	sbQuery.append("TEMP.CREATED_BY, ");				
    	sbQuery.append("TEMP.CREATED_TIMESTAMP, ");		
    	sbQuery.append("TEMP.LAST_MODIFIED_BY, ");		
    	sbQuery.append("TEMP.LAST_MODIFIED_TIMESTAMP, ");
    	sbQuery.append("TEMP.ACTION_IND ");
    	sbQuery.append("FROM ");
    	sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO_TEMP TEMP, ");
    	sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES TSA ");
    	sbQuery.append("WHERE ");
    	sbQuery.append("TEMP.FILE_NAME = '"+currfileName+"' ");
    	sbQuery.append("AND ");
    	sbQuery.append("TEMP.TSAINSTANCE_IDENTIFIER = TSA.TSAINSTANCE_IDENTIFIER ");
    	
    	String sqlFetchTempData = sbQuery.toString();
    	logger.debug("step2reader() sqlFetchTempData: "+sqlFetchTempData);
    	sbQuery=null;
    	
    	reader.setSql(sqlFetchTempData);
    	reader.setRowMapper(new AccountInfoTblMapper());
    	
    	logger.debug("step2reader() Exit");
    	return reader;
	}

	@Override
	public AccountInfo read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		logger.debug("read() enter");
		logger.debug("read() return null.");
		logger.debug("read() Exit");
		return null;
	}

}
