package com.ge.treasury.payment.datamanagement.reader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.ge.treasury.payment.datamanagement.model.ModelInfo;

public class ModelInfoStep1ItemReader implements ItemReader<ModelInfo>  {
	
private static final Logger logger = LoggerFactory.getLogger(ModelInfoStep1ItemReader.class);
	
	public FlatFileItemReader<ModelInfo> getModelInfoDataFromCSVFile(String inputFilePath){
		logger.debug("getModelInfoDataFromCSVFile(): Enter");
    	Resource inpuReesource = new FileSystemResource(inputFilePath);
    	FlatFileItemReader<ModelInfo> reader = new FlatFileItemReader<ModelInfo>();
    	if (inpuReesource.exists()){
    		logger.debug("Name of the Input File: "+inpuReesource.getFilename());
            reader.setResource(inpuReesource);
            reader.setLineMapper(new DefaultLineMapper<ModelInfo>() {{
                setLineTokenizer(new DelimitedLineTokenizer() {{
                    setNames(new String[] {
                    		"instrumentType",
                    		"modelId",
                    		"description"
                    		});
                }});
                setFieldSetMapper(new BeanWrapperFieldSetMapper<ModelInfo>() {{
                    setTargetType(ModelInfo.class);
                }});
            }});
            
    	}
    	logger.debug("getModelInfoDataFromCSVFile(): Exit");
        return reader;
	}
	
	@Override
	public ModelInfo read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		logger.debug("read() Enter");
		
		logger.debug("read() Exit");
		return null;
	}
	
}
