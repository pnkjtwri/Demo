package com.ge.treasury.payment.datamanagement.batch.listeners;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

import javax.mail.MessagingException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ge.treasury.payment.datamanagement.mail.EmailService;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;
import com.ge.treasury.payment.datamanagement.util.PDMInit;


/**
 * @author senthilkumar.raman
 * Delete TEMP table records based on current JobId, Send EMAIL to support team, Archive input files to NAS Share folder 
 * and Copy Input files to error NAS share folder if network error/ unexpected error happened.
 */

public class ModelInfoJobListener implements JobExecutionListener {
	private static final Logger logger= Logger.getLogger(ModelInfoJobListener.class);
	@Autowired 
    private JdbcTemplate jdbcTemplate;
	
	@Autowired 
	 private EmailService emailService;
	
	private String inputFilePath;
	private String jobId;
	Resource inpuResource;
	StringBuilder sbQuery = new StringBuilder();
	String currFileName =null;
	@Value("${NAS.dataFeed.Archive.Path}")
	private String archiveDirectory;
	
	@Value("${webcash.dataFeed.Archive.Path}")
	private String webcashArchiveDirectory;
	
	@Value("${NAS.dataFeed.Error.Path}")
	private String errorDirectory;
	
	@Value("${email.batch.completed.message}")
	private String batchCompletedMessage;
	
	@Value("${email.batch.failed.message}")
	private String batchFailedMessage;
	
	@Value("${NAS.dataFeed.Report.Path}")
	private String reportFilePath;
	
	@Value("${email.recipient.name}")
	private String recipientName;
	
	@Value("${email.recipient.emailid}")
	private String recipientEmailId;
	
	public ModelInfoJobListener(){
		
	}
	@Override
	public void beforeJob(JobExecution jobExecution) {
		logger.debug("beforeJob Enter");
		//Copy input file to NAS share Archive folder
		 //archiveModelInfoDataFileToNASFolder();
		JobParameters jobPm = jobExecution.getJobParameters();
		String pminputFilePath =  jobPm.getString("inputFileName");
		this.inputFilePath= pminputFilePath;
		logger.debug("beforeJob Exit");
	}

	@Override
	public void afterJob(JobExecution jobExecution)  {
		 logger.debug("afterJob() Enter");
		 
		 JobParameters jobPm = jobExecution.getJobParameters();
		 String pminputFilePath =  jobPm.getString("inputFileName");
		 String pmPgpFilePath = jobPm.getString("pgpFilePath");
		 this.inputFilePath= pminputFilePath;
		 
		//Unlock the input file from Lock table.
		 deleteLockedRecord(pmPgpFilePath);
		 
		 //Task1: Delete all records related to current job id from TEMP table
		 jobId = jobExecution.getExecutionContext().getString(PDMConstants.JOB_ID_KEY);
		 if(StringUtils.isNotBlank(jobId)){
			 deleteTempTable(jobId);
		 }else{
			 logger.error(PDMConstants.JOB_ID_KEY+" is NULL. Temp table data is not deleted as per process for this job");
		 }
		 		 
		 if( (BatchStatus.COMPLETED).equals(jobExecution.getStatus()) ){
			 
			 //Task2: Send Email Notification
			 String batchMessage = ((batchCompletedMessage==null)?PDMConstants.BATCH_COMPLETED_MSG:batchCompletedMessage);
			 sendEmailNotification(BatchStatus.COMPLETED,batchMessage);
			 archiveModelInfoDataFileToWebcashFolder();
			 
	    }else if( ((BatchStatus.FAILED).equals(jobExecution.getStatus())) || 
	    		 ((BatchStatus.FAILED).equals(jobExecution.getExitStatus())) ){
	    	
	    	//Task3: Send Email Notification
	    	String batchMessage = ((batchFailedMessage==null)?PDMConstants.BATCH_COMPLETED_MSG:batchFailedMessage);
	    	sendEmailNotification(BatchStatus.FAILED,batchMessage);
	    	
	    	//Task4: Copy input file to NAS share Error folder
	    	errorStatusModelInfoDataFileToNASFolder();
	    	
	    }
		 
		//Delete input file from input file path
		 logger.debug("Delete input file ["+pminputFilePath+"] from input file path.");
		 File srcfile1 = new File (pminputFilePath);
			if(srcfile1.exists()){
				if(srcfile1.delete()){
					logger.debug("input CSV file ("+srcfile1.getName()+") deleted from input file path.");
				}else{
					logger.error("input CSV file ("+srcfile1.getName()+") not deleted from input file path.");
				}
			 }else{
				logger.error("input CSV file ("+srcfile1.getName()+") does not exist.");
			 }
			
		//delete PGP input file
		if(pmPgpFilePath!=null){
			File pgpFile = new File (pmPgpFilePath);
			if(pgpFile.exists()){
				pgpFile.delete();
				logger.debug("input PGP file ("+pgpFile.getName()+") deleted from input file path.");
			}else{
		 		logger.debug("input PGP file ("+pgpFile.getName()+") does not exist.");
		 	 }
		}
		 
		logger.debug("afterJob() Exit");
	}
	
	//Clear TEMP table value based on current JOB_ID
	private void deleteTempTable(String jobId){
		logger.debug("deleteTempTable() Enter");
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("DELETE FROM ");
		sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO_TEMP ");
		sbQuery.append("WHERE ");
		sbQuery.append("JOB_ID = ? ");
		String sqlDeleteTempTable = sbQuery.toString();
		logger.debug("sqlDeleteTempTable: "+sqlDeleteTempTable); 
		sbQuery=null;
		int noOfRecordsDeleted = jdbcTemplate.update(sqlDeleteTempTable, jobId);
		logger.debug("noOfRecordsDeleted: "+noOfRecordsDeleted); 
		logger.debug("deleteTempTable() Exit");
	}
	
	//Unlock input file from Lock table.
	private void deleteLockedRecord(String currFileName){
		logger.debug("deleteLockedRecord() Enter");
		logger.debug("Unlock "+currFileName);
		
		if(currFileName!=null){
			currFileName = new File (currFileName).getName();
		}else{
			currFileName="";
		}
		
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("DELETE FROM ");
		sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_LOCKED_FILES ");
		sbQuery.append("WHERE ");
		sbQuery.append("LOCKED_FILE_NAME = ? ");
		String sqlDeleteLockedFile = sbQuery.toString();
		logger.debug("sqlDeleteLockedFile: "+sqlDeleteLockedFile); 
		sbQuery=null;
		int noOfRecordsDeleted = jdbcTemplate.update(sqlDeleteLockedFile, currFileName);
		if(noOfRecordsDeleted==0){
			logger.debug("File not found in the table to unlock");
		}else if (noOfRecordsDeleted>0){
			logger.debug(currFileName+" File unlocked successfully");
		}else{
			logger.debug("noOfRecordsDeleted="+noOfRecordsDeleted);
		}
		logger.debug("deleteLockedRecord() Exit");
	}
	
	private void archiveModelInfoDataFileToWebcashFolder() {
		logger.debug("archiveModelInfoDataFileToWebcashFolder() Enter");
		inpuResource = new FileSystemResource(inputFilePath);
		
        try {
        	File file = inpuResource.getFile();
        	File targetDir = new File(webcashArchiveDirectory );
        	FileUtils.copyFileToDirectory(file, targetDir);//(srcFile, destDir);
        	
		} catch (IOException e) {
			logger.debug("IOException: "+e.getMessage());
			e.printStackTrace();
		}
		logger.debug("archiveModelInfoDataFileToWebcashFolder() Exit");
	}
	
	private void errorStatusModelInfoDataFileToNASFolder() {
		logger.debug("errorStatusModelInfoDataFileToNASFolder() Enter");
		inpuResource = new FileSystemResource(inputFilePath);
       
        try {
        	File file = inpuResource.getFile();
        	File targetDir = new File(errorDirectory );
			FileUtils.copyFileToDirectory(file, targetDir);//(srcFile, destDir);
		} catch (IOException e) {
			logger.debug("IOException: "+e.getMessage());
			e.printStackTrace();
		}
		logger.debug("errorStatusModelInfoDataFileToNASFolder() Exit");
	}

	private void sendEmailNotification(BatchStatus batchStatus,String batchMessage){
		logger.debug("sendEmailNotification() Enter");
		try {
			PDMInit util = new PDMInit(inputFilePath);
			Resource inputResource = new FileSystemResource(inputFilePath);
			File inputFile = inputResource.getFile();
			String inputFileName = inputResource.getFilename();
			FileInputStream modelfin= new FileInputStream(inputFile);
			byte[] attachmentInputBytes = IOUtils.toByteArray(modelfin);
			modelfin.close();
			String reportDirectory = reportFilePath;
			String rFilePath= util.getReportFileName(reportDirectory);
			Resource reportResource = new FileSystemResource(rFilePath);
			
			String reportFileName =null;
			byte[] attachmentReportBytes = null;
			if(reportResource!=null && reportResource.exists()){//check report file available
				logger.debug("sendEmailNotification(): Report file found.");
				File reportFile = reportResource.getFile();
				if(checkNoOfRecordsAvailable(reportFile)){
					reportFileName = reportResource.getFilename();
					FileInputStream modelReportStream= new FileInputStream(reportFile);
					attachmentReportBytes = IOUtils.toByteArray(modelReportStream);
					modelReportStream.close();
				}else{
					logger.info("is deleted reportFile? "+reportFile.delete());
				}
				
			}else{
				logger.debug("sendEmailNotification(): Report file not found.");
			}
			
			emailService.sendMailWithAttachmentAndFileInfo(
					recipientName, 
					recipientEmailId, 
					inputFileName, 
					attachmentInputBytes,
					reportFileName,
					attachmentReportBytes,
					PDMConstants.CONTENT_TYPE_HTML, 
					batchStatus,
					batchMessage);
			
		} catch (MessagingException e) {
			logger.debug("sendEmailNotification(): MessagingException: "+e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			logger.debug("sendEmailNotification(): IOException: "+e.getMessage());
			e.printStackTrace();
		}
		logger.debug("sendEmailNotification() Exit");
	}
	
	@SuppressWarnings("unused")
	private boolean checkNoOfRecordsAvailable(File reportFile){
		logger.debug("checkNoOfRecordsAvailable() Enter");
		boolean isRecordsFound = false;
		try {
			BufferedReader br = new BufferedReader(new FileReader(reportFile.getPath()));
			String strLine = null;
			String line = null; 
			int i = 0;
			
			while ((strLine = br.readLine()) != null) {
				i++;
				if(i==1)line=strLine;
				if(i==2)break;
			}
			br.close();
			//checking at least one rows in file....
			if(i==2){
				isRecordsFound=true;
			}
		} catch (IOException e) {
			logger.debug("checkNoOfRecordsAvailable() got exception :"+e.getMessage());
			e.printStackTrace();
		}
		
		logger.debug("checkNoOfRecordsAvailable() isRecordsFound="+isRecordsFound);
		logger.debug("checkNoOfRecordsAvailable() Enter");
		return isRecordsFound;
	}
}
