package com.ge.treasury.payment.datamanagement.batch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.listener.ExecutionContextPromotionListener;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.treasury.payment.datamanagement.batch.listeners.AccountInfoJobListener;
import com.ge.treasury.payment.datamanagement.model.AccountInfo;
import com.ge.treasury.payment.datamanagement.processor.AccountInfoStep2ItemProcessor;
import com.ge.treasury.payment.datamanagement.reader.AccountInfoStep1ItemReader;
import com.ge.treasury.payment.datamanagement.reader.AccountInfoStep2ItemReader;
import com.ge.treasury.payment.datamanagement.util.PDMConstants;
import com.ge.treasury.payment.datamanagement.util.PDMInit;
import com.ge.treasury.payment.datamanagement.writers.AccountInfoStep1ItemWriter;
import com.ge.treasury.payment.datamanagement.writers.AccountInfoUpdateItemPreparedStatementSetter;

/**
 * Batch configuration for Account Data feed.
 * @author senthilkumar.raman
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfigurationForAccountInfo implements PDMConstants {
	
	@Value("${spring-config.server.node1}")
	private String snode1;
	//private String inputFilePath="";
	@Value("${batch.chunk.value}")
	private int chunkValue;
	
	@Autowired 
    private DataSource dataSource;
    @Autowired
    private JobBuilderFactory 	accountJobBuildFactory;
	@Autowired
	private JobRepository accountJobRepository;
    @Autowired
    private StepBuilderFactory accountStepBuilderFactory;
    @Autowired
    private FlatFileItemWriter<AccountInfo> accountErrorDelegateWriter;
    @Autowired
    private JdbcBatchItemWriter<AccountInfo> accountDelegateForMasterTbl;
    
	private static final Logger logger= Logger.getLogger(BatchConfigurationForAccountInfo.class);
	
		
    @Bean
    @StepScope
    public FlatFileItemReader<AccountInfo> step1AccountReader(@Value("#{jobParameters[inputFileName]}") String inputFilePath)  {
    	logger.debug("step1AccountReader called");
		return new AccountInfoStep1ItemReader().getAccountInfoDataFromCSVFile(inputFilePath);
    }
    
    @Bean
    public ExecutionContextPromotionListener executionContextPromotionListener() {
        ExecutionContextPromotionListener executionContextPromotionListener=new ExecutionContextPromotionListener();
        executionContextPromotionListener.setKeys(new String[]{"JOB_ID_KEY"});
        return executionContextPromotionListener;
    }
    
    @Bean
    public ItemWriter<AccountInfo> step1AccountWriter() {
    	logger.debug("step1AccountWriter called");
    	AccountInfoStep1ItemWriter acIfStep1wr = new AccountInfoStep1ItemWriter(dataSource);
        return acIfStep1wr;
    }
   
    @Bean
    @StepScope
    public JdbcCursorItemReader<AccountInfo> step2AccountReader(@Value("#{jobParameters[inputFileName]}") String inputFilePath) throws UnexpectedInputException, ParseException, Exception {
    	logger.debug("step2AccountReader called");
        return new AccountInfoStep2ItemReader().getJdbcCursorDelegate(dataSource,inputFilePath);
    }
    
    @Bean
    public ItemProcessor<AccountInfo, AccountInfo> step2AccountProcessor() {
    	logger.debug("step2AccountProcessor called");
        return new AccountInfoStep2ItemProcessor();
    }
    
    @Bean 
	 public ClassifierCompositeItemWriter<AccountInfo> createAccountClassifier(){
    	logger.debug("createAccountClassifier called");
		 ClassifierCompositeItemWriter<AccountInfo> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<AccountInfo>();      
	 	classifierCompositeItemWriter.setClassifier(new Classifier<AccountInfo, ItemWriter<? super AccountInfo>>() {          
	 	    @Override
	 	    public ItemWriter<? super AccountInfo> classify(AccountInfo classifiable) {
	 	        ItemWriter<? super AccountInfo> itemWriter = null;
	 	        if("VALID".equalsIgnoreCase(classifiable.getOpCode())) { // condition
	 	            
	 	            if((PDMConstants.NEWLY_CREATED).equalsIgnoreCase(classifiable.getActionInd())){
	 	            	
	 	            	itemWriter = accountDelegateForMasterTbl; // I use compositeItemWriter to write on A and B
	 	            }else if((PDMConstants.UPDATED).equalsIgnoreCase(classifiable.getActionInd())){
	 	            	 
	 	            	List<String> currentColumnNameList = new ArrayList<String>(10);
	 	            	int order =0;
	 	            	if(classifiable.getAccountNumber()!=null ){
	 	            		currentColumnNameList.add(order,"ACCOUNT_NUMBER");
	 	            		order++;
	 	            	}
	 	            	if (classifiable.getAccountFormat()!=null){
	 	            		currentColumnNameList.add(order,"ACCOUNT_FORMAT");
	 	            		order++;
	 	            	}
	 	            	if (classifiable.getBankId()!=null){
	 	            		currentColumnNameList.add(order,"BANK_ID");
	 	            		order++;
	 	            	}
	 	            	if (classifiable.getBankName()!=null){
	 	            		currentColumnNameList.add(order,"BANK_NAME");
	 	            		order++;
	 	            	}
	 	            	if (classifiable.getCountry()!=null){
	 	            		currentColumnNameList.add(order,"COUNTRY");
	 	            		order++;
	 	            	}
	 	            	
	 	            	JdbcBatchItemWriter<AccountInfo> jdbcWriter = new JdbcBatchItemWriter<AccountInfo>();
	 					jdbcWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<AccountInfo>());
	 				        StringBuilder sb=new StringBuilder(10);
	 				        sb.append("UPDATE Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_ACCOUNT_INFO ");
	 				        sb.append("SET ");
	 				        
	 				        int length = currentColumnNameList.size();
	 				        for( int c = 0; c< length; c++){
	 				        	sb.append(currentColumnNameList.get(c));
	 				        	sb.append(" = ?, ");
	 				        }
	 				        
	 				        sb.append("LAST_MODIFIED_BY = ?, LAST_MODIFIED_TIMESTAMP = ? ");
	 				        sb.append("WHERE ");
	 				        sb.append("TSAINSTANCES_ID =? AND ACCOUNT_ID = ? ");
	 				        
	 			        jdbcWriter.setSql(sb.toString());
	 			        jdbcWriter.setItemPreparedStatementSetter(new AccountInfoUpdateItemPreparedStatementSetter(currentColumnNameList));
	 			        jdbcWriter.setDataSource(dataSource);
	 			        
	 			        logger.debug("Account Master Update SQL: "+sb.toString());
	 			    	sb=null;
	 			    	logger.debug("accountDelegateForMasterTbl() Exit");
	 	            	
	 	            	itemWriter = jdbcWriter; // Update master table
	 	            }
	 	            
	 	        } else {
	 	            itemWriter = accountErrorDelegateWriter; // I use single JdbcBatchItemWriter to write only on A
	 	        } 
	 	        return itemWriter;
	 	    }
	 	});
	 	
	 	return classifierCompositeItemWriter;
	 }
    
    @Bean
	public AccountInfoJobListener accountInfoJobListener() {
		return new AccountInfoJobListener();
	}
    
	@Bean
    public Job AccountFeedJob() throws UnexpectedInputException, ParseException, Exception {
    	logger.debug("AccountInfoJob() called");
    	return accountJobBuildFactory.get("AccountFeedJob"+getSuffix_yyyyMMddHHmmss())
    						  .incrementer(new RunIdIncrementer())
    						  .listener(accountInfoJobListener())
				    		  .start(step1(step1AccountReader(""),null, step1AccountWriter()))
				    		  .next (step2(step2AccountReader(""),step2AccountProcessor(),createAccountClassifier()))
				    		  .build();
    }
	
    @Bean
    protected Step step1(ItemReader<AccountInfo> step1reader, ItemProcessor<AccountInfo, AccountInfo>
    step1processor,ItemWriter<AccountInfo> step1writer) {
    	logger.debug("step1() called");
	    return accountStepBuilderFactory.get("step1")
	    						 .<AccountInfo, AccountInfo> chunk(chunkValue)
	    						 .reader(step1reader)
	    						 .processor(step1processor)
	    						 .writer(step1writer)
	    						 .allowStartIfComplete(true)
	    						 .build();
    }
    
    @Bean
    protected Step step2(ItemReader<AccountInfo> step2reader, ItemProcessor<AccountInfo, AccountInfo>
    step2processor, ItemWriter<AccountInfo> step2Writer) {
    	logger.debug("step2() called");
    	return accountStepBuilderFactory.get("step2")
    							 .transactionManager(accInfoTransactionManager())
				    			 .repository(accountJobRepository)
					    		 .<AccountInfo, AccountInfo> chunk(chunkValue) 
							     .reader(step2reader)
							     .processor(step2processor)
							     .writer(step2Writer) 
							     .listener(executionContextPromotionListener())
							     .stream(accountErrorDelegateWriter)  
							     .allowStartIfComplete(true)
							     .build();
    }

    @Bean
	public PlatformTransactionManager  accInfoTransactionManager(){
    	logger.debug("accInfoTransactionManager() called");
		return new DataSourceTransactionManager (dataSource);
	}
    
    public String getSuffix_yyyyMMddHHmmss(){
		logger.debug("getSuffix_yyyyMMddHHmmss() Enter");
		String result = new SimpleDateFormat("yyyyMMddHHmmss").format(new DateTime(DateTimeZone.UTC).toDate());
		logger.debug("getSuffix_yyyyMMddHHmmss() Exit");
	    return result;
	}
    
}
