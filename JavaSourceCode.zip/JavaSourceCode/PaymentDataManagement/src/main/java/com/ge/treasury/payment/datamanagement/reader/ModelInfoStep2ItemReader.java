package com.ge.treasury.payment.datamanagement.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.ge.treasury.payment.datamanagement.mapper.ModelInfoTblMapper;
import com.ge.treasury.payment.datamanagement.model.ModelInfo;

public class ModelInfoStep2ItemReader implements ItemReader<ModelInfo>  {
	
	private static final Logger logger = LoggerFactory.getLogger(ModelInfoStep2ItemReader.class);
	
	private String currfileName;
	private JdbcCursorItemReader<ModelInfo> reader;
	
	public JdbcCursorItemReader<ModelInfo> getJdbcCursorDelegate(DataSource dataSource, String fileName) throws UnexpectedInputException, ParseException, Exception {
	//public JdbcCursorItemReader<ModelInfo> getJdbcCursorDelegate(DataSource dataSource) throws UnexpectedInputException, ParseException, Exception {
		Resource inpuResource = new FileSystemResource(fileName); 
		currfileName=inpuResource.getFilename();

		logger.debug("step2reader() Enter");
    	reader = new JdbcCursorItemReader<ModelInfo>();
    	reader.setDataSource(dataSource);
    	StringBuilder sbQuery = new StringBuilder();
    	sbQuery.append("SELECT ");	
    	sbQuery.append("TSA.TSAINSTACES_ID AS TSAINSTANCES_ID, ");	
    	sbQuery.append("TEMP.MODEL_ID, ");				
    	sbQuery.append("TEMP.INSTRUMENT_TYPE, ");			
    	sbQuery.append("TEMP.DESCRIPTION, ");			
    	sbQuery.append("TEMP.ACTIVE_IND, ");				
    	sbQuery.append("TEMP.DELETE_FLAG, ");				
    	sbQuery.append("TEMP.DUPLICATE_FLAG, ");			
    	sbQuery.append("TEMP.COMMENTS, ");				
    	sbQuery.append("TEMP.CREATED_BY, ");				
    	sbQuery.append("TEMP.CREATED_TIMESTAMP, ");		
    	sbQuery.append("TEMP.LAST_MODIFIED_BY, ");		
    	sbQuery.append("TEMP.LAST_MODIFIED_TIMESTAMP ");
    	sbQuery.append("FROM ");
    	sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_MODEL_INFO_TEMP TEMP, ");
    	sbQuery.append("Webcash_TSA_Splitter.dbo.T_WEBCASHTSA_TSAINSTANCES TSA ");
    	sbQuery.append("WHERE ");
    	sbQuery.append("TEMP.FILE_NAME = '"+currfileName+"' ");
    	sbQuery.append("AND ");
    	sbQuery.append("TEMP.TSAINSTANCE_IDENTIFIER = TSA.TSAINSTANCE_IDENTIFIER ");
    	
    	String sqlFetchTempData = sbQuery.toString();
    	logger.debug("step2reader() sqlFetchTempData: "+sqlFetchTempData);
    	sbQuery=null;
    	
    	reader.setSql(sqlFetchTempData);
    	reader.setRowMapper(new ModelInfoTblMapper());
    	
    	logger.debug("step2reader() Exit");
    	return reader;
	}

	@Override
	public ModelInfo read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		logger.debug("step2reader: read() Enter");
		logger.debug("step2reader: read() Exit");
		return null;
	}

}
