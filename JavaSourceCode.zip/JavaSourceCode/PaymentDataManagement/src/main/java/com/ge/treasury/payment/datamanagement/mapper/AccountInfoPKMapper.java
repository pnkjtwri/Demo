package com.ge.treasury.payment.datamanagement.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.ge.treasury.payment.datamanagement.model.AccountInfoPK;
import com.ge.treasury.payment.datamanagement.writers.AccountInfoPKPreparedStatementCreator;

/**
 * Used to check Duplicate record validation at Temp table and Master table level
 * 
 * @author senthilkumar.raman
 *
 */

public class AccountInfoPKMapper implements RowMapper<AccountInfoPK>{
	
	public AccountInfoPK mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
		final Logger logger= Logger.getLogger(AccountInfoPKPreparedStatementCreator.class);
		logger.debug("mapRow() Enter");
		logger.debug("Set value for executed query with resultSet.");
		String accountId = resultSet.getString("ACCOUNT_ID");
		
		AccountInfoPK acctInfoPK = new AccountInfoPK();
		acctInfoPK.setAccountId(accountId);
		
		logger.debug("mapRow() Exit");
		return acctInfoPK;
	}


}
