package com.ge.treasury.payment.datamanagement.writers;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.ge.treasury.payment.datamanagement.model.AccountInfo;

public class AccountInfoTempItemPreparedStatementSetter implements ItemPreparedStatementSetter<AccountInfo> {
	
	private static final Logger logger= Logger.getLogger(AccountInfoTempItemPreparedStatementSetter.class);

	public void setValues(AccountInfo accInfo, PreparedStatement ps) throws SQLException {
		logger.debug("setValues() Enter"); 
		logger.debug("setValues() for TSAId-AcctId:"+accInfo.getTsaInstancesIdentifier()+"-"+accInfo.getAccountId());
		ps.setString(1, accInfo.getJobId());
        ps.setString(2, accInfo.getTsaInstancesIdentifier());
        ps.setString(3, accInfo.getAccountId());
        ps.setString(4, accInfo.getAccountNumber());
        ps.setString(5, accInfo.getAccountFormat());
        ps.setString(6, accInfo.getBankId());
        ps.setString(7, accInfo.getBankName());
        ps.setString(8, accInfo.getCountry());
        ps.setString(9, accInfo.getActiveInd());
        ps.setString(10, accInfo.getDeleteFlag());
        ps.setString(11, accInfo.getDuplicateFlag());
        ps.setString(12, accInfo.getComments());
        ps.setString(13, accInfo.getCreatedBy());
        ps.setTimestamp(14, accInfo.getCreatedTimeStamp());
        ps.setString(15, accInfo.getLastModifiedBy());
        ps.setTimestamp(16, accInfo.getLastModifedTimestamp());
        ps.setString(17, accInfo.getActionInd());
        ps.setString(18, accInfo.getFileName());
        logger.debug("setValues() Exit"); 
	}
}
