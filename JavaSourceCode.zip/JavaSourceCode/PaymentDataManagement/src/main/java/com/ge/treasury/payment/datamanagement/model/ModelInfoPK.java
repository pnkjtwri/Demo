package com.ge.treasury.payment.datamanagement.model;
/**
 * Java bean used to validate duplicate records validation in TEMP table.
 * @author senthilkumar.raman
 *
 */
public class ModelInfoPK {
	
	private int tsaInstancesId;
	private String tsaInstancesIdentifier;
	private String modelId;
	private String jobId;
	
	public ModelInfoPK(){
		
	}
	
	public ModelInfoPK(int tsaInstancesId, String modelId){
		this.tsaInstancesId=tsaInstancesId;
		this.modelId=modelId;
	}
	
	public int getTsaInstancesId() {
		return tsaInstancesId;
	}

	public void setTsaInstancesId(int tsaInstancesId) {
		this.tsaInstancesId = tsaInstancesId;
	}
	
	public String getTsaInstancesIdentifier() {
		return tsaInstancesIdentifier;
	}

	public void setTsaInstancesIdentifier(String tsaInstancesIdentifier) {
		this.tsaInstancesIdentifier = tsaInstancesIdentifier;
	}

	public String getModelId() {
		return modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	@Override
	public String toString() {
		return "ModelInfoPK [ tsaInstancesIdentifier= "+tsaInstancesIdentifier+", tsaInstancesId="+ tsaInstancesId+ ", modelId=" + modelId + ", jobId=" + jobId +"]";
				
	}
	
}
